CREATE FUNCTION get_uuid
RETURN VARCHAR
IS
guid VARCHAR (50);
BEGIN
guid := lower(RAWTOHEX(sys_guid()));
RETURN
substr(guid,1,8)||'-'||substr(guid,9,4)||'-'||substr(guid,13,4)||'-'||substr(guid,17,4)||'-'||substr(guid,21,12);
END get_uuid;
--删除临时表
drop table E7_STA_INDEX_INST_DIMEN_K;
--1.建立临时表，存放主键
create table E7_STA_INDEX_INST_DIMEN_K as (

SELECT INDEXINSTDIMEN.*
  FROM E7_STA_REPINST R
  LEFT JOIN E7_STA_REPORT RR ON RR.REPORT_CODE = R.REPORT_CODE
  LEFT JOIN E7_STA_RPT_INDEX_INST RPTINDEX ON R.REPINST_ID = RPTINDEX.REPINST_ID
  LEFT JOIN E7_STA_INDEX_INST INDEXINST ON RPTINDEX.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
  LEFT JOIN E7_STA_INDEX_INST_DIMEN INDEXINSTDIMEN ON INDEXINSTDIMEN.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
  LEFT JOIN E7_STA_INDEX_INST_DIMEN INDEXINSTDIMEN1 ON RPTINDEX.STA_INDEX_INST_ID=INDEXINSTDIMEN1.STA_INDEX_INST_ID
  AND INDEXINSTDIMEN1.DIM_DETAIL_CODE<>INDEXINSTDIMEN.DIM_DETAIL_CODE
 WHERE RR.REPORT_CODE = 'T0019'
   and  INDEXINST.INDEX_CODE in ('Engy_csmp_cost')
   and INDEXINSTDIMEN.Dim_Detail_Code  ='Natural_gas'
   and INDEXINSTDIMEN1.Dim_Detail_Code in ('Compre_consu' ,'Compre_consu_other' ,'Vent_amount' ,'Vent_amount_other' )

   );
 --插入天然气自用量维度
 declare
   cursor cur_d is select * from E7_STA_INDEX_INST_DIMEN_K;

 begin
   for var_d in cur_d loop
       insert into E7_STA_INDEX_INST_DIMEN t
       (t.Repinst_Dtl_Dimen, t.Sta_Index_Inst_Id, t.Dim_Code, t.Dim_Detail_Code, t.Unit_Code, t.Create_Time, t.Update_Time)
       values
       (UPPER(replace(get_uuid(),'-','')),var_d.STA_INDEX_INST_ID,'Cru_oil_E_cons_typ'
        ,'Since_the_amo_N'
        ,'071'
        ,sysdate
        ,sysdate);

        insert into E7_STA_INDEX_INST_DIMEN t
       (t.Repinst_Dtl_Dimen, t.Sta_Index_Inst_Id, t.Dim_Code, t.Dim_Detail_Code, t.Unit_Code, t.Create_Time, t.Update_Time)
       values
       (UPPER(replace(get_uuid(),'-','')),var_d.STA_INDEX_INST_ID,'Industry_type'
        ,'Non_industrial'
        ,'071'
        ,sysdate
        ,sysdate);
   end loop;
   commit;
 end;

--5.添加删除表实例
insert into e7_sta_del_repinst
    select s_e7_sta_del_repinst.nextval,repinst_id,sysdate,sysdate
    from e7.e7_sta_repinst t where t.report_code = 'T0019';

--6.更新四表的UP时间
update e7.E7_STA_INDEX_INST_DIMEN t set t.update_time=sysdate where t.sta_index_inst_id in (
       select sta_index_inst_id from e7.E7_STA_RPT_INDEX_INST t where t.repinst_id in (
             select repinst_id from e7.E7_STA_REPINST t where report_code = 'T0019'
       )
);
update  e7.E7_STA_RPT_INDEX_INST t set t.update_time=sysdate where t.repinst_id in (
       select repinst_id from e7.E7_STA_REPINST t where report_code = 'T0019'
);
update  e7.E7_STA_INDEX_INST t set t.update_time=sysdate where t.sta_index_inst_id in (
       select sta_index_inst_id from e7.E7_STA_RPT_INDEX_INST t where t.repinst_id in (
        select repinst_id from e7.E7_STA_REPINST t where report_code = 'T0019'
));
update e7.E7_STA_REPINST t set t.update_time=sysdate  where report_code = 'T0019';
/

