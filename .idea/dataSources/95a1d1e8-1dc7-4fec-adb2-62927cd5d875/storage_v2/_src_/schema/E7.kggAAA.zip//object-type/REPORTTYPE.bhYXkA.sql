CREATE type reportType as object(
reportCode varchar2(50),
reportName varchar2(50)
)
/

