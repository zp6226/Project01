CREATE type locationType as object(
location varchar2(50),
indexvalue NUMBER(20,5)
)
/

