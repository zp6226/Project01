CREATE PROCEDURE P_SUM
AS
V_SUM NUMBER;
CUR_ID TEST_A.ID%TYPE;
L_SQL VARCHAR2(2000);
CURSOR CUR_ID1
 IS SELECT ID FROM TEST_A;

BEGIN
    OPEN CUR_ID1;
    LOOP
      FETCH CUR_ID1 INTO CUR_ID;
      IF CUR_ID1%FOUND THEN
       select sum(c) INTO V_SUM from (select distinct(id),c,org_id from test_B  connect by  org_id = prior id start with id =CUR_ID);

       L_SQL:='INSERT INTO TEST_C(ID,SUM) VALUES (  @CUR_ID@,@V_NUM@ )';
       L_SQL:=REPLACE(L_SQL,'@CUR_ID@',CUR_ID);
        L_SQL:=REPLACE(L_SQL,'@V_NUM@',V_SUM);
       EXECUTE IMMEDIATE L_SQL;
       COMMIT;
       ELSE
         DBMS_OUTPUT.put_line('已取出所有数据');
         exit;
        END IF;
       END LOOP;
       COMMIT;
END;
/

