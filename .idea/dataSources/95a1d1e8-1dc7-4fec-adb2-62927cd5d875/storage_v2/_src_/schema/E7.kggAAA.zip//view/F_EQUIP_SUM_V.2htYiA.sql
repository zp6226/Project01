CREATE VIEW F_EQUIP_SUM_V AS
  WITH T_DIM_STAGE
        AS (  SELECT a.repinst_id,
                     a.org_id,
                     a.report_code,
                     a.report_year,
                     a.report_quarter,
                     a.report_month,
                     c.sta_index_inst_id,
                     c.index_code,
                     MAX (
                        DECODE (d.DIM_CODE,
                                'E_cons_typ', d.dim_detail_code,
                                NULL))
                        AS E_cons_typ,
                     MAX (c.index_value) AS index_value
                FROM E7.e7_sta_repinst a
                     JOIN E7.e7_sta_rpt_index_inst b
                        ON a.repinst_id = b.repinst_id
                     JOIN E7.e7_sta_index_inst c
                        ON b.sta_index_inst_id = c.sta_index_inst_id
                     LEFT JOIN E7.e7_sta_index_inst_dimen d
                        ON c.sta_index_inst_id = d.sta_index_inst_id
               WHERE a.report_code IN ('T0035')
            --and a.STATUS='04'
            GROUP BY a.repinst_id,
                     a.org_id,
                     a.report_code,
                     a.report_year,
                     a.report_quarter,
                     a.report_month,
                     c.sta_index_inst_id,
                     c.index_code),
        T_SEMI_FACT_STAGE
        AS (  SELECT t.repinst_id AS REPINST_ID,
                     t.org_id AS ORG_ID,
                     t.report_code AS REPORT_CODE,
                     t.report_year AS RPT_YEAR,
                     t.report_quarter AS RPT_QTR,
                     t.report_month AS RPT_MTH,
                     NVL (t.E_cons_typ, 'N/A') AS E_cons_typ,
                     ---------------------ó?μ?μ???±ê×a?aáD----------------
                     MAX (
                        DECODE (t.index_code,
                                'dev_amt_in_use', t.index_value,
                                NULL))
                        AS EQUIP_IN_USE_CNT,
                     MAX (
                        DECODE (t.index_code,
                                'dev_capacity', t.index_value,
                                NULL))
                        AS EQUIP_CPCTY_QTY,
                     MAX (
                        DECODE (t.index_code,
                                'dev_amt_updated', t.index_value,
                                NULL))
                        AS EQUIP_UPD_CNT,
                     MAX (
                        DECODE (t.index_code,
                                'dev_amt_abandoned', t.index_value,
                                NULL))
                        AS EQUIP_DISUSE_CNT,
                     MAX (
                        DECODE (t.index_code,
                                'dev_amt_tested', t.index_value,
                                NULL))
                        AS EQUIP_TEST_CNT,
                     MAX (
                        DECODE (t.index_code,
                                'dev_amt_tested_pass', t.index_value,
                                NULL))
                        AS EQUIP_TEST_PASS_CNT,
                     MAX (
                        DECODE (t.index_code,
                                'dev_efficiency_tested', t.index_value,
                                NULL))
                        AS EQUIP_TEST_EFCNCY_PCT,
                     MAX (
                        DECODE (t.index_code,
                                'dev_sys_efficiency_tested', t.index_value,
                                NULL))
                        AS EQUIP_SYSTM_TEST_EFCNCY_PCT,
                     MAX (
                        DECODE (t.index_code,
                                'Engy_csmp_amt_pratl', t.index_value,
                                NULL))
                        AS ENRGY_CNSMPTN_PHYSCL_QTY,
                     MAX (
                        DECODE (t.index_code,
                                'stadc_coef', t.index_value,
                                NULL))
                        AS STNDRD_COAL_COEFCNT_RATE
                --------------------??±ê?áê?---------------------
                FROM T_DIM_STAGE t
            GROUP BY t.repinst_id,
                     t.org_id,
                     t.report_code,
                     t.report_year,
                     t.report_quarter,
                     t.report_month,
                     t.E_cons_typ)
   SELECT ROWNUM AS F_EQUIP_SUM_KEY,
          NVL (do.ORG_ID, -2) AS ORG_ID,
          TO_NUMBER (m.RPT_YEAR) * 100 + TO_NUMBER (m.RPT_MTH) AS RPT_MNTH_ID,
          m.REPINST_ID AS SRC_RPT_INSTNC_ID,
          m.REPORT_CODE AS SRC_RPT_CD,
          -----------
          NVL (dim1.EQUIP_TYPE_CD, -2) AS EQUIP_TYPE_CD,
          -----------??±ê-----------------

          m.EQUIP_IN_USE_CNT AS EQUIP_IN_USE_CNT,
          m.EQUIP_CPCTY_QTY AS EQUIP_CPCTY_QTY,
          m.EQUIP_UPD_CNT AS EQUIP_UPD_CNT,
          m.EQUIP_DISUSE_CNT AS EQUIP_DISUSE_CNT,
          m.EQUIP_TEST_CNT AS EQUIP_TEST_CNT,
          m.EQUIP_TEST_PASS_CNT AS EQUIP_TEST_PASS_CNT,
          m.EQUIP_TEST_EFCNCY_PCT AS EQUIP_TEST_EFCNCY_PCT,
          m.EQUIP_SYSTM_TEST_EFCNCY_PCT AS EQUIP_SYSTM_TEST_EFCNCY_PCT,
          m.ENRGY_CNSMPTN_PHYSCL_QTY AS ENRGY_CNSMPTN_PHYSCL_QTY,
          m.STNDRD_COAL_COEFCNT_RATE AS STNDRD_COAL_COEFCNT_RATE,
          -------------??±êíê-----------------------
          '' AS ROW_STS_CD,
          SYSDATE AS INSRT_TM,
          SYSDATE AS UPD_TM
     FROM T_SEMI_FACT_STAGE m
          LEFT JOIN E7.D_EQUIP_TYPE dim1
             ON m.E_cons_typ = dim1.EQUIP_TYPE_DESC
          LEFT JOIN E7.D_ORGNZTN do
             ON do.src_org_id = m.org_id
/

