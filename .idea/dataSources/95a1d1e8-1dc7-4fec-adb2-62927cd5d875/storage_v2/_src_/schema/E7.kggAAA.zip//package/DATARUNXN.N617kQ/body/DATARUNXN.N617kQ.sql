CREATE PACKAGE BODY DataRUNXN IS

FUNCTION ISAUTH(P_RPTORGID IN VARCHAR2,P_RPTCODE IN VARCHAR2)
  return   number is
  authresult number(10);
  begin
   authresult:=0;
   SELECT count(1) into authresult  FROM E7_STA_RPT_AUTH AUTH WHERE P_RPTCODE = auth.report_code and P_RPTORGID= auth.org_id ;
   return authresult;
  end;
  
 FUNCTION SJUDGESTATUS( P_RPTCODE IN VARCHAR2, P_RPTYEAR  IN VARCHAR2,P_RPTMONTH IN VARCHAR2,P_RPTORGID IN VARCHAR2)
return   number is
statusResult number(2);
begin
  statusResult:=0;
  SELECT COUNT(1)  into statusResult FROM e7_sta_repinst repinst
  WHERE repinst.report_year= P_RPTYEAR and repinst.report_month=P_RPTMONTH
        and repinst.report_code=P_RPTCODE and repinst.org_id=P_RPTORGID
        and (repinst.status='03'or repinst.status='05');
 return statusResult;
end;

PROCEDURE DELDATASXNNW(P_RPTCODE  IN VARCHAR2,
                       P_RPTYEAR  IN VARCHAR2,
                       P_RPTMONTH IN VARCHAR2,
                       P_RPTORGID IN VARCHAR2) AS
BEGIN
  delete from e7_sta_index_inst_dimen
   where sta_index_inst_id in
         (select sta_index_inst_id
            from e7_sta_index_inst
           where sta_index_inst_id in
                 (select sta_index_inst_id
                    from e7_sta_rpt_index_inst
                   where repinst_id in
                         (select repinst_id
                            from e7_sta_repinst
                           where report_code = P_RPTCODE
                             and org_id = P_RPTORGID
                             and report_year = P_RPTYEAR
                             and report_month = P_RPTMONTH)
                     ) and composited_index_code = P_RPTORGID)
     and composite_dim_code =P_RPTORGID;
  COMMIT;


  INSERT INTO TEMP_STA_INDEX_INST_ID
  SELECT STA_INDEX_INST_ID from e7_sta_index_inst
   where sta_index_inst_id in
         (select sta_index_inst_id
            from e7_sta_rpt_index_inst
           where repinst_id in
                 (select repinst_id
                    from e7_sta_repinst
                   where report_code = P_RPTCODE
                     and org_id = P_RPTORGID
                     and report_year = P_RPTYEAR
                     and report_month = P_RPTMONTH)
             ) AND composited_index_code = P_RPTORGID;
   COMMIT;
  delete from e7_sta_index_inst
   where sta_index_inst_id in
         (select sta_index_inst_id
            from e7_sta_rpt_index_inst
           where repinst_id in
                 (select repinst_id
                    from e7_sta_repinst
                   where report_code = P_RPTCODE
                     and org_id = P_RPTORGID
                     and report_year = P_RPTYEAR
                     and report_month = P_RPTMONTH)
             ) AND composited_index_code = P_RPTORGID;
  COMMIT;
  delete from e7_sta_rpt_index_inst
   where repinst_id in (select repinst_id
                          from e7_sta_repinst
                         where report_code = P_RPTCODE
                           and org_id = P_RPTORGID
                           and report_year = P_RPTYEAR
                           and report_month = P_RPTMONTH)
     and sta_index_inst_id IN(SELECT STA_INDEX_INST_ID FROM TEMP_STA_INDEX_INST_ID);
  COMMIT;
  delete from TEMP_STA_INDEX_INST_ID;
  COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
END;






 PROCEDURE DataM_RUNXNNW01(
     P_RPTYEAR IN VARCHAR2,
     P_RPTMONTH IN VARCHAR2,
     P_RPTORGID IN VARCHAR2)
     AS
      CURSOR RPTINDEXINST IS SELECT
      repinst_id,
sta_index_inst_id,
create_time,
update_time

       FROM (
select distinct repinst_id,sta_index_inst_id,sysdate CREATE_TIME,sysdate UPDATE_TIME from (
select repinst_id,
 max(sta_index_inst_id)||'XN' as sta_index_inst_id,
       index_code,
       sum(index_value) index_value,
       max(repinst_dtl_dimen)||'XN' as repinst_dtl_dimen,
       dim_code,
       dim_detail_code,
       max(repinst_dtl_dimen1)||'XN1' as repinst_dtl_dimen1,
       dim_code1,
       dim_detail_code1,
        max(repinst_dtl_dimen2)||'XN2' as repinst_dtl_dimen2,
       dim_code2,
       dim_detail_code2,
        max(repinst_dtl_dimen3)||'XN3' as repinst_dtl_dimen3,
       dim_code3,
       dim_detail_code3,
        max(repinst_dtl_dimen4)||'XN4' as repinst_dtl_dimen4,
       dim_code4,
       dim_detail_code4,
       max(repinst_dtl_dimen5)||'XN5' as repinst_dtl_dimen5,
       dim_code5,
       dim_detail_code5,
       max(repinst_dtl_dimen6)||'XN6' as repinst_dtl_dimen6,
       dim_code6,
       dim_detail_code6
  from (select repinst_id,
          sta_index_inst_id,
               index_code,
               index_value,
               composited_index_code,
                repinst_dtl_dimen,
                dim_code,
               dim_detail_code,
                repinst_dtl_dimen1,
               dim_code1,
               dim_detail_code1,
                 repinst_dtl_dimen2,
               dim_code2,
               dim_detail_code2,
                repinst_dtl_dimen3,
               dim_code3,
               dim_detail_code3,
              repinst_dtl_dimen4,
               dim_code4,
               dim_detail_code4,
                repinst_dtl_dimen5,
               dim_code5,
               dim_detail_code5,
                repinst_dtl_dimen6,
               dim_code6,
               dim_detail_code6
          from (select repinst.repinst_id,
                       repinst.writer,
                       repinst.write_date,
                       repinst.checker,
                       indexinst.sta_index_inst_id,
                       indexinst.remark,
                       indexinst.index_code,
                       indexinst.index_value,
                       indexinst.COMPOSITED_INDEX_CODE,
                       indexinst.unit_code,
                       codelist.Code_Name              AS UNIT_NAME,
                       dimeninst.repinst_dtl_dimen     as repinst_dtl_dimen,
                       dimeninst.dim_code              as dim_code,
                       dimeninst.dim_detail_code       as dim_detail_code,
                       dimeninst1.repinst_dtl_dimen    as repinst_dtl_dimen1,
                       dimeninst1.dim_code             as dim_code1,
                       dimeninst1.dim_detail_code      as dim_detail_code1,
                       dimeninst2.repinst_dtl_dimen    as repinst_dtl_dimen2,
                       dimeninst2.dim_code             as dim_code2,
                       dimeninst2.dim_detail_code      as dim_detail_code2,
                       dimeninst3.repinst_dtl_dimen    as repinst_dtl_dimen3,
                       dimeninst3.dim_code             as dim_code3,
                       dimeninst3.dim_detail_code      as dim_detail_code3,
                       dimeninst4.repinst_dtl_dimen    as repinst_dtl_dimen4,
                       dimeninst4.dim_code             as dim_code4,
                       dimeninst4.dim_detail_code      as dim_detail_code4,
                       dimeninst5.repinst_dtl_dimen    as repinst_dtl_dimen5,
                       dimeninst5.dim_code             as dim_code5,
                       dimeninst5.dim_detail_code      as dim_detail_code5,
                       dimeninst6.repinst_dtl_dimen    as repinst_dtl_dimen6,
                       dimeninst6.dim_code             as dim_code6,
                       dimeninst6.dim_detail_code      as dim_detail_code6
                  from e7_sta_repinst repinst
                  left join e7_sta_rpt_index_inst rptindexinst
                    on repinst.repinst_id = rptindexinst.repinst_id
                  left join e7_sta_index_inst indexinst
                    on rptindexinst.sta_index_inst_id =
                       indexinst.sta_index_inst_id
                  left join e7_sta_index_inst_dimen dimeninst
                    on dimeninst.dim_code = 'Business_type'
                   and indexinst.sta_index_inst_id =
                       dimeninst.sta_index_inst_id
                  left join e7_sta_index_inst_dimen dimeninst1
                    on dimeninst1.dim_code = 'Province_type'
                   and indexinst.sta_index_inst_id =
                       dimeninst1.sta_index_inst_id
                  left join e7_sta_index_inst_dimen dimeninst2
                    on dimeninst2.dim_code = 'Assets_type'
                   and indexinst.sta_index_inst_id =
                       dimeninst2.sta_index_inst_id
                  left join e7_sta_index_inst_dimen dimeninst3
                    on dimeninst3.dim_code = 'Industry_type'
                   and indexinst.sta_index_inst_id =
                       dimeninst3.sta_index_inst_id
                  left join e7_sta_index_inst_dimen dimeninst4
                    on dimeninst4.dim_code = 'Cru_oil_E_cons_typ'
                   and indexinst.sta_index_inst_id =
                       dimeninst4.sta_index_inst_id
                  left join e7_sta_index_inst_dimen dimeninst5
                    on dimeninst5.dim_code = 'Custom_dimen_first'
                   and indexinst.sta_index_inst_id =
                       dimeninst5.sta_index_inst_id
                  left join e7_sta_index_inst_dimen dimeninst6
                    on dimeninst6.dim_code = 'Custom_dimen_second'
                   and indexinst.sta_index_inst_id =
                       dimeninst6.sta_index_inst_id
                  left join e7_sys_codelist codelist
                    on codelist.codelist_code = 'UNIT_CODE'
                   and indexinst.unit_code = codelist.code_value
                 where repinst.report_code = 'XNNW01'
                   and repinst.org_id =   P_RPTORGID
                   and repinst.report_year =   P_RPTYEAR
                   and repinst.report_month =   P_RPTMONTH
                   group by
                   repinst.repinst_id,
                       repinst.writer,
                       repinst.write_date,
                       repinst.checker,
                       indexinst.sta_index_inst_id,
                       indexinst.remark,
                       indexinst.index_code,
                       indexinst.index_value,
                       indexinst.COMPOSITED_INDEX_CODE,
                       indexinst.unit_code,
                       codelist.Code_Name,
                       dimeninst.repinst_dtl_dimen,
                       dimeninst.dim_code,
                       dimeninst.dim_detail_code,
                       dimeninst1.repinst_dtl_dimen ,
                       dimeninst1.dim_code          ,
                       dimeninst1.dim_detail_code    ,
                       dimeninst2.repinst_dtl_dimen  ,
                       dimeninst2.dim_code           ,
                       dimeninst2.dim_detail_code    ,
                       dimeninst3.repinst_dtl_dimen  ,
                       dimeninst3.dim_code           ,
                       dimeninst3.dim_detail_code    ,
                       dimeninst4.repinst_dtl_dimen  ,
                       dimeninst4.dim_code           ,
                       dimeninst4.dim_detail_code    ,
                       dimeninst5.repinst_dtl_dimen   ,
                       dimeninst5.dim_code           ,
                       dimeninst5.dim_detail_code    ,
                       dimeninst6.repinst_dtl_dimen  ,
                       dimeninst6.dim_code          ,
                       dimeninst6.dim_detail_code

                   )
         where index_code in ('Engy_csmp_amt_pratl',
                              'Engy_csmp_amt_stadc',
                              'Engy_csmp_cost')
           and (dim_code4 in ('Cru_oil_E_cons_typ') or dim_code4 is null))
           where composited_index_code is not null and dim_detail_code is not null
 group by repinst_id,
          index_code,
         dim_code,
          dim_detail_code,
          dim_code1,
          dim_detail_code1,
          dim_code2,
          dim_detail_code2,
          dim_code3,
          dim_detail_code3,
          dim_code4,
          dim_detail_code4,
          dim_code5,
          dim_detail_code5,
          dim_code6,
          dim_detail_code6)
          );

          CURSOR INDEXINST IS SELECT
          sta_index_inst_id,
index_code,
org_id,
report_year,
report_quarter,
report_month,
report_frequent_code,
index_value,
unit_code,
remark,
index_inst_orderno,
composited_index_code,
create_time,
update_time


           FROM(

select distinct sta_index_inst_id,index_code,P_RPTORGID org_id,P_RPTYEAR report_year,null report_quarter,P_RPTMONTH report_month,3 report_frequent_code,index_value index_value,null unit_code,null remark,null index_inst_orderno,P_RPTORGID composited_index_code,sysdate create_time,sysdate UPDATE_time from (
select repinst_id,
 max(sta_index_inst_id)||'XN' as sta_index_inst_id,
       index_code,
       sum(index_value) index_value,
       max(repinst_dtl_dimen)||'XN' as repinst_dtl_dimen,
       dim_code,
       dim_detail_code,
       max(repinst_dtl_dimen1)||'XN1' as repinst_dtl_dimen1,
       dim_code1,
       dim_detail_code1,
        max(repinst_dtl_dimen2)||'XN2' as repinst_dtl_dimen2,
       dim_code2,
       dim_detail_code2,
        max(repinst_dtl_dimen3)||'XN3' as repinst_dtl_dimen3,
       dim_code3,
       dim_detail_code3,
        max(repinst_dtl_dimen4)||'XN4' as repinst_dtl_dimen4,
       dim_code4,
       dim_detail_code4,
       max(repinst_dtl_dimen5)||'XN5' as repinst_dtl_dimen5,
       dim_code5,
       dim_detail_code5,
       max(repinst_dtl_dimen6)||'XN6' as repinst_dtl_dimen6,
       dim_code6,
       dim_detail_code6
  from (select repinst_id,
          sta_index_inst_id,
               index_code,
               index_value,
               composited_index_code,
                repinst_dtl_dimen,
                dim_code,
               dim_detail_code,
                repinst_dtl_dimen1,
               dim_code1,
               dim_detail_code1,
                 repinst_dtl_dimen2,
               dim_code2,
                dim_detail_code2,
                repinst_dtl_dimen3,
               dim_code3,
               dim_detail_code3,
              repinst_dtl_dimen4,
               dim_code4,
               dim_detail_code4,
                repinst_dtl_dimen5,
               dim_code5,
               dim_detail_code5,
                repinst_dtl_dimen6,
               dim_code6,
               dim_detail_code6
          from (select repinst.repinst_id,
                       repinst.writer,
                       repinst.write_date,
                       repinst.checker,
                       indexinst.sta_index_inst_id,
                       indexinst.remark,
                       indexinst.index_code,
                       indexinst.index_value,
                       indexinst.COMPOSITED_INDEX_CODE,
                       indexinst.unit_code,
                       codelist.Code_Name              AS UNIT_NAME,
                       dimeninst.repinst_dtl_dimen     as repinst_dtl_dimen,
                       dimeninst.dim_code              as dim_code,
                       dimeninst.dim_detail_code       as dim_detail_code,
                       dimeninst1.repinst_dtl_dimen    as repinst_dtl_dimen1,
                       dimeninst1.dim_code             as dim_code1,
                       dimeninst1.dim_detail_code      as dim_detail_code1,
                       dimeninst2.repinst_dtl_dimen    as repinst_dtl_dimen2,
                       dimeninst2.dim_code             as dim_code2,
                       dimeninst2.dim_detail_code      as dim_detail_code2,
                       dimeninst3.repinst_dtl_dimen    as repinst_dtl_dimen3,
                       dimeninst3.dim_code             as dim_code3,
                       dimeninst3.dim_detail_code      as dim_detail_code3,
                       dimeninst4.repinst_dtl_dimen    as repinst_dtl_dimen4,
                       dimeninst4.dim_code             as dim_code4,
                       dimeninst4.dim_detail_code      as dim_detail_code4,
                       dimeninst5.repinst_dtl_dimen    as repinst_dtl_dimen5,
                       dimeninst5.dim_code             as dim_code5,
                       dimeninst5.dim_detail_code      as dim_detail_code5,
                       dimeninst6.repinst_dtl_dimen    as repinst_dtl_dimen6,
                       dimeninst6.dim_code             as dim_code6,
                       dimeninst6.dim_detail_code      as dim_detail_code6
                  from e7_sta_repinst repinst
                  left join e7_sta_rpt_index_inst rptindexinst
                    on repinst.repinst_id = rptindexinst.repinst_id
                  left join e7_sta_index_inst indexinst
                    on rptindexinst.sta_index_inst_id =
                       indexinst.sta_index_inst_id
                  left join e7_sta_index_inst_dimen dimeninst
                    on dimeninst.dim_code = 'Business_type'
                   and indexinst.sta_index_inst_id =
                       dimeninst.sta_index_inst_id
                  left join e7_sta_index_inst_dimen dimeninst1
                    on dimeninst1.dim_code = 'Province_type'
                   and indexinst.sta_index_inst_id =
                       dimeninst1.sta_index_inst_id
                  left join e7_sta_index_inst_dimen dimeninst2
                    on dimeninst2.dim_code = 'Assets_type'
                   and indexinst.sta_index_inst_id =
                       dimeninst2.sta_index_inst_id
                  left join e7_sta_index_inst_dimen dimeninst3
                    on dimeninst3.dim_code = 'Industry_type'
                   and indexinst.sta_index_inst_id =
                       dimeninst3.sta_index_inst_id
                  left join e7_sta_index_inst_dimen dimeninst4
                    on dimeninst4.dim_code = 'Cru_oil_E_cons_typ'
                   and indexinst.sta_index_inst_id =
                       dimeninst4.sta_index_inst_id
                  left join e7_sta_index_inst_dimen dimeninst5
                    on dimeninst5.dim_code = 'Custom_dimen_first'
                   and indexinst.sta_index_inst_id =
                       dimeninst5.sta_index_inst_id
                  left join e7_sta_index_inst_dimen dimeninst6
                    on dimeninst6.dim_code = 'Custom_dimen_second'
                   and indexinst.sta_index_inst_id =
                       dimeninst6.sta_index_inst_id
                  left join e7_sys_codelist codelist
                    on codelist.codelist_code = 'UNIT_CODE'
                   and indexinst.unit_code = codelist.code_value
                 where repinst.report_code = 'XNNW01'
                   and repinst.org_id =   P_RPTORGID
                   and repinst.report_year =   P_RPTYEAR
                   and repinst.report_month =   P_RPTMONTH
                   group by
                   repinst.repinst_id,
                       repinst.writer,
                       repinst.write_date,
                       repinst.checker,
                       indexinst.sta_index_inst_id,
                       indexinst.remark,
                       indexinst.index_code,
                       indexinst.index_value,
                       indexinst.COMPOSITED_INDEX_CODE,
                       indexinst.unit_code,
                       codelist.Code_Name,
                       dimeninst.repinst_dtl_dimen,
                       dimeninst.dim_code,
                       dimeninst.dim_detail_code,
                       dimeninst1.repinst_dtl_dimen ,
                       dimeninst1.dim_code          ,
                       dimeninst1.dim_detail_code    ,
                       dimeninst2.repinst_dtl_dimen  ,
                       dimeninst2.dim_code           ,
                       dimeninst2.dim_detail_code    ,
                       dimeninst3.repinst_dtl_dimen  ,
                       dimeninst3.dim_code           ,
                       dimeninst3.dim_detail_code    ,
                       dimeninst4.repinst_dtl_dimen  ,
                       dimeninst4.dim_code           ,
                       dimeninst4.dim_detail_code    ,
                       dimeninst5.repinst_dtl_dimen   ,
                       dimeninst5.dim_code           ,
                       dimeninst5.dim_detail_code    ,
                       dimeninst6.repinst_dtl_dimen  ,
                       dimeninst6.dim_code          ,
                       dimeninst6.dim_detail_code

                   )
         where index_code in ('Engy_csmp_amt_pratl',
                              'Engy_csmp_amt_stadc',
                              'Engy_csmp_cost')
           and (dim_code4 in ('Cru_oil_E_cons_typ') or dim_code4 is null))
           where composited_index_code is not null and dim_detail_code is not null
 group by repinst_id,
          index_code,
         dim_code,
          dim_detail_code,
          dim_code1,
          dim_detail_code1,
          dim_code2,
          dim_detail_code2,
          dim_code3,
          dim_detail_code3,
          dim_code4,
          dim_detail_code4,
          dim_code5,
          dim_detail_code5,
          dim_code6,
          dim_detail_code6)
          );

          CURSOR INDEXINSTDIMEN IS SELECT
          repinst_dtl_dimen,
sta_index_inst_id,
dim_code,
dim_detail_code,
dim_source,
dim_deteail_id,
dim_deteail_id2,
unit_code,
composite_dim_code,
create_time,
update_time

           FROM(

select distinct repinst_dtl_dimen,sta_index_inst_id,dim_code,dim_detail_code,null dim_source,null dim_deteail_id,null dim_deteail_id2,null unit_code,  P_RPTORGID composite_dim_code ,sysdate create_time,sysdate update_time from (select repinst_id,
       sta_index_inst_id,
       index_code,
       index_value,
       repinst_dtl_dimen,
       dim_code,
       dim_detail_code,
       repinst_dtl_dimen1,
       dim_code1,
       dim_detail_code1,
       repinst_dtl_dimen2,
       dim_code2,
       dim_detail_code2,
       repinst_dtl_dimen3,
       dim_code3,
       dim_detail_code3,
       repinst_dtl_dimen4,
       dim_code4,
       dim_detail_code4,
       repinst_dtl_dimen5,
       dim_code5,
       dim_detail_code5,
       repinst_dtl_dimen6,
       dim_code6,
       dim_detail_code6
  from (select repinst_id,
               max(sta_index_inst_id) || 'XN' as sta_index_inst_id,
               index_code,
               sum(index_value) index_value,
               max(repinst_dtl_dimen) || 'XN' as repinst_dtl_dimen,
               dim_code,
               dim_detail_code,
               max(repinst_dtl_dimen1) || 'XN1' as repinst_dtl_dimen1,
               dim_code1,
               dim_detail_code1,
               max(repinst_dtl_dimen2) || 'XN2' as repinst_dtl_dimen2,
               dim_code2,
               dim_detail_code2,
               max(repinst_dtl_dimen3) || 'XN3' as repinst_dtl_dimen3,
               dim_code3,
               dim_detail_code3,
               max(repinst_dtl_dimen4) || 'XN4' as repinst_dtl_dimen4,
               dim_code4,
               dim_detail_code4,
               max(repinst_dtl_dimen5) || 'XN5' as repinst_dtl_dimen5,
               dim_code5,
               dim_detail_code5,
               max(repinst_dtl_dimen6) || 'XN6' as repinst_dtl_dimen6,
               dim_code6,
               dim_detail_code6
          from (select repinst_id,
                       sta_index_inst_id,
                       index_code,
                       index_value,
                       composited_index_code,
                       repinst_dtl_dimen,
                       dim_code,
                       dim_detail_code,
                       repinst_dtl_dimen1,
                       dim_code1,
                       dim_detail_code1,
                       repinst_dtl_dimen2,
                       dim_code2,
                       dim_detail_code2,
                       repinst_dtl_dimen3,
                       dim_code3,
                       dim_detail_code3,
                       repinst_dtl_dimen4,
                       dim_code4,
                       dim_detail_code4,
                       repinst_dtl_dimen5,
                       dim_code5,
                       dim_detail_code5,
                       repinst_dtl_dimen6,
                       dim_code6,
                       dim_detail_code6
                  from (select repinst.repinst_id,
                               repinst.writer,
                               repinst.write_date,
                               repinst.checker,
                               indexinst.sta_index_inst_id,
                               indexinst.remark,
                               indexinst.index_code,
                               indexinst.index_value,
                               indexinst.COMPOSITED_INDEX_CODE,
                               indexinst.unit_code,
                               codelist.Code_Name              AS UNIT_NAME,
                               dimeninst.repinst_dtl_dimen     as repinst_dtl_dimen,
                               dimeninst.dim_code              as dim_code,
                               dimeninst.dim_detail_code       as dim_detail_code,
                               dimeninst1.repinst_dtl_dimen    as repinst_dtl_dimen1,
                               dimeninst1.dim_code             as dim_code1,
                               dimeninst1.dim_detail_code      as dim_detail_code1,
                               dimeninst2.repinst_dtl_dimen    as repinst_dtl_dimen2,
                               dimeninst2.dim_code             as dim_code2,
                               dimeninst2.dim_detail_code      as dim_detail_code2,
                               dimeninst3.repinst_dtl_dimen    as repinst_dtl_dimen3,
                               dimeninst3.dim_code             as dim_code3,
                               dimeninst3.dim_detail_code      as dim_detail_code3,
                               dimeninst4.repinst_dtl_dimen    as repinst_dtl_dimen4,
                               dimeninst4.dim_code             as dim_code4,
                               dimeninst4.dim_detail_code      as dim_detail_code4,
                               dimeninst5.repinst_dtl_dimen    as repinst_dtl_dimen5,
                               dimeninst5.dim_code             as dim_code5,
                               dimeninst5.dim_detail_code      as dim_detail_code5,
                               dimeninst6.repinst_dtl_dimen    as repinst_dtl_dimen6,
                               dimeninst6.dim_code             as dim_code6,
                               dimeninst6.dim_detail_code      as dim_detail_code6
                          from e7_sta_repinst repinst
                          left join e7_sta_rpt_index_inst rptindexinst
                            on repinst.repinst_id = rptindexinst.repinst_id
                          left join e7_sta_index_inst indexinst
                            on rptindexinst.sta_index_inst_id =
                               indexinst.sta_index_inst_id
                          left join e7_sta_index_inst_dimen dimeninst
                            on dimeninst.dim_code = 'Business_type'
                           and indexinst.sta_index_inst_id =
                               dimeninst.sta_index_inst_id
                          left join e7_sta_index_inst_dimen dimeninst1
                            on dimeninst1.dim_code = 'Province_type'
                           and indexinst.sta_index_inst_id =
                               dimeninst1.sta_index_inst_id
                          left join e7_sta_index_inst_dimen dimeninst2
                            on dimeninst2.dim_code = 'Assets_type'
                           and indexinst.sta_index_inst_id =
                               dimeninst2.sta_index_inst_id
                          left join e7_sta_index_inst_dimen dimeninst3
                            on dimeninst3.dim_code = 'Industry_type'
                           and indexinst.sta_index_inst_id =
                               dimeninst3.sta_index_inst_id
                          left join e7_sta_index_inst_dimen dimeninst4
                            on dimeninst4.dim_code = 'Cru_oil_E_cons_typ'
                           and indexinst.sta_index_inst_id =
                               dimeninst4.sta_index_inst_id
                          left join e7_sta_index_inst_dimen dimeninst5
                            on dimeninst5.dim_code = 'Custom_dimen_first'
                           and indexinst.sta_index_inst_id =
                               dimeninst5.sta_index_inst_id
                          left join e7_sta_index_inst_dimen dimeninst6
                            on dimeninst6.dim_code = 'Custom_dimen_second'
                           and indexinst.sta_index_inst_id =
                               dimeninst6.sta_index_inst_id
                          left join e7_sys_codelist codelist
                            on codelist.codelist_code = 'UNIT_CODE'
                           and indexinst.unit_code = codelist.code_value
                         where repinst.report_code = 'XNNW01'
                           and repinst.org_id =   P_RPTORGID
                           and repinst.report_year =   P_RPTYEAR
                           and repinst.report_month =   P_RPTMONTH
                         group by repinst.repinst_id,
                                  repinst.writer,
                                  repinst.write_date,
                                  repinst.checker,
                                  indexinst.sta_index_inst_id,
                                  indexinst.remark,
                                  indexinst.index_code,
                                  indexinst.index_value,
                                  indexinst.COMPOSITED_INDEX_CODE,
                                  indexinst.unit_code,
                                  codelist.Code_Name,
                                  dimeninst.repinst_dtl_dimen,
                                  dimeninst.dim_code,
                                  dimeninst.dim_detail_code,
                                  dimeninst1.repinst_dtl_dimen,
                                  dimeninst1.dim_code,
                                  dimeninst1.dim_detail_code,
                                  dimeninst2.repinst_dtl_dimen,
                                  dimeninst2.dim_code,
                                  dimeninst2.dim_detail_code,
                                  dimeninst3.repinst_dtl_dimen,
                                  dimeninst3.dim_code,
                                  dimeninst3.dim_detail_code,
                                  dimeninst4.repinst_dtl_dimen,
                                  dimeninst4.dim_code,
                                  dimeninst4.dim_detail_code,
                                  dimeninst5.repinst_dtl_dimen,
                                  dimeninst5.dim_code,
                                  dimeninst5.dim_detail_code,
                                  dimeninst6.repinst_dtl_dimen,
                                  dimeninst6.dim_code,
                                  dimeninst6.dim_detail_code

                        )
                 where index_code in ('Engy_csmp_amt_pratl',
                                      'Engy_csmp_amt_stadc',
                                      'Engy_csmp_cost')
                   and (dim_code4 in ('Cru_oil_E_cons_typ') or
                       dim_code4 is null))
         where composited_index_code is not null
           and dim_detail_code is not null
         group by repinst_id,
                  index_code,
                  dim_code,
                  dim_detail_code,
                  dim_code1,
                  dim_detail_code1,
                  dim_code2,
                  dim_detail_code2,
                  dim_code3,
                  dim_detail_code3,
                  dim_code4,
                  dim_detail_code4,
                  dim_code5,
                  dim_detail_code5,
                  dim_code6,
                  dim_detail_code6)
 where repinst_dtl_dimen is not null ) where repinst_dtl_dimen <> 'XN'
          union all
          select distinct repinst_dtl_dimen1,sta_index_inst_id,dim_code1,dim_detail_code1,null,null,null,null, P_RPTORGID ,sysdate,sysdate from (select repinst_id,
       sta_index_inst_id,
       index_code,
       index_value,
       repinst_dtl_dimen,
       dim_code,
       dim_detail_code,
       repinst_dtl_dimen1,
       dim_code1,
       dim_detail_code1,
       repinst_dtl_dimen2,
       dim_code2,
       dim_detail_code2,
       repinst_dtl_dimen3,
       dim_code3,
       dim_detail_code3,
       repinst_dtl_dimen4,
       dim_code4,
       dim_detail_code4,
       repinst_dtl_dimen5,
       dim_code5,
       dim_detail_code5,
       repinst_dtl_dimen6,
       dim_code6,
       dim_detail_code6
  from (select repinst_id,
               max(sta_index_inst_id) || 'XN' as sta_index_inst_id,
               index_code,
               sum(index_value) index_value,
               max(repinst_dtl_dimen) || 'XN' as repinst_dtl_dimen,
               dim_code,
               dim_detail_code,
               max(repinst_dtl_dimen1) || 'XN1' as repinst_dtl_dimen1,
               dim_code1,
               dim_detail_code1,
               max(repinst_dtl_dimen2) || 'XN2' as repinst_dtl_dimen2,
               dim_code2,
               dim_detail_code2,
               max(repinst_dtl_dimen3) || 'XN3' as repinst_dtl_dimen3,
               dim_code3,
               dim_detail_code3,
               max(repinst_dtl_dimen4) || 'XN4' as repinst_dtl_dimen4,
               dim_code4,
               dim_detail_code4,
               max(repinst_dtl_dimen5) || 'XN5' as repinst_dtl_dimen5,
               dim_code5,
               dim_detail_code5,
               max(repinst_dtl_dimen6) || 'XN6' as repinst_dtl_dimen6,
               dim_code6,
               dim_detail_code6
          from (select repinst_id,
                       sta_index_inst_id,
                       index_code,
                       index_value,
                       composited_index_code,
                       repinst_dtl_dimen,
                       dim_code,
                       dim_detail_code,
                       repinst_dtl_dimen1,
                       dim_code1,
                       dim_detail_code1,
                       repinst_dtl_dimen2,
                       dim_code2,
                       dim_detail_code2,
                       repinst_dtl_dimen3,
                       dim_code3,
                       dim_detail_code3,
                       repinst_dtl_dimen4,
                       dim_code4,
                       dim_detail_code4,
                       repinst_dtl_dimen5,
                       dim_code5,
                       dim_detail_code5,
                       repinst_dtl_dimen6,
                       dim_code6,
                       dim_detail_code6
                  from (select repinst.repinst_id,
                               repinst.writer,
                               repinst.write_date,
                               repinst.checker,
                               indexinst.sta_index_inst_id,
                               indexinst.remark,
                               indexinst.index_code,
                               indexinst.index_value,
                               indexinst.COMPOSITED_INDEX_CODE,
                               indexinst.unit_code,
                               codelist.Code_Name              AS UNIT_NAME,
                               dimeninst.repinst_dtl_dimen     as repinst_dtl_dimen,
                               dimeninst.dim_code              as dim_code,
                               dimeninst.dim_detail_code       as dim_detail_code,
                               dimeninst1.repinst_dtl_dimen    as repinst_dtl_dimen1,
                               dimeninst1.dim_code             as dim_code1,
                               dimeninst1.dim_detail_code      as dim_detail_code1,
                               dimeninst2.repinst_dtl_dimen    as repinst_dtl_dimen2,
                               dimeninst2.dim_code             as dim_code2,
                               dimeninst2.dim_detail_code      as dim_detail_code2,
                               dimeninst3.repinst_dtl_dimen    as repinst_dtl_dimen3,
                               dimeninst3.dim_code             as dim_code3,
                               dimeninst3.dim_detail_code      as dim_detail_code3,
                               dimeninst4.repinst_dtl_dimen    as repinst_dtl_dimen4,
                               dimeninst4.dim_code             as dim_code4,
                               dimeninst4.dim_detail_code      as dim_detail_code4,
                               dimeninst5.repinst_dtl_dimen    as repinst_dtl_dimen5,
                               dimeninst5.dim_code             as dim_code5,
                               dimeninst5.dim_detail_code      as dim_detail_code5,
                               dimeninst6.repinst_dtl_dimen    as repinst_dtl_dimen6,
                               dimeninst6.dim_code             as dim_code6,
                               dimeninst6.dim_detail_code      as dim_detail_code6
                          from e7_sta_repinst repinst
                          left join e7_sta_rpt_index_inst rptindexinst
                            on repinst.repinst_id = rptindexinst.repinst_id
                          left join e7_sta_index_inst indexinst
                            on rptindexinst.sta_index_inst_id =
                               indexinst.sta_index_inst_id
                          left join e7_sta_index_inst_dimen dimeninst
                            on dimeninst.dim_code = 'Business_type'
                           and indexinst.sta_index_inst_id =
                               dimeninst.sta_index_inst_id
                          left join e7_sta_index_inst_dimen dimeninst1
                            on dimeninst1.dim_code = 'Province_type'
                           and indexinst.sta_index_inst_id =
                               dimeninst1.sta_index_inst_id
                          left join e7_sta_index_inst_dimen dimeninst2
                            on dimeninst2.dim_code = 'Assets_type'
                           and indexinst.sta_index_inst_id =
                               dimeninst2.sta_index_inst_id
                          left join e7_sta_index_inst_dimen dimeninst3
                            on dimeninst3.dim_code = 'Industry_type'
                           and indexinst.sta_index_inst_id =
                               dimeninst3.sta_index_inst_id
                          left join e7_sta_index_inst_dimen dimeninst4
                            on dimeninst4.dim_code = 'Cru_oil_E_cons_typ'
                           and indexinst.sta_index_inst_id =
                               dimeninst4.sta_index_inst_id
                          left join e7_sta_index_inst_dimen dimeninst5
                            on dimeninst5.dim_code = 'Custom_dimen_first'
                           and indexinst.sta_index_inst_id =
                               dimeninst5.sta_index_inst_id
                          left join e7_sta_index_inst_dimen dimeninst6
                            on dimeninst6.dim_code = 'Custom_dimen_second'
                           and indexinst.sta_index_inst_id =
                               dimeninst6.sta_index_inst_id
                          left join e7_sys_codelist codelist
                            on codelist.codelist_code = 'UNIT_CODE'
                           and indexinst.unit_code = codelist.code_value
                         where repinst.report_code = 'XNNW01'
                           and repinst.org_id =  P_RPTORGID
                           and repinst.report_year =   P_RPTYEAR
                           and repinst.report_month =   P_RPTMONTH
                         group by repinst.repinst_id,
                                  repinst.writer,
                                  repinst.write_date,
                                  repinst.checker,
                                  indexinst.sta_index_inst_id,
                                  indexinst.remark,
                                  indexinst.index_code,
                                  indexinst.index_value,
                                  indexinst.COMPOSITED_INDEX_CODE,
                                  indexinst.unit_code,
                                  codelist.Code_Name,
                                  dimeninst.repinst_dtl_dimen,
                                  dimeninst.dim_code,
                                  dimeninst.dim_detail_code,
                                  dimeninst1.repinst_dtl_dimen,
                                  dimeninst1.dim_code,
                                  dimeninst1.dim_detail_code,
                                  dimeninst2.repinst_dtl_dimen,
                                  dimeninst2.dim_code,
                                  dimeninst2.dim_detail_code,
                                  dimeninst3.repinst_dtl_dimen,
                                  dimeninst3.dim_code,
                                  dimeninst3.dim_detail_code,
                                  dimeninst4.repinst_dtl_dimen,
                                  dimeninst4.dim_code,
                                  dimeninst4.dim_detail_code,
                                  dimeninst5.repinst_dtl_dimen,
                                  dimeninst5.dim_code,
                                  dimeninst5.dim_detail_code,
                                  dimeninst6.repinst_dtl_dimen,
                                  dimeninst6.dim_code,
                                  dimeninst6.dim_detail_code

                        )
                 where index_code in ('Engy_csmp_amt_pratl',
                                      'Engy_csmp_amt_stadc',
                                      'Engy_csmp_cost')
                   and (dim_code4 in ('Cru_oil_E_cons_typ') or
                       dim_code4 is null))
         where composited_index_code is not null
           and dim_detail_code is not null
         group by repinst_id,
                  index_code,
                  dim_code,
                  dim_detail_code,
                  dim_code1,
                  dim_detail_code1,
                  dim_code2,
                  dim_detail_code2,
                  dim_code3,
                  dim_detail_code3,
                  dim_code4,
                  dim_detail_code4,
                  dim_code5,
                  dim_detail_code5,
                  dim_code6,
                  dim_detail_code6)
 where repinst_dtl_dimen1 is not null)  where repinst_dtl_dimen1 <> 'XN1'
          union all
          select distinct repinst_dtl_dimen2,sta_index_inst_id,dim_code2,dim_detail_code2,null,null,null,null, P_RPTORGID ,sysdate,sysdate from (select repinst_id,
       sta_index_inst_id,
       index_code,
       index_value,
       repinst_dtl_dimen,
       dim_code,
       dim_detail_code,
       repinst_dtl_dimen1,
       dim_code1,
       dim_detail_code1,
       repinst_dtl_dimen2,
       dim_code2,
       dim_detail_code2,
       repinst_dtl_dimen3,
       dim_code3,
       dim_detail_code3,
       repinst_dtl_dimen4,
       dim_code4,
       dim_detail_code4,
       repinst_dtl_dimen5,
       dim_code5,
       dim_detail_code5,
       repinst_dtl_dimen6,
       dim_code6,
       dim_detail_code6
  from (select repinst_id,
               max(sta_index_inst_id) || 'XN' as sta_index_inst_id,
               index_code,
               sum(index_value) index_value,
               max(repinst_dtl_dimen) || 'XN' as repinst_dtl_dimen,
               dim_code,
               dim_detail_code,
               max(repinst_dtl_dimen1) || 'XN1' as repinst_dtl_dimen1,
               dim_code1,
               dim_detail_code1,
               max(repinst_dtl_dimen2) || 'XN2' as repinst_dtl_dimen2,
               dim_code2,
               dim_detail_code2,
               max(repinst_dtl_dimen3) || 'XN3' as repinst_dtl_dimen3,
               dim_code3,
               dim_detail_code3,
               max(repinst_dtl_dimen4) || 'XN4' as repinst_dtl_dimen4,
               dim_code4,
               dim_detail_code4,
               max(repinst_dtl_dimen5) || 'XN5' as repinst_dtl_dimen5,
               dim_code5,
               dim_detail_code5,
               max(repinst_dtl_dimen6) || 'XN6' as repinst_dtl_dimen6,
               dim_code6,
               dim_detail_code6
          from (select repinst_id,
                       sta_index_inst_id,
                       index_code,
                       index_value,
                       composited_index_code,
                       repinst_dtl_dimen,
                       dim_code,
                       dim_detail_code,
                       repinst_dtl_dimen1,
                       dim_code1,
                       dim_detail_code1,
                       repinst_dtl_dimen2,
                       dim_code2,
                       dim_detail_code2,
                       repinst_dtl_dimen3,
                       dim_code3,
                       dim_detail_code3,
                       repinst_dtl_dimen4,
                       dim_code4,
                       dim_detail_code4,
                       repinst_dtl_dimen5,
                       dim_code5,
                       dim_detail_code5,
                       repinst_dtl_dimen6,
                       dim_code6,
                       dim_detail_code6
                  from (select repinst.repinst_id,
                               repinst.writer,
                               repinst.write_date,
                               repinst.checker,
                               indexinst.sta_index_inst_id,
                               indexinst.remark,
                               indexinst.index_code,
                               indexinst.index_value,
                               indexinst.COMPOSITED_INDEX_CODE,
                               indexinst.unit_code,
                               codelist.Code_Name              AS UNIT_NAME,
                               dimeninst.repinst_dtl_dimen     as repinst_dtl_dimen,
                               dimeninst.dim_code              as dim_code,
                               dimeninst.dim_detail_code       as dim_detail_code,
                               dimeninst1.repinst_dtl_dimen    as repinst_dtl_dimen1,
                               dimeninst1.dim_code             as dim_code1,
                               dimeninst1.dim_detail_code      as dim_detail_code1,
                               dimeninst2.repinst_dtl_dimen    as repinst_dtl_dimen2,
                               dimeninst2.dim_code             as dim_code2,
                               dimeninst2.dim_detail_code      as dim_detail_code2,
                               dimeninst3.repinst_dtl_dimen    as repinst_dtl_dimen3,
                               dimeninst3.dim_code             as dim_code3,
                               dimeninst3.dim_detail_code      as dim_detail_code3,
                               dimeninst4.repinst_dtl_dimen    as repinst_dtl_dimen4,
                               dimeninst4.dim_code             as dim_code4,
                               dimeninst4.dim_detail_code      as dim_detail_code4,
                               dimeninst5.repinst_dtl_dimen    as repinst_dtl_dimen5,
                               dimeninst5.dim_code             as dim_code5,
                               dimeninst5.dim_detail_code      as dim_detail_code5,
                               dimeninst6.repinst_dtl_dimen    as repinst_dtl_dimen6,
                               dimeninst6.dim_code             as dim_code6,
                               dimeninst6.dim_detail_code      as dim_detail_code6
                          from e7_sta_repinst repinst
                          left join e7_sta_rpt_index_inst rptindexinst
                            on repinst.repinst_id = rptindexinst.repinst_id
                          left join e7_sta_index_inst indexinst
                            on rptindexinst.sta_index_inst_id =
                               indexinst.sta_index_inst_id
                          left join e7_sta_index_inst_dimen dimeninst
                            on dimeninst.dim_code = 'Business_type'
                           and indexinst.sta_index_inst_id =
                               dimeninst.sta_index_inst_id
                          left join e7_sta_index_inst_dimen dimeninst1
                            on dimeninst1.dim_code = 'Province_type'
                           and indexinst.sta_index_inst_id =
                               dimeninst1.sta_index_inst_id
                          left join e7_sta_index_inst_dimen dimeninst2
                            on dimeninst2.dim_code = 'Assets_type'
                           and indexinst.sta_index_inst_id =
                               dimeninst2.sta_index_inst_id
                          left join e7_sta_index_inst_dimen dimeninst3
                            on dimeninst3.dim_code = 'Industry_type'
                           and indexinst.sta_index_inst_id =
                               dimeninst3.sta_index_inst_id
                          left join e7_sta_index_inst_dimen dimeninst4
                            on dimeninst4.dim_code = 'Cru_oil_E_cons_typ'
                           and indexinst.sta_index_inst_id =
                               dimeninst4.sta_index_inst_id
                          left join e7_sta_index_inst_dimen dimeninst5
                            on dimeninst5.dim_code = 'Custom_dimen_first'
                           and indexinst.sta_index_inst_id =
                               dimeninst5.sta_index_inst_id
                          left join e7_sta_index_inst_dimen dimeninst6
                            on dimeninst6.dim_code = 'Custom_dimen_second'
                           and indexinst.sta_index_inst_id =
                               dimeninst6.sta_index_inst_id
                          left join e7_sys_codelist codelist
                            on codelist.codelist_code = 'UNIT_CODE'
                           and indexinst.unit_code = codelist.code_value
                         where repinst.report_code = 'XNNW01'
                           and repinst.org_id =  P_RPTORGID
                           and repinst.report_year =  P_RPTYEAR
                           and repinst.report_month =  P_RPTMONTH
                         group by repinst.repinst_id,
                                  repinst.writer,
                                  repinst.write_date,
                                  repinst.checker,
                                  indexinst.sta_index_inst_id,
                                  indexinst.remark,
                                  indexinst.index_code,
                                  indexinst.index_value,
                                  indexinst.COMPOSITED_INDEX_CODE,
                                  indexinst.unit_code,
                                  codelist.Code_Name,
                                  dimeninst.repinst_dtl_dimen,
                                  dimeninst.dim_code,
                                  dimeninst.dim_detail_code,
                                  dimeninst1.repinst_dtl_dimen,
                                  dimeninst1.dim_code,
                                  dimeninst1.dim_detail_code,
                                  dimeninst2.repinst_dtl_dimen,
                                  dimeninst2.dim_code,
                                  dimeninst2.dim_detail_code,
                                  dimeninst3.repinst_dtl_dimen,
                                  dimeninst3.dim_code,
                                  dimeninst3.dim_detail_code,
                                  dimeninst4.repinst_dtl_dimen,
                                  dimeninst4.dim_code,
                                  dimeninst4.dim_detail_code,
                                  dimeninst5.repinst_dtl_dimen,
                                  dimeninst5.dim_code,
                                  dimeninst5.dim_detail_code,
                                  dimeninst6.repinst_dtl_dimen,
                                  dimeninst6.dim_code,
                                  dimeninst6.dim_detail_code

                        )
                 where index_code in ('Engy_csmp_amt_pratl',
                                      'Engy_csmp_amt_stadc',
                                      'Engy_csmp_cost')
                   and (dim_code4 in ('Cru_oil_E_cons_typ') or
                       dim_code4 is null))
         where composited_index_code is not null
           and dim_detail_code is not null
         group by repinst_id,
                  index_code,
                  dim_code,
                  dim_detail_code,
                  dim_code1,
                  dim_detail_code1,
                  dim_code2,
                  dim_detail_code2,
                  dim_code3,
                  dim_detail_code3,
                  dim_code4,
                  dim_detail_code4,
                  dim_code5,
                  dim_detail_code5,
                  dim_code6,
                  dim_detail_code6)
 where repinst_dtl_dimen2 is not null)  where repinst_dtl_dimen2 <> 'XN2'
          union all
          select distinct repinst_dtl_dimen3,sta_index_inst_id,dim_code3,dim_detail_code3,null,null,null,null, P_RPTORGID ,sysdate,sysdate from (select repinst_id,
       sta_index_inst_id,
       index_code,
       index_value,
       repinst_dtl_dimen,
       dim_code,
       dim_detail_code,
       repinst_dtl_dimen1,
       dim_code1,
       dim_detail_code1,
       repinst_dtl_dimen2,
       dim_code2,
       dim_detail_code2,
       repinst_dtl_dimen3,
       dim_code3,
       dim_detail_code3,
       repinst_dtl_dimen4,
       dim_code4,
       dim_detail_code4,
       repinst_dtl_dimen5,
       dim_code5,
       dim_detail_code5,
       repinst_dtl_dimen6,
       dim_code6,
       dim_detail_code6
  from (select repinst_id,
               max(sta_index_inst_id) || 'XN' as sta_index_inst_id,
               index_code,
               sum(index_value) index_value,
               max(repinst_dtl_dimen) || 'XN' as repinst_dtl_dimen,
               dim_code,
               dim_detail_code,
               max(repinst_dtl_dimen1) || 'XN1' as repinst_dtl_dimen1,
               dim_code1,
               dim_detail_code1,
               max(repinst_dtl_dimen2) || 'XN2' as repinst_dtl_dimen2,
               dim_code2,
               dim_detail_code2,
               max(repinst_dtl_dimen3) || 'XN3' as repinst_dtl_dimen3,
               dim_code3,
               dim_detail_code3,
               max(repinst_dtl_dimen4) || 'XN4' as repinst_dtl_dimen4,
               dim_code4,
               dim_detail_code4,
               max(repinst_dtl_dimen5) || 'XN5' as repinst_dtl_dimen5,
               dim_code5,
               dim_detail_code5,
               max(repinst_dtl_dimen6) || 'XN6' as repinst_dtl_dimen6,
               dim_code6,
               dim_detail_code6
          from (select repinst_id,
                       sta_index_inst_id,
                       index_code,
                       index_value,
                       composited_index_code,
                       repinst_dtl_dimen,
                       dim_code,
                       dim_detail_code,
                       repinst_dtl_dimen1,
                       dim_code1,
                       dim_detail_code1,
                       repinst_dtl_dimen2,
                       dim_code2,
                       dim_detail_code2,
                       repinst_dtl_dimen3,
                       dim_code3,
                       dim_detail_code3,
                       repinst_dtl_dimen4,
                       dim_code4,
                       dim_detail_code4,
                       repinst_dtl_dimen5,
                       dim_code5,
                       dim_detail_code5,
                       repinst_dtl_dimen6,
                       dim_code6,
                       dim_detail_code6
                  from (select repinst.repinst_id,
                               repinst.writer,
                               repinst.write_date,
                               repinst.checker,
                               indexinst.sta_index_inst_id,
                               indexinst.remark,
                               indexinst.index_code,
                               indexinst.index_value,
                               indexinst.COMPOSITED_INDEX_CODE,
                               indexinst.unit_code,
                               codelist.Code_Name              AS UNIT_NAME,
                               dimeninst.repinst_dtl_dimen     as repinst_dtl_dimen,
                               dimeninst.dim_code              as dim_code,
                               dimeninst.dim_detail_code       as dim_detail_code,
                               dimeninst1.repinst_dtl_dimen    as repinst_dtl_dimen1,
                               dimeninst1.dim_code             as dim_code1,
                               dimeninst1.dim_detail_code      as dim_detail_code1,
                               dimeninst2.repinst_dtl_dimen    as repinst_dtl_dimen2,
                               dimeninst2.dim_code             as dim_code2,
                               dimeninst2.dim_detail_code      as dim_detail_code2,
                               dimeninst3.repinst_dtl_dimen    as repinst_dtl_dimen3,
                               dimeninst3.dim_code             as dim_code3,
                               dimeninst3.dim_detail_code      as dim_detail_code3,
                               dimeninst4.repinst_dtl_dimen    as repinst_dtl_dimen4,
                               dimeninst4.dim_code             as dim_code4,
                               dimeninst4.dim_detail_code      as dim_detail_code4,
                               dimeninst5.repinst_dtl_dimen    as repinst_dtl_dimen5,
                               dimeninst5.dim_code             as dim_code5,
                               dimeninst5.dim_detail_code      as dim_detail_code5,
                               dimeninst6.repinst_dtl_dimen    as repinst_dtl_dimen6,
                               dimeninst6.dim_code             as dim_code6,
                               dimeninst6.dim_detail_code      as dim_detail_code6
                          from e7_sta_repinst repinst
                          left join e7_sta_rpt_index_inst rptindexinst
                            on repinst.repinst_id = rptindexinst.repinst_id
                          left join e7_sta_index_inst indexinst
                            on rptindexinst.sta_index_inst_id =
                               indexinst.sta_index_inst_id
                          left join e7_sta_index_inst_dimen dimeninst
                            on dimeninst.dim_code = 'Business_type'
                           and indexinst.sta_index_inst_id =
                               dimeninst.sta_index_inst_id
                          left join e7_sta_index_inst_dimen dimeninst1
                            on dimeninst1.dim_code = 'Province_type'
                           and indexinst.sta_index_inst_id =
                               dimeninst1.sta_index_inst_id
                          left join e7_sta_index_inst_dimen dimeninst2
                            on dimeninst2.dim_code = 'Assets_type'
                           and indexinst.sta_index_inst_id =
                               dimeninst2.sta_index_inst_id
                          left join e7_sta_index_inst_dimen dimeninst3
                            on dimeninst3.dim_code = 'Industry_type'
                           and indexinst.sta_index_inst_id =
                               dimeninst3.sta_index_inst_id
                          left join e7_sta_index_inst_dimen dimeninst4
                            on dimeninst4.dim_code = 'Cru_oil_E_cons_typ'
                           and indexinst.sta_index_inst_id =
                               dimeninst4.sta_index_inst_id
                          left join e7_sta_index_inst_dimen dimeninst5
                            on dimeninst5.dim_code = 'Custom_dimen_first'
                           and indexinst.sta_index_inst_id =
                               dimeninst5.sta_index_inst_id
                          left join e7_sta_index_inst_dimen dimeninst6
                            on dimeninst6.dim_code = 'Custom_dimen_second'
                           and indexinst.sta_index_inst_id =
                               dimeninst6.sta_index_inst_id
                          left join e7_sys_codelist codelist
                            on codelist.codelist_code = 'UNIT_CODE'
                           and indexinst.unit_code = codelist.code_value
                         where repinst.report_code = 'XNNW01'
                           and repinst.org_id =  P_RPTORGID
                           and repinst.report_year =  P_RPTYEAR
                           and repinst.report_month =  P_RPTMONTH
                         group by repinst.repinst_id,
                                  repinst.writer,
                                  repinst.write_date,
                                  repinst.checker,
                                  indexinst.sta_index_inst_id,
                                  indexinst.remark,
                                  indexinst.index_code,
                                  indexinst.index_value,
                                  indexinst.COMPOSITED_INDEX_CODE,
                                  indexinst.unit_code,
                                  codelist.Code_Name,
                                  dimeninst.repinst_dtl_dimen,
                                  dimeninst.dim_code,
                                  dimeninst.dim_detail_code,
                                  dimeninst1.repinst_dtl_dimen,
                                  dimeninst1.dim_code,
                                  dimeninst1.dim_detail_code,
                                  dimeninst2.repinst_dtl_dimen,
                                  dimeninst2.dim_code,
                                  dimeninst2.dim_detail_code,
                                  dimeninst3.repinst_dtl_dimen,
                                  dimeninst3.dim_code,
                                  dimeninst3.dim_detail_code,
                                  dimeninst4.repinst_dtl_dimen,
                                  dimeninst4.dim_code,
                                  dimeninst4.dim_detail_code,
                                  dimeninst5.repinst_dtl_dimen,
                                  dimeninst5.dim_code,
                                  dimeninst5.dim_detail_code,
                                  dimeninst6.repinst_dtl_dimen,
                                  dimeninst6.dim_code,
                                  dimeninst6.dim_detail_code

                        )
                 where index_code in ('Engy_csmp_amt_pratl',
                                      'Engy_csmp_amt_stadc',
                                      'Engy_csmp_cost')
                   and (dim_code4 in ('Cru_oil_E_cons_typ') or
                       dim_code4 is null))
         where composited_index_code is not null
           and dim_detail_code is not null
         group by repinst_id,
                  index_code,
                  dim_code,
                  dim_detail_code,
                  dim_code1,
                  dim_detail_code1,
                  dim_code2,
                  dim_detail_code2,
                  dim_code3,
                  dim_detail_code3,
                  dim_code4,
                  dim_detail_code4,
                  dim_code5,
                  dim_detail_code5,
                  dim_code6,
                  dim_detail_code6)
 where repinst_dtl_dimen3 is not null)  where repinst_dtl_dimen3 <> 'XN3'
          union all
          select distinct repinst_dtl_dimen4,sta_index_inst_id,dim_code4,dim_detail_code4,null,null,null,null, P_RPTORGID ,sysdate,sysdate from (select repinst_id,
       sta_index_inst_id,
       index_code,
       index_value,
       repinst_dtl_dimen,
       dim_code,
       dim_detail_code,
       repinst_dtl_dimen1,
       dim_code1,
       dim_detail_code1,
       repinst_dtl_dimen2,
       dim_code2,
       dim_detail_code2,
       repinst_dtl_dimen3,
       dim_code3,
       dim_detail_code3,
       repinst_dtl_dimen4,
       dim_code4,
       dim_detail_code4,
       repinst_dtl_dimen5,
       dim_code5,
       dim_detail_code5,
       repinst_dtl_dimen6,
       dim_code6,
       dim_detail_code6
  from (select repinst_id,
               max(sta_index_inst_id) || 'XN' as sta_index_inst_id,
               index_code,
               sum(index_value) index_value,
               max(repinst_dtl_dimen) || 'XN' as repinst_dtl_dimen,
               dim_code,
               dim_detail_code,
               max(repinst_dtl_dimen1) || 'XN1' as repinst_dtl_dimen1,
               dim_code1,
               dim_detail_code1,
               max(repinst_dtl_dimen2) || 'XN2' as repinst_dtl_dimen2,
               dim_code2,
               dim_detail_code2,
               max(repinst_dtl_dimen3) || 'XN3' as repinst_dtl_dimen3,
               dim_code3,
               dim_detail_code3,
               max(repinst_dtl_dimen4) || 'XN4' as repinst_dtl_dimen4,
               dim_code4,
               dim_detail_code4,
               max(repinst_dtl_dimen5) || 'XN5' as repinst_dtl_dimen5,
               dim_code5,
               dim_detail_code5,
               max(repinst_dtl_dimen6) || 'XN6' as repinst_dtl_dimen6,
               dim_code6,
               dim_detail_code6
          from (select repinst_id,
                       sta_index_inst_id,
                       index_code,
                       index_value,
                       composited_index_code,
                       repinst_dtl_dimen,
                       dim_code,
                       dim_detail_code,
                       repinst_dtl_dimen1,
                       dim_code1,
                       dim_detail_code1,
                       repinst_dtl_dimen2,
                       dim_code2,
                       dim_detail_code2,
                       repinst_dtl_dimen3,
                       dim_code3,
                       dim_detail_code3,
                       repinst_dtl_dimen4,
                       dim_code4,
                       dim_detail_code4,
                       repinst_dtl_dimen5,
                       dim_code5,
                       dim_detail_code5,
                       repinst_dtl_dimen6,
                       dim_code6,
                       dim_detail_code6
                  from (select repinst.repinst_id,
                               repinst.writer,
                               repinst.write_date,
                               repinst.checker,
                               indexinst.sta_index_inst_id,
                               indexinst.remark,
                               indexinst.index_code,
                               indexinst.index_value,
                               indexinst.COMPOSITED_INDEX_CODE,
                               indexinst.unit_code,
                               codelist.Code_Name              AS UNIT_NAME,
                               dimeninst.repinst_dtl_dimen     as repinst_dtl_dimen,
                               dimeninst.dim_code              as dim_code,
                               dimeninst.dim_detail_code       as dim_detail_code,
                               dimeninst1.repinst_dtl_dimen    as repinst_dtl_dimen1,
                               dimeninst1.dim_code             as dim_code1,
                               dimeninst1.dim_detail_code      as dim_detail_code1,
                               dimeninst2.repinst_dtl_dimen    as repinst_dtl_dimen2,
                               dimeninst2.dim_code             as dim_code2,
                               dimeninst2.dim_detail_code      as dim_detail_code2,
                               dimeninst3.repinst_dtl_dimen    as repinst_dtl_dimen3,
                               dimeninst3.dim_code             as dim_code3,
                               dimeninst3.dim_detail_code      as dim_detail_code3,
                               dimeninst4.repinst_dtl_dimen    as repinst_dtl_dimen4,
                               dimeninst4.dim_code             as dim_code4,
                               dimeninst4.dim_detail_code      as dim_detail_code4,
                               dimeninst5.repinst_dtl_dimen    as repinst_dtl_dimen5,
                               dimeninst5.dim_code             as dim_code5,
                               dimeninst5.dim_detail_code      as dim_detail_code5,
                               dimeninst6.repinst_dtl_dimen    as repinst_dtl_dimen6,
                               dimeninst6.dim_code             as dim_code6,
                               dimeninst6.dim_detail_code      as dim_detail_code6
                          from e7_sta_repinst repinst
                          left join e7_sta_rpt_index_inst rptindexinst
                            on repinst.repinst_id = rptindexinst.repinst_id
                          left join e7_sta_index_inst indexinst
                            on rptindexinst.sta_index_inst_id =
                               indexinst.sta_index_inst_id
                          left join e7_sta_index_inst_dimen dimeninst
                            on dimeninst.dim_code = 'Business_type'
                           and indexinst.sta_index_inst_id =
                               dimeninst.sta_index_inst_id
                          left join e7_sta_index_inst_dimen dimeninst1
                            on dimeninst1.dim_code = 'Province_type'
                           and indexinst.sta_index_inst_id =
                               dimeninst1.sta_index_inst_id
                          left join e7_sta_index_inst_dimen dimeninst2
                            on dimeninst2.dim_code = 'Assets_type'
                           and indexinst.sta_index_inst_id =
                               dimeninst2.sta_index_inst_id
                          left join e7_sta_index_inst_dimen dimeninst3
                            on dimeninst3.dim_code = 'Industry_type'
                           and indexinst.sta_index_inst_id =
                               dimeninst3.sta_index_inst_id
                          left join e7_sta_index_inst_dimen dimeninst4
                            on dimeninst4.dim_code = 'Cru_oil_E_cons_typ'
                           and indexinst.sta_index_inst_id =
                               dimeninst4.sta_index_inst_id
                          left join e7_sta_index_inst_dimen dimeninst5
                            on dimeninst5.dim_code = 'Custom_dimen_first'
                           and indexinst.sta_index_inst_id =
                               dimeninst5.sta_index_inst_id
                          left join e7_sta_index_inst_dimen dimeninst6
                            on dimeninst6.dim_code = 'Custom_dimen_second'
                           and indexinst.sta_index_inst_id =
                               dimeninst6.sta_index_inst_id
                          left join e7_sys_codelist codelist
                            on codelist.codelist_code = 'UNIT_CODE'
                           and indexinst.unit_code = codelist.code_value
                         where repinst.report_code = 'XNNW01'
                           and repinst.org_id =  P_RPTORGID
                           and repinst.report_year =  P_RPTYEAR
                           and repinst.report_month =  P_RPTMONTH
                         group by repinst.repinst_id,
                                  repinst.writer,
                                  repinst.write_date,
                                  repinst.checker,
                                  indexinst.sta_index_inst_id,
                                  indexinst.remark,
                                  indexinst.index_code,
                                  indexinst.index_value,
                                  indexinst.COMPOSITED_INDEX_CODE,
                                  indexinst.unit_code,
                                  codelist.Code_Name,
                                  dimeninst.repinst_dtl_dimen,
                                  dimeninst.dim_code,
                                  dimeninst.dim_detail_code,
                                  dimeninst1.repinst_dtl_dimen,
                                  dimeninst1.dim_code,
                                  dimeninst1.dim_detail_code,
                                  dimeninst2.repinst_dtl_dimen,
                                  dimeninst2.dim_code,
                                  dimeninst2.dim_detail_code,
                                  dimeninst3.repinst_dtl_dimen,
                                  dimeninst3.dim_code,
                                  dimeninst3.dim_detail_code,
                                  dimeninst4.repinst_dtl_dimen,
                                  dimeninst4.dim_code,
                                  dimeninst4.dim_detail_code,
                                  dimeninst5.repinst_dtl_dimen,
                                  dimeninst5.dim_code,
                                  dimeninst5.dim_detail_code,
                                  dimeninst6.repinst_dtl_dimen,
                                  dimeninst6.dim_code,
                                  dimeninst6.dim_detail_code

                        )
                 where index_code in ('Engy_csmp_amt_pratl',
                                      'Engy_csmp_amt_stadc',
                                      'Engy_csmp_cost')
                   and (dim_code4 in ('Cru_oil_E_cons_typ') or
                       dim_code4 is null))
         where composited_index_code is not null
           and dim_detail_code is not null
         group by repinst_id,
                  index_code,
                  dim_code,
                  dim_detail_code,
                  dim_code1,
                  dim_detail_code1,
                  dim_code2,
                  dim_detail_code2,
                  dim_code3,
                  dim_detail_code3,
                  dim_code4,
                  dim_detail_code4,
                  dim_code5,
                  dim_detail_code5,
                  dim_code6,
                  dim_detail_code6)
 where repinst_dtl_dimen4 is not null)  where repinst_dtl_dimen4 <> 'XN4'
          union all
          select distinct repinst_dtl_dimen5,sta_index_inst_id,dim_code5,dim_detail_code5,null,null,null,null, P_RPTORGID ,sysdate,sysdate from (select repinst_id,
       sta_index_inst_id,
       index_code,
       index_value,
       repinst_dtl_dimen,
       dim_code,
       dim_detail_code,
       repinst_dtl_dimen1,
       dim_code1,
       dim_detail_code1,
       repinst_dtl_dimen2,
       dim_code2,
       dim_detail_code2,
       repinst_dtl_dimen3,
       dim_code3,
       dim_detail_code3,
       repinst_dtl_dimen4,
       dim_code4,
       dim_detail_code4,
       repinst_dtl_dimen5,
       dim_code5,
       dim_detail_code5,
       repinst_dtl_dimen6,
       dim_code6,
       dim_detail_code6
  from (select repinst_id,
               max(sta_index_inst_id) || 'XN' as sta_index_inst_id,
               index_code,
               sum(index_value) index_value,
               max(repinst_dtl_dimen) || 'XN' as repinst_dtl_dimen,
               dim_code,
               dim_detail_code,
               max(repinst_dtl_dimen1) || 'XN1' as repinst_dtl_dimen1,
               dim_code1,
               dim_detail_code1,
               max(repinst_dtl_dimen2) || 'XN2' as repinst_dtl_dimen2,
               dim_code2,
               dim_detail_code2,
               max(repinst_dtl_dimen3) || 'XN3' as repinst_dtl_dimen3,
               dim_code3,
               dim_detail_code3,
               max(repinst_dtl_dimen4) || 'XN4' as repinst_dtl_dimen4,
               dim_code4,
               dim_detail_code4,
               max(repinst_dtl_dimen5) || 'XN5' as repinst_dtl_dimen5,
               dim_code5,
               dim_detail_code5,
               max(repinst_dtl_dimen6) || 'XN6' as repinst_dtl_dimen6,
               dim_code6,
               dim_detail_code6
          from (select repinst_id,
                       sta_index_inst_id,
                       index_code,
                       index_value,
                       composited_index_code,
                       repinst_dtl_dimen,
                       dim_code,
                       dim_detail_code,
                       repinst_dtl_dimen1,
                       dim_code1,
                       dim_detail_code1,
                       repinst_dtl_dimen2,
                       dim_code2,
                       dim_detail_code2,
                       repinst_dtl_dimen3,
                       dim_code3,
                       dim_detail_code3,
                       repinst_dtl_dimen4,
                       dim_code4,
                       dim_detail_code4,
                       repinst_dtl_dimen5,
                       dim_code5,
                       dim_detail_code5,
                       repinst_dtl_dimen6,
                       dim_code6,
                       dim_detail_code6
                  from (select repinst.repinst_id,
                               repinst.writer,
                               repinst.write_date,
                               repinst.checker,
                               indexinst.sta_index_inst_id,
                               indexinst.remark,
                               indexinst.index_code,
                               indexinst.index_value,
                               indexinst.COMPOSITED_INDEX_CODE,
                               indexinst.unit_code,
                               codelist.Code_Name              AS UNIT_NAME,
                               dimeninst.repinst_dtl_dimen     as repinst_dtl_dimen,
                               dimeninst.dim_code              as dim_code,
                               dimeninst.dim_detail_code       as dim_detail_code,
                               dimeninst1.repinst_dtl_dimen    as repinst_dtl_dimen1,
                               dimeninst1.dim_code             as dim_code1,
                               dimeninst1.dim_detail_code      as dim_detail_code1,
                               dimeninst2.repinst_dtl_dimen    as repinst_dtl_dimen2,
                               dimeninst2.dim_code             as dim_code2,
                               dimeninst2.dim_detail_code      as dim_detail_code2,
                               dimeninst3.repinst_dtl_dimen    as repinst_dtl_dimen3,
                               dimeninst3.dim_code             as dim_code3,
                               dimeninst3.dim_detail_code      as dim_detail_code3,
                               dimeninst4.repinst_dtl_dimen    as repinst_dtl_dimen4,
                               dimeninst4.dim_code             as dim_code4,
                               dimeninst4.dim_detail_code      as dim_detail_code4,
                               dimeninst5.repinst_dtl_dimen    as repinst_dtl_dimen5,
                               dimeninst5.dim_code             as dim_code5,
                               dimeninst5.dim_detail_code      as dim_detail_code5,
                               dimeninst6.repinst_dtl_dimen    as repinst_dtl_dimen6,
                               dimeninst6.dim_code             as dim_code6,
                               dimeninst6.dim_detail_code      as dim_detail_code6
                          from e7_sta_repinst repinst
                          left join e7_sta_rpt_index_inst rptindexinst
                            on repinst.repinst_id = rptindexinst.repinst_id
                          left join e7_sta_index_inst indexinst
                            on rptindexinst.sta_index_inst_id =
                               indexinst.sta_index_inst_id
                          left join e7_sta_index_inst_dimen dimeninst
                            on dimeninst.dim_code = 'Business_type'
                           and indexinst.sta_index_inst_id =
                               dimeninst.sta_index_inst_id
                          left join e7_sta_index_inst_dimen dimeninst1
                            on dimeninst1.dim_code = 'Province_type'
                           and indexinst.sta_index_inst_id =
                               dimeninst1.sta_index_inst_id
                          left join e7_sta_index_inst_dimen dimeninst2
                            on dimeninst2.dim_code = 'Assets_type'
                           and indexinst.sta_index_inst_id =
                               dimeninst2.sta_index_inst_id
                          left join e7_sta_index_inst_dimen dimeninst3
                            on dimeninst3.dim_code = 'Industry_type'
                           and indexinst.sta_index_inst_id =
                               dimeninst3.sta_index_inst_id
                          left join e7_sta_index_inst_dimen dimeninst4
                            on dimeninst4.dim_code = 'Cru_oil_E_cons_typ'
                           and indexinst.sta_index_inst_id =
                               dimeninst4.sta_index_inst_id
                          left join e7_sta_index_inst_dimen dimeninst5
                            on dimeninst5.dim_code = 'Custom_dimen_first'
                           and indexinst.sta_index_inst_id =
                               dimeninst5.sta_index_inst_id
                          left join e7_sta_index_inst_dimen dimeninst6
                            on dimeninst6.dim_code = 'Custom_dimen_second'
                           and indexinst.sta_index_inst_id =
                               dimeninst6.sta_index_inst_id
                          left join e7_sys_codelist codelist
                            on codelist.codelist_code = 'UNIT_CODE'
                           and indexinst.unit_code = codelist.code_value
                         where repinst.report_code = 'XNNW01'
                           and repinst.org_id =  P_RPTORGID
                           and repinst.report_year =  P_RPTYEAR
                           and repinst.report_month =  P_RPTMONTH
                         group by repinst.repinst_id,
                                  repinst.writer,
                                  repinst.write_date,
                                  repinst.checker,
                                  indexinst.sta_index_inst_id,
                                  indexinst.remark,
                                  indexinst.index_code,
                                  indexinst.index_value,
                                  indexinst.COMPOSITED_INDEX_CODE,
                                  indexinst.unit_code,
                                  codelist.Code_Name,
                                  dimeninst.repinst_dtl_dimen,
                                  dimeninst.dim_code,
                                  dimeninst.dim_detail_code,
                                  dimeninst1.repinst_dtl_dimen,
                                  dimeninst1.dim_code,
                                  dimeninst1.dim_detail_code,
                                  dimeninst2.repinst_dtl_dimen,
                                  dimeninst2.dim_code,
                                  dimeninst2.dim_detail_code,
                                  dimeninst3.repinst_dtl_dimen,
                                  dimeninst3.dim_code,
                                  dimeninst3.dim_detail_code,
                                  dimeninst4.repinst_dtl_dimen,
                                  dimeninst4.dim_code,
                                  dimeninst4.dim_detail_code,
                                  dimeninst5.repinst_dtl_dimen,
                                  dimeninst5.dim_code,
                                  dimeninst5.dim_detail_code,
                                  dimeninst6.repinst_dtl_dimen,
                                  dimeninst6.dim_code,
                                  dimeninst6.dim_detail_code

                        )
                 where index_code in ('Engy_csmp_amt_pratl',
                                      'Engy_csmp_amt_stadc',
                                      'Engy_csmp_cost')
                   and (dim_code4 in ('Cru_oil_E_cons_typ') or
                       dim_code4 is null))
         where composited_index_code is not null
           and dim_detail_code is not null
         group by repinst_id,
                  index_code,
                  dim_code,
                  dim_detail_code,
                  dim_code1,
                  dim_detail_code1,
                  dim_code2,
                  dim_detail_code2,
                  dim_code3,
                  dim_detail_code3,
                  dim_code4,
                  dim_detail_code4,
                  dim_code5,
                  dim_detail_code5,
                  dim_code6,
                  dim_detail_code6)
 where repinst_dtl_dimen5 is not null) where repinst_dtl_dimen5 <> 'XN5'
          union all
          select distinct repinst_dtl_dimen6,sta_index_inst_id,dim_code6,dim_detail_code6,null,null,null,null, P_RPTORGID ,sysdate,sysdate from (select repinst_id,
       sta_index_inst_id,
       index_code,
       index_value,
       repinst_dtl_dimen,
       dim_code,
       dim_detail_code,
       repinst_dtl_dimen1,
       dim_code1,
       dim_detail_code1,
       repinst_dtl_dimen2,
       dim_code2,
       dim_detail_code2,
       repinst_dtl_dimen3,
       dim_code3,
       dim_detail_code3,
       repinst_dtl_dimen4,
       dim_code4,
       dim_detail_code4,
       repinst_dtl_dimen5,
       dim_code5,
       dim_detail_code5,
       repinst_dtl_dimen6,
       dim_code6,
       dim_detail_code6
  from (select repinst_id,
               max(sta_index_inst_id) || 'XN' as sta_index_inst_id,
               index_code,
               sum(index_value) index_value,
               max(repinst_dtl_dimen) || 'XN' as repinst_dtl_dimen,
               dim_code,
               dim_detail_code,
               max(repinst_dtl_dimen1) || 'XN1' as repinst_dtl_dimen1,
               dim_code1,
               dim_detail_code1,
               max(repinst_dtl_dimen2) || 'XN2' as repinst_dtl_dimen2,
               dim_code2,
               dim_detail_code2,
               max(repinst_dtl_dimen3) || 'XN3' as repinst_dtl_dimen3,
               dim_code3,
               dim_detail_code3,
               max(repinst_dtl_dimen4) || 'XN4' as repinst_dtl_dimen4,
               dim_code4,
               dim_detail_code4,
               max(repinst_dtl_dimen5) || 'XN5' as repinst_dtl_dimen5,
               dim_code5,
               dim_detail_code5,
               max(repinst_dtl_dimen6) || 'XN6' as repinst_dtl_dimen6,
               dim_code6,
               dim_detail_code6
          from (select repinst_id,
                       sta_index_inst_id,
                       index_code,
                       index_value,
                       composited_index_code,
                       repinst_dtl_dimen,
                       dim_code,
                       dim_detail_code,
                       repinst_dtl_dimen1,
                       dim_code1,
                       dim_detail_code1,
                       repinst_dtl_dimen2,
                       dim_code2,
                       dim_detail_code2,
                       repinst_dtl_dimen3,
                       dim_code3,
                       dim_detail_code3,
                       repinst_dtl_dimen4,
                       dim_code4,
                       dim_detail_code4,
                       repinst_dtl_dimen5,
                       dim_code5,
                       dim_detail_code5,
                       repinst_dtl_dimen6,
                       dim_code6,
                       dim_detail_code6
                  from (select repinst.repinst_id,
                               repinst.writer,
                               repinst.write_date,
                               repinst.checker,
                               indexinst.sta_index_inst_id,
                               indexinst.remark,
                               indexinst.index_code,
                               indexinst.index_value,
                               indexinst.COMPOSITED_INDEX_CODE,
                               indexinst.unit_code,
                               codelist.Code_Name              AS UNIT_NAME,
                               dimeninst.repinst_dtl_dimen     as repinst_dtl_dimen,
                               dimeninst.dim_code              as dim_code,
                               dimeninst.dim_detail_code       as dim_detail_code,
                               dimeninst1.repinst_dtl_dimen    as repinst_dtl_dimen1,
                               dimeninst1.dim_code             as dim_code1,
                               dimeninst1.dim_detail_code      as dim_detail_code1,
                               dimeninst2.repinst_dtl_dimen    as repinst_dtl_dimen2,
                               dimeninst2.dim_code             as dim_code2,
                               dimeninst2.dim_detail_code      as dim_detail_code2,
                               dimeninst3.repinst_dtl_dimen    as repinst_dtl_dimen3,
                               dimeninst3.dim_code             as dim_code3,
                               dimeninst3.dim_detail_code      as dim_detail_code3,
                               dimeninst4.repinst_dtl_dimen    as repinst_dtl_dimen4,
                               dimeninst4.dim_code             as dim_code4,
                               dimeninst4.dim_detail_code      as dim_detail_code4,
                               dimeninst5.repinst_dtl_dimen    as repinst_dtl_dimen5,
                               dimeninst5.dim_code             as dim_code5,
                               dimeninst5.dim_detail_code      as dim_detail_code5,
                               dimeninst6.repinst_dtl_dimen    as repinst_dtl_dimen6,
                               dimeninst6.dim_code             as dim_code6,
                               dimeninst6.dim_detail_code      as dim_detail_code6
                          from e7_sta_repinst repinst
                          left join e7_sta_rpt_index_inst rptindexinst
                            on repinst.repinst_id = rptindexinst.repinst_id
                          left join e7_sta_index_inst indexinst
                            on rptindexinst.sta_index_inst_id =
                               indexinst.sta_index_inst_id
                          left join e7_sta_index_inst_dimen dimeninst
                            on dimeninst.dim_code = 'Business_type'
                           and indexinst.sta_index_inst_id =
                               dimeninst.sta_index_inst_id
                          left join e7_sta_index_inst_dimen dimeninst1
                            on dimeninst1.dim_code = 'Province_type'
                           and indexinst.sta_index_inst_id =
                               dimeninst1.sta_index_inst_id
                          left join e7_sta_index_inst_dimen dimeninst2
                            on dimeninst2.dim_code = 'Assets_type'
                           and indexinst.sta_index_inst_id =
                               dimeninst2.sta_index_inst_id
                          left join e7_sta_index_inst_dimen dimeninst3
                            on dimeninst3.dim_code = 'Industry_type'
                           and indexinst.sta_index_inst_id =
                               dimeninst3.sta_index_inst_id
                          left join e7_sta_index_inst_dimen dimeninst4
                            on dimeninst4.dim_code = 'Cru_oil_E_cons_typ'
                           and indexinst.sta_index_inst_id =
                               dimeninst4.sta_index_inst_id
                          left join e7_sta_index_inst_dimen dimeninst5
                            on dimeninst5.dim_code = 'Custom_dimen_first'
                           and indexinst.sta_index_inst_id =
                               dimeninst5.sta_index_inst_id
                          left join e7_sta_index_inst_dimen dimeninst6
                            on dimeninst6.dim_code = 'Custom_dimen_second'
                           and indexinst.sta_index_inst_id =
                               dimeninst6.sta_index_inst_id
                          left join e7_sys_codelist codelist
                            on codelist.codelist_code = 'UNIT_CODE'
                           and indexinst.unit_code = codelist.code_value
                         where repinst.report_code = 'XNNW01'
                           and repinst.org_id =  P_RPTORGID
                           and repinst.report_year =  P_RPTYEAR
                           and repinst.report_month =  P_RPTMONTH
                         group by repinst.repinst_id,
                                  repinst.writer,
                                  repinst.write_date,
                                  repinst.checker,
                                  indexinst.sta_index_inst_id,
                                  indexinst.remark,
                                  indexinst.index_code,
                                  indexinst.index_value,
                                  indexinst.COMPOSITED_INDEX_CODE,
                                  indexinst.unit_code,
                                  codelist.Code_Name,
                                  dimeninst.repinst_dtl_dimen,
                                  dimeninst.dim_code,
                                  dimeninst.dim_detail_code,
                                  dimeninst1.repinst_dtl_dimen,
                                  dimeninst1.dim_code,
                                  dimeninst1.dim_detail_code,
                                  dimeninst2.repinst_dtl_dimen,
                                  dimeninst2.dim_code,
                                  dimeninst2.dim_detail_code,
                                  dimeninst3.repinst_dtl_dimen,
                                  dimeninst3.dim_code,
                                  dimeninst3.dim_detail_code,
                                  dimeninst4.repinst_dtl_dimen,
                                  dimeninst4.dim_code,
                                  dimeninst4.dim_detail_code,
                                  dimeninst5.repinst_dtl_dimen,
                                  dimeninst5.dim_code,
                                  dimeninst5.dim_detail_code,
                                  dimeninst6.repinst_dtl_dimen,
                                  dimeninst6.dim_code,
                                  dimeninst6.dim_detail_code

                        )
                 where index_code in ('Engy_csmp_amt_pratl',
                                      'Engy_csmp_amt_stadc',
                                      'Engy_csmp_cost')
                   and (dim_code4 in ('Cru_oil_E_cons_typ') or
                       dim_code4 is null))
         where composited_index_code is not null
           and dim_detail_code is not null
         group by repinst_id,
                  index_code,
                  dim_code,
                  dim_detail_code,
                  dim_code1,
                  dim_detail_code1,
                  dim_code2,
                  dim_detail_code2,
                  dim_code3,
                  dim_detail_code3,
                  dim_code4,
                  dim_detail_code4,
                  dim_code5,
                  dim_detail_code5,
                  dim_code6,
                  dim_detail_code6)
 where repinst_dtl_dimen6 is not null) where repinst_dtl_dimen6 <> 'XN6'
          );
           V_RPTINDEXINST E7_STA_RPT_INDEX_INST%ROWTYPE;
           V_INDEXINST E7_STA_INDEX_INST%ROWTYPE;
           V_INDEXINSTDIMEN E7_STA_INDEX_INST_DIMEN%ROWTYPE;
          begin
            DELDATASXNNW('XNNW01',P_RPTYEAR,P_RPTMONTH ,P_RPTORGID);
            FOR RPTINDEXINSTE IN RPTINDEXINST LOOP
                V_RPTINDEXINST.REPINST_ID :=  RPTINDEXINSTE.REPINST_ID;
                V_RPTINDEXINST.STA_INDEX_INST_ID := RPTINDEXINSTE.STA_INDEX_INST_ID;
                V_RPTINDEXINST.CREATE_TIME := RPTINDEXINSTE.CREATE_TIME;
                V_RPTINDEXINST.UPDATE_TIME := RPTINDEXINSTE.UPDATE_TIME;
                INSERT INTO E7_STA_RPT_INDEX_INST VALUES V_RPTINDEXINST;
             END LOOP;
             COMMIT;

             FOR INDEXINSTE IN INDEXINST LOOP
                V_INDEXINST.sta_index_inst_id    :=INDEXINSTE.sta_index_inst_id;
                V_INDEXINST.index_code           :=INDEXINSTE.index_code;
                V_INDEXINST.org_id               :=INDEXINSTE.org_id;
                V_INDEXINST.report_year          :=INDEXINSTE.report_year;
                V_INDEXINST.report_quarter       :=INDEXINSTE.report_quarter;
                V_INDEXINST.report_month         :=INDEXINSTE.report_month;
                V_INDEXINST.report_frequent_code :=INDEXINSTE.report_frequent_code;
                V_INDEXINST.index_value          :=INDEXINSTE.index_value;
                V_INDEXINST.unit_code            :=INDEXINSTE.unit_code;
                V_INDEXINST.remark               :=INDEXINSTE.remark;
                V_INDEXINST.index_inst_orderno   :=INDEXINSTE.index_inst_orderno;
                V_INDEXINST.composited_index_code:=INDEXINSTE.composited_index_code;
                V_INDEXINST.create_time          :=INDEXINSTE.create_time;
                V_INDEXINST.update_time          :=INDEXINSTE.update_time;
                INSERT INTO E7_STA_INDEX_INST VALUES V_INDEXINST;
             END LOOP;
             COMMIT;

             FOR INDEXINSTDIMENE IN INDEXINSTDIMEN LOOP
                V_INDEXINSTDIMEN.repinst_dtl_dimen :=INDEXINSTDIMENE.repinst_dtl_dimen;
                V_INDEXINSTDIMEN.sta_index_inst_id :=INDEXINSTDIMENE.sta_index_inst_id;
                V_INDEXINSTDIMEN.dim_code          :=INDEXINSTDIMENE.dim_code;
                V_INDEXINSTDIMEN.dim_detail_code   :=INDEXINSTDIMENE.dim_detail_code;
                V_INDEXINSTDIMEN.dim_source        :=INDEXINSTDIMENE.dim_source;
                V_INDEXINSTDIMEN.dim_deteail_id    :=INDEXINSTDIMENE.dim_deteail_id;
                V_INDEXINSTDIMEN.dim_deteail_id2   :=INDEXINSTDIMENE.dim_deteail_id2;
                V_INDEXINSTDIMEN.unit_code         :=INDEXINSTDIMENE.unit_code;
                V_INDEXINSTDIMEN.composite_dim_code:=INDEXINSTDIMENE.composite_dim_code;
                V_INDEXINSTDIMEN.create_time       :=INDEXINSTDIMENE.create_time;
                V_INDEXINSTDIMEN.update_time       :=INDEXINSTDIMENE.update_time;
                INSERT INTO E7_STA_INDEX_INST_DIMEN VALUES V_INDEXINSTDIMEN;
             END LOOP;
             COMMIT;
               EXCEPTION WHEN OTHERS THEN
                ROLLBACK;
           END;



           PROCEDURE DataM_RUNXNNW02(
     P_RPTYEAR IN VARCHAR2,
     P_RPTMONTH IN VARCHAR2,
     P_RPTORGID IN VARCHAR2)
     AS
      CURSOR RPTINDEXINST IS SELECT * FROM (with a as (
select repinst.repinst_id,
repinst.org_id,
                       indexinst.sta_index_inst_id,
                       indexinst.index_code,
                       indexinst.index_value,
                       indexinst.COMPOSITED_INDEX_CODE,
                       dimeninst.repinst_dtl_dimen     as repinst_dtl_dimen,
                       dimeninst.dim_code              as dim_code,
                       dimeninst.dim_detail_code       as dim_detail_code,
                       dimeninst1.repinst_dtl_dimen    as repinst_dtl_dimen1,
                       dimeninst1.dim_code             as dim_code1,
                       dimeninst1.dim_detail_code      as dim_detail_code1,
                       dimeninst2.repinst_dtl_dimen    as repinst_dtl_dimen2,
                       dimeninst2.dim_code             as dim_code2,
                       dimeninst2.dim_detail_code      as dim_detail_code2,
                       dimeninst3.repinst_dtl_dimen    as repinst_dtl_dimen3,
                       dimeninst3.dim_code             as dim_code3,
                       dimeninst3.dim_detail_code      as dim_detail_code3,
                       dimeninst4.repinst_dtl_dimen    as repinst_dtl_dimen4,
                       dimeninst4.dim_code             as dim_code4,
                       dimeninst4.dim_detail_code      as dim_detail_code4,
                       dimeninst5.repinst_dtl_dimen    as repinst_dtl_dimen5,
                       dimeninst5.dim_code             as dim_code5,
                       dimeninst5.dim_detail_code      as dim_detail_code5,
                       dimeninst6.repinst_dtl_dimen    as repinst_dtl_dimen6,
                       dimeninst6.dim_code             as dim_code6,
                       dimeninst6.dim_detail_code      as dim_detail_code6
                  from e7_sta_repinst repinst
                  left join e7_sta_rpt_index_inst rptindexinst
                    on repinst.repinst_id = rptindexinst.repinst_id
                  left join e7_sta_index_inst indexinst
                    on rptindexinst.sta_index_inst_id =
                       indexinst.sta_index_inst_id
                  left join e7_sta_index_inst_dimen dimeninst
                    on dimeninst.dim_code = 'Business_type'
                   and indexinst.sta_index_inst_id =
                       dimeninst.sta_index_inst_id
                  left join e7_sta_index_inst_dimen dimeninst1
                    on dimeninst1.dim_code = 'Province_type'
                   and indexinst.sta_index_inst_id =
                       dimeninst1.sta_index_inst_id
                  left join e7_sta_index_inst_dimen dimeninst2
                    on dimeninst2.dim_code = 'Assets_type'
                   and indexinst.sta_index_inst_id =
                       dimeninst2.sta_index_inst_id
                  left join e7_sta_index_inst_dimen dimeninst3
                    on dimeninst3.dim_code = 'Industry_type'
                   and indexinst.sta_index_inst_id =
                       dimeninst3.sta_index_inst_id
                  left join e7_sta_index_inst_dimen dimeninst4
                    on dimeninst4.dim_code = 'Cru_oil_E_cons_typ'
                   and indexinst.sta_index_inst_id =
                       dimeninst4.sta_index_inst_id
                  left join e7_sta_index_inst_dimen dimeninst5
                    on dimeninst5.dim_code = 'Custom_dimen_first'
                   and indexinst.sta_index_inst_id =
                       dimeninst5.sta_index_inst_id
                  left join e7_sta_index_inst_dimen dimeninst6
                    on dimeninst6.dim_code = 'Custom_dimen_second'
                   and indexinst.sta_index_inst_id =
                       dimeninst6.sta_index_inst_id

                 where repinst.report_code in( 'XNNW01','XNNW02')
                   and repinst.report_year =   P_RPTYEAR
                   and repinst.report_month =   P_RPTMONTH
                   and indexinst.COMPOSITED_INDEX_CODE in (select org_id from e7_sys_org where parent_org_id = P_RPTORGID)
                   group by
                       repinst.repinst_id,
                       repinst.org_id,
                       indexinst.sta_index_inst_id,
                       indexinst.remark,
                       indexinst.index_code,
                       indexinst.index_value,
                       indexinst.COMPOSITED_INDEX_CODE,
                       dimeninst.repinst_dtl_dimen,
                       dimeninst.dim_code,
                       dimeninst.dim_detail_code,
                       dimeninst1.repinst_dtl_dimen ,
                       dimeninst1.dim_code          ,
                       dimeninst1.dim_detail_code    ,
                       dimeninst2.repinst_dtl_dimen  ,
                       dimeninst2.dim_code           ,
                       dimeninst2.dim_detail_code    ,
                       dimeninst3.repinst_dtl_dimen  ,
                       dimeninst3.dim_code           ,
                       dimeninst3.dim_detail_code    ,
                       dimeninst4.repinst_dtl_dimen  ,
                       dimeninst4.dim_code           ,
                       dimeninst4.dim_detail_code    ,
                       dimeninst5.repinst_dtl_dimen   ,
                       dimeninst5.dim_code           ,
                       dimeninst5.dim_detail_code    ,
                       dimeninst6.repinst_dtl_dimen  ,
                       dimeninst6.dim_code          ,
                       dimeninst6.dim_detail_code
                       ),
                       repinstid as (
                                 select repinst_id from e7_sta_repinst where org_id =P_RPTORGID and report_year =P_RPTYEAR and report_month = P_RPTMONTH and report_code = 'XNNW02'
                       ),
                      
                       res3 as (
                       
                       
                       select 
                        max(repinstid.repinst_id) as repinst_id ,
                       to_number(P_RPTORGID) as org_id,
                       max(sta_index_inst_id)||'XN' as sta_index_inst_id,
                       max(index_code) as index_code,
                       sum(index_value) as index_value,
                       to_char(P_RPTORGID) as composited_index_code,
                       max(repinst_dtl_dimen)||'XN' as repinst_dtl_dimen,
                       dim_code,
                       dim_detail_code,
                        max(repinst_dtl_dimen1)||'XN1' as repinst_dtl_dimen1,
                       dim_code1,
                       dim_detail_code1,
                        max(repinst_dtl_dimen2)||'XN2' as repinst_dtl_dimen2,
                       dim_code2,
                       dim_detail_code2,
                        max(repinst_dtl_dimen3)||'XN3' as repinst_dtl_dimen3,
                       dim_code3,
                       dim_detail_code3,
                        max(repinst_dtl_dimen4)||'XN4' as repinst_dtl_dimen4,
                       dim_code4,
                       dim_detail_code4,
                        max(repinst_dtl_dimen5)||'XN5' as repinst_dtl_dimen5,
                       dim_code5,
                       dim_detail_code5,
                        max(repinst_dtl_dimen6)||'XN6' as repinst_dtl_dimen6,
                       dim_code6,
                       dim_detail_code6
                       from a,repinstid
                       group by 
                       index_code,
                       dim_code,
                       dim_detail_code,
                       dim_code1,
                       dim_detail_code1,
                       dim_code2,
                       dim_detail_code2,
                       dim_code3,
                       dim_detail_code3,
                       dim_code4,
                       dim_detail_code4,
                       dim_code5,
                       dim_detail_code5,
                       dim_code6,
                       dim_detail_code6
                       
                       ),
                       resr as (
                        select * from res3)

          --sta_rpt_index_inst
          select 
          repinst_id,
          sta_index_inst_id,
          sysdate create_time,
          sysdate update_time 
          from resr);

          CURSOR INDEXINST IS SELECT * from (with a as (
select repinst.repinst_id,
repinst.org_id,
                       indexinst.sta_index_inst_id,
                       indexinst.index_code,
                       indexinst.index_value,
                       indexinst.COMPOSITED_INDEX_CODE,
                       dimeninst.repinst_dtl_dimen     as repinst_dtl_dimen,
                       dimeninst.dim_code              as dim_code,
                       dimeninst.dim_detail_code       as dim_detail_code,
                       dimeninst1.repinst_dtl_dimen    as repinst_dtl_dimen1,
                       dimeninst1.dim_code             as dim_code1,
                       dimeninst1.dim_detail_code      as dim_detail_code1,
                       dimeninst2.repinst_dtl_dimen    as repinst_dtl_dimen2,
                       dimeninst2.dim_code             as dim_code2,
                       dimeninst2.dim_detail_code      as dim_detail_code2,
                       dimeninst3.repinst_dtl_dimen    as repinst_dtl_dimen3,
                       dimeninst3.dim_code             as dim_code3,
                       dimeninst3.dim_detail_code      as dim_detail_code3,
                       dimeninst4.repinst_dtl_dimen    as repinst_dtl_dimen4,
                       dimeninst4.dim_code             as dim_code4,
                       dimeninst4.dim_detail_code      as dim_detail_code4,
                       dimeninst5.repinst_dtl_dimen    as repinst_dtl_dimen5,
                       dimeninst5.dim_code             as dim_code5,
                       dimeninst5.dim_detail_code      as dim_detail_code5,
                       dimeninst6.repinst_dtl_dimen    as repinst_dtl_dimen6,
                       dimeninst6.dim_code             as dim_code6,
                       dimeninst6.dim_detail_code      as dim_detail_code6
                  from e7_sta_repinst repinst
                  left join e7_sta_rpt_index_inst rptindexinst
                    on repinst.repinst_id = rptindexinst.repinst_id
                  left join e7_sta_index_inst indexinst
                    on rptindexinst.sta_index_inst_id =
                       indexinst.sta_index_inst_id
                  left join e7_sta_index_inst_dimen dimeninst
                    on dimeninst.dim_code = 'Business_type'
                   and indexinst.sta_index_inst_id =
                       dimeninst.sta_index_inst_id
                  left join e7_sta_index_inst_dimen dimeninst1
                    on dimeninst1.dim_code = 'Province_type'
                   and indexinst.sta_index_inst_id =
                       dimeninst1.sta_index_inst_id
                  left join e7_sta_index_inst_dimen dimeninst2
                    on dimeninst2.dim_code = 'Assets_type'
                   and indexinst.sta_index_inst_id =
                       dimeninst2.sta_index_inst_id
                  left join e7_sta_index_inst_dimen dimeninst3
                    on dimeninst3.dim_code = 'Industry_type'
                   and indexinst.sta_index_inst_id =
                       dimeninst3.sta_index_inst_id
                  left join e7_sta_index_inst_dimen dimeninst4
                    on dimeninst4.dim_code = 'Cru_oil_E_cons_typ'
                   and indexinst.sta_index_inst_id =
                       dimeninst4.sta_index_inst_id
                  left join e7_sta_index_inst_dimen dimeninst5
                    on dimeninst5.dim_code = 'Custom_dimen_first'
                   and indexinst.sta_index_inst_id =
                       dimeninst5.sta_index_inst_id
                  left join e7_sta_index_inst_dimen dimeninst6
                    on dimeninst6.dim_code = 'Custom_dimen_second'
                   and indexinst.sta_index_inst_id =
                       dimeninst6.sta_index_inst_id

                 where repinst.report_code in( 'XNNW01','XNNW02')
                   and repinst.report_year =   P_RPTYEAR
                   and repinst.report_month =   P_RPTMONTH
                   and indexinst.COMPOSITED_INDEX_CODE in (select org_id from e7_sys_org where parent_org_id = P_RPTORGID)
                   group by
                       repinst.repinst_id,
                       repinst.org_id,
                       indexinst.sta_index_inst_id,
                       indexinst.remark,
                       indexinst.index_code,
                       indexinst.index_value,
                       indexinst.COMPOSITED_INDEX_CODE,
                       dimeninst.repinst_dtl_dimen,
                       dimeninst.dim_code,
                       dimeninst.dim_detail_code,
                       dimeninst1.repinst_dtl_dimen ,
                       dimeninst1.dim_code          ,
                       dimeninst1.dim_detail_code    ,
                       dimeninst2.repinst_dtl_dimen  ,
                       dimeninst2.dim_code           ,
                       dimeninst2.dim_detail_code    ,
                       dimeninst3.repinst_dtl_dimen  ,
                       dimeninst3.dim_code           ,
                       dimeninst3.dim_detail_code    ,
                       dimeninst4.repinst_dtl_dimen  ,
                       dimeninst4.dim_code           ,
                       dimeninst4.dim_detail_code    ,
                       dimeninst5.repinst_dtl_dimen   ,
                       dimeninst5.dim_code           ,
                       dimeninst5.dim_detail_code    ,
                       dimeninst6.repinst_dtl_dimen  ,
                       dimeninst6.dim_code          ,
                       dimeninst6.dim_detail_code
                       ),
                       repinstid as (
                                 select repinst_id from e7_sta_repinst where org_id =P_RPTORGID and report_year =P_RPTYEAR and report_month = P_RPTMONTH AND REPORT_CODE = 'XNNW02'
                       ),
                       
                       res3 as (
                       
                       
                       select 
                        max(repinstid.repinst_id) as repinst_id ,
                       to_number(P_RPTORGID) as org_id,
                       max(sta_index_inst_id)||'XN' as sta_index_inst_id,
                       max(index_code) as index_code,
                       sum(index_value) as index_value,
                       to_char(P_RPTORGID) as composited_index_code,
                       max(repinst_dtl_dimen)||'XN' as repinst_dtl_dimen,
                       dim_code,
                       dim_detail_code,
                        max(repinst_dtl_dimen1)||'XN1' as repinst_dtl_dimen1,
                       dim_code1,
                       dim_detail_code1,
                        max(repinst_dtl_dimen2)||'XN2' as repinst_dtl_dimen2,
                       dim_code2,
                       dim_detail_code2,
                        max(repinst_dtl_dimen3)||'XN3' as repinst_dtl_dimen3,
                       dim_code3,
                       dim_detail_code3,
                        max(repinst_dtl_dimen4)||'XN4' as repinst_dtl_dimen4,
                       dim_code4,
                       dim_detail_code4,
                        max(repinst_dtl_dimen5)||'XN5' as repinst_dtl_dimen5,
                       dim_code5,
                       dim_detail_code5,
                        max(repinst_dtl_dimen6)||'XN6' as repinst_dtl_dimen6,
                       dim_code6,
                       dim_detail_code6
                       from a,repinstid
                       group by 
                       index_code,
                       dim_code,
                       dim_detail_code,
                       dim_code1,
                       dim_detail_code1,
                       dim_code2,
                       dim_detail_code2,
                       dim_code3,
                       dim_detail_code3,
                       dim_code4,
                       dim_detail_code4,
                       dim_code5,
                       dim_detail_code5,
                       dim_code6,
                       dim_detail_code6
                       
                       ),
                       resr as (
                        select * from res3)

          --sta_rpt_index_inst
/*          select 
          repinst_id,
          sta_index_inst_id,
          sysdate create_time,
          sysdate update_time 
          from resr*/
--e7_sta_index_inst
select 
sta_index_inst_id,
index_code,
org_id,
to_number(P_RPTYEAR) as report_year,
to_char(to_date(P_RPTYEAR||P_RPTMONTH,'yyyyMM'),'Q') as report_quarter,
P_RPTMONTH as report_month,
3 as report_frequent_code,
index_value,
null as unit_code,
null as remark,
null as index_inst_orderno,
composited_index_code as composited_index_code,
sysdate as create_time,
sysdate as update_time
from resr
                   
);
          CURSOR INDEXINSTDIMEN IS SELECT * from (with a as (
select repinst.repinst_id,
repinst.org_id,
                       indexinst.sta_index_inst_id,
                       indexinst.index_code,
                       indexinst.index_value,
                       indexinst.COMPOSITED_INDEX_CODE,
                       dimeninst.repinst_dtl_dimen     as repinst_dtl_dimen,
                       dimeninst.dim_code              as dim_code,
                       dimeninst.dim_detail_code       as dim_detail_code,
                       dimeninst1.repinst_dtl_dimen    as repinst_dtl_dimen1,
                       dimeninst1.dim_code             as dim_code1,
                       dimeninst1.dim_detail_code      as dim_detail_code1,
                       dimeninst2.repinst_dtl_dimen    as repinst_dtl_dimen2,
                       dimeninst2.dim_code             as dim_code2,
                       dimeninst2.dim_detail_code      as dim_detail_code2,
                       dimeninst3.repinst_dtl_dimen    as repinst_dtl_dimen3,
                       dimeninst3.dim_code             as dim_code3,
                       dimeninst3.dim_detail_code      as dim_detail_code3,
                       dimeninst4.repinst_dtl_dimen    as repinst_dtl_dimen4,
                       dimeninst4.dim_code             as dim_code4,
                       dimeninst4.dim_detail_code      as dim_detail_code4,
                       dimeninst5.repinst_dtl_dimen    as repinst_dtl_dimen5,
                       dimeninst5.dim_code             as dim_code5,
                       dimeninst5.dim_detail_code      as dim_detail_code5,
                       dimeninst6.repinst_dtl_dimen    as repinst_dtl_dimen6,
                       dimeninst6.dim_code             as dim_code6,
                       dimeninst6.dim_detail_code      as dim_detail_code6
                  from e7_sta_repinst repinst
                  left join e7_sta_rpt_index_inst rptindexinst
                    on repinst.repinst_id = rptindexinst.repinst_id
                  left join e7_sta_index_inst indexinst
                    on rptindexinst.sta_index_inst_id =
                       indexinst.sta_index_inst_id
                  left join e7_sta_index_inst_dimen dimeninst
                    on dimeninst.dim_code = 'Business_type'
                   and indexinst.sta_index_inst_id =
                       dimeninst.sta_index_inst_id
                  left join e7_sta_index_inst_dimen dimeninst1
                    on dimeninst1.dim_code = 'Province_type'
                   and indexinst.sta_index_inst_id =
                       dimeninst1.sta_index_inst_id
                  left join e7_sta_index_inst_dimen dimeninst2
                    on dimeninst2.dim_code = 'Assets_type'
                   and indexinst.sta_index_inst_id =
                       dimeninst2.sta_index_inst_id
                  left join e7_sta_index_inst_dimen dimeninst3
                    on dimeninst3.dim_code = 'Industry_type'
                   and indexinst.sta_index_inst_id =
                       dimeninst3.sta_index_inst_id
                  left join e7_sta_index_inst_dimen dimeninst4
                    on dimeninst4.dim_code = 'Cru_oil_E_cons_typ'
                   and indexinst.sta_index_inst_id =
                       dimeninst4.sta_index_inst_id
                  left join e7_sta_index_inst_dimen dimeninst5
                    on dimeninst5.dim_code = 'Custom_dimen_first'
                   and indexinst.sta_index_inst_id =
                       dimeninst5.sta_index_inst_id
                  left join e7_sta_index_inst_dimen dimeninst6
                    on dimeninst6.dim_code = 'Custom_dimen_second'
                   and indexinst.sta_index_inst_id =
                       dimeninst6.sta_index_inst_id

                 where repinst.report_code in( 'XNNW01','XNNW02')
                   and repinst.report_year =   P_RPTYEAR
                   and repinst.report_month =   P_RPTMONTH
                   and indexinst.COMPOSITED_INDEX_CODE in (select org_id from e7_sys_org where parent_org_id = P_RPTORGID)
                   group by
                       repinst.repinst_id,
                       repinst.org_id,
                       indexinst.sta_index_inst_id,
                       indexinst.remark,
                       indexinst.index_code,
                       indexinst.index_value,
                       indexinst.COMPOSITED_INDEX_CODE,
                       dimeninst.repinst_dtl_dimen,
                       dimeninst.dim_code,
                       dimeninst.dim_detail_code,
                       dimeninst1.repinst_dtl_dimen ,
                       dimeninst1.dim_code          ,
                       dimeninst1.dim_detail_code    ,
                       dimeninst2.repinst_dtl_dimen  ,
                       dimeninst2.dim_code           ,
                       dimeninst2.dim_detail_code    ,
                       dimeninst3.repinst_dtl_dimen  ,
                       dimeninst3.dim_code           ,
                       dimeninst3.dim_detail_code    ,
                       dimeninst4.repinst_dtl_dimen  ,
                       dimeninst4.dim_code           ,
                       dimeninst4.dim_detail_code    ,
                       dimeninst5.repinst_dtl_dimen   ,
                       dimeninst5.dim_code           ,
                       dimeninst5.dim_detail_code    ,
                       dimeninst6.repinst_dtl_dimen  ,
                       dimeninst6.dim_code          ,
                       dimeninst6.dim_detail_code
                       ),
                       repinstid as (
                                 select repinst_id from e7_sta_repinst where org_id =P_RPTORGID and report_year =P_RPTYEAR and report_month = P_RPTMONTH AND REPORT_CODE = 'XNNW02'
                       ),
                       
                       res3 as (
                       
                       
                       select 
                        max(repinstid.repinst_id) as repinst_id ,
                       to_number(P_RPTORGID) as org_id,
                       max(sta_index_inst_id)||'XN' as sta_index_inst_id,
                       max(index_code) as index_code,
                       sum(index_value) as index_value,
                       to_char(P_RPTORGID) as composited_index_code,
                       max(repinst_dtl_dimen)||'XN' as repinst_dtl_dimen,
                       dim_code,
                       dim_detail_code,
                        max(repinst_dtl_dimen1)||'XN1' as repinst_dtl_dimen1,
                       dim_code1,
                       dim_detail_code1,
                        max(repinst_dtl_dimen2)||'XN2' as repinst_dtl_dimen2,
                       dim_code2,
                       dim_detail_code2,
                        max(repinst_dtl_dimen3)||'XN3' as repinst_dtl_dimen3,
                       dim_code3,
                       dim_detail_code3,
                        max(repinst_dtl_dimen4)||'XN4' as repinst_dtl_dimen4,
                       dim_code4,
                       dim_detail_code4,
                        max(repinst_dtl_dimen5)||'XN5' as repinst_dtl_dimen5,
                       dim_code5,
                       dim_detail_code5,
                        max(repinst_dtl_dimen6)||'XN6' as repinst_dtl_dimen6,
                       dim_code6,
                       dim_detail_code6
                       from a,repinstid
                       group by 
                       index_code,
                       dim_code,
                       dim_detail_code,
                       dim_code1,
                       dim_detail_code1,
                       dim_code2,
                       dim_detail_code2,
                       dim_code3,
                       dim_detail_code3,
                       dim_code4,
                       dim_detail_code4,
                       dim_code5,
                       dim_detail_code5,
                       dim_code6,
                       dim_detail_code6
                       
                       ),
                       resr as (
                       select * from res3)


select repinst_dtl_dimen,
sta_index_inst_id,
dim_code,
dim_detail_code,
null as dim_source,
null as dim_deteail_id,
null as dim_deteail_id2,
null as unit_code,
composited_index_code AS composite_dim_code,
sysdate as create_time,
sysdate as update_time
from resr where repinst_dtl_dimen <> 'XN' AND repinst_dtl_dimen <> 'XNXN'
UNION ALL
select repinst_dtl_dimen1,
sta_index_inst_id,
dim_code1,
dim_detail_code1,
null as dim_source,
null as dim_deteail_id,
null as dim_deteail_id2,
null as unit_code,
composited_index_code AS composite_dim_code,
sysdate as create_time,
sysdate as update_time
from resr where repinst_dtl_dimen1 <> 'XN1' AND repinst_dtl_dimen1 <> 'XN1XN1'
UNION ALL
select repinst_dtl_dimen2,
sta_index_inst_id,
dim_code2,
dim_detail_code2,
null as dim_source,
null as dim_deteail_id,
null as dim_deteail_id2,
null as unit_code,
composited_index_code AS composite_dim_code,
sysdate as create_time,
sysdate as update_time
from resr where repinst_dtl_dimen2 <> 'XN2' AND repinst_dtl_dimen2 <> 'XN2XN2'
UNION ALL
select repinst_dtl_dimen3,
sta_index_inst_id,
dim_code3,
dim_detail_code3,
null as dim_source,
null as dim_deteail_id,
null as dim_deteail_id2,
null as unit_code,
composited_index_code AS composite_dim_code,
sysdate as create_time,
sysdate as update_time
from resr where repinst_dtl_dimen3 <> 'XN3' AND repinst_dtl_dimen3 <> 'XN3XN3'
UNION ALL
select repinst_dtl_dimen4,
sta_index_inst_id,
dim_code4,
dim_detail_code4,
null as dim_source,
null as dim_deteail_id,
null as dim_deteail_id2,
null as unit_code,
composited_index_code AS composite_dim_code,
sysdate as create_time,
sysdate as update_time
from resr where repinst_dtl_dimen4 <> 'XN4' AND repinst_dtl_dimen4 <> 'XN4XN4'
UNION ALL
select repinst_dtl_dimen5,
sta_index_inst_id,
dim_code5,
dim_detail_code5,
null as dim_source,
null as dim_deteail_id,
null as dim_deteail_id2,
null as unit_code,
composited_index_code AS composite_dim_code,
sysdate as create_time,
sysdate as update_time
from resr where repinst_dtl_dimen5 <> 'XN5' AND repinst_dtl_dimen5 <> 'XN5XN5'
UNION ALL
select repinst_dtl_dimen6,
sta_index_inst_id,
dim_code6,
dim_detail_code6,
null as dim_source,
null as dim_deteail_id,
null as dim_deteail_id2,
null as unit_code,
composited_index_code AS composite_dim_code,
sysdate as create_time,
sysdate as update_time
from resr where repinst_dtl_dimen6 <> 'XN6' AND repinst_dtl_dimen6 <> 'XN6XN6');
 
           V_RPTINDEXINST E7_STA_RPT_INDEX_INST%ROWTYPE;
           V_INDEXINST E7_STA_INDEX_INST%ROWTYPE;
           V_INDEXINSTDIMEN E7_STA_INDEX_INST_DIMEN%ROWTYPE;
          begin
            DELDATASXNNW('XNNW02',P_RPTYEAR,P_RPTMONTH ,P_RPTORGID);
            FOR RPTINDEXINSTE IN RPTINDEXINST LOOP
                V_RPTINDEXINST.REPINST_ID :=  RPTINDEXINSTE.REPINST_ID;
                V_RPTINDEXINST.STA_INDEX_INST_ID := RPTINDEXINSTE.STA_INDEX_INST_ID;
                V_RPTINDEXINST.CREATE_TIME := RPTINDEXINSTE.CREATE_TIME;
                V_RPTINDEXINST.UPDATE_TIME := RPTINDEXINSTE.UPDATE_TIME;
                INSERT INTO E7_STA_RPT_INDEX_INST VALUES V_RPTINDEXINST;
             END LOOP;
             COMMIT;

             FOR INDEXINSTE IN INDEXINST LOOP
                V_INDEXINST.sta_index_inst_id    :=INDEXINSTE.sta_index_inst_id;
                V_INDEXINST.index_code           :=INDEXINSTE.index_code;
                V_INDEXINST.org_id               :=INDEXINSTE.org_id;
                V_INDEXINST.report_year          :=INDEXINSTE.report_year;
                V_INDEXINST.report_quarter       :=INDEXINSTE.report_quarter;
                V_INDEXINST.report_month         :=INDEXINSTE.report_month;
                V_INDEXINST.report_frequent_code :=INDEXINSTE.report_frequent_code;
                V_INDEXINST.index_value          :=INDEXINSTE.index_value;
                V_INDEXINST.unit_code            :=INDEXINSTE.unit_code;
                V_INDEXINST.remark               :=INDEXINSTE.remark;
                V_INDEXINST.index_inst_orderno   :=INDEXINSTE.index_inst_orderno;
                V_INDEXINST.composited_index_code:=INDEXINSTE.composited_index_code;
                V_INDEXINST.create_time          :=INDEXINSTE.create_time;
                V_INDEXINST.update_time          :=INDEXINSTE.update_time;
                INSERT INTO E7_STA_INDEX_INST VALUES V_INDEXINST;
             END LOOP;
             COMMIT;

             FOR INDEXINSTDIMENE IN INDEXINSTDIMEN LOOP
                V_INDEXINSTDIMEN.repinst_dtl_dimen :=INDEXINSTDIMENE.repinst_dtl_dimen;
                V_INDEXINSTDIMEN.sta_index_inst_id :=INDEXINSTDIMENE.sta_index_inst_id;
                V_INDEXINSTDIMEN.dim_code          :=INDEXINSTDIMENE.dim_code;
                V_INDEXINSTDIMEN.dim_detail_code   :=INDEXINSTDIMENE.dim_detail_code;
                V_INDEXINSTDIMEN.dim_source        :=INDEXINSTDIMENE.dim_source;
                V_INDEXINSTDIMEN.dim_deteail_id    :=INDEXINSTDIMENE.dim_deteail_id;
                V_INDEXINSTDIMEN.dim_deteail_id2   :=INDEXINSTDIMENE.dim_deteail_id2;
                V_INDEXINSTDIMEN.unit_code         :=INDEXINSTDIMENE.unit_code;
                V_INDEXINSTDIMEN.composite_dim_code:=INDEXINSTDIMENE.composite_dim_code;
                V_INDEXINSTDIMEN.create_time       :=INDEXINSTDIMENE.create_time;
                V_INDEXINSTDIMEN.update_time       :=INDEXINSTDIMENE.update_time;
                INSERT INTO E7_STA_INDEX_INST_DIMEN VALUES V_INDEXINSTDIMEN;
             END LOOP;
             COMMIT;
               EXCEPTION WHEN OTHERS THEN
                ROLLBACK;
           END;

PROCEDURE DataQYXNNW01(P_RPTCODE  IN VARCHAR2,
                         P_RPTYEAR  IN VARCHAR2,
                         P_RPTMONTH IN VARCHAR2,
                         P_RPTORGID IN VARCHAR2) AS
           CURSOR RESR IS SELECT * FROM (
      with a as
       (select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'rqTotal' index_code,
               rqTotal index_value
          from Data_NHTZ WHERE TJNY = P_RPTYEAR||lpad(P_RPTMONTH, 2, 0)
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'rqUsedTotal' index_code,
               rqUsedTotal index_value
          from Data_NHTZ WHERE TJNY = P_RPTYEAR||lpad(P_RPTMONTH, 2, 0)
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'rqRLZY' index_code,
               rqRLZY index_value
          from Data_NHTZ WHERE TJNY = P_RPTYEAR||lpad(P_RPTMONTH, 2, 0)
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'rqYLZY' index_code,
               rqYLZY index_value
          from Data_NHTZ WHERE TJNY = P_RPTYEAR||lpad(P_RPTMONTH, 2, 0)
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'rqJGZH' index_code,
               rqJGZH index_value
          from Data_NHTZ WHERE TJNY = P_RPTYEAR||lpad(P_RPTMONTH, 2, 0)
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'rqYSXF' index_code,
               rqYSXF index_value
          from Data_NHTZ WHERE TJNY = P_RPTYEAR||lpad(P_RPTMONTH, 2, 0)
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'rqUsedMoney' index_code,
               rqUsedMoney index_value
          from Data_NHTZ WHERE TJNY = P_RPTYEAR||lpad(P_RPTMONTH, 2, 0)
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'rqWastTotal' index_code,
               rqWastTotal index_value
          from Data_NHTZ WHERE TJNY = P_RPTYEAR||lpad(P_RPTMONTH, 2, 0)
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'rqSS' index_code,
               rqSS index_value
          from Data_NHTZ WHERE TJNY = P_RPTYEAR||lpad(P_RPTMONTH, 2, 0)
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'rqFK' index_code,
               rqFK index_value
          from Data_NHTZ WHERE TJNY = P_RPTYEAR||lpad(P_RPTMONTH, 2, 0)
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'rqWastMoney' index_code,
               rqWastMoney index_value
          from Data_NHTZ WHERE TJNY = P_RPTYEAR||lpad(P_RPTMONTH, 2, 0)
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'dTotal' index_code,
               dTotal index_value
          from Data_NHTZ WHERE TJNY = P_RPTYEAR||lpad(P_RPTMONTH, 2, 0)
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'dUsedTotal' index_code,
               dUsedTotal index_value
          from Data_NHTZ WHERE TJNY = P_RPTYEAR||lpad(P_RPTMONTH, 2, 0)
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'dWastTotal' index_code,
               dWastTotal index_value
          from Data_NHTZ WHERE TJNY = P_RPTYEAR||lpad(P_RPTMONTH, 2, 0)
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'dTotalMoney' index_code,
               dTotalMoney index_value
          from Data_NHTZ WHERE TJNY = P_RPTYEAR||lpad(P_RPTMONTH, 2, 0)
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'mUsedTotal' index_code,
               mUsedTotal index_value
          from Data_NHTZ WHERE TJNY = P_RPTYEAR||lpad(P_RPTMONTH, 2, 0)
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'mTotalMoney' index_code,
               mTotalMoney index_value
          from Data_NHTZ WHERE TJNY = P_RPTYEAR||lpad(P_RPTMONTH, 2, 0)
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'yyTotal' index_code,
               yyTotal index_value
          from Data_NHTZ WHERE TJNY = P_RPTYEAR||lpad(P_RPTMONTH, 2, 0)
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'yyUsedTotal' index_code,
               yyUsedTotal index_value
          from Data_NHTZ WHERE TJNY = P_RPTYEAR||lpad(P_RPTMONTH, 2, 0)
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'yyUsedMoney' index_code,
               yyUsedMoney index_value
          from Data_NHTZ WHERE TJNY = P_RPTYEAR||lpad(P_RPTMONTH, 2, 0)
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'yyWastTotal' index_code,
               yyWastTotal index_value
          from Data_NHTZ WHERE TJNY = P_RPTYEAR||lpad(P_RPTMONTH, 2, 0)
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'yyWastMoney' index_code,
               yyWastMoney index_value
          from Data_NHTZ WHERE TJNY = P_RPTYEAR||lpad(P_RPTMONTH, 2, 0)
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'qyBuyTotal' index_code,
               qyBuyTotal index_value
          from Data_NHTZ WHERE TJNY = P_RPTYEAR||lpad(P_RPTMONTH, 2, 0)
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'qyBuyMoney' index_code,
               qyBuyMoney index_value
          from Data_NHTZ WHERE TJNY = P_RPTYEAR||lpad(P_RPTMONTH, 2, 0)
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'qyUsedTotal' index_code,
               qyUsedTotal index_value
          from Data_NHTZ WHERE TJNY = P_RPTYEAR||lpad(P_RPTMONTH, 2, 0)
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'qyYSUsedTotal' index_code,
               qyYSUsedTotal index_value
          from Data_NHTZ WHERE TJNY = P_RPTYEAR||lpad(P_RPTMONTH, 2, 0)
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'qyUsedMoney' index_code,
               qyUsedMoney index_value
          from Data_NHTZ WHERE TJNY = P_RPTYEAR||lpad(P_RPTMONTH, 2, 0)
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'cyBuyTotal' index_code,
               cyBuyTotal index_value
          from Data_NHTZ WHERE TJNY = P_RPTYEAR||lpad(P_RPTMONTH, 2, 0)
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'cyBuyMoney' index_code,
               cyBuyMoney index_value
          from Data_NHTZ WHERE TJNY = P_RPTYEAR||lpad(P_RPTMONTH, 2, 0)
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'cyUsedTotal' index_code,
               cyUsedTotal index_value
          from Data_NHTZ WHERE TJNY = P_RPTYEAR||lpad(P_RPTMONTH, 2, 0)
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'cyYSUsedTotal' index_code,
               cyYSUsedTotal index_value
          from Data_NHTZ WHERE TJNY = P_RPTYEAR||lpad(P_RPTMONTH, 2, 0)
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'cyUsedMoney' index_code,
               cyUsedMoney index_value
          from Data_NHTZ WHERE TJNY = P_RPTYEAR||lpad(P_RPTMONTH, 2, 0)
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'zyUsedTotal' index_code,
               zyUsedTotal index_value
          from Data_NHTZ WHERE TJNY = P_RPTYEAR||lpad(P_RPTMONTH, 2, 0)
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'zyUsedMoney' index_code,
               zyUsedMoney index_value
          from Data_NHTZ WHERE TJNY = P_RPTYEAR||lpad(P_RPTMONTH, 2, 0)
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'gqUsedTotal' index_code,
               gqUsedTotal index_value
          from Data_NHTZ WHERE TJNY = P_RPTYEAR||lpad(P_RPTMONTH, 2, 0)
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'gqUsedMoney' index_code,
               gqUsedMoney index_value
          from Data_NHTZ WHERE TJNY = P_RPTYEAR||lpad(P_RPTMONTH, 2, 0)
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'sjUsedTotal' index_code,
               sjUsedTotal index_value
          from Data_NHTZ WHERE TJNY = P_RPTYEAR||lpad(P_RPTMONTH, 2, 0)
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'sjUsedMoney' index_code,
               sjUsedMoney index_value
          from Data_NHTZ WHERE TJNY = P_RPTYEAR||lpad(P_RPTMONTH, 2, 0)
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'qtUsedTotal' index_code,
               qtUsedTotal index_value
          from Data_NHTZ WHERE TJNY = P_RPTYEAR||lpad(P_RPTMONTH, 2, 0)
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'qtUsedMoney' index_code,
               qtUsedMoney index_value
          from Data_NHTZ WHERE TJNY = P_RPTYEAR||lpad(P_RPTMONTH, 2, 0)
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'zlWaterTotal' index_code,
               zlWaterTotal*1 index_value
          from Data_NHTZ WHERE TJNY = P_RPTYEAR||lpad(P_RPTMONTH, 2, 0)
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'zlWaterUsedTotal' index_code,
               zlWaterUsedTotal*1 index_value
          from Data_NHTZ WHERE TJNY = P_RPTYEAR||lpad(P_RPTMONTH, 2, 0)
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'zlWaterWastTotal' index_code,
               zlWaterWastTotal*1 index_value
          from Data_NHTZ WHERE TJNY = P_RPTYEAR||lpad(P_RPTMONTH, 2, 0)
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'zlWaterTotalMoney' index_code,
               zlWaterTotalMoney index_value
          from Data_NHTZ WHERE TJNY = P_RPTYEAR||lpad(P_RPTMONTH, 2, 0)
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'dbWaterTotal' index_code,
               dbWaterTotal*1 index_value
          from Data_NHTZ WHERE TJNY = P_RPTYEAR||lpad(P_RPTMONTH, 2, 0)
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'dbWaterUsedTotal' index_code,
               dbWaterUsedTotal*1 index_value
          from Data_NHTZ WHERE TJNY = P_RPTYEAR||lpad(P_RPTMONTH, 2, 0)
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'dbWaterWastTotal' index_code,
               dbWaterWastTotal*1 index_value
          from Data_NHTZ WHERE TJNY = P_RPTYEAR||lpad(P_RPTMONTH, 2, 0)
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'dbWaterTotalMoney' index_code,
               dbWaterTotalMoney index_value
          from Data_NHTZ WHERE TJNY = P_RPTYEAR||lpad(P_RPTMONTH, 2, 0)
        union all 
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'dxWaterTotal' index_code,
               dxWaterTotal*1 index_value
          from Data_NHTZ WHERE TJNY = P_RPTYEAR||lpad(P_RPTMONTH, 2, 0)
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'dxWaterUsedTotal' index_code,
               dxWaterUsedTotal*1 index_value
          from Data_NHTZ WHERE TJNY = P_RPTYEAR||lpad(P_RPTMONTH, 2, 0)
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'dxWaterWastTotal' index_code,
               dxWaterWastTotal*1 index_value
          from Data_NHTZ WHERE TJNY = P_RPTYEAR||lpad(P_RPTMONTH, 2, 0)
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'dxWaterTotalMoney' index_code,
               dxWaterTotalMoney index_value
          from Data_NHTZ WHERE TJNY = P_RPTYEAR||lpad(P_RPTMONTH, 2, 0)
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'zWaterUsedTotal' index_code,
               zWaterUsedTotal*1 index_value
          from Data_NHTZ WHERE TJNY = P_RPTYEAR||lpad(P_RPTMONTH, 2, 0)
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'zWaterUsedMoney' index_code,
               zWaterUsedMoney index_value
          from Data_NHTZ WHERE TJNY = P_RPTYEAR||lpad(P_RPTMONTH, 2, 0)),
      b as
       (select * from e7_sys_org_xn WHERE p_org_id = P_RPTORGID),
      c as
       (select b.org_id id,
               b.p_org_id,
               a.tjny,
               a.index_code,
               a.index_value,
               b.business_type,
               b.province_type,
               b.assets_type,
               b.industry_type
          from a
         inner join b
            on a.dyname = b.org_name_xn
            AND a.dwcode = b.org_id_xn),
      d as
       (select p_org_id,
               tjny,
               index_code,
               sum(index_value) index_value,
               business_type,
               province_type,
               assets_type,
               industry_type
          from c
         group by p_org_id,
                  tjny,
                  index_code,
                  business_type,
                  province_type,
                  assets_type,
                  industry_type),
      e as
       (select p_org_id as id,
               p_org_id,
               tjny,
               index_code,
               index_value,
               business_type,
               province_type,
               assets_type,
               industry_type
          from d),
      f as
       (select * from (select * from e union all select * from c)),
      g as
       (select *
          from (select
                -- rownum,
                 f.id as org_id,
                 orgxn.p_org_id,
                 f.tjny,
                 xn.index_code,
                 xn.dim_code,
                 xn.dim_detail_code,
                 xn.dim_code1,
                 xn.dim_detail_code1,
                 xn.dim_code2,
                 xn.dim_detail_code2,
                 f.business_type,
                 f.province_type,
                 f.assets_type,
                 f.industry_type,
                 f.index_value,
                 index_value * stadc as stadc_amt
                  from f
                  left join xn_dim_detail xn
                    on f.index_code = xn.index_code_xn
                  left join e7_sys_org_xn orgxn
                    on f.id = orgxn.org_id
                 where index_code_xn is not null
                   and tjny = P_RPTYEAR || lpad(P_RPTMONTH, 2, 0))
         where org_id = P_RPTORGID
            or p_org_id = P_RPTORGID),
      --作业区合计
  /*    zyq_sum as
       (select org_id,
               p_org_id,
               tjny,
               index_code,
               dim_code,
               dim_detail_code,
               dim_code1,
               dim_detail_code1,
               dim_code2,
               dim_detail_code2,
               business_type,
               province_type,
               assets_type,
               industry_type,
               sum(index_value) as index_value,
               sum(stadc_amt) as stadc_amt
          from g
         where org_id = P_RPTORGID
         and index_code = 'Engy_csmp_amt_pratl'
         group by org_id,
                  p_org_id,
                  tjny,
                  index_code,
                  dim_code,
                  dim_detail_code,
                  dim_code1,
                  dim_detail_code1,
                  dim_code2,
                  dim_detail_code2,
                  business_type,
                  province_type,
                  assets_type,
                  industry_type),*/
      --作业区总合计
      zyq_stadc_sum as
       (select org_id,
               p_org_id,
               tjny,
               'Engy_csmp_amt_stadc' as index_code,
               null as dim_code,
               null as dim_detail_code,
               null as dim_code1,
               null as dim_detail_code1,
               null as dim_code2,
               null as dim_detail_code2,
               business_type as business_type,
               province_type as province_type,
               assets_type as assets_type,
               industry_type as industry_type,
               sum(stadc_amt) as index_value,
               sum(stadc_amt) as stadc_amt
          from g
         where org_id = P_RPTORGID
           and index_code = 'Engy_csmp_amt_pratl'
           and dim_detail_code1 not in ('Transportation_amount_G','Transportation_amount_D')
         group by org_id,
                  p_org_id,
                  tjny,
                  index_code,
                  business_type,
                  province_type,
                  assets_type,
                  industry_type),
      --行总合计
      jz_stadc_sum as
       (select org_id,
               p_org_id,
               tjny,
               'Engy_csmp_amt_stadc' as index_code,
               null as dim_code,
               null as dim_detail_code,
               null as dim_code1,
               null as dim_detail_code1,
               null as dim_code2,
               null as dim_detail_code2,
               business_type as business_type,
               province_type as province_type,
               assets_type as assets_type,
               industry_type as industry_type,
               sum(stadc_amt) as index_value,
               sum(stadc_amt) as stadc_amt
          from g
         where p_org_id = P_RPTORGID
           and index_code = 'Engy_csmp_amt_pratl'
           and dim_detail_code1 not in ('Transportation_amount_G','Transportation_amount_D')
         group by org_id,
                  p_org_id,
                  tjny,
                  index_code,
                  business_type,
                  province_type,
                  assets_type,
                  industry_type),
      res as
       (SELECT ROWNUM as rid, T.*
          FROM (select *
                  from jz_stadc_sum
                union all
                select *
                  from zyq_stadc_sum
              /*  union all
                select *
                  from zyq_sum*/
                union all
                select *
                  from g) T),
      resr as
       (select rid,
               org_id,
               p_org_id,
               tjny,
               'QYXNNW01' || P_RPTORGID || TJNY || rid as sta_index_inst_id,
               index_code,
               decode(dim_code,
                      null,
                      null,
                      'QYXNNW01' || P_RPTORGID || TJNY || rid || 'D') repinst_dtl_dimen,
               dim_code,
               dim_detail_code,
               decode(dim_code1,
                      null,
                      null,
                      'QYXNNW01' || P_RPTORGID || TJNY || rid || 'D1') repinst_dtl_dimen1,
               dim_code1,
               dim_detail_code1,
               decode(dim_code2,
                      null,
                      null,
                      'QYXNNW01' || P_RPTORGID || TJNY || rid || 'D2') repinst_dtl_dimen2,
               dim_code2,
               dim_detail_code2,
               decode(business_type,
                      null,
                      null,
                      'QYXNNW01' || P_RPTORGID || TJNY || rid || 'BU') repinst_dtl_dimen3,
               'Business_type' as dim_code3,
               business_type as dim_detail_code3,
               decode(province_type,
                      null,
                      null,
                      'QYXNNW01' || P_RPTORGID || TJNY || rid || 'PR') repinst_dtl_dimen4,
               'Province_type' as dim_code4,
               province_type as dim_detail_code4,
               decode(assets_type,
                      null,
                      null,
                      'QYXNNW01' || P_RPTORGID || TJNY || rid || 'AS') repinst_dtl_dimen5,
               'Assets_type' as dim_code5,
               assets_type as dim_detail_code5,
               decode(industry_type,
                      null,
                      null,
                      'QYXNNW01' || P_RPTORGID || TJNY || rid || 'IN') repinst_dtl_dimen6,
               'Industry_type' as dim_code6,
               industry_type as dim_detail_code6,
               index_value,
               stadc_amt
          from res)
      SELECT * FROM RESR);
      RPTINDEXINST E7_STA_RPT_INDEX_INST%ROWTYPE;
      STAINDEXINST E7_STA_INDEX_INST%ROWTYPE;
      STAINDEXINSTDIMEN E7_STA_INDEX_INST_DIMEN%ROWTYPE;
      BEGIN
        DELDATAS(P_RPTCODE,P_RPTORGID ,P_RPTYEAR ,P_RPTMONTH);
       CREATE_XNNWREPINST(P_RPTCODE, P_RPTYEAR,P_RPTMONTH,P_RPTORGID);

       FOR E7STARPTINDEXINST IN RESR LOOP
                RPTINDEXINST.REPINST_ID:='QYXNNW01'||P_RPTORGID||P_RPTYEAR||lpad(P_RPTMONTH,2,0);
                RPTINDEXINST.STA_INDEX_INST_ID:=E7STARPTINDEXINST.STA_INDEX_INST_ID;
                RPTINDEXINST.CREATE_TIME:=SYSDATE;
                RPTINDEXINST.UPDATE_TIME:=SYSDATE;
                INSERT INTO E7_STA_RPT_INDEX_INST VALUES RPTINDEXINST;
       END LOOP;
       COMMIT;


        FOR E7STAINDEXINST IN RESR LOOP
                STAINDEXINST.STA_INDEX_INST_ID:=E7STAINDEXINST.STA_INDEX_INST_ID;
                STAINDEXINST.INDEX_CODE:=E7STAINDEXINST.INDEX_CODE;
                STAINDEXINST.ORG_ID:=P_RPTORGID;
                STAINDEXINST.REPORT_YEAR:=P_RPTYEAR;
                STAINDEXINST.REPORT_QUARTER:=to_char(to_date(P_RPTYEAR||lpad(P_RPTMONTH,2,0),'yyyyMM'), 'Q');
                STAINDEXINST.REPORT_MONTH:=P_RPTMONTH;
                STAINDEXINST.REPORT_FREQUENT_CODE:=3;
                STAINDEXINST.INDEX_VALUE:=E7STAINDEXINST.INDEX_VALUE;
                STAINDEXINST.UNIT_CODE:= NULL;
                STAINDEXINST.REMARK:=SYSDATE||'INSERT';
                STAINDEXINST.INDEX_INST_ORDERNO:=NULL;
                STAINDEXINST.COMPOSITED_INDEX_CODE:=E7STAINDEXINST.ORG_ID;
                STAINDEXINST.CREATE_TIME:=SYSDATE;
                STAINDEXINST.UPDATE_TIME:=SYSDATE;
                INSERT INTO E7_STA_INDEX_INST VALUES STAINDEXINST;
       END LOOP;
       COMMIT;

      -- DATAQYINDEXDIMEN(P_RPTYEAR,P_RPTMONTH,P_RPTORGID);
      FOR E7STAINDEXINSTDIMEN IN RESR LOOP
          STAINDEXINSTDIMEN.repinst_dtl_dimen  :=E7STAINDEXINSTDIMEN.repinst_dtl_dimen ;
          STAINDEXINSTDIMEN.sta_index_inst_id  :=E7STAINDEXINSTDIMEN.sta_index_inst_id ;
          STAINDEXINSTDIMEN.dim_code           :=E7STAINDEXINSTDIMEN.dim_code          ;
          STAINDEXINSTDIMEN.dim_detail_code    :=E7STAINDEXINSTDIMEN.dim_detail_code   ;
          STAINDEXINSTDIMEN.dim_source         := NULL       ;
          STAINDEXINSTDIMEN.dim_deteail_id     := NULL   ;
          STAINDEXINSTDIMEN.dim_deteail_id2    := NULL   ;
          STAINDEXINSTDIMEN.unit_code          := NULL        ;
          STAINDEXINSTDIMEN.composite_dim_code := E7STAINDEXINSTDIMEN.ORG_ID;
          STAINDEXINSTDIMEN.create_time        := SYSDATE       ;
          STAINDEXINSTDIMEN.update_time        := SYSDATE       ;
          IF STAINDEXINSTDIMEN.repinst_dtl_dimen IS NOT NULL then
          INSERT INTO E7_STA_INDEX_INST_DIMEN VALUES STAINDEXINSTDIMEN;
          END IF;
          

          STAINDEXINSTDIMEN.repinst_dtl_dimen  :=E7STAINDEXINSTDIMEN.repinst_dtl_dimen1 ;
          STAINDEXINSTDIMEN.sta_index_inst_id  :=E7STAINDEXINSTDIMEN.sta_index_inst_id ;
          STAINDEXINSTDIMEN.dim_code           :=E7STAINDEXINSTDIMEN.dim_code1          ;
          STAINDEXINSTDIMEN.dim_detail_code    :=E7STAINDEXINSTDIMEN.dim_detail_code1   ;
          STAINDEXINSTDIMEN.dim_source         := NULL       ;
          STAINDEXINSTDIMEN.dim_deteail_id     := NULL   ;
          STAINDEXINSTDIMEN.dim_deteail_id2    := NULL   ;
          STAINDEXINSTDIMEN.unit_code          := NULL        ;
          STAINDEXINSTDIMEN.composite_dim_code :=E7STAINDEXINSTDIMEN.ORG_ID;
          STAINDEXINSTDIMEN.create_time        := SYSDATE       ;
          STAINDEXINSTDIMEN.update_time        := SYSDATE       ;
          IF STAINDEXINSTDIMEN.repinst_dtl_dimen IS NOT NULL then
          INSERT INTO E7_STA_INDEX_INST_DIMEN VALUES STAINDEXINSTDIMEN;
          END IF;

          STAINDEXINSTDIMEN.repinst_dtl_dimen  :=E7STAINDEXINSTDIMEN.repinst_dtl_dimen2 ;
          STAINDEXINSTDIMEN.sta_index_inst_id  :=E7STAINDEXINSTDIMEN.sta_index_inst_id ;
          STAINDEXINSTDIMEN.dim_code           :=E7STAINDEXINSTDIMEN.dim_code2          ;
          STAINDEXINSTDIMEN.dim_detail_code    :=E7STAINDEXINSTDIMEN.dim_detail_code2   ;
          STAINDEXINSTDIMEN.dim_source         := NULL       ;
          STAINDEXINSTDIMEN.dim_deteail_id     := NULL   ;
          STAINDEXINSTDIMEN.dim_deteail_id2    := NULL   ;
          STAINDEXINSTDIMEN.unit_code          := NULL        ;
          STAINDEXINSTDIMEN.composite_dim_code :=E7STAINDEXINSTDIMEN.ORG_ID;
          STAINDEXINSTDIMEN.create_time        := SYSDATE       ;
          STAINDEXINSTDIMEN.update_time        := SYSDATE       ;
          IF STAINDEXINSTDIMEN.repinst_dtl_dimen IS NOT NULL then
          INSERT INTO E7_STA_INDEX_INST_DIMEN VALUES STAINDEXINSTDIMEN;
          END IF;

          STAINDEXINSTDIMEN.repinst_dtl_dimen  :=E7STAINDEXINSTDIMEN.repinst_dtl_dimen3 ;
          STAINDEXINSTDIMEN.sta_index_inst_id  :=E7STAINDEXINSTDIMEN.sta_index_inst_id ;
          STAINDEXINSTDIMEN.dim_code           :=E7STAINDEXINSTDIMEN.dim_code3          ;
          STAINDEXINSTDIMEN.dim_detail_code    :=E7STAINDEXINSTDIMEN.dim_detail_code3   ;
          STAINDEXINSTDIMEN.dim_source         := NULL       ;
          STAINDEXINSTDIMEN.dim_deteail_id     := NULL   ;
          STAINDEXINSTDIMEN.dim_deteail_id2    := NULL   ;
          STAINDEXINSTDIMEN.unit_code          := NULL        ;
          STAINDEXINSTDIMEN.composite_dim_code :=E7STAINDEXINSTDIMEN.ORG_ID;
          STAINDEXINSTDIMEN.create_time        := SYSDATE       ;
          STAINDEXINSTDIMEN.update_time        := SYSDATE       ;
          IF STAINDEXINSTDIMEN.repinst_dtl_dimen IS NOT NULL then
          INSERT INTO E7_STA_INDEX_INST_DIMEN VALUES STAINDEXINSTDIMEN;
          END IF;

          STAINDEXINSTDIMEN.repinst_dtl_dimen  :=E7STAINDEXINSTDIMEN.repinst_dtl_dimen4 ;
          STAINDEXINSTDIMEN.sta_index_inst_id  :=E7STAINDEXINSTDIMEN.sta_index_inst_id ;
          STAINDEXINSTDIMEN.dim_code           :=E7STAINDEXINSTDIMEN.dim_code4          ;
          STAINDEXINSTDIMEN.dim_detail_code    :=E7STAINDEXINSTDIMEN.dim_detail_code4   ;
          STAINDEXINSTDIMEN.dim_source         := NULL       ;
          STAINDEXINSTDIMEN.dim_deteail_id     := NULL   ;
          STAINDEXINSTDIMEN.dim_deteail_id2    := NULL   ;
          STAINDEXINSTDIMEN.unit_code          := NULL        ;
          STAINDEXINSTDIMEN.composite_dim_code :=E7STAINDEXINSTDIMEN.ORG_ID;
          STAINDEXINSTDIMEN.create_time        := SYSDATE       ;
          STAINDEXINSTDIMEN.update_time        := SYSDATE       ;
          IF STAINDEXINSTDIMEN.repinst_dtl_dimen IS NOT NULL then
          INSERT INTO E7_STA_INDEX_INST_DIMEN VALUES STAINDEXINSTDIMEN;
          END IF;

          STAINDEXINSTDIMEN.repinst_dtl_dimen  :=E7STAINDEXINSTDIMEN.repinst_dtl_dimen5 ;
          STAINDEXINSTDIMEN.sta_index_inst_id  :=E7STAINDEXINSTDIMEN.sta_index_inst_id ;
          STAINDEXINSTDIMEN.dim_code           :=E7STAINDEXINSTDIMEN.dim_code5          ;
          STAINDEXINSTDIMEN.dim_detail_code    :=E7STAINDEXINSTDIMEN.dim_detail_code5   ;
          STAINDEXINSTDIMEN.dim_source         := NULL       ;
          STAINDEXINSTDIMEN.dim_deteail_id     := NULL   ;
          STAINDEXINSTDIMEN.dim_deteail_id2    := NULL   ;
          STAINDEXINSTDIMEN.unit_code          := NULL        ;
          STAINDEXINSTDIMEN.composite_dim_code :=E7STAINDEXINSTDIMEN.ORG_ID;
          STAINDEXINSTDIMEN.create_time        := SYSDATE       ;
          STAINDEXINSTDIMEN.update_time        := SYSDATE       ;
          IF STAINDEXINSTDIMEN.repinst_dtl_dimen IS NOT NULL then
          INSERT INTO E7_STA_INDEX_INST_DIMEN VALUES STAINDEXINSTDIMEN;
          END IF;   

          STAINDEXINSTDIMEN.repinst_dtl_dimen  :=E7STAINDEXINSTDIMEN.repinst_dtl_dimen6 ;
          STAINDEXINSTDIMEN.sta_index_inst_id  :=E7STAINDEXINSTDIMEN.sta_index_inst_id ;
          STAINDEXINSTDIMEN.dim_code           :=E7STAINDEXINSTDIMEN.dim_code6          ;
          STAINDEXINSTDIMEN.dim_detail_code    :=E7STAINDEXINSTDIMEN.dim_detail_code6   ;
          STAINDEXINSTDIMEN.dim_source         := NULL       ;
          STAINDEXINSTDIMEN.dim_deteail_id     := NULL   ;
          STAINDEXINSTDIMEN.dim_deteail_id2    := NULL   ;
          STAINDEXINSTDIMEN.unit_code          := NULL        ;
          STAINDEXINSTDIMEN.composite_dim_code :=E7STAINDEXINSTDIMEN.ORG_ID;
          STAINDEXINSTDIMEN.create_time        := SYSDATE       ;
          STAINDEXINSTDIMEN.update_time        := SYSDATE       ;
          IF STAINDEXINSTDIMEN.repinst_dtl_dimen IS NOT NULL then
          INSERT INTO E7_STA_INDEX_INST_DIMEN VALUES STAINDEXINSTDIMEN;
          END IF;
          END LOOP;
          COMMIT;
          
        EXCEPTION WHEN OTHERS THEN
                ROLLBACK;
       END;


PROCEDURE DataQYXNNW02(P_RPTCODE  IN VARCHAR2,
                         P_RPTYEAR  IN VARCHAR2,
                         P_RPTMONTH IN VARCHAR2,
                         P_RPTORGID IN VARCHAR2) AS
           CURSOR RESR IS SELECT * FROM (select 
'QY'||'XNNW02'||P_RPTORGID||P_RPTYEAR||P_RPTMONTH as repinst_id,
P_RPTORGID as org_id,
decode(max(sta_index_inst_id)||'XN02','XN02',NULL,max(sta_index_inst_id)||'XN02') as sta_index_inst_id,
index_code,
sum(index_value) as index_value,
P_RPTORGID as composited_index_code,
DECODE(max(repinst_dtl_dimen)||'XN02','XN02',NULL,max(repinst_dtl_dimen)||'XN02') as repinst_dtl_dimen,
dim_code,
dim_detail_code,
DECODE(max(repinst_dtl_dimen1)||'XN02','XN02',NULL,max(repinst_dtl_dimen1)||'XN02')  as repinst_dtl_dimen1,
dim_code1,
dim_detail_code1,
DECODE(max(repinst_dtl_dimen2)||'XN02','XN02',NULL,max(repinst_dtl_dimen2)||'XN02')  as repinst_dtl_dimen2,
dim_code2,
dim_detail_code2,
DECODE(max(repinst_dtl_dimen3)||'XN02','XN02',NULL,max(repinst_dtl_dimen3)||'XN02')  as repinst_dtl_dimen3,
dim_code3,
dim_detail_code3,
DECODE(max(repinst_dtl_dimen4)||'XN02','XN02',NULL,max(repinst_dtl_dimen4)||'XN02')  as repinst_dtl_dimen4,
dim_code4,
dim_detail_code4,
DECODE(max(repinst_dtl_dimen5)||'XN02','XN02',NULL,max(repinst_dtl_dimen5)||'XN02')  as repinst_dtl_dimen5,
dim_code5,
dim_detail_code5,
DECODE(max(repinst_dtl_dimen6)||'XN02','XN02',NULL,max(repinst_dtl_dimen6)||'XN02')  as repinst_dtl_dimen6,
dim_code6,
dim_detail_code6

 from (
select repinst.repinst_id,
repinst.org_id,
                       indexinst.sta_index_inst_id,
                       indexinst.index_code,
                       indexinst.index_value,
                       indexinst.COMPOSITED_INDEX_CODE,
                       dimeninst.repinst_dtl_dimen     as repinst_dtl_dimen,
                       dimeninst.dim_code              as dim_code,
                       dimeninst.dim_detail_code       as dim_detail_code,
                       dimeninst1.repinst_dtl_dimen    as repinst_dtl_dimen1,
                       dimeninst1.dim_code             as dim_code1,
                       dimeninst1.dim_detail_code      as dim_detail_code1,
                       dimeninst2.repinst_dtl_dimen    as repinst_dtl_dimen2,
                       dimeninst2.dim_code             as dim_code2,
                       dimeninst2.dim_detail_code      as dim_detail_code2,
                       dimeninst3.repinst_dtl_dimen    as repinst_dtl_dimen3,
                       dimeninst3.dim_code             as dim_code3,
                       dimeninst3.dim_detail_code      as dim_detail_code3,
                       dimeninst4.repinst_dtl_dimen    as repinst_dtl_dimen4,
                       dimeninst4.dim_code             as dim_code4,
                       dimeninst4.dim_detail_code      as dim_detail_code4,
                       dimeninst5.repinst_dtl_dimen    as repinst_dtl_dimen5,
                       dimeninst5.dim_code             as dim_code5,
                       dimeninst5.dim_detail_code      as dim_detail_code5,
                       dimeninst6.repinst_dtl_dimen    as repinst_dtl_dimen6,
                       dimeninst6.dim_code             as dim_code6,
                       dimeninst6.dim_detail_code      as dim_detail_code6
                  from e7_sta_repinst repinst
                  left join e7_sta_rpt_index_inst rptindexinst
                    on repinst.repinst_id = rptindexinst.repinst_id
                  left join e7_sta_index_inst indexinst
                    on rptindexinst.sta_index_inst_id =
                       indexinst.sta_index_inst_id
                  left join e7_sta_index_inst_dimen dimeninst
                    on dimeninst.dim_code = 'Business_type'
                   and indexinst.sta_index_inst_id =
                       dimeninst.sta_index_inst_id
                  left join e7_sta_index_inst_dimen dimeninst1
                    on dimeninst1.dim_code = 'Province_type'
                   and indexinst.sta_index_inst_id =
                       dimeninst1.sta_index_inst_id
                  left join e7_sta_index_inst_dimen dimeninst2
                    on dimeninst2.dim_code = 'Assets_type'
                   and indexinst.sta_index_inst_id =
                       dimeninst2.sta_index_inst_id
                  left join e7_sta_index_inst_dimen dimeninst3
                    on dimeninst3.dim_code = 'Industry_type'
                   and indexinst.sta_index_inst_id =
                       dimeninst3.sta_index_inst_id
                  left join e7_sta_index_inst_dimen dimeninst4
                    on dimeninst4.dim_code = 'Cru_oil_E_cons_typ'
                   and indexinst.sta_index_inst_id =
                       dimeninst4.sta_index_inst_id
                  left join e7_sta_index_inst_dimen dimeninst5
                    on dimeninst5.dim_code = 'Custom_dimen_first'
                   and indexinst.sta_index_inst_id =
                       dimeninst5.sta_index_inst_id
                  left join e7_sta_index_inst_dimen dimeninst6
                    on dimeninst6.dim_code = 'Custom_dimen_second'
                   and indexinst.sta_index_inst_id =
                       dimeninst6.sta_index_inst_id

                 where repinst.report_code in( 'XNNW01')
                   and repinst.report_year =   P_RPTYEAR
                   and repinst.report_month =   P_RPTMONTH
                   and indexinst.COMPOSITED_INDEX_CODE in (select org_id from e7_sys_org where parent_org_id = P_RPTORGID)
                   group by
                       repinst.repinst_id,
                       repinst.org_id,
                       indexinst.sta_index_inst_id,
                       indexinst.remark,
                       indexinst.index_code,
                       indexinst.index_value,
                       indexinst.COMPOSITED_INDEX_CODE,
                       dimeninst.repinst_dtl_dimen,
                       dimeninst.dim_code,
                       dimeninst.dim_detail_code,
                       dimeninst1.repinst_dtl_dimen ,
                       dimeninst1.dim_code          ,
                       dimeninst1.dim_detail_code    ,
                       dimeninst2.repinst_dtl_dimen  ,
                       dimeninst2.dim_code           ,
                       dimeninst2.dim_detail_code    ,
                       dimeninst3.repinst_dtl_dimen  ,
                       dimeninst3.dim_code           ,
                       dimeninst3.dim_detail_code    ,
                       dimeninst4.repinst_dtl_dimen  ,
                       dimeninst4.dim_code           ,
                       dimeninst4.dim_detail_code    ,
                       dimeninst5.repinst_dtl_dimen   ,
                       dimeninst5.dim_code           ,
                       dimeninst5.dim_detail_code    ,
                       dimeninst6.repinst_dtl_dimen  ,
                       dimeninst6.dim_code          ,
                       dimeninst6.dim_detail_code
                       )
                       
                       group by 
                          index_code,
                          dim_code,dim_detail_code,
                          dim_code1,dim_detail_code1,
                          dim_code2,dim_detail_code2,
                          dim_code3,dim_detail_code3,
                          dim_code4,dim_detail_code4,
                          dim_code5,dim_detail_code5,
                          dim_code6,dim_detail_code6);
      RPTINDEXINST E7_STA_RPT_INDEX_INST%ROWTYPE;
      STAINDEXINST E7_STA_INDEX_INST%ROWTYPE;
      STAINDEXINSTDIMEN E7_STA_INDEX_INST_DIMEN%ROWTYPE;
      BEGIN
      
       CREATE_XNNWREPINST(P_RPTCODE, P_RPTYEAR,P_RPTMONTH,P_RPTORGID);

       FOR E7STARPTINDEXINST IN RESR LOOP
                RPTINDEXINST.REPINST_ID:='QY'||P_RPTCODE||P_RPTORGID||P_RPTYEAR||lpad(P_RPTMONTH,2,0);
                RPTINDEXINST.STA_INDEX_INST_ID:=E7STARPTINDEXINST.STA_INDEX_INST_ID;
                RPTINDEXINST.CREATE_TIME:=SYSDATE;
                RPTINDEXINST.UPDATE_TIME:=SYSDATE;
                IF RPTINDEXINST.STA_INDEX_INST_ID IS NOT NULL THEN
                INSERT INTO E7_STA_RPT_INDEX_INST VALUES RPTINDEXINST;
                END IF;
       END LOOP;
       COMMIT;


        FOR E7STAINDEXINST IN RESR LOOP
                STAINDEXINST.STA_INDEX_INST_ID:=E7STAINDEXINST.STA_INDEX_INST_ID;
                STAINDEXINST.INDEX_CODE:=E7STAINDEXINST.INDEX_CODE;
                STAINDEXINST.ORG_ID:=P_RPTORGID;
                STAINDEXINST.REPORT_YEAR:=P_RPTYEAR;
                STAINDEXINST.REPORT_QUARTER:=to_char(to_date(P_RPTYEAR||lpad(P_RPTMONTH,2,0),'yyyyMM'), 'Q');
                STAINDEXINST.REPORT_MONTH:=P_RPTMONTH;
                STAINDEXINST.REPORT_FREQUENT_CODE:=3;
                STAINDEXINST.INDEX_VALUE:=E7STAINDEXINST.INDEX_VALUE;
                STAINDEXINST.UNIT_CODE:= NULL;
                STAINDEXINST.REMARK:=SYSDATE||'INSERT';
                STAINDEXINST.INDEX_INST_ORDERNO:=NULL;
                STAINDEXINST.COMPOSITED_INDEX_CODE:=E7STAINDEXINST.org_id;
                STAINDEXINST.CREATE_TIME:=SYSDATE;
                STAINDEXINST.UPDATE_TIME:=SYSDATE;
                IF STAINDEXINST.STA_INDEX_INST_ID IS NOT NULL  THEN
                INSERT INTO E7_STA_INDEX_INST VALUES STAINDEXINST;
                END IF;
       END LOOP;
       COMMIT;

       FOR E7STAINDEXINSTDIMEN IN RESR LOOP
          STAINDEXINSTDIMEN.repinst_dtl_dimen  :=E7STAINDEXINSTDIMEN.repinst_dtl_dimen ;
          STAINDEXINSTDIMEN.sta_index_inst_id  :=E7STAINDEXINSTDIMEN.sta_index_inst_id ;
          STAINDEXINSTDIMEN.dim_code           :=E7STAINDEXINSTDIMEN.dim_code          ;
          STAINDEXINSTDIMEN.dim_detail_code    :=E7STAINDEXINSTDIMEN.dim_detail_code   ;
          STAINDEXINSTDIMEN.dim_source         := NULL       ;
          STAINDEXINSTDIMEN.dim_deteail_id     := NULL   ;
          STAINDEXINSTDIMEN.dim_deteail_id2    := NULL   ;
          STAINDEXINSTDIMEN.unit_code          := NULL        ;
          STAINDEXINSTDIMEN.composite_dim_code := E7STAINDEXINSTDIMEN.org_id;
          STAINDEXINSTDIMEN.create_time        := SYSDATE       ;
          STAINDEXINSTDIMEN.update_time        := SYSDATE       ;
          IF STAINDEXINSTDIMEN.repinst_dtl_dimen IS NOT NULL then
          INSERT INTO E7_STA_INDEX_INST_DIMEN VALUES STAINDEXINSTDIMEN;
          END IF;
          

          STAINDEXINSTDIMEN.repinst_dtl_dimen  :=E7STAINDEXINSTDIMEN.repinst_dtl_dimen1 ;
          STAINDEXINSTDIMEN.sta_index_inst_id  :=E7STAINDEXINSTDIMEN.sta_index_inst_id ;
          STAINDEXINSTDIMEN.dim_code           :=E7STAINDEXINSTDIMEN.dim_code1          ;
          STAINDEXINSTDIMEN.dim_detail_code    :=E7STAINDEXINSTDIMEN.dim_detail_code1   ;
          STAINDEXINSTDIMEN.dim_source         := NULL       ;
          STAINDEXINSTDIMEN.dim_deteail_id     := NULL   ;
          STAINDEXINSTDIMEN.dim_deteail_id2    := NULL   ;
          STAINDEXINSTDIMEN.unit_code          := NULL        ;
          STAINDEXINSTDIMEN.composite_dim_code :=E7STAINDEXINSTDIMEN.org_id;
          STAINDEXINSTDIMEN.create_time        := SYSDATE       ;
          STAINDEXINSTDIMEN.update_time        := SYSDATE       ;
          IF STAINDEXINSTDIMEN.repinst_dtl_dimen IS NOT NULL then
          INSERT INTO E7_STA_INDEX_INST_DIMEN VALUES STAINDEXINSTDIMEN;
          END IF;

          STAINDEXINSTDIMEN.repinst_dtl_dimen  :=E7STAINDEXINSTDIMEN.repinst_dtl_dimen2 ;
          STAINDEXINSTDIMEN.sta_index_inst_id  :=E7STAINDEXINSTDIMEN.sta_index_inst_id ;
          STAINDEXINSTDIMEN.dim_code           :=E7STAINDEXINSTDIMEN.dim_code2          ;
          STAINDEXINSTDIMEN.dim_detail_code    :=E7STAINDEXINSTDIMEN.dim_detail_code2   ;
          STAINDEXINSTDIMEN.dim_source         := NULL       ;
          STAINDEXINSTDIMEN.dim_deteail_id     := NULL   ;
          STAINDEXINSTDIMEN.dim_deteail_id2    := NULL   ;
          STAINDEXINSTDIMEN.unit_code          := NULL        ;
          STAINDEXINSTDIMEN.composite_dim_code :=E7STAINDEXINSTDIMEN.org_id;
          STAINDEXINSTDIMEN.create_time        := SYSDATE       ;
          STAINDEXINSTDIMEN.update_time        := SYSDATE       ;
          IF STAINDEXINSTDIMEN.repinst_dtl_dimen IS NOT NULL then
          INSERT INTO E7_STA_INDEX_INST_DIMEN VALUES STAINDEXINSTDIMEN;
          END IF;

          STAINDEXINSTDIMEN.repinst_dtl_dimen  :=E7STAINDEXINSTDIMEN.repinst_dtl_dimen3 ;
          STAINDEXINSTDIMEN.sta_index_inst_id  :=E7STAINDEXINSTDIMEN.sta_index_inst_id ;
          STAINDEXINSTDIMEN.dim_code           :=E7STAINDEXINSTDIMEN.dim_code3          ;
          STAINDEXINSTDIMEN.dim_detail_code    :=E7STAINDEXINSTDIMEN.dim_detail_code3   ;
          STAINDEXINSTDIMEN.dim_source         := NULL       ;
          STAINDEXINSTDIMEN.dim_deteail_id     := NULL   ;
          STAINDEXINSTDIMEN.dim_deteail_id2    := NULL   ;
          STAINDEXINSTDIMEN.unit_code          := NULL        ;
          STAINDEXINSTDIMEN.composite_dim_code :=E7STAINDEXINSTDIMEN.org_id;
          STAINDEXINSTDIMEN.create_time        := SYSDATE       ;
          STAINDEXINSTDIMEN.update_time        := SYSDATE       ;
          IF STAINDEXINSTDIMEN.repinst_dtl_dimen IS NOT NULL then
          INSERT INTO E7_STA_INDEX_INST_DIMEN VALUES STAINDEXINSTDIMEN;
          END IF;

          STAINDEXINSTDIMEN.repinst_dtl_dimen  :=E7STAINDEXINSTDIMEN.repinst_dtl_dimen4 ;
          STAINDEXINSTDIMEN.sta_index_inst_id  :=E7STAINDEXINSTDIMEN.sta_index_inst_id ;
          STAINDEXINSTDIMEN.dim_code           :=E7STAINDEXINSTDIMEN.dim_code4          ;
          STAINDEXINSTDIMEN.dim_detail_code    :=E7STAINDEXINSTDIMEN.dim_detail_code4   ;
          STAINDEXINSTDIMEN.dim_source         := NULL       ;
          STAINDEXINSTDIMEN.dim_deteail_id     := NULL   ;
          STAINDEXINSTDIMEN.dim_deteail_id2    := NULL   ;
          STAINDEXINSTDIMEN.unit_code          := NULL        ;
          STAINDEXINSTDIMEN.composite_dim_code :=E7STAINDEXINSTDIMEN.org_id;
          STAINDEXINSTDIMEN.create_time        := SYSDATE       ;
          STAINDEXINSTDIMEN.update_time        := SYSDATE       ;
          IF STAINDEXINSTDIMEN.repinst_dtl_dimen IS NOT NULL then
          INSERT INTO E7_STA_INDEX_INST_DIMEN VALUES STAINDEXINSTDIMEN;
          END IF;

          STAINDEXINSTDIMEN.repinst_dtl_dimen  :=E7STAINDEXINSTDIMEN.repinst_dtl_dimen5 ;
          STAINDEXINSTDIMEN.sta_index_inst_id  :=E7STAINDEXINSTDIMEN.sta_index_inst_id ;
          STAINDEXINSTDIMEN.dim_code           :=E7STAINDEXINSTDIMEN.dim_code5          ;
          STAINDEXINSTDIMEN.dim_detail_code    :=E7STAINDEXINSTDIMEN.dim_detail_code5   ;
          STAINDEXINSTDIMEN.dim_source         := NULL       ;
          STAINDEXINSTDIMEN.dim_deteail_id     := NULL   ;
          STAINDEXINSTDIMEN.dim_deteail_id2    := NULL   ;
          STAINDEXINSTDIMEN.unit_code          := NULL        ;
          STAINDEXINSTDIMEN.composite_dim_code :=E7STAINDEXINSTDIMEN.org_id;
          STAINDEXINSTDIMEN.create_time        := SYSDATE       ;
          STAINDEXINSTDIMEN.update_time        := SYSDATE       ;
          IF STAINDEXINSTDIMEN.repinst_dtl_dimen IS NOT NULL then
          INSERT INTO E7_STA_INDEX_INST_DIMEN VALUES STAINDEXINSTDIMEN;
          END IF;   

          STAINDEXINSTDIMEN.repinst_dtl_dimen  :=E7STAINDEXINSTDIMEN.repinst_dtl_dimen6 ;
          STAINDEXINSTDIMEN.sta_index_inst_id  :=E7STAINDEXINSTDIMEN.sta_index_inst_id ;
          STAINDEXINSTDIMEN.dim_code           :=E7STAINDEXINSTDIMEN.dim_code6          ;
          STAINDEXINSTDIMEN.dim_detail_code    :=E7STAINDEXINSTDIMEN.dim_detail_code6   ;
          STAINDEXINSTDIMEN.dim_source         := NULL       ;
          STAINDEXINSTDIMEN.dim_deteail_id     := NULL   ;
          STAINDEXINSTDIMEN.dim_deteail_id2    := NULL   ;
          STAINDEXINSTDIMEN.unit_code          := NULL        ;
          STAINDEXINSTDIMEN.composite_dim_code :=E7STAINDEXINSTDIMEN.org_id;
          STAINDEXINSTDIMEN.create_time        := SYSDATE       ;
          STAINDEXINSTDIMEN.update_time        := SYSDATE       ;
          IF STAINDEXINSTDIMEN.repinst_dtl_dimen IS NOT NULL then
          INSERT INTO E7_STA_INDEX_INST_DIMEN VALUES STAINDEXINSTDIMEN;
          END IF;
          END LOOP;
          COMMIT;


        EXCEPTION WHEN OTHERS THEN
                ROLLBACK;
       END;





   PROCEDURE DATAQYINDEXDIMEN( P_RPTYEAR  IN VARCHAR2,
                             P_RPTMONTH IN VARCHAR2,
                             P_RPTORGID IN VARCHAR2) AS
  CURSOR RESR IS SELECT * FROM (
      with a as
       (select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'rqTotal' index_code,
               rqTotal index_value
          from Data_NHTZ
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'rqUsedTotal' index_code,
               rqUsedTotal index_value
          from Data_NHTZ
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'rqRLZY' index_code,
               rqRLZY index_value
          from Data_NHTZ
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'rqYLZY' index_code,
               rqYLZY index_value
          from Data_NHTZ
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'rqJGZH' index_code,
               rqJGZH index_value
          from Data_NHTZ
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'rqYSXF' index_code,
               rqYSXF index_value
          from Data_NHTZ
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'rqUsedMoney' index_code,
               rqUsedMoney index_value
          from Data_NHTZ
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'rqWastTotal' index_code,
               rqWastTotal index_value
          from Data_NHTZ
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'rqSS' index_code,
               rqSS index_value
          from Data_NHTZ
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'rqFK' index_code,
               rqFK index_value
          from Data_NHTZ
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'rqWastMoney' index_code,
               rqWastMoney index_value
          from Data_NHTZ
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'dTotal' index_code,
               dTotal index_value
          from Data_NHTZ
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'dUsedTotal' index_code,
               dUsedTotal index_value
          from Data_NHTZ
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'dWastTotal' index_code,
               dWastTotal index_value
          from Data_NHTZ
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'dTotalMoney' index_code,
               dTotalMoney index_value
          from Data_NHTZ
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'mUsedTotal' index_code,
               mUsedTotal index_value
          from Data_NHTZ
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'mTotalMoney' index_code,
               mTotalMoney index_value
          from Data_NHTZ
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'yyTotal' index_code,
               yyTotal index_value
          from Data_NHTZ
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'yyUsedTotal' index_code,
               yyUsedTotal index_value
          from Data_NHTZ
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'yyUsedMoney' index_code,
               yyUsedMoney index_value
          from Data_NHTZ
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'yyWastTotal' index_code,
               yyWastTotal index_value
          from Data_NHTZ
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'yyWastMoney' index_code,
               yyWastMoney index_value
          from Data_NHTZ
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'qyBuyTotal' index_code,
               qyBuyTotal index_value
          from Data_NHTZ
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'qyBuyMoney' index_code,
               qyBuyMoney index_value
          from Data_NHTZ
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'qyUsedTotal' index_code,
               qyUsedTotal index_value
          from Data_NHTZ
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'qyYSUsedTotal' index_code,
               qyYSUsedTotal index_value
          from Data_NHTZ
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'qyUsedMoney' index_code,
               qyUsedMoney index_value
          from Data_NHTZ
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'cyBuyTotal' index_code,
               cyBuyTotal index_value
          from Data_NHTZ
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'cyBuyMoney' index_code,
               cyBuyMoney index_value
          from Data_NHTZ
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'cyUsedTotal' index_code,
               cyUsedTotal index_value
          from Data_NHTZ
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'cyYSUsedTotal' index_code,
               cyYSUsedTotal index_value
          from Data_NHTZ
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'cyUsedMoney' index_code,
               cyUsedMoney index_value
          from Data_NHTZ
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'zyUsedTotal' index_code,
               zyUsedTotal index_value
          from Data_NHTZ
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'zyUsedMoney' index_code,
               zyUsedMoney index_value
          from Data_NHTZ
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'gqUsedTotal' index_code,
               gqUsedTotal index_value
          from Data_NHTZ
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'gqUsedMoney' index_code,
               gqUsedMoney index_value
          from Data_NHTZ
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'sjUsedTotal' index_code,
               sjUsedTotal index_value
          from Data_NHTZ
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'sjUsedMoney' index_code,
               sjUsedMoney index_value
          from Data_NHTZ
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'qtUsedTotal' index_code,
               qtUsedTotal index_value
          from Data_NHTZ
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'qtUsedMoney' index_code,
               qtUsedMoney index_value
          from Data_NHTZ
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'zlWaterTotal' index_code,
               zlWaterTotal index_value
          from Data_NHTZ
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'zlWaterUsedTotal' index_code,
               zlWaterUsedTotal index_value
          from Data_NHTZ
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'zlWaterWastTotal' index_code,
               zlWaterWastTotal index_value
          from Data_NHTZ
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'zlWaterTotalMoney' index_code,
               zlWaterTotalMoney index_value
          from Data_NHTZ
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'dbWaterTotal' index_code,
               dbWaterTotal index_value
          from Data_NHTZ
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'dbWaterUsedTotal' index_code,
               dbWaterUsedTotal index_value
          from Data_NHTZ
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'dbWaterWastTotal' index_code,
               dbWaterWastTotal index_value
          from Data_NHTZ
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'dbWaterTotalMoney' index_code,
               dbWaterTotalMoney index_value
          from Data_NHTZ
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'dxWaterTotal' index_code,
               dxWaterTotal index_value
          from Data_NHTZ
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'dxWaterUsedTotal' index_code,
               dxWaterUsedTotal index_value
          from Data_NHTZ
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'dxWaterWastTotal' index_code,
               dxWaterWastTotal index_value
          from Data_NHTZ
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'dxWaterTotalMoney' index_code,
               dxWaterTotalMoney index_value
          from Data_NHTZ
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'zWaterUsedTotal' index_code,
               zWaterUsedTotal index_value
          from Data_NHTZ
        union all
        select ID,
               Dwcode,
               Dyname,
               flcode,
               TJNY,
               'zWaterUsedMoney' index_code,
               zWaterUsedMoney index_value
          from Data_NHTZ),
      b as
       (select * from e7_sys_org_xn),
      c as
       (select b.org_id id,
               b.p_org_id,
               a.tjny,
               a.index_code,
               a.index_value,
               b.business_type,
               b.province_type,
               b.assets_type,
               b.industry_type
          from a
         inner join b
            on a.dyname = b.org_name_xn),
      d as
       (select p_org_id,
               tjny,
               index_code,
               sum(index_value) index_value,
               business_type,
               province_type,
               assets_type,
               industry_type
          from c
         group by p_org_id,
                  tjny,
                  index_code,
                  business_type,
                  province_type,
                  assets_type,
                  industry_type),
      e as
       (select p_org_id as id,
               p_org_id,
               tjny,
               index_code,
               index_value,
               business_type,
               province_type,
               assets_type,
               industry_type
          from d),
      f as
       (select * from (select * from e union all select * from c)),
      g as
       (select *
          from (select
                -- rownum,
                 f.id as org_id,
                 orgxn.p_org_id,
                 f.tjny,
                 xn.index_code,
                 xn.dim_code,
                 xn.dim_detail_code,
                 xn.dim_code1,
                 xn.dim_detail_code1,
                 xn.dim_code2,
                 xn.dim_detail_code2,
                 f.business_type,
                 f.province_type,
                 f.assets_type,
                 f.industry_type,
                 f.index_value,
                 index_value * stadc as stadc_amt
                  from f
                  left join xn_dim_detail xn
                    on f.index_code = xn.index_code_xn
                  left join e7_sys_org_xn orgxn
                    on f.id = orgxn.org_id
                 where index_code_xn is not null
                   and tjny = P_RPTYEAR || lpad(P_RPTMONTH, 2, 0))
         where org_id = P_RPTORGID
            or p_org_id = P_RPTORGID),
      --作业区合计
    /*  zyq_sum as
       (select org_id,
               p_org_id,
               tjny,
               index_code,
               dim_code,
               dim_detail_code,
               dim_code1,
               dim_detail_code1,
               dim_code2,
               dim_detail_code2,
               business_type,
               province_type,
               assets_type,
               industry_type,
               sum(index_value) as index_value,
               sum(stadc_amt) as stadc_amt
          from g
         where org_id = P_RPTORGID
          and index_code = 'Engy_csmp_amt_pratl'
         group by org_id,
                  p_org_id,
                  tjny,
                  index_code,
                  dim_code,
                  dim_detail_code,
                  dim_code1,
                  dim_detail_code1,
                  dim_code2,
                  dim_detail_code2,
                  business_type,
                  province_type,
                  assets_type,
                  industry_type),*/
      --作业区总合计
      zyq_stadc_sum as
       (select org_id,
               p_org_id,
               tjny,
               'Engy_csmp_amt_stadc' as index_code,
               null as dim_code,
               null as dim_detail_code,
               null as dim_code1,
               null as dim_detail_code1,
               null as dim_code2,
               null as dim_detail_code2,
               business_type as business_type,
               province_type as province_type,
               assets_type as assets_type,
               industry_type as industry_type,
               sum(stadc_amt) as index_value,
               sum(stadc_amt) as stadc_amt
          from g
         where org_id = P_RPTORGID
           and index_code = 'Engy_csmp_amt_pratl'
           and dim_detail_code1 not in ('Transportation_amount_G','Transportation_amount_D')
         group by org_id,
                  p_org_id,
                  tjny,
                  index_code,
                  business_type,
                  province_type,
                  assets_type,
                  industry_type),
      --行总合计
      jz_stadc_sum as
       (select org_id,
               p_org_id,
               tjny,
               'Engy_csmp_amt_stadc' as index_code,
               null as dim_code,
               null as dim_detail_code,
               null as dim_code1,
               null as dim_detail_code1,
               null as dim_code2,
               null as dim_detail_code2,
               business_type as business_type,
               province_type as province_type,
               assets_type as assets_type,
               industry_type as industry_type,
               sum(stadc_amt) as index_value,
               sum(stadc_amt) as stadc_amt
          from g
         where p_org_id = P_RPTORGID
           and index_code = 'Engy_csmp_amt_pratl'
           and dim_detail_code1 not in ('Transportation_amount_G','Transportation_amount_D')
         group by org_id,
                  p_org_id,
                  tjny,
                  index_code,
                  business_type,
                  province_type,
                  assets_type,
                  industry_type),
      res as
       (SELECT ROWNUM as rid, T.*
          FROM (select *
                  from jz_stadc_sum
                union all
                select *
                  from zyq_stadc_sum
               /* union all
                select *
                  from zyq_sum*/
                union all
                select *
                  from g) T),
      resr as
       (select rid,
               org_id,
               p_org_id,
               tjny,
               'QYXNNW01' || P_RPTORGID || TJNY || rid as sta_index_inst_id,
               index_code,
               decode(dim_code,
                      null,
                      null,
                      'QYXNNW01' || P_RPTORGID || TJNY || rid || 'D') repinst_dtl_dimen,
               dim_code,
               dim_detail_code,
               decode(dim_code1,
                      null,
                      null,
                      'QYXNNW01' || P_RPTORGID || TJNY || rid || 'D1') repinst_dtl_dimen1,
               dim_code1,
               dim_detail_code1,
               decode(dim_code2,
                      null,
                      null,
                      'QYXNNW01' || P_RPTORGID || TJNY || rid || 'D2') repinst_dtl_dimen2,
               dim_code2,
               dim_detail_code2,
               decode(business_type,
                      null,
                      null,
                      'QYXNNW01' || P_RPTORGID || TJNY || rid || 'BU') repinst_dtl_dimen3,
               'Business_type' as dim_code3,
               business_type as dim_detail_code3,
               decode(province_type,
                      null,
                      null,
                      'QYXNNW01' || P_RPTORGID || TJNY || rid || 'PR') repinst_dtl_dimen4,
               'Province_type' as dim_code4,
               province_type as dim_detail_code4,
               decode(assets_type,
                      null,
                      null,
                      'QYXNNW01' || P_RPTORGID || TJNY || rid || 'AS') repinst_dtl_dimen5,
               'Assets_type' as dim_code5,
               assets_type as dim_detail_code5,
               decode(industry_type,
                      null,
                      null,
                      'QYXNNW01' || P_RPTORGID || TJNY || rid || 'IN') repinst_dtl_dimen6,
               'Industry_type' as dim_code6,
               industry_type as dim_detail_code6,
               index_value,
               stadc_amt
          from res)
      select * from
       (select repinst_dtl_dimen,
       sta_index_inst_id,
       dim_code,
       dim_detail_code,
       null as dim_source,
       null as dim_detail_id,
       null as dim_detail_id2,
       null as unit_code,
       org_id as composite_dim_code,
       sysdate as create_time,
       sysdate as update_time
       from resr
       union all
        select repinst_dtl_dimen1,
       sta_index_inst_id,
       dim_code1,
       dim_detail_code1,
       null as dim_source,
       null as dim_detail_id,
       null as dim_detail_id2,
       null as unit_code,
       org_id as composite_dim_code,
       sysdate as create_time,
       sysdate as update_time
       from resr
       union all
        select repinst_dtl_dimen2,
       sta_index_inst_id,
       dim_code2,
       dim_detail_code2,
       null as dim_source,
       null as dim_detail_id,
       null as dim_detail_id2,
       null as unit_code,
       org_id as composite_dim_code,
       sysdate as create_time,
       sysdate as update_time
       from resr
       union all
        select repinst_dtl_dimen3,
       sta_index_inst_id,
       dim_code3,
       dim_detail_code3,
       null as dim_source,
       null as dim_detail_id,
       null as dim_detail_id2,
       null as unit_code,
       org_id as composite_dim_code,
       sysdate as create_time,
       sysdate as update_time
       from resr
       union all
        select repinst_dtl_dimen4,
       sta_index_inst_id,
       dim_code4,
       dim_detail_code4,
       null as dim_source,
       null as dim_detail_id,
       null as dim_detail_id2,
       null as unit_code,
       org_id as composite_dim_code,
       sysdate as create_time,
       sysdate as update_time
       from resr
       union all
        select repinst_dtl_dimen5,
       sta_index_inst_id,
       dim_code5,
       dim_detail_code5,
       null as dim_source,
       null as dim_detail_id,
       null as dim_detail_id2,
       null as unit_code,
       org_id as composite_dim_code,
       sysdate as create_time,
       sysdate as update_time
       from resr
       union all
        select repinst_dtl_dimen6,
       sta_index_inst_id,
       dim_code6,
       dim_detail_code6,
       null as dim_source,
       null as dim_detail_id,
       null as dim_detail_id2,
       null as unit_code,
       org_id as composite_dim_code,
       sysdate as create_time,
       sysdate as update_time
       from resr)
        where repinst_dtl_dimen is not null);

       STAINDEXINSTDIMEN E7_STA_INDEX_INST_DIMEN%ROWTYPE;
       BEGIN
       FOR E7STAINDEXINSTDIMEN IN RESR LOOP
                STAINDEXINSTDIMEN.REPINST_DTL_DIMEN:=E7STAINDEXINSTDIMEN.REPINST_DTL_DIMEN;
                STAINDEXINSTDIMEN.STA_INDEX_INST_ID:=E7STAINDEXINSTDIMEN.STA_INDEX_INST_ID;
                STAINDEXINSTDIMEN.DIM_CODE:=E7STAINDEXINSTDIMEN.DIM_CODE;
                STAINDEXINSTDIMEN.DIM_DETAIL_CODE:=E7STAINDEXINSTDIMEN.DIM_DETAIL_CODE;
                STAINDEXINSTDIMEN.DIM_SOURCE:=NULL;
                STAINDEXINSTDIMEN.DIM_DETEAIL_ID:=NULL;
                STAINDEXINSTDIMEN.DIM_DETEAIL_ID2:=NULL;
                STAINDEXINSTDIMEN.UNIT_CODE:=NULL;
                STAINDEXINSTDIMEN.COMPOSITE_DIM_CODE:=E7STAINDEXINSTDIMEN.COMPOSITE_DIM_CODE;
                STAINDEXINSTDIMEN.CREATE_TIME:=SYSDATE;
                STAINDEXINSTDIMEN.UPDATE_TIME:=SYSDATE;
                INSERT INTO E7_STA_INDEX_INST_DIMEN VALUES STAINDEXINSTDIMEN;
       END LOOP;
       COMMIT;
        EXCEPTION WHEN OTHERS THEN
                ROLLBACK;
       END;




  PROCEDURE CREATE_XNNWREPINST(P_RPTCODE  IN VARCHAR2,
                         P_RPTYEAR  IN VARCHAR2,
                         P_RPTMONTH IN VARCHAR2,
                         P_RPTORGID IN VARCHAR2) AS
   BEGIN
     DELDATAS(P_RPTCODE,P_RPTYEAR,P_RPTMONTH,P_RPTORGID);
     insert into e7_sta_repinst
       select 'QY'||P_RPTCODE||P_RPTORGID||P_RPTYEAR||lpad(P_RPTMONTH,2,0) as repinst_id,
        P_RPTORGID as org_id,
        P_RPTCODE as report_code,
        P_RPTYEAR as report_year,
        to_char(to_date(P_RPTYEAR||lpad(P_RPTMONTH,2,0),'yyyyMM'), 'Q') as report_quarter,
        P_RPTMONTH as report_month,
        3 as report_frequent_code,
        '02' as status,
        null as writer,
        sysdate as write_date,
        null as checjer,
        sysdate as check_date,
        null as condition,
        null as verify_note,
        P_RPTMONTH as create_user_id,
        null as create_user_name,
        sysdate as create_time,
        P_RPTMONTH as update_user_id,
        null as update_user_name,
        sysdate as update_time
        from dual;
        COMMIT;
        EXCEPTION WHEN OTHERS THEN
                ROLLBACK;
        END;


     PROCEDURE DELDATAS(P_RPTCODE  IN VARCHAR2,
                         P_RPTYEAR  IN VARCHAR2,
                         P_RPTMONTH IN VARCHAR2,
                         P_RPTORGID IN VARCHAR2) AS
  BEGIN
    delete from e7_sta_index_inst_dimen
     where sta_index_inst_id in
           (select sta_index_inst_id
              from e7_sta_index_inst
             where sta_index_inst_id in
                   (select sta_index_inst_id
                      from e7_sta_rpt_index_inst
                     where repinst_id in
                           (select repinst_id
                              from e7_sta_repinst
                             where report_code = P_RPTCODE
                               and report_year = P_RPTYEAR
                               and report_month = P_RPTMONTH
                               and org_id = P_RPTORGID
                               and STATUS in ('02','04'))));
    COMMIT;
    delete from e7_sta_index_inst
     where sta_index_inst_id in
           (select sta_index_inst_id
              from e7_sta_rpt_index_inst
             where repinst_id in
                   (select repinst_id
                      from e7_sta_repinst
                     where report_code = P_RPTCODE
                       and report_year = P_RPTYEAR
                       and report_month = P_RPTMONTH
                       and org_id = P_RPTORGID
                       and STATUS in ('02','04')));
    COMMIT;
    delete from e7_sta_rpt_index_inst
     where repinst_id in (select repinst_id
                            from e7_sta_repinst
                           where report_code = P_RPTCODE
                             and report_year = P_RPTYEAR
                             and report_month = P_RPTMONTH
                             and org_id = P_RPTORGID
                             and STATUS in ('02','04'));
    COMMIT;
    delete from e7_sta_repinst
           where repinst_id in (select repinst_id
                            from e7_sta_repinst
                           where report_code = P_RPTCODE
                             and report_year = P_RPTYEAR
                             and report_month = P_RPTMONTH
                             and org_id = P_RPTORGID
                             and STATUS in ('02','04'));
                             COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
  END;


  PROCEDURE DELDATAXN(P_RPTCODE  IN VARCHAR2,
                         P_RPTYEAR  IN VARCHAR2,
                         P_RPTMONTH IN VARCHAR2,
                         P_RPTORGID IN VARCHAR2) AS
  BEGIN
    delete from e7_sta_index_inst_dimen
     where sta_index_inst_id in
           (select sta_index_inst_id
              from e7_sta_index_inst
             where sta_index_inst_id in
                   (select sta_index_inst_id
                      from e7_sta_rpt_index_inst
                     where repinst_id in
                           (select repinst_id
                              from e7_sta_repinst
                             where report_code = P_RPTCODE
                               and report_year = P_RPTYEAR
                               and report_month = P_RPTMONTH
                               and org_id = P_RPTORGID
                               and STATUS in ('02','04'))));
    COMMIT;
    delete from e7_sta_index_inst
     where sta_index_inst_id in
           (select sta_index_inst_id
              from e7_sta_rpt_index_inst
             where repinst_id in
                   (select repinst_id
                      from e7_sta_repinst
                     where report_code = P_RPTCODE
                       and report_year = P_RPTYEAR
                       and report_month = P_RPTMONTH
                       and org_id = P_RPTORGID
                       and STATUS in ('02','04')));
    COMMIT;
    delete from e7_sta_rpt_index_inst
     where repinst_id in (select repinst_id
                            from e7_sta_repinst
                           where report_code = P_RPTCODE
                             and report_year = P_RPTYEAR
                             and report_month = P_RPTMONTH
                             and org_id = P_RPTORGID
                             and STATUS in ('02','04'));
    COMMIT;
    delete from e7_sta_repinst
           where repinst_id in (select repinst_id
                            from e7_sta_repinst
                           where report_code = P_RPTCODE
                             and report_year = P_RPTYEAR
                             and report_month = P_RPTMONTH
                             and org_id = P_RPTORGID
                             and STATUS in ('02','04'));
                             COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
    DBMS_OUTPUT.put_line(SQLERRM);
      ROLLBACK;
  END;
  --进销存上市
  PROCEDURE DATATransJXCLising(P_RPTCODE     IN VARCHAR2,
                            P_RPTYEAR     IN VARCHAR2,
                            P_RPTMONTH    IN VARCHAR2,
                            P_RPTORGID    IN VARCHAR2)
                            as
    CURSOR RPTINDEXINST IS SELECT * FROM (
    with a as
 (SELECT AA.REPINST_ID, BB.*
    FROM (SELECT REPINST_ID
            FROM E7_STA_REPINST
           WHERE ORG_ID = P_RPTORGID
             AND REPORT_CODE = P_RPTCODE
             AND REPORT_YEAR = P_RPTYEAR
             AND REPORT_MONTH = P_RPTMONTH) AA,
         (select repinst.org_id,
                 repinst.report_year,
                 P_RPTMONTH AS report_month,
                 MAX(indexinst.sta_index_inst_id) STA_INDEX_INST_ID,
                 indexinst.index_code,
                 sum(indexinst.index_value) index_value,
                 indexinst.COMPOSITED_INDEX_CODE,
                 dimeninst.dim_code as dim_code,
                 dimeninst.dim_detail_code as dim_detail_code,
                 dimeninst2.dim_code as dim_code2,
                 dimeninst2.dim_detail_code as dim_detail_code2,
                 dimeninst3.dim_code as dim_code3,
                 dimeninst3.dim_detail_code as dim_detail_code3,
                 dimeninst4.dim_code as dim_code4,
                 dimeninst4.dim_detail_code as dim_detail_code4,
                 dimeninst5.dim_code as dim_code5,
                 dimeninst5.dim_detail_code as dim_detail_code5,
                 dimeninst6.dim_code as dim_code6,
                 dimeninst6.dim_detail_code as dim_detail_code6
            from e7_sta_repinst repinst
            left join e7_sta_rpt_index_inst rptindexinst
              on repinst.repinst_id = rptindexinst.repinst_id
            left join e7_sta_index_inst indexinst
              on rptindexinst.sta_index_inst_id = indexinst.sta_index_inst_id
            left join e7_sta_index_inst_dimen dimeninst
              on dimeninst.dim_code = 'Business_type'
             and indexinst.sta_index_inst_id = dimeninst.sta_index_inst_id
            left join e7_sta_index_inst_dimen dimeninst2
              on dimeninst2.dim_code = 'Assets_type'
             and indexinst.sta_index_inst_id = dimeninst2.sta_index_inst_id
            left join e7_sta_index_inst_dimen dimeninst3
              on dimeninst3.dim_code = 'Industry_type'
             and indexinst.sta_index_inst_id = dimeninst3.sta_index_inst_id
            left join e7_sta_index_inst_dimen dimeninst4
              on dimeninst4.dim_code = 'Cru_oil_E_cons_typ'
             and indexinst.sta_index_inst_id = dimeninst4.sta_index_inst_id
            left join e7_sta_index_inst_dimen dimeninst5
              on dimeninst5.dim_code = 'Custom_dimen_first'
             and indexinst.sta_index_inst_id = dimeninst5.sta_index_inst_id
            left join e7_sta_index_inst_dimen dimeninst6
              on dimeninst6.dim_code = 'Custom_dimen_second'
             and indexinst.sta_index_inst_id = dimeninst6.sta_index_inst_id
           where repinst.report_code = P_RPTCODE
             and repinst.org_id = P_RPTORGID
             and indexinst.COMPOSITED_INDEX_CODE = P_RPTORGID
             and repinst.report_year = P_RPTYEAR
             and repinst.report_month <= P_RPTMONTH
           group by repinst.org_id,
                    repinst.report_year,
                    indexinst.index_code,
                    indexinst.COMPOSITED_INDEX_CODE,
                    dimeninst.dim_code,
                    dimeninst.dim_detail_code,
                    dimeninst2.dim_code,
                    dimeninst2.dim_detail_code,
                    dimeninst3.dim_code,
                    dimeninst3.dim_detail_code,
                    dimeninst4.dim_code,
                    dimeninst4.dim_detail_code,
                    dimeninst5.dim_code,
                    dimeninst5.dim_detail_code,
                    dimeninst6.dim_code,
                    dimeninst6.dim_detail_code) BB
                    ),
                    --购进实物量
                    temp1 as (
select  t1.repinst_id,
       P_RPTORGID org_id,
       'C0119' as report_code,
       P_RPTYEAR report_year,
       to_char(to_date(P_RPTYEAR||lpad(P_RPTMONTH,2,0),'yyyyMM'), 'q' ) as report_quarter,
       P_RPTMONTH report_month,
       t1.report_frequent_code,
       t1.status,
       t1.sta_index_inst_id,
       t1.index_code,
       t2.index_value,
       t1.unit_code,
       t1.index_inst_orderno,
       t1.composited_index_code,
       t1.repinst_dtl_dimen,
       t1.dim_code,
       t1.dim_detail_code,
       t1.repinst_dtl_dimen2,
       t1.dim_code2,
       t1.dim_detail_code2,
       t1.repinst_dtl_dimen3,
       t1.dim_code3,
       t1.dim_detail_code3,
       t1.repinst_dtl_dimen4,
       t1.dim_code4,
       t1.dim_detail_code4 as dim_detail_code4,
       t1.repinst_dtl_dimen5,
       t1.dim_code5,
       t1.dim_detail_code5 as dim_detail_code5

  from (select *
          from e7_sta_report_trans
         where index_code in ('Buy_in_engy_amt_pratl')
           and dim_detail_code in
               ('Natural_gas', 'Elec', 'Gen_bitu_coal', 'Gsl', 'Dies')) t1
  left join (
  select index_code,dim_detail_code2,dim_detail_code3,dim_detail_code4,sum(index_value) index_value from (
  select index_code,
  dim_detail_code,
                    dim_detail_code2,
                    dim_detail_code3,
                    dim_detail_code4,
                    sum(index_value) index_value
               from a
              where index_code = 'Engy_csmp_amt_pratl'
              
                 and dim_detail_code2 = 'Listing'
                 and (dim_detail_code5 not in( 'Transportation_amount_D', 'Transportation_amount_G') or dim_detail_code5 is null)
              group by index_code,
              dim_detail_code,
                       dim_detail_code2,
                       dim_detail_code3,
                       dim_detail_code4) tt
                        where not exists (select * from (
                  select dim_detail_code,'Natural_gas' as dim_detail_code4 from (
                  select * from e7_sta_dim_detail where dim_code = 'Business_type') 
                  start with dim_detail_code = 'Oil_and_gas_fields'
                  connect by  parent_dim_detail_code = prior dim_detail_code) tt2 where tt.dim_detail_code = tt2.dim_detail_code and tt.dim_detail_code4 = tt2.dim_detail_code4 )
             
                 group by index_code,
                       dim_detail_code2,
                       dim_detail_code3,
                       dim_detail_code4
                       ) t2
    on decode(t1.dim_detail_code,
              'Gen_bitu_coal',
              'Raw_coal',
              t1.dim_detail_code) = t2.dim_detail_code4),
              --购进实物量费用
              temp2 as (
select  t1.repinst_id,
       P_RPTORGID org_id,
       'C0119' as report_code,
       P_RPTYEAR report_year,
       to_char(to_date(P_RPTYEAR||lpad(P_RPTMONTH,2,0),'yyyyMM'), 'q' ) as report_quarter,
       P_RPTMONTH report_month,
       t1.report_frequent_code,
       t1.status,
       t1.sta_index_inst_id,
       t1.index_code,
       t2.index_value,
       t1.unit_code,
       t1.index_inst_orderno,
       t1.composited_index_code,
       t1.repinst_dtl_dimen,
       t1.dim_code,
       t1.dim_detail_code,
       t1.repinst_dtl_dimen2,
       t1.dim_code2,
       t1.dim_detail_code2,
       t1.repinst_dtl_dimen3,
       t1.dim_code3,
       t1.dim_detail_code3,
       t1.repinst_dtl_dimen4,
       t1.dim_code4,
       t1.dim_detail_code4 as dim_detail_code4,
       t1.repinst_dtl_dimen5,
       t1.dim_code5,
       t1.dim_detail_code5 as dim_detail_code5

  from (select *
          from e7_sta_report_trans
         where index_code in ('Buy_in_engy_cost')
           and dim_detail_code in
               ('Natural_gas', 'Elec', 'Gen_bitu_coal', 'Gsl', 'Dies')) t1
  left join (
  select index_code,dim_detail_code2,dim_detail_code3,dim_detail_code4,sum(index_value) index_value from (
  select index_code,dim_detail_code,
                    dim_detail_code2,
                    dim_detail_code3,
                    dim_detail_code4,
                    sum(index_value) index_value
               from a
              where index_code = 'Engy_csmp_cost'
                 and dim_detail_code2 = 'Listing'
                 and (dim_detail_code5 not in( 'Transportation_amount_D', 'Transportation_amount_G') or dim_detail_code5 is null)
              group by index_code,
              dim_detail_code,
                       dim_detail_code2,
                       dim_detail_code3,
                       dim_detail_code4) tt
                        where not exists (select * from (
                  select dim_detail_code,'Natural_gas' as dim_detail_code4 from (
                  select * from e7_sta_dim_detail where dim_code = 'Business_type') 
                  start with dim_detail_code = 'Oil_and_gas_fields'
                  connect by  parent_dim_detail_code = prior dim_detail_code) tt2 where tt.dim_detail_code = tt2.dim_detail_code and tt.dim_detail_code4 = tt2.dim_detail_code4 )
             
                 group by index_code,
                       dim_detail_code2,
                       dim_detail_code3,
                       dim_detail_code4
                       ) t2
    on t1.dim_detail_code =decode( t2.dim_detail_code4, 'Raw_coal','Gen_bitu_coal',t2.dim_detail_code4)),
    --用于原材料
    temp3 as (
    
    
select  t1.repinst_id,
       P_RPTORGID org_id,
       'C0119' as report_code,
       P_RPTYEAR report_year,
       to_char(to_date(P_RPTYEAR||lpad(P_RPTMONTH,2,0),'yyyyMM'), 'q' ) as report_quarter,
       P_RPTMONTH report_month,
       t1.report_frequent_code,
       t1.status,
       t1.sta_index_inst_id,
       t1.index_code,
       t2.index_value,
       t1.unit_code,
       t1.index_inst_orderno,
       t1.composited_index_code,
       t1.repinst_dtl_dimen,
       t1.dim_code,
       t1.dim_detail_code,
       t1.repinst_dtl_dimen2,
       t1.dim_code2,
       t1.dim_detail_code2,
       t1.repinst_dtl_dimen3,
       t1.dim_code3,
       t1.dim_detail_code3,
       t1.repinst_dtl_dimen4,
       t1.dim_code4,
       t1.dim_detail_code4 as dim_detail_code4,
       t1.repinst_dtl_dimen5,
       t1.dim_code5,
       t1.dim_detail_code5 as dim_detail_code5

  from (select *
          from e7_sta_report_trans
         where index_code in ('Engy_used_amt_pratl')
           and dim_detail_code in
               ('Natural_gas', 'Elec', 'Gen_bitu_coal', 'Gsl', 'Dies')
               and dim_detail_code3 = 'E_cons_as_raw_materi'
               ) t1
  left join (select index_code,
                    dim_detail_code2,
                    dim_detail_code3,
                    dim_detail_code4,
                    sum(index_value) index_value
               from a
              where index_code = 'Engy_csmp_amt_pratl'
                 and dim_detail_code2 = 'Listing'
                 and dim_detail_code3 = 'Industry'
                 and dim_detail_code6 = 'Material_own_amount_N'
                               group by index_code,
                       dim_detail_code2,
                       dim_detail_code3,
                       dim_detail_code4) t2
    on t1.dim_detail_code =decode( t2.dim_detail_code4, 'Raw_coal','Gen_bitu_coal',t2.dim_detail_code4)
    
    
          ) ,
          --非工业消费
          temp4 as (
          
    
    
select  t1.repinst_id,
       P_RPTORGID org_id,
       'C0119' as report_code,
       P_RPTYEAR report_year,
       to_char(to_date(P_RPTYEAR||lpad(P_RPTMONTH,2,0),'yyyyMM'), 'q' ) as report_quarter,
       P_RPTMONTH report_month,
       t1.report_frequent_code,
       t1.status,
       t1.sta_index_inst_id,
       t1.index_code,
       t2.index_value,
       t1.unit_code,
       t1.index_inst_orderno,
       t1.composited_index_code,
       t1.repinst_dtl_dimen,
       t1.dim_code,
       t1.dim_detail_code,
       t1.repinst_dtl_dimen2,
       t1.dim_code2,
       t1.dim_detail_code2,
       t1.repinst_dtl_dimen3,
       t1.dim_code3,
       t1.dim_detail_code3,
       t1.repinst_dtl_dimen4,
       t1.dim_code4,
       t1.dim_detail_code4 as dim_detail_code4,
       t1.repinst_dtl_dimen5,
       t1.dim_code5,
       t1.dim_detail_code5 as dim_detail_code5

  from (select *
          from e7_sta_report_trans
         where index_code in ('Engy_used_amt_pratl')
           and dim_detail_code in
               ('Natural_gas', 'Elec', 'Gen_bitu_coal', 'Gsl', 'Dies')
               and dim_detail_code3 = 'Non_Indust_prod_cons'
               ) t1
  left join (select index_code,
                    dim_detail_code2,
                    dim_detail_code3,
                    dim_detail_code4,
                    sum(index_value) index_value
               from a
              where index_code = 'Engy_csmp_amt_pratl'
                 and dim_detail_code2 = 'Listing'
                 and dim_detail_code3 = 'Non_industrial'
                 and (dim_detail_code5 not in( 'Transportation_amount_D', 'Transportation_amount_G') or dim_detail_code5 is null)
                -- and dim_detail_code
                               group by index_code,
                       dim_detail_code2,
                       dim_detail_code3,
                       dim_detail_code4) t2
    on t1.dim_detail_code =decode( t2.dim_detail_code4, 'Raw_coal','Gen_bitu_coal',t2.dim_detail_code4)
    ),
    --运输消费
          temp5 as (
          select 
           t1.repinst_id,
       P_RPTORGID as org_id,
       'C0119' as report_code,
       P_RPTYEAR report_year,
       to_char(to_date(P_RPTYEAR||lpad(P_RPTMONTH,2,0),'yyyyMM'), 'q' ) as report_quarter,
       P_RPTMONTH report_month,
       t1.report_frequent_code,
       t1.status,
       t1.sta_index_inst_id,
       t1.index_code,
       t2.index_value,
       t1.unit_code,
       t1.index_inst_orderno,
       t1.composited_index_code,
       t1.repinst_dtl_dimen,
       t1.dim_code,
       t1.dim_detail_code,
       t1.repinst_dtl_dimen2,
       t1.dim_code2,
       t1.dim_detail_code2,
       t1.repinst_dtl_dimen3,
       t1.dim_code3,
       t1.dim_detail_code3,
       t1.repinst_dtl_dimen4,
       t1.dim_code4,
       t1.dim_detail_code4 as dim_detail_code4,
       t1.repinst_dtl_dimen5,
       t1.dim_code5,
       t1.dim_detail_code5 as dim_detail_code5
  from (select *
          from e7_sta_report_trans
         where index_code in ('Engy_used_amt_pratl')
           and dim_detail_code in
               ('Natural_gas', 'Elec', 'Gen_bitu_coal', 'Gsl', 'Dies')
               and dim_detail_code2 = 'Trans_cons'
               ) t1
  left join (select index_code,
                    dim_detail_code2,
                    dim_detail_code3,
                    dim_detail_code4,
                    sum(index_value) index_value
               from a
              where index_code = 'Engy_csmp_amt_pratl'
                 and dim_detail_code2 = 'Listing'
                 and (dim_detail_code5 in ( 'Transportation_amount_D','Transportation_amount_G') or dim_detail_code6 = 'Transportation_amount_N')
                               group by index_code,
                       dim_detail_code2,
                       dim_detail_code3,
                       dim_detail_code4) t2
    on t1.dim_detail_code =decode( t2.dim_detail_code4, 'Raw_coal','Gen_bitu_coal',t2.dim_detail_code4)),
    
    --工业消费其他的值
    value_industOther as (
    select dim_detail_code4,nvl(value1,0)-nvl(value2,0)-nvl(value3,0) as index_value from (
     select 
     t1.dim_detail_code4,
    t1.index_value as value1,
    t2.index_value as value2,
    t3.index_value as value3
      from (
     
     select 
                    dim_detail_code4,
                    sum(index_value) index_value
               from a
              where index_code = 'Engy_csmp_amt_pratl'
                 and dim_detail_code2 = 'Listing'
                 and (dim_detail_code5 not in  ('Transportation_amount_D','Transportation_amount_G') or dim_detail_code5 is null)
                group by dim_detail_code4
     
     ) t1 --总消耗
     ,
     
     (
     select 
                    dim_detail_code4,
                    sum(index_value) index_value
               from a
              where index_code = 'Engy_csmp_amt_pratl'
                 and dim_detail_code2 = 'Listing'
                 and dim_detail_code3 = 'Non_industrial'
                 and (dim_detail_code5 not in  ('Transportation_amount_D','Transportation_amount_G') or dim_detail_code5 is null)
                -- and dim_detail_code
                               group by 
                       dim_detail_code4
     ) t2 --非工业消耗
     
     ,
     (select 
                    dim_detail_code4,
                    sum(index_value) index_value
               from a
              where index_code = 'Engy_csmp_amt_pratl'
                 and dim_detail_code2 = 'Listing'
                 and dim_detail_code3 = 'Industry'
                 and dim_detail_code6 = 'Material_own_amount_N'
                               group by 
                       dim_detail_code4
     ) t3 --原材料
     where t1.dim_detail_code4 = t2.dim_detail_code4 (+)
     and t1.dim_detail_code4 = t3.dim_detail_code4(+)
     )
     
    ),
    
    --工业生产消费中的其他
    temp6 as (
          select
         t1.repinst_id,
       P_RPTORGID org_id,
       'C0119' as report_code,
       P_RPTYEAR report_year,
       to_char(to_date(P_RPTYEAR||lpad(P_RPTMONTH,2,0),'yyyyMM'), 'q' ) as report_quarter,
       P_RPTMONTH report_month,
       t1.report_frequent_code,
       t1.status,
       t1.sta_index_inst_id,
       t1.index_code,
       t2.index_value,
       t1.unit_code,
       t1.index_inst_orderno,
       t1.composited_index_code,
       t1.repinst_dtl_dimen,
       t1.dim_code,
       t1.dim_detail_code,
       t1.repinst_dtl_dimen2,
       t1.dim_code2,
       t1.dim_detail_code2,
       t1.repinst_dtl_dimen3,
       t1.dim_code3,
       t1.dim_detail_code3,
       t1.repinst_dtl_dimen4,
       t1.dim_code4,
       t1.dim_detail_code4 as dim_detail_code4,
       t1.repinst_dtl_dimen5,
       t1.dim_code5,
       t1.dim_detail_code5 as dim_detail_code5
  from (select *
          from e7_sta_report_trans
         where index_code in ('Engy_used_amt_pratl')
           and dim_detail_code in
               ('Natural_gas', 'Elec', 'Gen_bitu_coal', 'Gsl', 'Dies')
               and dim_detail_code3 = 'Other_consum'
               ) t1
  left join value_industOther t2
    on t1.dim_detail_code =decode( t2.dim_detail_code4, 'Raw_coal','Gen_bitu_coal',t2.dim_detail_code4)
    ),
    --合计的另一半
    temp7 as (
    
          select
        t1.repinst_id,
       P_RPTORGID org_id,
       'C0119' as report_code,
       P_RPTYEAR report_year,
       to_char(to_date(P_RPTYEAR||lpad(P_RPTMONTH,2,0),'yyyyMM'), 'q' ) as report_quarter,
       P_RPTMONTH report_month,
       t1.report_frequent_code,
       t1.status,
       t1.sta_index_inst_id,
       t1.index_code,
       tp.index_value,
       t1.unit_code,
       t1.index_inst_orderno,
       t1.composited_index_code,
       t1.repinst_dtl_dimen,
       t1.dim_code,
       t1.dim_detail_code,
       t1.repinst_dtl_dimen2,
       t1.dim_code2,
       t1.dim_detail_code2,
       t1.repinst_dtl_dimen3,
       t1.dim_code3,
       t1.dim_detail_code3,
       t1.repinst_dtl_dimen4,
       t1.dim_code4,
       t1.dim_detail_code4 as dim_detail_code4,
       t1.repinst_dtl_dimen5,
       t1.dim_code5,
       t1.dim_detail_code5 as dim_detail_code5
  from (select *
          from e7_sta_report_trans
         where index_code in ('Engy_used_amt_pratl')
           and dim_detail_code in
               ('Natural_gas', 'Elec', 'Gen_bitu_coal', 'Gsl', 'Dies')
               and dim_detail_code2 = 'Other_consum'
               ) t1
  left join (
  
    select dim_detail_code4,nvl(value1,0)-nvl(value2,0) as index_value from (
     select 
     t1.dim_detail_code4,
    t1.index_value as value1,
    t2.index_value as value2
      from (
     
     select 
                    dim_detail_code4,
                    sum(index_value) index_value
               from a
              where index_code = 'Engy_csmp_amt_pratl'
                 and dim_detail_code2 = 'Listing'
                 and (dim_detail_code5 not in  ('Transportation_amount_D','Transportation_amount_G') or dim_detail_code5 is null)
                group by dim_detail_code4
     
     ) t1 --总消耗
     left join 
     
     (
     select 
                    dim_detail_code4,
                    sum(index_value) index_value
               from a
              where index_code = 'Engy_csmp_amt_pratl'
                 and dim_detail_code2 = 'Listing'
                 and (dim_detail_code5 in( 'Transportation_amount_D','Transportation_amount_G') or dim_detail_code6 = 'Transportation_amount_N')
                -- and dim_detail_code
                
                               group by 
                       dim_detail_code4
     ) t2 --运输消耗
     on t1.dim_detail_code4 =decode( t2.dim_detail_code4, 'Raw_coal','Gen_bitu_coal',t2.dim_detail_code4)
     )
  
  
  ) tp
  on t1.dim_detail_code =decode( tp.dim_detail_code4, 'Raw_coal','Gen_bitu_coal',tp.dim_detail_code4)
    
    ),
    --工业和非工业
    --工业
    temp8 as (
select  t1.repinst_id,
       P_RPTORGID org_id,
       'C0119' as report_code,
       P_RPTYEAR report_year,
       to_char(to_date(P_RPTYEAR||lpad(P_RPTMONTH,2,0),'yyyyMM'), 'q' ) as report_quarter,
       P_RPTMONTH report_month,
       t1.report_frequent_code,
       t1.status,
       t1.sta_index_inst_id,
       t1.index_code,
       t2.index_value,
       t1.unit_code,
       t1.index_inst_orderno,
       t1.composited_index_code,
       t1.repinst_dtl_dimen,
       t1.dim_code,
       t1.dim_detail_code,
       t1.repinst_dtl_dimen2,
       t1.dim_code2,
       t1.dim_detail_code2,
       t1.repinst_dtl_dimen3,
       t1.dim_code3,
       t1.dim_detail_code3,
       t1.repinst_dtl_dimen4,
       t1.dim_code4,
       t1.dim_detail_code4 as dim_detail_code4,
       t1.repinst_dtl_dimen5,
       t1.dim_code5,
       t1.dim_detail_code5 as dim_detail_code5

  from (select *
          from e7_sta_report_trans
         where index_code in ('Comph_engy_csmp_amt')
          and dim_detail_code5 = 'Industry'
               ) t1
  left join (select index_code,
                    dim_detail_code2,
                    dim_detail_code3,
                    dim_detail_code4,
                    sum(index_value) index_value
               from a
              where index_code = 'Engy_csmp_amt_stadc'
                 and dim_detail_code2 = 'Listing'
                 and dim_detail_code3 = 'Industry'
                 and (dim_detail_code5 not in  ('Transportation_amount_D','Transportation_amount_G') or dim_detail_code5 is null)
                -- and dim_detail_code
                               group by index_code,
                       dim_detail_code2,
                       dim_detail_code3,
                       dim_detail_code4) t2
    on t1.index_code =decode( t2.index_code, 'Engy_csmp_amt_stadc','Comph_engy_csmp_amt',t2.dim_detail_code4)
    
          
    ),
    --非工业
    temp9 as (
select t1.repinst_id,
       P_RPTORGID org_id,
       'C0119' as report_code,
       P_RPTYEAR report_year,
       to_char(to_date(P_RPTYEAR||lpad(P_RPTMONTH,2,0),'yyyyMM'), 'q' ) as report_quarter,
       P_RPTMONTH report_month,
       t1.report_frequent_code,
       t1.status,
       t1.sta_index_inst_id,
       t1.index_code,
       t2.index_value,
       t1.unit_code,
       t1.index_inst_orderno,
       t1.composited_index_code,
       t1.repinst_dtl_dimen,
       t1.dim_code,
       t1.dim_detail_code,
       t1.repinst_dtl_dimen2,
       t1.dim_code2,
       t1.dim_detail_code2,
       t1.repinst_dtl_dimen3,
       t1.dim_code3,
       t1.dim_detail_code3,
       t1.repinst_dtl_dimen4,
       t1.dim_code4,
       t1.dim_detail_code4 as dim_detail_code4,
       t1.repinst_dtl_dimen5,
       t1.dim_code5,
       t1.dim_detail_code5 as dim_detail_code5

  from (select *
          from e7_sta_report_trans
         where index_code in ('Comph_engy_csmp_amt')
          and dim_detail_code5 = 'Non_industrial'
               ) t1
  left join (select index_code,
                    dim_detail_code2,
                    dim_detail_code3,
                    dim_detail_code4,
                    sum(index_value) index_value
               from a
              where index_code = 'Engy_csmp_amt_stadc'
                 and dim_detail_code2 = 'Listing'
                 and dim_detail_code3 = 'Non_industrial'
                 and (dim_detail_code5 not in  ('Transportation_amount_D','Transportation_amount_G') or dim_detail_code5 is null)
                -- and dim_detail_code
                               group by index_code,
                       dim_detail_code2,
                       dim_detail_code3,
                       dim_detail_code4) t2
    on t1.index_code =decode( t2.index_code, 'Engy_csmp_amt_stadc','Comph_engy_csmp_amt',t2.dim_detail_code4)
          
    ),
    --折标系数
    temp10 as (
    SELECT 
          t1.repinst_id,
       P_RPTORGID org_id,
       'C0119' as report_code,
       P_RPTYEAR report_year,
       to_char(to_date(P_RPTYEAR||lpad(P_RPTMONTH,2,0),'yyyyMM'), 'q' )  report_quarter,
       P_RPTMONTH report_month,
       t1.report_frequent_code,
       t1.status,
       t1.sta_index_inst_id,
       t1.index_code,
       t1.index_value,
       t1.unit_code,
       t1.index_inst_orderno,
       t1.composited_index_code,
       t1.repinst_dtl_dimen,
       t1.dim_code,
       t1.dim_detail_code,
       t1.repinst_dtl_dimen2,
       t1.dim_code2,
       t1.dim_detail_code2,
       t1.repinst_dtl_dimen3,
       t1.dim_code3,
       t1.dim_detail_code3,
       t1.repinst_dtl_dimen4,
       t1.dim_code4,
       t1.dim_detail_code4 as dim_detail_code4,
       t1.repinst_dtl_dimen5,
       t1.dim_code5,
       t1.dim_detail_code5 as dim_detail_code5
       FROM E7_STA_REPORT_TRANS t1 WHERE INDEX_CODE in( 'Stadc_coef','Ybegin_stor_engy_amt_pratl','Latest_stor_engy_amt_pratl')
    ),
    results as (
    select 
     repinst_id,
       org_id,
      report_code,
      report_year,
       report_quarter,
       report_month,
       report_frequent_code,
       status,
       DECODE(STA_INDEX_INST_ID,NULL,NULL,sta_index_inst_id) sta_index_inst_id,
       index_code,
       index_value,
       unit_code,
       index_inst_orderno,
       composited_index_code,
       DECODE(repinst_dtl_dimen,NULL,NULL,repinst_dtl_dimen) repinst_dtl_dimen,
       dim_code,
       dim_detail_code,
       DECODE(repinst_dtl_dimen2,NULL,NULL,repinst_dtl_dimen2) repinst_dtl_dimen2,
       dim_code2,
       dim_detail_code2,
       DECODE(repinst_dtl_dimen3,NULL,NULL,repinst_dtl_dimen3) repinst_dtl_dimen3,
       dim_code3,
       dim_detail_code3,
       DECODE(repinst_dtl_dimen4,NULL,NULL,repinst_dtl_dimen4) repinst_dtl_dimen4,
       dim_code4,
       dim_detail_code4,
       DECODE(repinst_dtl_dimen5,NULL,NULL,repinst_dtl_dimen5) repinst_dtl_dimen5,
       dim_code5,
       dim_detail_code5
     from (
          select * from temp1 
          union all
          select * from temp2
          union all
          select * from temp3
          union all
          select * from temp4
          union all
          select * from temp5
          union all
          select * from temp6
          union all
          select * from temp7
          union all
          select * from temp8
          union all
          select * from temp9
          union all
          select * from temp10
          
          )
          )
          select 
          distinct 'QY'||'C0119'||P_RPTORGID||P_RPTYEAR||lpad(P_RPTMONTH,2,0) AS REPINST_ID,
          'TRANS'||P_RPTORGID||STA_INDEX_INST_ID AS STA_INDEX_INST_ID,
          null as create_time,
          null as update_time
          from results
          
    );
    CURSOR INDEXINST IS SELECT * FROM (
    with a as
 (SELECT AA.REPINST_ID, BB.*
    FROM (SELECT REPINST_ID
            FROM E7_STA_REPINST
           WHERE ORG_ID = P_RPTORGID
             AND REPORT_CODE = P_RPTCODE
             AND REPORT_YEAR = P_RPTYEAR
             AND REPORT_MONTH = P_RPTMONTH) AA,
         (select repinst.org_id,
                 repinst.report_year,
                 P_RPTMONTH AS report_month,
                 MAX(indexinst.sta_index_inst_id) STA_INDEX_INST_ID,
                 indexinst.index_code,
                 sum(indexinst.index_value) index_value,
                 indexinst.COMPOSITED_INDEX_CODE,
                 dimeninst.dim_code as dim_code,
                 dimeninst.dim_detail_code as dim_detail_code,
                 dimeninst2.dim_code as dim_code2,
                 dimeninst2.dim_detail_code as dim_detail_code2,
                 dimeninst3.dim_code as dim_code3,
                 dimeninst3.dim_detail_code as dim_detail_code3,
                 dimeninst4.dim_code as dim_code4,
                 dimeninst4.dim_detail_code as dim_detail_code4,
                 dimeninst5.dim_code as dim_code5,
                 dimeninst5.dim_detail_code as dim_detail_code5,
                 dimeninst6.dim_code as dim_code6,
                 dimeninst6.dim_detail_code as dim_detail_code6
            from e7_sta_repinst repinst
            left join e7_sta_rpt_index_inst rptindexinst
              on repinst.repinst_id = rptindexinst.repinst_id
            left join e7_sta_index_inst indexinst
              on rptindexinst.sta_index_inst_id = indexinst.sta_index_inst_id
            left join e7_sta_index_inst_dimen dimeninst
              on dimeninst.dim_code = 'Business_type'
             and indexinst.sta_index_inst_id = dimeninst.sta_index_inst_id
            left join e7_sta_index_inst_dimen dimeninst2
              on dimeninst2.dim_code = 'Assets_type'
             and indexinst.sta_index_inst_id = dimeninst2.sta_index_inst_id
            left join e7_sta_index_inst_dimen dimeninst3
              on dimeninst3.dim_code = 'Industry_type'
             and indexinst.sta_index_inst_id = dimeninst3.sta_index_inst_id
            left join e7_sta_index_inst_dimen dimeninst4
              on dimeninst4.dim_code = 'Cru_oil_E_cons_typ'
             and indexinst.sta_index_inst_id = dimeninst4.sta_index_inst_id
            left join e7_sta_index_inst_dimen dimeninst5
              on dimeninst5.dim_code = 'Custom_dimen_first'
             and indexinst.sta_index_inst_id = dimeninst5.sta_index_inst_id
            left join e7_sta_index_inst_dimen dimeninst6
              on dimeninst6.dim_code = 'Custom_dimen_second'
             and indexinst.sta_index_inst_id = dimeninst6.sta_index_inst_id
           where repinst.report_code = P_RPTCODE
             and repinst.org_id = P_RPTORGID
             and indexinst.COMPOSITED_INDEX_CODE = P_RPTORGID
             and repinst.report_year = P_RPTYEAR
             and repinst.report_month <= P_RPTMONTH
           group by repinst.org_id,
                    repinst.report_year,
                    indexinst.index_code,
                    indexinst.COMPOSITED_INDEX_CODE,
                    dimeninst.dim_code,
                    dimeninst.dim_detail_code,
                    dimeninst2.dim_code,
                    dimeninst2.dim_detail_code,
                    dimeninst3.dim_code,
                    dimeninst3.dim_detail_code,
                    dimeninst4.dim_code,
                    dimeninst4.dim_detail_code,
                    dimeninst5.dim_code,
                    dimeninst5.dim_detail_code,
                    dimeninst6.dim_code,
                    dimeninst6.dim_detail_code) BB
                    ),
                   --购进实物量
                    temp1 as (
select  t1.repinst_id,
       P_RPTORGID org_id,
       'C0119' as report_code,
       P_RPTYEAR report_year,
       to_char(to_date(P_RPTYEAR||lpad(P_RPTMONTH,2,0),'yyyyMM'), 'q' ) as report_quarter,
       P_RPTMONTH report_month,
       t1.report_frequent_code,
       t1.status,
       t1.sta_index_inst_id,
       t1.index_code,
       t2.index_value,
       t1.unit_code,
       t1.index_inst_orderno,
       t1.composited_index_code,
       t1.repinst_dtl_dimen,
       t1.dim_code,
       t1.dim_detail_code,
       t1.repinst_dtl_dimen2,
       t1.dim_code2,
       t1.dim_detail_code2,
       t1.repinst_dtl_dimen3,
       t1.dim_code3,
       t1.dim_detail_code3,
       t1.repinst_dtl_dimen4,
       t1.dim_code4,
       t1.dim_detail_code4 as dim_detail_code4,
       t1.repinst_dtl_dimen5,
       t1.dim_code5,
       t1.dim_detail_code5 as dim_detail_code5

  from (select *
          from e7_sta_report_trans
         where index_code in ('Buy_in_engy_amt_pratl')
           and dim_detail_code in
               ('Natural_gas', 'Elec', 'Gen_bitu_coal', 'Gsl', 'Dies')) t1
  left join (
  select index_code,dim_detail_code2,dim_detail_code3,dim_detail_code4,sum(index_value) index_value from (
  select index_code,
  dim_detail_code,
                    dim_detail_code2,
                    dim_detail_code3,
                    dim_detail_code4,
                    sum(index_value) index_value
               from a
              where index_code = 'Engy_csmp_amt_pratl'
              
                 and dim_detail_code2 = 'Listing'
                 and (dim_detail_code5 not in( 'Transportation_amount_D', 'Transportation_amount_G') or dim_detail_code5 is null)
              group by index_code,
              dim_detail_code,
                       dim_detail_code2,
                       dim_detail_code3,
                       dim_detail_code4) tt
                        where not exists (select * from (
                  select dim_detail_code,'Natural_gas' as dim_detail_code4 from (
                  select * from e7_sta_dim_detail where dim_code = 'Business_type') 
                  start with dim_detail_code = 'Oil_and_gas_fields'
                  connect by  parent_dim_detail_code = prior dim_detail_code) tt2 where tt.dim_detail_code = tt2.dim_detail_code and tt.dim_detail_code4 = tt2.dim_detail_code4 )
             
                 group by index_code,
                       dim_detail_code2,
                       dim_detail_code3,
                       dim_detail_code4
                       ) t2
    on decode(t1.dim_detail_code,
              'Gen_bitu_coal',
              'Raw_coal',
              t1.dim_detail_code) = t2.dim_detail_code4),
              --购进实物量费用
              temp2 as (
select  t1.repinst_id,
       P_RPTORGID org_id,
       'C0119' as report_code,
       P_RPTYEAR report_year,
       to_char(to_date(P_RPTYEAR||lpad(P_RPTMONTH,2,0),'yyyyMM'), 'q' ) as report_quarter,
       P_RPTMONTH report_month,
       t1.report_frequent_code,
       t1.status,
       t1.sta_index_inst_id,
       t1.index_code,
       t2.index_value,
       t1.unit_code,
       t1.index_inst_orderno,
       t1.composited_index_code,
       t1.repinst_dtl_dimen,
       t1.dim_code,
       t1.dim_detail_code,
       t1.repinst_dtl_dimen2,
       t1.dim_code2,
       t1.dim_detail_code2,
       t1.repinst_dtl_dimen3,
       t1.dim_code3,
       t1.dim_detail_code3,
       t1.repinst_dtl_dimen4,
       t1.dim_code4,
       t1.dim_detail_code4 as dim_detail_code4,
       t1.repinst_dtl_dimen5,
       t1.dim_code5,
       t1.dim_detail_code5 as dim_detail_code5

  from (select *
          from e7_sta_report_trans
         where index_code in ('Buy_in_engy_cost')
           and dim_detail_code in
               ('Natural_gas', 'Elec', 'Gen_bitu_coal', 'Gsl', 'Dies')) t1
  left join (
  select index_code,dim_detail_code2,dim_detail_code3,dim_detail_code4,sum(index_value) index_value from (
  select index_code,dim_detail_code,
                    dim_detail_code2,
                    dim_detail_code3,
                    dim_detail_code4,
                    sum(index_value) index_value
               from a
              where index_code = 'Engy_csmp_cost'
                 and dim_detail_code2 = 'Listing'
                 and (dim_detail_code5 not in( 'Transportation_amount_D', 'Transportation_amount_G') or dim_detail_code5 is null)
              group by index_code,
              dim_detail_code,
                       dim_detail_code2,
                       dim_detail_code3,
                       dim_detail_code4) tt
                        where not exists (select * from (
                  select dim_detail_code,'Natural_gas' as dim_detail_code4 from (
                  select * from e7_sta_dim_detail where dim_code = 'Business_type') 
                  start with dim_detail_code = 'Oil_and_gas_fields'
                  connect by  parent_dim_detail_code = prior dim_detail_code) tt2 where tt.dim_detail_code = tt2.dim_detail_code and tt.dim_detail_code4 = tt2.dim_detail_code4 )
             
                 group by index_code,
                       dim_detail_code2,
                       dim_detail_code3,
                       dim_detail_code4
                       ) t2
    on t1.dim_detail_code =decode( t2.dim_detail_code4, 'Raw_coal','Gen_bitu_coal',t2.dim_detail_code4)),
    --用于原材料
    temp3 as (
    
    
select  t1.repinst_id,
       P_RPTORGID org_id,
       'C0119' as report_code,
       P_RPTYEAR report_year,
       to_char(to_date(P_RPTYEAR||lpad(P_RPTMONTH,2,0),'yyyyMM'), 'q' ) as report_quarter,
       P_RPTMONTH report_month,
       t1.report_frequent_code,
       t1.status,
       t1.sta_index_inst_id,
       t1.index_code,
       t2.index_value,
       t1.unit_code,
       t1.index_inst_orderno,
       t1.composited_index_code,
       t1.repinst_dtl_dimen,
       t1.dim_code,
       t1.dim_detail_code,
       t1.repinst_dtl_dimen2,
       t1.dim_code2,
       t1.dim_detail_code2,
       t1.repinst_dtl_dimen3,
       t1.dim_code3,
       t1.dim_detail_code3,
       t1.repinst_dtl_dimen4,
       t1.dim_code4,
       t1.dim_detail_code4 as dim_detail_code4,
       t1.repinst_dtl_dimen5,
       t1.dim_code5,
       t1.dim_detail_code5 as dim_detail_code5

  from (select *
          from e7_sta_report_trans
         where index_code in ('Engy_used_amt_pratl')
           and dim_detail_code in
               ('Natural_gas', 'Elec', 'Gen_bitu_coal', 'Gsl', 'Dies')
               and dim_detail_code3 = 'E_cons_as_raw_materi'
               ) t1
  left join (select index_code,
                    dim_detail_code2,
                    dim_detail_code3,
                    dim_detail_code4,
                    sum(index_value) index_value
               from a
              where index_code = 'Engy_csmp_amt_pratl'
                 and dim_detail_code2 = 'Listing'
                 and dim_detail_code3 = 'Industry'
                 and dim_detail_code6 = 'Material_own_amount_N'
                               group by index_code,
                       dim_detail_code2,
                       dim_detail_code3,
                       dim_detail_code4) t2
    on t1.dim_detail_code =decode( t2.dim_detail_code4, 'Raw_coal','Gen_bitu_coal',t2.dim_detail_code4)
    
    
          ) ,
          --非工业消费
          temp4 as (
          
    
    
select  t1.repinst_id,
       P_RPTORGID org_id,
       'C0119' as report_code,
       P_RPTYEAR report_year,
       to_char(to_date(P_RPTYEAR||lpad(P_RPTMONTH,2,0),'yyyyMM'), 'q' ) as report_quarter,
       P_RPTMONTH report_month,
       t1.report_frequent_code,
       t1.status,
       t1.sta_index_inst_id,
       t1.index_code,
       t2.index_value,
       t1.unit_code,
       t1.index_inst_orderno,
       t1.composited_index_code,
       t1.repinst_dtl_dimen,
       t1.dim_code,
       t1.dim_detail_code,
       t1.repinst_dtl_dimen2,
       t1.dim_code2,
       t1.dim_detail_code2,
       t1.repinst_dtl_dimen3,
       t1.dim_code3,
       t1.dim_detail_code3,
       t1.repinst_dtl_dimen4,
       t1.dim_code4,
       t1.dim_detail_code4 as dim_detail_code4,
       t1.repinst_dtl_dimen5,
       t1.dim_code5,
       t1.dim_detail_code5 as dim_detail_code5

  from (select *
          from e7_sta_report_trans
         where index_code in ('Engy_used_amt_pratl')
           and dim_detail_code in
               ('Natural_gas', 'Elec', 'Gen_bitu_coal', 'Gsl', 'Dies')
               and dim_detail_code3 = 'Non_Indust_prod_cons'
               ) t1
  left join (select index_code,
                    dim_detail_code2,
                    dim_detail_code3,
                    dim_detail_code4,
                    sum(index_value) index_value
               from a
              where index_code = 'Engy_csmp_amt_pratl'
                 and dim_detail_code2 = 'Listing'
                 and dim_detail_code3 = 'Non_industrial'
                 and (dim_detail_code5 not in( 'Transportation_amount_D', 'Transportation_amount_G') or dim_detail_code5 is null)
                -- and dim_detail_code
                               group by index_code,
                       dim_detail_code2,
                       dim_detail_code3,
                       dim_detail_code4) t2
    on t1.dim_detail_code =decode( t2.dim_detail_code4, 'Raw_coal','Gen_bitu_coal',t2.dim_detail_code4)
    ),
    --运输消费
          temp5 as (
          select 
           t1.repinst_id,
       P_RPTORGID as org_id,
       'C0119' as report_code,
       P_RPTYEAR report_year,
       to_char(to_date(P_RPTYEAR||lpad(P_RPTMONTH,2,0),'yyyyMM'), 'q' ) as report_quarter,
       P_RPTMONTH report_month,
       t1.report_frequent_code,
       t1.status,
       t1.sta_index_inst_id,
       t1.index_code,
       t2.index_value,
       t1.unit_code,
       t1.index_inst_orderno,
       t1.composited_index_code,
       t1.repinst_dtl_dimen,
       t1.dim_code,
       t1.dim_detail_code,
       t1.repinst_dtl_dimen2,
       t1.dim_code2,
       t1.dim_detail_code2,
       t1.repinst_dtl_dimen3,
       t1.dim_code3,
       t1.dim_detail_code3,
       t1.repinst_dtl_dimen4,
       t1.dim_code4,
       t1.dim_detail_code4 as dim_detail_code4,
       t1.repinst_dtl_dimen5,
       t1.dim_code5,
       t1.dim_detail_code5 as dim_detail_code5
  from (select *
          from e7_sta_report_trans
         where index_code in ('Engy_used_amt_pratl')
           and dim_detail_code in
               ('Natural_gas', 'Elec', 'Gen_bitu_coal', 'Gsl', 'Dies')
               and dim_detail_code2 = 'Trans_cons'
               ) t1
  left join (select index_code,
                    dim_detail_code2,
                    dim_detail_code3,
                    dim_detail_code4,
                    sum(index_value) index_value
               from a
              where index_code = 'Engy_csmp_amt_pratl'
                 and dim_detail_code2 = 'Listing'
                 and (dim_detail_code5 in ( 'Transportation_amount_D','Transportation_amount_G') or dim_detail_code6 = 'Transportation_amount_N')
                               group by index_code,
                       dim_detail_code2,
                       dim_detail_code3,
                       dim_detail_code4) t2
    on t1.dim_detail_code =decode( t2.dim_detail_code4, 'Raw_coal','Gen_bitu_coal',t2.dim_detail_code4)),
    
    --工业消费其他的值
    value_industOther as (
    select dim_detail_code4,nvl(value1,0)-nvl(value2,0)-nvl(value3,0) as index_value from (
     select 
     t1.dim_detail_code4,
    t1.index_value as value1,
    t2.index_value as value2,
    t3.index_value as value3
      from (
     
     select 
                    dim_detail_code4,
                    sum(index_value) index_value
               from a
              where index_code = 'Engy_csmp_amt_pratl'
                 and dim_detail_code2 = 'Listing'
                 and (dim_detail_code5 not in  ('Transportation_amount_D','Transportation_amount_G') or dim_detail_code5 is null)
                group by dim_detail_code4
     
     ) t1 --总消耗
     ,
     
     (
     select 
                    dim_detail_code4,
                    sum(index_value) index_value
               from a
              where index_code = 'Engy_csmp_amt_pratl'
                 and dim_detail_code2 = 'Listing'
                 and dim_detail_code3 = 'Non_industrial'
                 and (dim_detail_code5 not in  ('Transportation_amount_D','Transportation_amount_G') or dim_detail_code5 is null)
                -- and dim_detail_code
                               group by 
                       dim_detail_code4
     ) t2 --非工业消耗
     
     ,
     (select 
                    dim_detail_code4,
                    sum(index_value) index_value
               from a
              where index_code = 'Engy_csmp_amt_pratl'
                 and dim_detail_code2 = 'Listing'
                 and dim_detail_code3 = 'Industry'
                 and dim_detail_code6 = 'Material_own_amount_N'
                               group by 
                       dim_detail_code4
     ) t3 --原材料
     where t1.dim_detail_code4 = t2.dim_detail_code4 (+)
     and t1.dim_detail_code4 = t3.dim_detail_code4(+)
     )
     
    
    ),
    
    --工业生产消费中的其他
    temp6 as (
          select
         t1.repinst_id,
       P_RPTORGID org_id,
       'C0119' as report_code,
       P_RPTYEAR report_year,
       to_char(to_date(P_RPTYEAR||lpad(P_RPTMONTH,2,0),'yyyyMM'), 'q' ) as report_quarter,
       P_RPTMONTH report_month,
       t1.report_frequent_code,
       t1.status,
       t1.sta_index_inst_id,
       t1.index_code,
       t2.index_value,
       t1.unit_code,
       t1.index_inst_orderno,
       t1.composited_index_code,
       t1.repinst_dtl_dimen,
       t1.dim_code,
       t1.dim_detail_code,
       t1.repinst_dtl_dimen2,
       t1.dim_code2,
       t1.dim_detail_code2,
       t1.repinst_dtl_dimen3,
       t1.dim_code3,
       t1.dim_detail_code3,
       t1.repinst_dtl_dimen4,
       t1.dim_code4,
       t1.dim_detail_code4 as dim_detail_code4,
       t1.repinst_dtl_dimen5,
       t1.dim_code5,
       t1.dim_detail_code5 as dim_detail_code5
  from (select *
          from e7_sta_report_trans
         where index_code in ('Engy_used_amt_pratl')
           and dim_detail_code in
               ('Natural_gas', 'Elec', 'Gen_bitu_coal', 'Gsl', 'Dies')
               and dim_detail_code3 = 'Other_consum'
               ) t1
  left join value_industOther t2
    on t1.dim_detail_code =decode( t2.dim_detail_code4, 'Raw_coal','Gen_bitu_coal',t2.dim_detail_code4)
    ),
    --合计的另一半
    temp7 as (
    
          select
        t1.repinst_id,
       P_RPTORGID org_id,
       'C0119' as report_code,
       P_RPTYEAR report_year,
       to_char(to_date(P_RPTYEAR||lpad(P_RPTMONTH,2,0),'yyyyMM'), 'q' ) as report_quarter,
       P_RPTMONTH report_month,
       t1.report_frequent_code,
       t1.status,
       t1.sta_index_inst_id,
       t1.index_code,
       tp.index_value,
       t1.unit_code,
       t1.index_inst_orderno,
       t1.composited_index_code,
       t1.repinst_dtl_dimen,
       t1.dim_code,
       t1.dim_detail_code,
       t1.repinst_dtl_dimen2,
       t1.dim_code2,
       t1.dim_detail_code2,
       t1.repinst_dtl_dimen3,
       t1.dim_code3,
       t1.dim_detail_code3,
       t1.repinst_dtl_dimen4,
       t1.dim_code4,
       t1.dim_detail_code4 as dim_detail_code4,
       t1.repinst_dtl_dimen5,
       t1.dim_code5,
       t1.dim_detail_code5 as dim_detail_code5
  from (select *
          from e7_sta_report_trans
         where index_code in ('Engy_used_amt_pratl')
           and dim_detail_code in
               ('Natural_gas', 'Elec', 'Gen_bitu_coal', 'Gsl', 'Dies')
               and dim_detail_code2 = 'Other_consum'
               ) t1
  left join (
  
    select dim_detail_code4,nvl(value1,0)-nvl(value2,0) as index_value from (
     select 
     t1.dim_detail_code4,
    t1.index_value as value1,
    t2.index_value as value2
      from (
     
     select 
                    dim_detail_code4,
                    sum(index_value) index_value
               from a
              where index_code = 'Engy_csmp_amt_pratl'
                 and dim_detail_code2 = 'Listing'
                 and (dim_detail_code5 not in  ('Transportation_amount_D','Transportation_amount_G') or dim_detail_code5 is null)
                group by dim_detail_code4
     
     ) t1 --总消耗
     left join 
     
     (
     select 
                    dim_detail_code4,
                    sum(index_value) index_value
               from a
              where index_code = 'Engy_csmp_amt_pratl'
                 and dim_detail_code2 = 'Listing'
                 and (dim_detail_code5 in( 'Transportation_amount_D','Transportation_amount_G') or dim_detail_code6 = 'Transportation_amount_N')
                -- and dim_detail_code
                
                               group by 
                       dim_detail_code4
     ) t2 --运输消耗
     on t1.dim_detail_code4 =decode( t2.dim_detail_code4, 'Raw_coal','Gen_bitu_coal',t2.dim_detail_code4)
     )
  
  
  ) tp
  on t1.dim_detail_code =decode( tp.dim_detail_code4, 'Raw_coal','Gen_bitu_coal',tp.dim_detail_code4)
    
    ),
    --工业和非工业
    --工业
    temp8 as (
select  t1.repinst_id,
       P_RPTORGID org_id,
       'C0119' as report_code,
       P_RPTYEAR report_year,
       to_char(to_date(P_RPTYEAR||lpad(P_RPTMONTH,2,0),'yyyyMM'), 'q' ) as report_quarter,
       P_RPTMONTH report_month,
       t1.report_frequent_code,
       t1.status,
       t1.sta_index_inst_id,
       t1.index_code,
       t2.index_value,
       t1.unit_code,
       t1.index_inst_orderno,
       t1.composited_index_code,
       t1.repinst_dtl_dimen,
       t1.dim_code,
       t1.dim_detail_code,
       t1.repinst_dtl_dimen2,
       t1.dim_code2,
       t1.dim_detail_code2,
       t1.repinst_dtl_dimen3,
       t1.dim_code3,
       t1.dim_detail_code3,
       t1.repinst_dtl_dimen4,
       t1.dim_code4,
       t1.dim_detail_code4 as dim_detail_code4,
       t1.repinst_dtl_dimen5,
       t1.dim_code5,
       t1.dim_detail_code5 as dim_detail_code5

  from (select *
          from e7_sta_report_trans
         where index_code in ('Comph_engy_csmp_amt')
          and dim_detail_code5 = 'Industry'
               ) t1
  left join (select index_code,
                    dim_detail_code2,
                    dim_detail_code3,
                    dim_detail_code4,
                    sum(index_value) index_value
               from a
              where index_code = 'Engy_csmp_amt_stadc'
                 and dim_detail_code2 = 'Listing'
                 and dim_detail_code3 = 'Industry'
                 and (dim_detail_code5 not in  ('Transportation_amount_D','Transportation_amount_G') or dim_detail_code5 is null)
                -- and dim_detail_code
                               group by index_code,
                       dim_detail_code2,
                       dim_detail_code3,
                       dim_detail_code4) t2
    on t1.index_code =decode( t2.index_code, 'Engy_csmp_amt_stadc','Comph_engy_csmp_amt',t2.dim_detail_code4)
    
          
    ),
    --非工业
    temp9 as (
select t1.repinst_id,
       P_RPTORGID org_id,
       'C0119' as report_code,
       P_RPTYEAR report_year,
       to_char(to_date(P_RPTYEAR||lpad(P_RPTMONTH,2,0),'yyyyMM'), 'q' ) as report_quarter,
       P_RPTMONTH report_month,
       t1.report_frequent_code,
       t1.status,
       t1.sta_index_inst_id,
       t1.index_code,
       t2.index_value,
       t1.unit_code,
       t1.index_inst_orderno,
       t1.composited_index_code,
       t1.repinst_dtl_dimen,
       t1.dim_code,
       t1.dim_detail_code,
       t1.repinst_dtl_dimen2,
       t1.dim_code2,
       t1.dim_detail_code2,
       t1.repinst_dtl_dimen3,
       t1.dim_code3,
       t1.dim_detail_code3,
       t1.repinst_dtl_dimen4,
       t1.dim_code4,
       t1.dim_detail_code4 as dim_detail_code4,
       t1.repinst_dtl_dimen5,
       t1.dim_code5,
       t1.dim_detail_code5 as dim_detail_code5

  from (select *
          from e7_sta_report_trans
         where index_code in ('Comph_engy_csmp_amt')
          and dim_detail_code5 = 'Non_industrial'
               ) t1
  left join (select index_code,
                    dim_detail_code2,
                    dim_detail_code3,
                    dim_detail_code4,
                    sum(index_value) index_value
               from a
              where index_code = 'Engy_csmp_amt_stadc'
                 and dim_detail_code2 = 'Listing'
                 and dim_detail_code3 = 'Non_industrial'
                 and (dim_detail_code5 not in  ('Transportation_amount_D','Transportation_amount_G') or dim_detail_code5 is null)
                -- and dim_detail_code
                               group by index_code,
                       dim_detail_code2,
                       dim_detail_code3,
                       dim_detail_code4) t2
    on t1.index_code =decode( t2.index_code, 'Engy_csmp_amt_stadc','Comph_engy_csmp_amt',t2.dim_detail_code4)
          
    ),
    --折标系数
    temp10 as (
    SELECT 
          t1.repinst_id,
       P_RPTORGID org_id,
       'C0119' as report_code,
       P_RPTYEAR report_year,
       to_char(to_date(P_RPTYEAR||lpad(P_RPTMONTH,2,0),'yyyyMM'), 'q' )  report_quarter,
       P_RPTMONTH report_month,
       t1.report_frequent_code,
       t1.status,
       t1.sta_index_inst_id,
       t1.index_code,
       t1.index_value,
       t1.unit_code,
       t1.index_inst_orderno,
       t1.composited_index_code,
       t1.repinst_dtl_dimen,
       t1.dim_code,
       t1.dim_detail_code,
       t1.repinst_dtl_dimen2,
       t1.dim_code2,
       t1.dim_detail_code2,
       t1.repinst_dtl_dimen3,
       t1.dim_code3,
       t1.dim_detail_code3,
       t1.repinst_dtl_dimen4,
       t1.dim_code4,
       t1.dim_detail_code4 as dim_detail_code4,
       t1.repinst_dtl_dimen5,
       t1.dim_code5,
       t1.dim_detail_code5 as dim_detail_code5
       FROM E7_STA_REPORT_TRANS t1 WHERE INDEX_CODE in( 'Stadc_coef','Ybegin_stor_engy_amt_pratl','Latest_stor_engy_amt_pratl')
    ),
    results as (
    select 
     repinst_id,
       org_id,
      report_code,
      report_year,
       report_quarter,
       report_month,
       report_frequent_code,
       status,
       DECODE(STA_INDEX_INST_ID,NULL,NULL,sta_index_inst_id) sta_index_inst_id,
       index_code,
       index_value,
       unit_code,
       index_inst_orderno,
       composited_index_code,
       DECODE(repinst_dtl_dimen,NULL,NULL,repinst_dtl_dimen) repinst_dtl_dimen,
       dim_code,
       dim_detail_code,
       DECODE(repinst_dtl_dimen2,NULL,NULL,repinst_dtl_dimen2) repinst_dtl_dimen2,
       dim_code2,
       dim_detail_code2,
       DECODE(repinst_dtl_dimen3,NULL,NULL,repinst_dtl_dimen3) repinst_dtl_dimen3,
       dim_code3,
       dim_detail_code3,
       DECODE(repinst_dtl_dimen4,NULL,NULL,repinst_dtl_dimen4) repinst_dtl_dimen4,
       dim_code4,
       dim_detail_code4,
       DECODE(repinst_dtl_dimen5,NULL,NULL,repinst_dtl_dimen5) repinst_dtl_dimen5,
       dim_code5,
       dim_detail_code5
     from (
          select * from temp1 
          union all
          select * from temp2
          union all
          select * from temp3
          union all
          select * from temp4
          union all
          select * from temp5
          union all
          select * from temp6
          union all
          select * from temp7
          union all
          select * from temp8
          union all
          select * from temp9
          union all
          select * from temp10
          
          )
          )
          select 
          distinct 
          'TRANS'||P_RPTORGID||STA_INDEX_INST_ID AS STA_INDEX_INST_ID,
          INDEX_CODE,
          ORG_ID,
          REPORT_YEAR,
          REPORT_QUARTER,
          REPORT_MONTH,
          REPORT_FREQUENT_CODE,
          sum(INDEX_VALUE) index_value,
          UNIT_CODE,
          null as REMARK,
          INDEX_INST_ORDERNO,
          composited_index_code,
          null as create_time,
          null as update_time
          from results
          group by sta_index_inst_id,
          index_code,
          org_id,
          report_year,
          report_quarter,
          report_month,
          report_frequent_code,
          unit_code,
          index_inst_orderno,
          composited_index_code
          
    );
    CURSOR INDEXINSTDIMEN IS SELECT * FROM (
    with a as
 (SELECT AA.REPINST_ID, BB.*
    FROM (SELECT REPINST_ID
            FROM E7_STA_REPINST
           WHERE ORG_ID = P_RPTORGID
             AND REPORT_CODE = P_RPTCODE
             AND REPORT_YEAR = P_RPTYEAR
             AND REPORT_MONTH = P_RPTMONTH) AA,
         (select repinst.org_id,
                 repinst.report_year,
                 P_RPTMONTH AS report_month,
                 MAX(indexinst.sta_index_inst_id) STA_INDEX_INST_ID,
                 indexinst.index_code,
                 sum(indexinst.index_value) index_value,
                 indexinst.COMPOSITED_INDEX_CODE,
                 dimeninst.dim_code as dim_code,
                 dimeninst.dim_detail_code as dim_detail_code,
                 dimeninst2.dim_code as dim_code2,
                 dimeninst2.dim_detail_code as dim_detail_code2,
                 dimeninst3.dim_code as dim_code3,
                 dimeninst3.dim_detail_code as dim_detail_code3,
                 dimeninst4.dim_code as dim_code4,
                 dimeninst4.dim_detail_code as dim_detail_code4,
                 dimeninst5.dim_code as dim_code5,
                 dimeninst5.dim_detail_code as dim_detail_code5,
                 dimeninst6.dim_code as dim_code6,
                 dimeninst6.dim_detail_code as dim_detail_code6
            from e7_sta_repinst repinst
            left join e7_sta_rpt_index_inst rptindexinst
              on repinst.repinst_id = rptindexinst.repinst_id
            left join e7_sta_index_inst indexinst
              on rptindexinst.sta_index_inst_id = indexinst.sta_index_inst_id
            left join e7_sta_index_inst_dimen dimeninst
              on dimeninst.dim_code = 'Business_type'
             and indexinst.sta_index_inst_id = dimeninst.sta_index_inst_id
            left join e7_sta_index_inst_dimen dimeninst2
              on dimeninst2.dim_code = 'Assets_type'
             and indexinst.sta_index_inst_id = dimeninst2.sta_index_inst_id
            left join e7_sta_index_inst_dimen dimeninst3
              on dimeninst3.dim_code = 'Industry_type'
             and indexinst.sta_index_inst_id = dimeninst3.sta_index_inst_id
            left join e7_sta_index_inst_dimen dimeninst4
              on dimeninst4.dim_code = 'Cru_oil_E_cons_typ'
             and indexinst.sta_index_inst_id = dimeninst4.sta_index_inst_id
            left join e7_sta_index_inst_dimen dimeninst5
              on dimeninst5.dim_code = 'Custom_dimen_first'
             and indexinst.sta_index_inst_id = dimeninst5.sta_index_inst_id
            left join e7_sta_index_inst_dimen dimeninst6
              on dimeninst6.dim_code = 'Custom_dimen_second'
             and indexinst.sta_index_inst_id = dimeninst6.sta_index_inst_id
           where repinst.report_code = P_RPTCODE
             and repinst.org_id = P_RPTORGID
             and indexinst.COMPOSITED_INDEX_CODE = P_RPTORGID
             and repinst.report_year = P_RPTYEAR
             and repinst.report_month <= P_RPTMONTH
           group by repinst.org_id,
                    repinst.report_year,
                    indexinst.index_code,
                    indexinst.COMPOSITED_INDEX_CODE,
                    dimeninst.dim_code,
                    dimeninst.dim_detail_code,
                    dimeninst2.dim_code,
                    dimeninst2.dim_detail_code,
                    dimeninst3.dim_code,
                    dimeninst3.dim_detail_code,
                    dimeninst4.dim_code,
                    dimeninst4.dim_detail_code,
                    dimeninst5.dim_code,
                    dimeninst5.dim_detail_code,
                    dimeninst6.dim_code,
                    dimeninst6.dim_detail_code) BB
                    ),
                    --购进实物量
                    temp1 as (
select  t1.repinst_id,
       P_RPTORGID org_id,
       'C0119' as report_code,
       P_RPTYEAR report_year,
       to_char(to_date(P_RPTYEAR||lpad(P_RPTMONTH,2,0),'yyyyMM'), 'q' ) as report_quarter,
       P_RPTMONTH report_month,
       t1.report_frequent_code,
       t1.status,
       t1.sta_index_inst_id,
       t1.index_code,
       t2.index_value,
       t1.unit_code,
       t1.index_inst_orderno,
       t1.composited_index_code,
       t1.repinst_dtl_dimen,
       t1.dim_code,
       t1.dim_detail_code,
       t1.repinst_dtl_dimen2,
       t1.dim_code2,
       t1.dim_detail_code2,
       t1.repinst_dtl_dimen3,
       t1.dim_code3,
       t1.dim_detail_code3,
       t1.repinst_dtl_dimen4,
       t1.dim_code4,
       t1.dim_detail_code4 as dim_detail_code4,
       t1.repinst_dtl_dimen5,
       t1.dim_code5,
       t1.dim_detail_code5 as dim_detail_code5

  from (select *
          from e7_sta_report_trans
         where index_code in ('Buy_in_engy_amt_pratl')
           and dim_detail_code in
               ('Natural_gas', 'Elec', 'Gen_bitu_coal', 'Gsl', 'Dies')) t1
  left join (
  select index_code,dim_detail_code2,dim_detail_code3,dim_detail_code4,sum(index_value) index_value from (
  select index_code,
  dim_detail_code,
                    dim_detail_code2,
                    dim_detail_code3,
                    dim_detail_code4,
                    sum(index_value) index_value
               from a
              where index_code = 'Engy_csmp_amt_pratl'
              
                 and dim_detail_code2 = 'Listing'
                 and (dim_detail_code5 not in( 'Transportation_amount_D', 'Transportation_amount_G') or dim_detail_code5 is null)
              group by index_code,
              dim_detail_code,
                       dim_detail_code2,
                       dim_detail_code3,
                       dim_detail_code4) tt
                        where not exists (select * from (
                  select dim_detail_code,'Natural_gas' as dim_detail_code4 from (
                  select * from e7_sta_dim_detail where dim_code = 'Business_type') 
                  start with dim_detail_code = 'Oil_and_gas_fields'
                  connect by  parent_dim_detail_code = prior dim_detail_code) tt2 where tt.dim_detail_code = tt2.dim_detail_code and tt.dim_detail_code4 = tt2.dim_detail_code4 )
             
                 group by index_code,
                       dim_detail_code2,
                       dim_detail_code3,
                       dim_detail_code4
                       ) t2
    on decode(t1.dim_detail_code,
              'Gen_bitu_coal',
              'Raw_coal',
              t1.dim_detail_code) = t2.dim_detail_code4),
              --购进实物量费用
              temp2 as (
select  t1.repinst_id,
       P_RPTORGID org_id,
       'C0119' as report_code,
       P_RPTYEAR report_year,
       to_char(to_date(P_RPTYEAR||lpad(P_RPTMONTH,2,0),'yyyyMM'), 'q' ) as report_quarter,
       P_RPTMONTH report_month,
       t1.report_frequent_code,
       t1.status,
       t1.sta_index_inst_id,
       t1.index_code,
       t2.index_value,
       t1.unit_code,
       t1.index_inst_orderno,
       t1.composited_index_code,
       t1.repinst_dtl_dimen,
       t1.dim_code,
       t1.dim_detail_code,
       t1.repinst_dtl_dimen2,
       t1.dim_code2,
       t1.dim_detail_code2,
       t1.repinst_dtl_dimen3,
       t1.dim_code3,
       t1.dim_detail_code3,
       t1.repinst_dtl_dimen4,
       t1.dim_code4,
       t1.dim_detail_code4 as dim_detail_code4,
       t1.repinst_dtl_dimen5,
       t1.dim_code5,
       t1.dim_detail_code5 as dim_detail_code5

  from (select *
          from e7_sta_report_trans
         where index_code in ('Buy_in_engy_cost')
           and dim_detail_code in
               ('Natural_gas', 'Elec', 'Gen_bitu_coal', 'Gsl', 'Dies')) t1
  left join (
  select index_code,dim_detail_code2,dim_detail_code3,dim_detail_code4,sum(index_value) index_value from (
  select index_code,dim_detail_code,
                    dim_detail_code2,
                    dim_detail_code3,
                    dim_detail_code4,
                    sum(index_value) index_value
               from a
              where index_code = 'Engy_csmp_cost'
                 and dim_detail_code2 = 'Listing'
                 and (dim_detail_code5 not in( 'Transportation_amount_D', 'Transportation_amount_G') or dim_detail_code5 is null)
              group by index_code,
              dim_detail_code,
                       dim_detail_code2,
                       dim_detail_code3,
                       dim_detail_code4) tt
                        where not exists (select * from (
                  select dim_detail_code,'Natural_gas' as dim_detail_code4 from (
                  select * from e7_sta_dim_detail where dim_code = 'Business_type') 
                  start with dim_detail_code = 'Oil_and_gas_fields'
                  connect by  parent_dim_detail_code = prior dim_detail_code) tt2 where tt.dim_detail_code = tt2.dim_detail_code and tt.dim_detail_code4 = tt2.dim_detail_code4 )
             
                 group by index_code,
                       dim_detail_code2,
                       dim_detail_code3,
                       dim_detail_code4
                       ) t2
    on t1.dim_detail_code =decode( t2.dim_detail_code4, 'Raw_coal','Gen_bitu_coal',t2.dim_detail_code4)),
    --用于原材料
    temp3 as (
    
    
select  t1.repinst_id,
       P_RPTORGID org_id,
       'C0119' as report_code,
       P_RPTYEAR report_year,
       to_char(to_date(P_RPTYEAR||lpad(P_RPTMONTH,2,0),'yyyyMM'), 'q' ) as report_quarter,
       P_RPTMONTH report_month,
       t1.report_frequent_code,
       t1.status,
       t1.sta_index_inst_id,
       t1.index_code,
       t2.index_value,
       t1.unit_code,
       t1.index_inst_orderno,
       t1.composited_index_code,
       t1.repinst_dtl_dimen,
       t1.dim_code,
       t1.dim_detail_code,
       t1.repinst_dtl_dimen2,
       t1.dim_code2,
       t1.dim_detail_code2,
       t1.repinst_dtl_dimen3,
       t1.dim_code3,
       t1.dim_detail_code3,
       t1.repinst_dtl_dimen4,
       t1.dim_code4,
       t1.dim_detail_code4 as dim_detail_code4,
       t1.repinst_dtl_dimen5,
       t1.dim_code5,
       t1.dim_detail_code5 as dim_detail_code5

  from (select *
          from e7_sta_report_trans
         where index_code in ('Engy_used_amt_pratl')
           and dim_detail_code in
               ('Natural_gas', 'Elec', 'Gen_bitu_coal', 'Gsl', 'Dies')
               and dim_detail_code3 = 'E_cons_as_raw_materi'
               ) t1
  left join (select index_code,
                    dim_detail_code2,
                    dim_detail_code3,
                    dim_detail_code4,
                    sum(index_value) index_value
               from a
              where index_code = 'Engy_csmp_amt_pratl'
                 and dim_detail_code2 = 'Listing'
                 and dim_detail_code3 = 'Industry'
                 and dim_detail_code6 = 'Material_own_amount_N'
                               group by index_code,
                       dim_detail_code2,
                       dim_detail_code3,
                       dim_detail_code4) t2
    on t1.dim_detail_code =decode( t2.dim_detail_code4, 'Raw_coal','Gen_bitu_coal',t2.dim_detail_code4)
    
    
          ) ,
          --非工业消费
          temp4 as (
          
    
    
select  t1.repinst_id,
       P_RPTORGID org_id,
       'C0119' as report_code,
       P_RPTYEAR report_year,
       to_char(to_date(P_RPTYEAR||lpad(P_RPTMONTH,2,0),'yyyyMM'), 'q' ) as report_quarter,
       P_RPTMONTH report_month,
       t1.report_frequent_code,
       t1.status,
       t1.sta_index_inst_id,
       t1.index_code,
       t2.index_value,
       t1.unit_code,
       t1.index_inst_orderno,
       t1.composited_index_code,
       t1.repinst_dtl_dimen,
       t1.dim_code,
       t1.dim_detail_code,
       t1.repinst_dtl_dimen2,
       t1.dim_code2,
       t1.dim_detail_code2,
       t1.repinst_dtl_dimen3,
       t1.dim_code3,
       t1.dim_detail_code3,
       t1.repinst_dtl_dimen4,
       t1.dim_code4,
       t1.dim_detail_code4 as dim_detail_code4,
       t1.repinst_dtl_dimen5,
       t1.dim_code5,
       t1.dim_detail_code5 as dim_detail_code5

  from (select *
          from e7_sta_report_trans
         where index_code in ('Engy_used_amt_pratl')
           and dim_detail_code in
               ('Natural_gas', 'Elec', 'Gen_bitu_coal', 'Gsl', 'Dies')
               and dim_detail_code3 = 'Non_Indust_prod_cons'
               ) t1
  left join (select index_code,
                    dim_detail_code2,
                    dim_detail_code3,
                    dim_detail_code4,
                    sum(index_value) index_value
               from a
              where index_code = 'Engy_csmp_amt_pratl'
                 and dim_detail_code2 = 'Listing'
                 and dim_detail_code3 = 'Non_industrial'
                 and (dim_detail_code5 not in( 'Transportation_amount_D', 'Transportation_amount_G') or dim_detail_code5 is null)
                -- and dim_detail_code
                               group by index_code,
                       dim_detail_code2,
                       dim_detail_code3,
                       dim_detail_code4) t2
    on t1.dim_detail_code =decode( t2.dim_detail_code4, 'Raw_coal','Gen_bitu_coal',t2.dim_detail_code4)
    ),
    --运输消费
          temp5 as (
          select 
           t1.repinst_id,
       P_RPTORGID as org_id,
       'C0119' as report_code,
       P_RPTYEAR report_year,
       to_char(to_date(P_RPTYEAR||lpad(P_RPTMONTH,2,0),'yyyyMM'), 'q' ) as report_quarter,
       P_RPTMONTH report_month,
       t1.report_frequent_code,
       t1.status,
       t1.sta_index_inst_id,
       t1.index_code,
       t2.index_value,
       t1.unit_code,
       t1.index_inst_orderno,
       t1.composited_index_code,
       t1.repinst_dtl_dimen,
       t1.dim_code,
       t1.dim_detail_code,
       t1.repinst_dtl_dimen2,
       t1.dim_code2,
       t1.dim_detail_code2,
       t1.repinst_dtl_dimen3,
       t1.dim_code3,
       t1.dim_detail_code3,
       t1.repinst_dtl_dimen4,
       t1.dim_code4,
       t1.dim_detail_code4 as dim_detail_code4,
       t1.repinst_dtl_dimen5,
       t1.dim_code5,
       t1.dim_detail_code5 as dim_detail_code5
  from (select *
          from e7_sta_report_trans
         where index_code in ('Engy_used_amt_pratl')
           and dim_detail_code in
               ('Natural_gas', 'Elec', 'Gen_bitu_coal', 'Gsl', 'Dies')
               and dim_detail_code2 = 'Trans_cons'
               ) t1
  left join (select index_code,
                    dim_detail_code2,
                    dim_detail_code3,
                    dim_detail_code4,
                    sum(index_value) index_value
               from a
              where index_code = 'Engy_csmp_amt_pratl'
                 and dim_detail_code2 = 'Listing'
                 and (dim_detail_code5 in ( 'Transportation_amount_D','Transportation_amount_G') or dim_detail_code6 = 'Transportation_amount_N')
                               group by index_code,
                       dim_detail_code2,
                       dim_detail_code3,
                       dim_detail_code4) t2
    on t1.dim_detail_code =decode( t2.dim_detail_code4, 'Raw_coal','Gen_bitu_coal',t2.dim_detail_code4)),
    
    --工业消费其他的值
    value_industOther as (
    select dim_detail_code4,nvl(value1,0)-nvl(value2,0)-nvl(value3,0) as index_value from (
     select 
     t1.dim_detail_code4,
    t1.index_value as value1,
    t2.index_value as value2,
    t3.index_value as value3
      from (
     
     select 
                    dim_detail_code4,
                    sum(index_value) index_value
               from a
              where index_code = 'Engy_csmp_amt_pratl'
                 and dim_detail_code2 = 'Listing'
                 and (dim_detail_code5 not in  ('Transportation_amount_D','Transportation_amount_G') or dim_detail_code5 is null)
                group by dim_detail_code4
     
     ) t1 --总消耗
     ,
     
     (
     select 
                    dim_detail_code4,
                    sum(index_value) index_value
               from a
              where index_code = 'Engy_csmp_amt_pratl'
                 and dim_detail_code2 = 'Listing'
                 and dim_detail_code3 = 'Non_industrial'
                 and (dim_detail_code5 not in  ('Transportation_amount_D','Transportation_amount_G') or dim_detail_code5 is null)
                -- and dim_detail_code
                               group by 
                       dim_detail_code4
     ) t2 --非工业消耗
     
     ,
     (select 
                    dim_detail_code4,
                    sum(index_value) index_value
               from a
              where index_code = 'Engy_csmp_amt_pratl'
                 and dim_detail_code2 = 'Listing'
                 and dim_detail_code3 = 'Industry'
                 and dim_detail_code6 = 'Material_own_amount_N'
                               group by 
                       dim_detail_code4
     ) t3 --原材料
     where t1.dim_detail_code4 = t2.dim_detail_code4 (+)
     and t1.dim_detail_code4 = t3.dim_detail_code4(+)
     )
     
    
    ),
    
    --工业生产消费中的其他
    temp6 as (
          select
         t1.repinst_id,
       P_RPTORGID org_id,
       'C0119' as report_code,
       P_RPTYEAR report_year,
       to_char(to_date(P_RPTYEAR||lpad(P_RPTMONTH,2,0),'yyyyMM'), 'q' ) as report_quarter,
       P_RPTMONTH report_month,
       t1.report_frequent_code,
       t1.status,
       t1.sta_index_inst_id,
       t1.index_code,
       t2.index_value,
       t1.unit_code,
       t1.index_inst_orderno,
       t1.composited_index_code,
       t1.repinst_dtl_dimen,
       t1.dim_code,
       t1.dim_detail_code,
       t1.repinst_dtl_dimen2,
       t1.dim_code2,
       t1.dim_detail_code2,
       t1.repinst_dtl_dimen3,
       t1.dim_code3,
       t1.dim_detail_code3,
       t1.repinst_dtl_dimen4,
       t1.dim_code4,
       t1.dim_detail_code4 as dim_detail_code4,
       t1.repinst_dtl_dimen5,
       t1.dim_code5,
       t1.dim_detail_code5 as dim_detail_code5
  from (select *
          from e7_sta_report_trans
         where index_code in ('Engy_used_amt_pratl')
           and dim_detail_code in
               ('Natural_gas', 'Elec', 'Gen_bitu_coal', 'Gsl', 'Dies')
               and dim_detail_code3 = 'Other_consum'
               ) t1
  left join value_industOther t2
    on t1.dim_detail_code =decode( t2.dim_detail_code4, 'Raw_coal','Gen_bitu_coal',t2.dim_detail_code4)
    ),
    --合计的另一半
    temp7 as (
    
          select
        t1.repinst_id,
       P_RPTORGID org_id,
       'C0119' as report_code,
       P_RPTYEAR report_year,
       to_char(to_date(P_RPTYEAR||lpad(P_RPTMONTH,2,0),'yyyyMM'), 'q' ) as report_quarter,
       P_RPTMONTH report_month,
       t1.report_frequent_code,
       t1.status,
       t1.sta_index_inst_id,
       t1.index_code,
       tp.index_value,
       t1.unit_code,
       t1.index_inst_orderno,
       t1.composited_index_code,
       t1.repinst_dtl_dimen,
       t1.dim_code,
       t1.dim_detail_code,
       t1.repinst_dtl_dimen2,
       t1.dim_code2,
       t1.dim_detail_code2,
       t1.repinst_dtl_dimen3,
       t1.dim_code3,
       t1.dim_detail_code3,
       t1.repinst_dtl_dimen4,
       t1.dim_code4,
       t1.dim_detail_code4 as dim_detail_code4,
       t1.repinst_dtl_dimen5,
       t1.dim_code5,
       t1.dim_detail_code5 as dim_detail_code5
  from (select *
          from e7_sta_report_trans
         where index_code in ('Engy_used_amt_pratl')
           and dim_detail_code in
               ('Natural_gas', 'Elec', 'Gen_bitu_coal', 'Gsl', 'Dies')
               and dim_detail_code2 = 'Other_consum'
               ) t1
  left join (
  
    select dim_detail_code4,nvl(value1,0)-nvl(value2,0) as index_value from (
     select 
     t1.dim_detail_code4,
    t1.index_value as value1,
    t2.index_value as value2
      from (
     
     select 
                    dim_detail_code4,
                    sum(index_value) index_value
               from a
              where index_code = 'Engy_csmp_amt_pratl'
                 and dim_detail_code2 = 'Listing'
                 and (dim_detail_code5 not in  ('Transportation_amount_D','Transportation_amount_G') or dim_detail_code5 is null)
                group by dim_detail_code4
     
     ) t1 --总消耗
     left join 
     
     (
     select 
                    dim_detail_code4,
                    sum(index_value) index_value
               from a
              where index_code = 'Engy_csmp_amt_pratl'
                 and dim_detail_code2 = 'Listing'
                 and (dim_detail_code5 in( 'Transportation_amount_D','Transportation_amount_G') or dim_detail_code6 = 'Transportation_amount_N')
                -- and dim_detail_code
                
                               group by 
                       dim_detail_code4
     ) t2 --运输消耗
     on t1.dim_detail_code4 =decode( t2.dim_detail_code4, 'Raw_coal','Gen_bitu_coal',t2.dim_detail_code4)
     )
  
  
  ) tp
  on t1.dim_detail_code =decode( tp.dim_detail_code4, 'Raw_coal','Gen_bitu_coal',tp.dim_detail_code4)
    
    ),
    --工业和非工业
    --工业
    temp8 as (
select  t1.repinst_id,
       P_RPTORGID org_id,
       'C0119' as report_code,
       P_RPTYEAR report_year,
       to_char(to_date(P_RPTYEAR||lpad(P_RPTMONTH,2,0),'yyyyMM'), 'q' ) as report_quarter,
       P_RPTMONTH report_month,
       t1.report_frequent_code,
       t1.status,
       t1.sta_index_inst_id,
       t1.index_code,
       t2.index_value,
       t1.unit_code,
       t1.index_inst_orderno,
       t1.composited_index_code,
       t1.repinst_dtl_dimen,
       t1.dim_code,
       t1.dim_detail_code,
       t1.repinst_dtl_dimen2,
       t1.dim_code2,
       t1.dim_detail_code2,
       t1.repinst_dtl_dimen3,
       t1.dim_code3,
       t1.dim_detail_code3,
       t1.repinst_dtl_dimen4,
       t1.dim_code4,
       t1.dim_detail_code4 as dim_detail_code4,
       t1.repinst_dtl_dimen5,
       t1.dim_code5,
       t1.dim_detail_code5 as dim_detail_code5

  from (select *
          from e7_sta_report_trans
         where index_code in ('Comph_engy_csmp_amt')
          and dim_detail_code5 = 'Industry'
               ) t1
  left join (select index_code,
                    dim_detail_code2,
                    dim_detail_code3,
                    dim_detail_code4,
                    sum(index_value) index_value
               from a
              where index_code = 'Engy_csmp_amt_stadc'
                 and dim_detail_code2 = 'Listing'
                 and dim_detail_code3 = 'Industry'
                 and (dim_detail_code5 not in  ('Transportation_amount_D','Transportation_amount_G') or dim_detail_code5 is null)
                -- and dim_detail_code
                               group by index_code,
                       dim_detail_code2,
                       dim_detail_code3,
                       dim_detail_code4) t2
    on t1.index_code =decode( t2.index_code, 'Engy_csmp_amt_stadc','Comph_engy_csmp_amt',t2.dim_detail_code4)
    
          
    ),
    --非工业
    temp9 as (
select t1.repinst_id,
       P_RPTORGID org_id,
       'C0119' as report_code,
       P_RPTYEAR report_year,
       to_char(to_date(P_RPTYEAR||lpad(P_RPTMONTH,2,0),'yyyyMM'), 'q' ) as report_quarter,
       P_RPTMONTH report_month,
       t1.report_frequent_code,
       t1.status,
       t1.sta_index_inst_id,
       t1.index_code,
       t2.index_value,
       t1.unit_code,
       t1.index_inst_orderno,
       t1.composited_index_code,
       t1.repinst_dtl_dimen,
       t1.dim_code,
       t1.dim_detail_code,
       t1.repinst_dtl_dimen2,
       t1.dim_code2,
       t1.dim_detail_code2,
       t1.repinst_dtl_dimen3,
       t1.dim_code3,
       t1.dim_detail_code3,
       t1.repinst_dtl_dimen4,
       t1.dim_code4,
       t1.dim_detail_code4 as dim_detail_code4,
       t1.repinst_dtl_dimen5,
       t1.dim_code5,
       t1.dim_detail_code5 as dim_detail_code5

  from (select *
          from e7_sta_report_trans
         where index_code in ('Comph_engy_csmp_amt')
          and dim_detail_code5 = 'Non_industrial'
               ) t1
  left join (select index_code,
                    dim_detail_code2,
                    dim_detail_code3,
                    dim_detail_code4,
                    sum(index_value) index_value
               from a
              where index_code = 'Engy_csmp_amt_stadc'
                 and dim_detail_code2 = 'Listing'
                 and dim_detail_code3 = 'Non_industrial'
                 and (dim_detail_code5 not in  ('Transportation_amount_D','Transportation_amount_G') or dim_detail_code5 is null)
                -- and dim_detail_code
                               group by index_code,
                       dim_detail_code2,
                       dim_detail_code3,
                       dim_detail_code4) t2
    on t1.index_code =decode( t2.index_code, 'Engy_csmp_amt_stadc','Comph_engy_csmp_amt',t2.dim_detail_code4)
          
    ),
    --折标系数
    temp10 as (
    SELECT 
          t1.repinst_id,
       P_RPTORGID org_id,
       'C0119' as report_code,
       P_RPTYEAR report_year,
       to_char(to_date(P_RPTYEAR||lpad(P_RPTMONTH,2,0),'yyyyMM'), 'q' )  report_quarter,
       P_RPTMONTH report_month,
       t1.report_frequent_code,
       t1.status,
       t1.sta_index_inst_id,
       t1.index_code,
       t1.index_value,
       t1.unit_code,
       t1.index_inst_orderno,
       t1.composited_index_code,
       t1.repinst_dtl_dimen,
       t1.dim_code,
       t1.dim_detail_code,
       t1.repinst_dtl_dimen2,
       t1.dim_code2,
       t1.dim_detail_code2,
       t1.repinst_dtl_dimen3,
       t1.dim_code3,
       t1.dim_detail_code3,
       t1.repinst_dtl_dimen4,
       t1.dim_code4,
       t1.dim_detail_code4 as dim_detail_code4,
       t1.repinst_dtl_dimen5,
       t1.dim_code5,
       t1.dim_detail_code5 as dim_detail_code5
       FROM E7_STA_REPORT_TRANS t1 WHERE INDEX_CODE in( 'Stadc_coef','Ybegin_stor_engy_amt_pratl','Latest_stor_engy_amt_pratl')
    ),
    results as (
    select 
     repinst_id,
       org_id,
      report_code,
      report_year,
       report_quarter,
       report_month,
       report_frequent_code,
       status,
       DECODE(STA_INDEX_INST_ID,NULL,NULL,sta_index_inst_id) sta_index_inst_id,
       index_code,
       index_value,
       unit_code,
       index_inst_orderno,
       composited_index_code,
       DECODE(repinst_dtl_dimen,NULL,NULL,repinst_dtl_dimen) repinst_dtl_dimen,
       dim_code,
       dim_detail_code,
       DECODE(repinst_dtl_dimen2,NULL,NULL,repinst_dtl_dimen2) repinst_dtl_dimen2,
       dim_code2,
       dim_detail_code2,
       DECODE(repinst_dtl_dimen3,NULL,NULL,repinst_dtl_dimen3) repinst_dtl_dimen3,
       dim_code3,
       dim_detail_code3,
       DECODE(repinst_dtl_dimen4,NULL,NULL,repinst_dtl_dimen4) repinst_dtl_dimen4,
       dim_code4,
       dim_detail_code4,
       DECODE(repinst_dtl_dimen5,NULL,NULL,repinst_dtl_dimen5) repinst_dtl_dimen5,
       dim_code5,
       dim_detail_code5
     from (
          select * from temp1 
          union all
          select * from temp2
          union all
          select * from temp3
          union all
          select * from temp4
          union all
          select * from temp5
          union all
          select * from temp6
          union all
          select * from temp7
          union all
          select * from temp8
          union all
          select * from temp9
          union all
          select * from temp10
          
          )
          )
          select 
          distinct 
          'TRANS'||P_RPTORGID||repinst_dtl_dimen AS REPINST_DTL_DIMEN,
          'TRANS'||P_RPTORGID||sta_index_inst_id AS STA_INDEX_INST_ID,
          dim_code ,
          dim_detail_code,
          NULL AS dim_source,
          NULL AS dim_deteail_id,
          NULL AS dim_deteail_id2,
          unit_code,
          NULL AS composite_dim_code,
          SYSDATE AS create_time,
          SYSDATE AS update_time
          from results WHERE repinst_dtl_dimen IS NOT NULL
          UNION ALL
          select 
          distinct 
          'TRANS'||P_RPTORGID||repinst_dtl_dimen2,
          'TRANS'||P_RPTORGID||sta_index_inst_id,
          dim_code2 ,
          dim_detail_code2,
          NULL AS dim_source,
          NULL AS dim_deteail_id,
          NULL AS dim_deteail_id2,
          unit_code,
          NULL AS composite_dim_code,
          SYSDATE AS create_time,
          SYSDATE AS update_time
          from results WHERE repinst_dtl_dimen2 IS NOT NULL
          UNION ALL
          select 
          distinct 
          'TRANS'||P_RPTORGID||repinst_dtl_dimen3,
          'TRANS'||P_RPTORGID||sta_index_inst_id,
          dim_code3 ,
          dim_detail_code3,
          NULL AS dim_source,
          NULL AS dim_deteail_id,
          NULL AS dim_deteail_id2,
          unit_code,
          NULL AS composite_dim_code,
          SYSDATE AS create_time,
          SYSDATE AS update_time
          from results WHERE repinst_dtl_dimen3 IS NOT NULL
          UNION ALL
          select 
          distinct 
          'TRANS'||P_RPTORGID||repinst_dtl_dimen4,
          'TRANS'||P_RPTORGID||sta_index_inst_id,
          dim_code4 ,
          dim_detail_code4,
          NULL AS dim_source,
          NULL AS dim_deteail_id,
          NULL AS dim_deteail_id2,
          unit_code,
          NULL AS composite_dim_code,
          SYSDATE AS create_time,
          SYSDATE AS update_time
          from results WHERE repinst_dtl_dimen4 IS NOT NULL
          UNION ALL
          select 
          distinct 
          'TRANS'||P_RPTORGID||repinst_dtl_dimen5,
          'TRANS'||P_RPTORGID||sta_index_inst_id,
          dim_code5 ,
          dim_detail_code5,
          NULL AS dim_source,
          NULL AS dim_deteail_id,
          NULL AS dim_deteail_id2,
          unit_code,
          NULL AS composite_dim_code,
          SYSDATE AS create_time,
          SYSDATE AS update_time
          from results WHERE repinst_dtl_dimen5 IS NOT NULL
          
    );
    
       RPTINDEXINSTT E7_STA_RPT_INDEX_INST%ROWTYPE;
      STAINDEXINST E7_STA_INDEX_INST%ROWTYPE;
      STAINDEXINSTDIMEN E7_STA_INDEX_INST_DIMEN%ROWTYPE;
      AUTH NUMBER(10);
      STATUS NUMBER(10);
      BEGIN
        AUTH:=ISAUTH(P_RPTORGID,P_RPTCODE);
        STATUS:=SJUDGESTATUS('C0119',P_RPTYEAR,P_RPTMONTH,P_RPTORGID);
        IF AUTH >0 THEN
          IF STATUS =0 THEN
        DELDATAS('C0119',P_RPTYEAR ,P_RPTMONTH,P_RPTORGID );
       CREATE_XNNWREPINST('C0119', P_RPTYEAR,P_RPTMONTH,P_RPTORGID);

       FOR E7STARPTINDEXINST IN RPTINDEXINST LOOP
                RPTINDEXINSTT.REPINST_ID:='QY'||'C0119'||P_RPTORGID||P_RPTYEAR||lpad(P_RPTMONTH,2,0);
                RPTINDEXINSTT.STA_INDEX_INST_ID:=E7STARPTINDEXINST.STA_INDEX_INST_ID||P_RPTMONTH;
                RPTINDEXINSTT.CREATE_TIME:=SYSDATE;
                RPTINDEXINSTT.UPDATE_TIME:=SYSDATE;
                INSERT INTO E7_STA_RPT_INDEX_INST VALUES RPTINDEXINSTT;
       END LOOP;
       COMMIT;


        FOR E7STAINDEXINST IN INDEXINST LOOP
                STAINDEXINST.STA_INDEX_INST_ID:=E7STAINDEXINST.STA_INDEX_INST_ID||P_RPTMONTH;
                STAINDEXINST.INDEX_CODE:=E7STAINDEXINST.INDEX_CODE;
                STAINDEXINST.ORG_ID:=P_RPTORGID;
                STAINDEXINST.REPORT_YEAR:=P_RPTYEAR;
                STAINDEXINST.REPORT_QUARTER:=to_char(to_date(P_RPTYEAR||lpad(P_RPTMONTH,2,0),'yyyyMM'), 'Q');
                STAINDEXINST.REPORT_MONTH:=P_RPTMONTH;
                STAINDEXINST.REPORT_FREQUENT_CODE:=3;
                STAINDEXINST.INDEX_VALUE:=E7STAINDEXINST.INDEX_VALUE;
                STAINDEXINST.UNIT_CODE:= NULL;
                STAINDEXINST.REMARK:=NULL;
                STAINDEXINST.INDEX_INST_ORDERNO:=NULL;
                STAINDEXINST.COMPOSITED_INDEX_CODE:=NULL;
                STAINDEXINST.CREATE_TIME:=SYSDATE;
                STAINDEXINST.UPDATE_TIME:=SYSDATE;
                INSERT INTO E7_STA_INDEX_INST VALUES STAINDEXINST;
       END LOOP;
       COMMIT;

      -- DATAQYINDEXDIMEN(P_RPTYEAR,P_RPTMONTH,P_RPTORGID);
      FOR E7STAINDEXINSTDIMEN IN INDEXINSTDIMEN LOOP
          STAINDEXINSTDIMEN.repinst_dtl_dimen  :=E7STAINDEXINSTDIMEN.repinst_dtl_dimen||P_RPTMONTH ;
          STAINDEXINSTDIMEN.sta_index_inst_id  :=E7STAINDEXINSTDIMEN.sta_index_inst_id||P_RPTMONTH ;
          STAINDEXINSTDIMEN.dim_code           :=E7STAINDEXINSTDIMEN.dim_code          ;
          STAINDEXINSTDIMEN.dim_detail_code    :=E7STAINDEXINSTDIMEN.dim_detail_code   ;
          STAINDEXINSTDIMEN.dim_source         := NULL       ;
          STAINDEXINSTDIMEN.dim_deteail_id     := NULL   ;
          STAINDEXINSTDIMEN.dim_deteail_id2    := NULL   ;
          STAINDEXINSTDIMEN.unit_code          := NULL        ;
          STAINDEXINSTDIMEN.composite_dim_code := NULL;
          STAINDEXINSTDIMEN.create_time        := SYSDATE       ;
          STAINDEXINSTDIMEN.update_time        := SYSDATE       ;
          IF STAINDEXINSTDIMEN.repinst_dtl_dimen IS NOT NULL then
          INSERT INTO E7_STA_INDEX_INST_DIMEN VALUES STAINDEXINSTDIMEN;
          END IF;
          END LOOP;
          COMMIT;
          END IF;
          END IF;
        EXCEPTION WHEN OTHERS THEN
          DBMS_OUTPUT.put_line(SQLERRM);
                ROLLBACK;
       END;
 
  --进销存上市
   PROCEDURE DATATransJXCNoLising(P_RPTCODE     IN VARCHAR2,
                            P_RPTYEAR     IN VARCHAR2,
                            P_RPTMONTH    IN VARCHAR2,
                            P_RPTORGID    IN VARCHAR2)
                            as
    CURSOR RPTINDEXINST IS SELECT * FROM (
    with a as
 (SELECT AA.REPINST_ID, BB.*
    FROM (SELECT REPINST_ID
            FROM E7_STA_REPINST
           WHERE ORG_ID = P_RPTORGID
             AND REPORT_CODE = P_RPTCODE
             AND REPORT_YEAR = P_RPTYEAR
             AND REPORT_MONTH = P_RPTMONTH) AA,
         (select repinst.org_id,
                 repinst.report_year,
                 P_RPTMONTH AS report_month,
                 MAX(indexinst.sta_index_inst_id) STA_INDEX_INST_ID,
                 indexinst.index_code,
                 sum(indexinst.index_value) index_value,
                 indexinst.COMPOSITED_INDEX_CODE,
                 dimeninst.dim_code as dim_code,
                 dimeninst.dim_detail_code as dim_detail_code,
                 dimeninst2.dim_code as dim_code2,
                 dimeninst2.dim_detail_code as dim_detail_code2,
                 dimeninst3.dim_code as dim_code3,
                 dimeninst3.dim_detail_code as dim_detail_code3,
                 dimeninst4.dim_code as dim_code4,
                 dimeninst4.dim_detail_code as dim_detail_code4,
                 dimeninst5.dim_code as dim_code5,
                 dimeninst5.dim_detail_code as dim_detail_code5,
                 dimeninst6.dim_code as dim_code6,
                 dimeninst6.dim_detail_code as dim_detail_code6
            from e7_sta_repinst repinst
            left join e7_sta_rpt_index_inst rptindexinst
              on repinst.repinst_id = rptindexinst.repinst_id
            left join e7_sta_index_inst indexinst
              on rptindexinst.sta_index_inst_id = indexinst.sta_index_inst_id
            left join e7_sta_index_inst_dimen dimeninst
              on dimeninst.dim_code = 'Business_type'
             and indexinst.sta_index_inst_id = dimeninst.sta_index_inst_id
            left join e7_sta_index_inst_dimen dimeninst2
              on dimeninst2.dim_code = 'Assets_type'
             and indexinst.sta_index_inst_id = dimeninst2.sta_index_inst_id
            left join e7_sta_index_inst_dimen dimeninst3
              on dimeninst3.dim_code = 'Industry_type'
             and indexinst.sta_index_inst_id = dimeninst3.sta_index_inst_id
            left join e7_sta_index_inst_dimen dimeninst4
              on dimeninst4.dim_code = 'Cru_oil_E_cons_typ'
             and indexinst.sta_index_inst_id = dimeninst4.sta_index_inst_id
            left join e7_sta_index_inst_dimen dimeninst5
              on dimeninst5.dim_code = 'Custom_dimen_first'
             and indexinst.sta_index_inst_id = dimeninst5.sta_index_inst_id
            left join e7_sta_index_inst_dimen dimeninst6
              on dimeninst6.dim_code = 'Custom_dimen_second'
             and indexinst.sta_index_inst_id = dimeninst6.sta_index_inst_id
           where repinst.report_code = P_RPTCODE
             and repinst.org_id = P_RPTORGID
             and indexinst.COMPOSITED_INDEX_CODE = P_RPTORGID
             and repinst.report_year = P_RPTYEAR
             and repinst.report_month <= P_RPTMONTH
           group by repinst.org_id,
                    repinst.report_year,
                    indexinst.index_code,
                    indexinst.COMPOSITED_INDEX_CODE,
                    dimeninst.dim_code,
                    dimeninst.dim_detail_code,
                    dimeninst2.dim_code,
                    dimeninst2.dim_detail_code,
                    dimeninst3.dim_code,
                    dimeninst3.dim_detail_code,
                    dimeninst4.dim_code,
                    dimeninst4.dim_detail_code,
                    dimeninst5.dim_code,
                    dimeninst5.dim_detail_code,
                    dimeninst6.dim_code,
                    dimeninst6.dim_detail_code) BB
                    ),
                    --购进实物量
                    temp1 as (
select  t1.repinst_id,
       P_RPTORGID org_id,
       'C0121' as report_code,
       P_RPTYEAR report_year,
       to_char(to_date(P_RPTYEAR||lpad(P_RPTMONTH,2,0),'yyyyMM'), 'q' ) as report_quarter,
       P_RPTMONTH report_month,
       t1.report_frequent_code,
       t1.status,
       t1.sta_index_inst_id,
       t1.index_code,
       t2.index_value,
       t1.unit_code,
       t1.index_inst_orderno,
       t1.composited_index_code,
       t1.repinst_dtl_dimen,
       t1.dim_code,
       t1.dim_detail_code,
       t1.repinst_dtl_dimen2,
       t1.dim_code2,
       t1.dim_detail_code2,
       t1.repinst_dtl_dimen3,
       t1.dim_code3,
       t1.dim_detail_code3,
       t1.repinst_dtl_dimen4,
       t1.dim_code4,
       'No_listing' as dim_detail_code4,
       t1.repinst_dtl_dimen5,
       t1.dim_code5,
       t1.dim_detail_code5 as dim_detail_code5

  from (select *
          from e7_sta_report_trans
         where index_code in ('Buy_in_engy_amt_pratl')
           and dim_detail_code in
               ('Natural_gas', 'Elec', 'Gen_bitu_coal', 'Gsl', 'Dies')) t1
  left join (
  select index_code,dim_detail_code2,dim_detail_code3,dim_detail_code4,sum(index_value) index_value from (
  select index_code,
  dim_detail_code,
                    dim_detail_code2,
                    dim_detail_code3,
                    dim_detail_code4,
                    sum(index_value) index_value
               from a
              where index_code = 'Engy_csmp_amt_pratl'
              
                 and dim_detail_code2 = 'No_listing'
                 and (dim_detail_code5 not in( 'Transportation_amount_D', 'Transportation_amount_G') or dim_detail_code5 is null)
              group by index_code,
              dim_detail_code,
                       dim_detail_code2,
                       dim_detail_code3,
                       dim_detail_code4) tt
                        where not exists (select * from (
                  select dim_detail_code,'Natural_gas' as dim_detail_code4 from (
                  select * from e7_sta_dim_detail where dim_code = 'Business_type') 
                  start with dim_detail_code = 'Oil_and_gas_fields'
                  connect by  parent_dim_detail_code = prior dim_detail_code) tt2 where tt.dim_detail_code = tt2.dim_detail_code and tt.dim_detail_code4 = tt2.dim_detail_code4 )
             
                 group by index_code,
                       dim_detail_code2,
                       dim_detail_code3,
                       dim_detail_code4
                       ) t2
    on decode(t1.dim_detail_code,
              'Gen_bitu_coal',
              'Raw_coal',
              t1.dim_detail_code) = t2.dim_detail_code4),
              --购进实物量费用
              temp2 as (
select  t1.repinst_id,
       P_RPTORGID org_id,
       'C0121' as report_code,
       P_RPTYEAR report_year,
       to_char(to_date(P_RPTYEAR||lpad(P_RPTMONTH,2,0),'yyyyMM'), 'q' ) as report_quarter,
       P_RPTMONTH report_month,
       t1.report_frequent_code,
       t1.status,
       t1.sta_index_inst_id,
       t1.index_code,
       t2.index_value,
       t1.unit_code,
       t1.index_inst_orderno,
       t1.composited_index_code,
       t1.repinst_dtl_dimen,
       t1.dim_code,
       t1.dim_detail_code,
       t1.repinst_dtl_dimen2,
       t1.dim_code2,
       t1.dim_detail_code2,
       t1.repinst_dtl_dimen3,
       t1.dim_code3,
       t1.dim_detail_code3,
       t1.repinst_dtl_dimen4,
       t1.dim_code4,
       'No_listing' as dim_detail_code4,
       t1.repinst_dtl_dimen5,
       t1.dim_code5,
       t1.dim_detail_code5 as dim_detail_code5

  from (select *
          from e7_sta_report_trans
         where index_code in ('Buy_in_engy_cost')
           and dim_detail_code in
               ('Natural_gas', 'Elec', 'Gen_bitu_coal', 'Gsl', 'Dies')) t1
  left join (
  select index_code,dim_detail_code2,dim_detail_code3,dim_detail_code4,sum(index_value) index_value from (
  select index_code,dim_detail_code,
                    dim_detail_code2,
                    dim_detail_code3,
                    dim_detail_code4,
                    sum(index_value) index_value
               from a
              where index_code = 'Engy_csmp_cost'
                 and dim_detail_code2 = 'No_listing'
                 and (dim_detail_code5 not in( 'Transportation_amount_D', 'Transportation_amount_G') or dim_detail_code5 is null)
              group by index_code,
              dim_detail_code,
                       dim_detail_code2,
                       dim_detail_code3,
                       dim_detail_code4) tt
                        where not exists (select * from (
                  select dim_detail_code,'Natural_gas' as dim_detail_code4 from (
                  select * from e7_sta_dim_detail where dim_code = 'Business_type') 
                  start with dim_detail_code = 'Oil_and_gas_fields'
                  connect by  parent_dim_detail_code = prior dim_detail_code) tt2 where tt.dim_detail_code = tt2.dim_detail_code and tt.dim_detail_code4 = tt2.dim_detail_code4 )
             
                 group by index_code,
                       dim_detail_code2,
                       dim_detail_code3,
                       dim_detail_code4
                       ) t2
    on t1.dim_detail_code =decode( t2.dim_detail_code4, 'Raw_coal','Gen_bitu_coal',t2.dim_detail_code4)),
    --用于原材料
    temp3 as (
    
    
select  t1.repinst_id,
       P_RPTORGID org_id,
       'C0121' as report_code,
       P_RPTYEAR report_year,
       to_char(to_date(P_RPTYEAR||lpad(P_RPTMONTH,2,0),'yyyyMM'), 'q' ) as report_quarter,
       P_RPTMONTH report_month,
       t1.report_frequent_code,
       t1.status,
       t1.sta_index_inst_id,
       t1.index_code,
       t2.index_value,
       t1.unit_code,
       t1.index_inst_orderno,
       t1.composited_index_code,
       t1.repinst_dtl_dimen,
       t1.dim_code,
       t1.dim_detail_code,
       t1.repinst_dtl_dimen2,
       t1.dim_code2,
       t1.dim_detail_code2,
       t1.repinst_dtl_dimen3,
       t1.dim_code3,
       t1.dim_detail_code3,
       t1.repinst_dtl_dimen4,
       t1.dim_code4,
       'No_listing' as dim_detail_code4,
       t1.repinst_dtl_dimen5,
       t1.dim_code5,
       t1.dim_detail_code5 as dim_detail_code5

  from (select *
          from e7_sta_report_trans
         where index_code in ('Engy_used_amt_pratl')
           and dim_detail_code in
               ('Natural_gas', 'Elec', 'Gen_bitu_coal', 'Gsl', 'Dies')
               and dim_detail_code3 = 'E_cons_as_raw_materi'
               ) t1
  left join (select index_code,
                    dim_detail_code2,
                    dim_detail_code3,
                    dim_detail_code4,
                    sum(index_value) index_value
               from a
              where index_code = 'Engy_csmp_amt_pratl'
                 and dim_detail_code2 = 'No_listing'
                 and dim_detail_code3 = 'Industry'
                 and dim_detail_code6 = 'Material_own_amount_N'
                               group by index_code,
                       dim_detail_code2,
                       dim_detail_code3,
                       dim_detail_code4) t2
    on t1.dim_detail_code =decode( t2.dim_detail_code4, 'Raw_coal','Gen_bitu_coal',t2.dim_detail_code4)
    
    
          ) ,
          --非工业消费
          temp4 as (
          
    
    
select  t1.repinst_id,
       P_RPTORGID org_id,
       'C0121' as report_code,
       P_RPTYEAR report_year,
       to_char(to_date(P_RPTYEAR||lpad(P_RPTMONTH,2,0),'yyyyMM'), 'q' ) as report_quarter,
       P_RPTMONTH report_month,
       t1.report_frequent_code,
       t1.status,
       t1.sta_index_inst_id,
       t1.index_code,
       t2.index_value,
       t1.unit_code,
       t1.index_inst_orderno,
       t1.composited_index_code,
       t1.repinst_dtl_dimen,
       t1.dim_code,
       t1.dim_detail_code,
       t1.repinst_dtl_dimen2,
       t1.dim_code2,
       t1.dim_detail_code2,
       t1.repinst_dtl_dimen3,
       t1.dim_code3,
       t1.dim_detail_code3,
       t1.repinst_dtl_dimen4,
       t1.dim_code4,
       'No_listing' as dim_detail_code4,
       t1.repinst_dtl_dimen5,
       t1.dim_code5,
       t1.dim_detail_code5 as dim_detail_code5

  from (select *
          from e7_sta_report_trans
         where index_code in ('Engy_used_amt_pratl')
           and dim_detail_code in
               ('Natural_gas', 'Elec', 'Gen_bitu_coal', 'Gsl', 'Dies')
               and dim_detail_code3 = 'Non_Indust_prod_cons'
               ) t1
  left join (select index_code,
                    dim_detail_code2,
                    dim_detail_code3,
                    dim_detail_code4,
                    sum(index_value) index_value
               from a
              where index_code = 'Engy_csmp_amt_pratl'
                 and dim_detail_code2 = 'No_listing'
                 and dim_detail_code3 = 'Non_industrial'
                 and (dim_detail_code5 not in( 'Transportation_amount_D', 'Transportation_amount_G') or dim_detail_code5 is null)
                -- and dim_detail_code
                               group by index_code,
                       dim_detail_code2,
                       dim_detail_code3,
                       dim_detail_code4) t2
    on t1.dim_detail_code =decode( t2.dim_detail_code4, 'Raw_coal','Gen_bitu_coal',t2.dim_detail_code4)
    ),
    --运输消费
          temp5 as (
          select 
           t1.repinst_id,
       P_RPTORGID as org_id,
       'C0121' as report_code,
       P_RPTYEAR report_year,
       to_char(to_date(P_RPTYEAR||lpad(P_RPTMONTH,2,0),'yyyyMM'), 'q' ) as report_quarter,
       P_RPTMONTH report_month,
       t1.report_frequent_code,
       t1.status,
       t1.sta_index_inst_id,
       t1.index_code,
       t2.index_value,
       t1.unit_code,
       t1.index_inst_orderno,
       t1.composited_index_code,
       t1.repinst_dtl_dimen,
       t1.dim_code,
       t1.dim_detail_code,
       t1.repinst_dtl_dimen2,
       t1.dim_code2,
       t1.dim_detail_code2,
       t1.repinst_dtl_dimen3,
       t1.dim_code3,
       t1.dim_detail_code3,
       t1.repinst_dtl_dimen4,
       t1.dim_code4,
       'No_listing' as dim_detail_code4,
       t1.repinst_dtl_dimen5,
       t1.dim_code5,
       t1.dim_detail_code5 as dim_detail_code5
  from (select *
          from e7_sta_report_trans
         where index_code in ('Engy_used_amt_pratl')
           and dim_detail_code in
               ('Natural_gas', 'Elec', 'Gen_bitu_coal', 'Gsl', 'Dies')
               and dim_detail_code2 = 'Trans_cons'
               ) t1
  left join (select index_code,
                    dim_detail_code2,
                    dim_detail_code3,
                    dim_detail_code4,
                    sum(index_value) index_value
               from a
              where index_code = 'Engy_csmp_amt_pratl'
                 and dim_detail_code2 = 'No_listing'
                 and (dim_detail_code5 in ( 'Transportation_amount_D','Transportation_amount_G') or dim_detail_code6 = 'Transportation_amount_N')
                               group by index_code,
                       dim_detail_code2,
                       dim_detail_code3,
                       dim_detail_code4) t2
    on t1.dim_detail_code =decode( t2.dim_detail_code4, 'Raw_coal','Gen_bitu_coal',t2.dim_detail_code4)),
    
    --工业消费其他的值
    value_industOther as (
    select dim_detail_code4,nvl(value1,0)-nvl(value2,0)-nvl(value3,0) as index_value from (
     select 
     t1.dim_detail_code4,
    t1.index_value as value1,
    t2.index_value as value2,
    t3.index_value as value3
      from (
     
     select 
                    dim_detail_code4,
                    sum(index_value) index_value
               from a
              where index_code = 'Engy_csmp_amt_pratl'
                 and dim_detail_code2 = 'No_listing'
                 and (dim_detail_code5 not in  ('Transportation_amount_D','Transportation_amount_G') or dim_detail_code5 is null)
                group by dim_detail_code4
     
     ) t1 --总消耗
     ,
     
     (
     select 
                    dim_detail_code4,
                    sum(index_value) index_value
               from a
              where index_code = 'Engy_csmp_amt_pratl'
                 and dim_detail_code2 = 'No_listing'
                 and dim_detail_code3 = 'Non_industrial'
                 and (dim_detail_code5 not in  ('Transportation_amount_D','Transportation_amount_G') or dim_detail_code5 is null)
                -- and dim_detail_code
                               group by 
                       dim_detail_code4
     ) t2 --非工业消耗
     
     ,
     (select 
                    dim_detail_code4,
                    sum(index_value) index_value
               from a
              where index_code = 'Engy_csmp_amt_pratl'
                 and dim_detail_code2 = 'No_listing'
                 and dim_detail_code3 = 'Industry'
                 and dim_detail_code6 = 'Material_own_amount_N'
                               group by 
                       dim_detail_code4
     ) t3 --原材料
     where t1.dim_detail_code4 = t2.dim_detail_code4 (+)
     and t1.dim_detail_code4 = t3.dim_detail_code4(+)
     )
     
    ),
    
    --工业生产消费中的其他
    temp6 as (
          select
         t1.repinst_id,
       P_RPTORGID org_id,
       'C0121' as report_code,
       P_RPTYEAR report_year,
       to_char(to_date(P_RPTYEAR||lpad(P_RPTMONTH,2,0),'yyyyMM'), 'q' ) as report_quarter,
       P_RPTMONTH report_month,
       t1.report_frequent_code,
       t1.status,
       t1.sta_index_inst_id,
       t1.index_code,
       t2.index_value,
       t1.unit_code,
       t1.index_inst_orderno,
       t1.composited_index_code,
       t1.repinst_dtl_dimen,
       t1.dim_code,
       t1.dim_detail_code,
       t1.repinst_dtl_dimen2,
       t1.dim_code2,
       t1.dim_detail_code2,
       t1.repinst_dtl_dimen3,
       t1.dim_code3,
       t1.dim_detail_code3,
       t1.repinst_dtl_dimen4,
       t1.dim_code4,
       'No_listing' as dim_detail_code4,
       t1.repinst_dtl_dimen5,
       t1.dim_code5,
       t1.dim_detail_code5 as dim_detail_code5
  from (select *
          from e7_sta_report_trans
         where index_code in ('Engy_used_amt_pratl')
           and dim_detail_code in
               ('Natural_gas', 'Elec', 'Gen_bitu_coal', 'Gsl', 'Dies')
               and dim_detail_code3 = 'Other_consum'
               ) t1
  left join value_industOther t2
    on t1.dim_detail_code =decode( t2.dim_detail_code4, 'Raw_coal','Gen_bitu_coal',t2.dim_detail_code4)
    ),
    --合计的另一半
    temp7 as (
    
          select
        t1.repinst_id,
       P_RPTORGID org_id,
       'C0121' as report_code,
       P_RPTYEAR report_year,
       to_char(to_date(P_RPTYEAR||lpad(P_RPTMONTH,2,0),'yyyyMM'), 'q' ) as report_quarter,
       P_RPTMONTH report_month,
       t1.report_frequent_code,
       t1.status,
       t1.sta_index_inst_id,
       t1.index_code,
       tp.index_value,
       t1.unit_code,
       t1.index_inst_orderno,
       t1.composited_index_code,
       t1.repinst_dtl_dimen,
       t1.dim_code,
       t1.dim_detail_code,
       t1.repinst_dtl_dimen2,
       t1.dim_code2,
       t1.dim_detail_code2,
       t1.repinst_dtl_dimen3,
       t1.dim_code3,
       t1.dim_detail_code3,
       t1.repinst_dtl_dimen4,
       t1.dim_code4,
       'No_listing' as dim_detail_code4,
       t1.repinst_dtl_dimen5,
       t1.dim_code5,
       t1.dim_detail_code5 as dim_detail_code5
  from (select *
          from e7_sta_report_trans
         where index_code in ('Engy_used_amt_pratl')
           and dim_detail_code in
               ('Natural_gas', 'Elec', 'Gen_bitu_coal', 'Gsl', 'Dies')
               and dim_detail_code2 = 'Other_consum'
               ) t1
  left join (
  
    select dim_detail_code4,nvl(value1,0)-nvl(value2,0) as index_value from (
     select 
     t1.dim_detail_code4,
    t1.index_value as value1,
    t2.index_value as value2
      from (
     
     select 
                    dim_detail_code4,
                    sum(index_value) index_value
               from a
              where index_code = 'Engy_csmp_amt_pratl'
                 and dim_detail_code2 = 'No_listing'
                 and (dim_detail_code5 not in  ('Transportation_amount_D','Transportation_amount_G') or dim_detail_code5 is null)
                group by dim_detail_code4
     
     ) t1 --总消耗
     left join 
     
     (
     select 
                    dim_detail_code4,
                    sum(index_value) index_value
               from a
              where index_code = 'Engy_csmp_amt_pratl'
                 and dim_detail_code2 = 'No_listing'
                 and (dim_detail_code5 in( 'Transportation_amount_D','Transportation_amount_G') or dim_detail_code6 = 'Transportation_amount_N')
                -- and dim_detail_code
                
                               group by 
                       dim_detail_code4
     ) t2 --运输消耗
     on t1.dim_detail_code4 =decode( t2.dim_detail_code4, 'Raw_coal','Gen_bitu_coal',t2.dim_detail_code4)
     )
  
  
  ) tp
  on t1.dim_detail_code =decode( tp.dim_detail_code4, 'Raw_coal','Gen_bitu_coal',tp.dim_detail_code4)
    
    ),
    --工业和非工业
    --工业
    temp8 as (
select  t1.repinst_id,
       P_RPTORGID org_id,
       'C0121' as report_code,
       P_RPTYEAR report_year,
       to_char(to_date(P_RPTYEAR||lpad(P_RPTMONTH,2,0),'yyyyMM'), 'q' ) as report_quarter,
       P_RPTMONTH report_month,
       t1.report_frequent_code,
       t1.status,
       t1.sta_index_inst_id,
       t1.index_code,
       t2.index_value,
       t1.unit_code,
       t1.index_inst_orderno,
       t1.composited_index_code,
       t1.repinst_dtl_dimen,
       t1.dim_code,
       t1.dim_detail_code,
       t1.repinst_dtl_dimen2,
       t1.dim_code2,
       t1.dim_detail_code2,
       t1.repinst_dtl_dimen3,
       t1.dim_code3,
       t1.dim_detail_code3,
       t1.repinst_dtl_dimen4,
       t1.dim_code4,
       'No_listing' as dim_detail_code4,
       t1.repinst_dtl_dimen5,
       t1.dim_code5,
       t1.dim_detail_code5 as dim_detail_code5

  from (select *
          from e7_sta_report_trans
         where index_code in ('Comph_engy_csmp_amt')
          and dim_detail_code5 = 'Industry'
               ) t1
  left join (select index_code,
                    dim_detail_code2,
                    dim_detail_code3,
                    dim_detail_code4,
                    sum(index_value) index_value
               from a
              where index_code = 'Engy_csmp_amt_stadc'
                 and dim_detail_code2 = 'No_listing'
                 and dim_detail_code3 = 'Industry'
                 and (dim_detail_code5 not in  ('Transportation_amount_D','Transportation_amount_G') or dim_detail_code5 is null)
                -- and dim_detail_code
                               group by index_code,
                       dim_detail_code2,
                       dim_detail_code3,
                       dim_detail_code4) t2
    on t1.index_code =decode( t2.index_code, 'Engy_csmp_amt_stadc','Comph_engy_csmp_amt',t2.dim_detail_code4)
    
          
    ),
    --非工业
    temp9 as (
select t1.repinst_id,
       P_RPTORGID org_id,
       'C0121' as report_code,
       P_RPTYEAR report_year,
       to_char(to_date(P_RPTYEAR||lpad(P_RPTMONTH,2,0),'yyyyMM'), 'q' ) as report_quarter,
       P_RPTMONTH report_month,
       t1.report_frequent_code,
       t1.status,
       t1.sta_index_inst_id,
       t1.index_code,
       t2.index_value,
       t1.unit_code,
       t1.index_inst_orderno,
       t1.composited_index_code,
       t1.repinst_dtl_dimen,
       t1.dim_code,
       t1.dim_detail_code,
       t1.repinst_dtl_dimen2,
       t1.dim_code2,
       t1.dim_detail_code2,
       t1.repinst_dtl_dimen3,
       t1.dim_code3,
       t1.dim_detail_code3,
       t1.repinst_dtl_dimen4,
       t1.dim_code4,
       'No_listing' as dim_detail_code4,
       t1.repinst_dtl_dimen5,
       t1.dim_code5,
       t1.dim_detail_code5 as dim_detail_code5

  from (select *
          from e7_sta_report_trans
         where index_code in ('Comph_engy_csmp_amt')
          and dim_detail_code5 = 'Non_industrial'
               ) t1
  left join (select index_code,
                    dim_detail_code2,
                    dim_detail_code3,
                    dim_detail_code4,
                    sum(index_value) index_value
               from a
              where index_code = 'Engy_csmp_amt_stadc'
                 and dim_detail_code2 = 'No_listing'
                 and dim_detail_code3 = 'Non_industrial'
                 and (dim_detail_code5 not in  ('Transportation_amount_D','Transportation_amount_G') or dim_detail_code5 is null)
                -- and dim_detail_code
                               group by index_code,
                       dim_detail_code2,
                       dim_detail_code3,
                       dim_detail_code4) t2
    on t1.index_code =decode( t2.index_code, 'Engy_csmp_amt_stadc','Comph_engy_csmp_amt',t2.dim_detail_code4)
          
    ),
    --折标系数
    temp10 as (
    SELECT 
          t1.repinst_id,
       P_RPTORGID org_id,
       'C0121' as report_code,
       P_RPTYEAR report_year,
       to_char(to_date(P_RPTYEAR||lpad(P_RPTMONTH,2,0),'yyyyMM'), 'q' )  report_quarter,
       P_RPTMONTH report_month,
       t1.report_frequent_code,
       t1.status,
       t1.sta_index_inst_id,
       t1.index_code,
       t1.index_value,
       t1.unit_code,
       t1.index_inst_orderno,
       t1.composited_index_code,
       t1.repinst_dtl_dimen,
       t1.dim_code,
       t1.dim_detail_code,
       t1.repinst_dtl_dimen2,
       t1.dim_code2,
       t1.dim_detail_code2,
       t1.repinst_dtl_dimen3,
       t1.dim_code3,
       t1.dim_detail_code3,
       t1.repinst_dtl_dimen4,
       t1.dim_code4,
       'No_listing' as dim_detail_code4,
       t1.repinst_dtl_dimen5,
       t1.dim_code5,
       t1.dim_detail_code5 as dim_detail_code5
       FROM E7_STA_REPORT_TRANS t1 WHERE INDEX_CODE in( 'Stadc_coef','Ybegin_stor_engy_amt_pratl','Latest_stor_engy_amt_pratl')
    ),
    results as (
    select 
     repinst_id,
       org_id,
      report_code,
      report_year,
       report_quarter,
       report_month,
       report_frequent_code,
       status,
       DECODE(STA_INDEX_INST_ID,NULL,NULL,sta_index_inst_id) sta_index_inst_id,
       index_code,
       index_value,
       unit_code,
       index_inst_orderno,
       composited_index_code,
       DECODE(repinst_dtl_dimen,NULL,NULL,repinst_dtl_dimen) repinst_dtl_dimen,
       dim_code,
       dim_detail_code,
       DECODE(repinst_dtl_dimen2,NULL,NULL,repinst_dtl_dimen2) repinst_dtl_dimen2,
       dim_code2,
       dim_detail_code2,
       DECODE(repinst_dtl_dimen3,NULL,NULL,repinst_dtl_dimen3) repinst_dtl_dimen3,
       dim_code3,
       dim_detail_code3,
       DECODE(repinst_dtl_dimen4,NULL,NULL,repinst_dtl_dimen4) repinst_dtl_dimen4,
       dim_code4,
       dim_detail_code4,
       DECODE(repinst_dtl_dimen5,NULL,NULL,repinst_dtl_dimen5) repinst_dtl_dimen5,
       dim_code5,
       dim_detail_code5
     from (
          select * from temp1 
          union all
          select * from temp2
          union all
          select * from temp3
          union all
          select * from temp4
          union all
          select * from temp5
          union all
          select * from temp6
          union all
          select * from temp7
          union all
          select * from temp8
          union all
          select * from temp9
          union all
          select * from temp10
          
          )
          )
          select 
          distinct 'QY'||'C0121'||P_RPTORGID||P_RPTYEAR||lpad(P_RPTMONTH,2,0) AS REPINST_ID,
          'NoTRANS'||P_RPTORGID||STA_INDEX_INST_ID AS STA_INDEX_INST_ID,
          null as create_time,
          null as update_time
          from results
          
    );
    CURSOR INDEXINST IS SELECT * FROM (
    with a as
 (SELECT AA.REPINST_ID, BB.*
    FROM (SELECT REPINST_ID
            FROM E7_STA_REPINST
           WHERE ORG_ID = P_RPTORGID
             AND REPORT_CODE = P_RPTCODE
             AND REPORT_YEAR = P_RPTYEAR
             AND REPORT_MONTH = P_RPTMONTH) AA,
         (select repinst.org_id,
                 repinst.report_year,
                 P_RPTMONTH AS report_month,
                 MAX(indexinst.sta_index_inst_id) STA_INDEX_INST_ID,
                 indexinst.index_code,
                 sum(indexinst.index_value) index_value,
                 indexinst.COMPOSITED_INDEX_CODE,
                 dimeninst.dim_code as dim_code,
                 dimeninst.dim_detail_code as dim_detail_code,
                 dimeninst2.dim_code as dim_code2,
                 dimeninst2.dim_detail_code as dim_detail_code2,
                 dimeninst3.dim_code as dim_code3,
                 dimeninst3.dim_detail_code as dim_detail_code3,
                 dimeninst4.dim_code as dim_code4,
                 dimeninst4.dim_detail_code as dim_detail_code4,
                 dimeninst5.dim_code as dim_code5,
                 dimeninst5.dim_detail_code as dim_detail_code5,
                 dimeninst6.dim_code as dim_code6,
                 dimeninst6.dim_detail_code as dim_detail_code6
            from e7_sta_repinst repinst
            left join e7_sta_rpt_index_inst rptindexinst
              on repinst.repinst_id = rptindexinst.repinst_id
            left join e7_sta_index_inst indexinst
              on rptindexinst.sta_index_inst_id = indexinst.sta_index_inst_id
            left join e7_sta_index_inst_dimen dimeninst
              on dimeninst.dim_code = 'Business_type'
             and indexinst.sta_index_inst_id = dimeninst.sta_index_inst_id
            left join e7_sta_index_inst_dimen dimeninst2
              on dimeninst2.dim_code = 'Assets_type'
             and indexinst.sta_index_inst_id = dimeninst2.sta_index_inst_id
            left join e7_sta_index_inst_dimen dimeninst3
              on dimeninst3.dim_code = 'Industry_type'
             and indexinst.sta_index_inst_id = dimeninst3.sta_index_inst_id
            left join e7_sta_index_inst_dimen dimeninst4
              on dimeninst4.dim_code = 'Cru_oil_E_cons_typ'
             and indexinst.sta_index_inst_id = dimeninst4.sta_index_inst_id
            left join e7_sta_index_inst_dimen dimeninst5
              on dimeninst5.dim_code = 'Custom_dimen_first'
             and indexinst.sta_index_inst_id = dimeninst5.sta_index_inst_id
            left join e7_sta_index_inst_dimen dimeninst6
              on dimeninst6.dim_code = 'Custom_dimen_second'
             and indexinst.sta_index_inst_id = dimeninst6.sta_index_inst_id
           where repinst.report_code = P_RPTCODE
             and repinst.org_id = P_RPTORGID
             and indexinst.COMPOSITED_INDEX_CODE = P_RPTORGID
             and repinst.report_year = P_RPTYEAR
             and repinst.report_month <= P_RPTMONTH
           group by repinst.org_id,
                    repinst.report_year,
                    indexinst.index_code,
                    indexinst.COMPOSITED_INDEX_CODE,
                    dimeninst.dim_code,
                    dimeninst.dim_detail_code,
                    dimeninst2.dim_code,
                    dimeninst2.dim_detail_code,
                    dimeninst3.dim_code,
                    dimeninst3.dim_detail_code,
                    dimeninst4.dim_code,
                    dimeninst4.dim_detail_code,
                    dimeninst5.dim_code,
                    dimeninst5.dim_detail_code,
                    dimeninst6.dim_code,
                    dimeninst6.dim_detail_code) BB
                    ),
                   --购进实物量
                    temp1 as (
select  t1.repinst_id,
       P_RPTORGID org_id,
       'C0121' as report_code,
       P_RPTYEAR report_year,
       to_char(to_date(P_RPTYEAR||lpad(P_RPTMONTH,2,0),'yyyyMM'), 'q' ) as report_quarter,
       P_RPTMONTH report_month,
       t1.report_frequent_code,
       t1.status,
       t1.sta_index_inst_id,
       t1.index_code,
       t2.index_value,
       t1.unit_code,
       t1.index_inst_orderno,
       t1.composited_index_code,
       t1.repinst_dtl_dimen,
       t1.dim_code,
       t1.dim_detail_code,
       t1.repinst_dtl_dimen2,
       t1.dim_code2,
       t1.dim_detail_code2,
       t1.repinst_dtl_dimen3,
       t1.dim_code3,
       t1.dim_detail_code3,
       t1.repinst_dtl_dimen4,
       t1.dim_code4,
       'No_listing' as dim_detail_code4,
       t1.repinst_dtl_dimen5,
       t1.dim_code5,
       t1.dim_detail_code5 as dim_detail_code5

  from (select *
          from e7_sta_report_trans
         where index_code in ('Buy_in_engy_amt_pratl')
           and dim_detail_code in
               ('Natural_gas', 'Elec', 'Gen_bitu_coal', 'Gsl', 'Dies')) t1
  left join (
  select index_code,dim_detail_code2,dim_detail_code3,dim_detail_code4,sum(index_value) index_value from (
  select index_code,
  dim_detail_code,
                    dim_detail_code2,
                    dim_detail_code3,
                    dim_detail_code4,
                    sum(index_value) index_value
               from a
              where index_code = 'Engy_csmp_amt_pratl'
              
                 and dim_detail_code2 = 'No_listing'
                 and (dim_detail_code5 not in( 'Transportation_amount_D', 'Transportation_amount_G') or dim_detail_code5 is null)
              group by index_code,
              dim_detail_code,
                       dim_detail_code2,
                       dim_detail_code3,
                       dim_detail_code4) tt
                        where not exists (select * from (
                  select dim_detail_code,'Natural_gas' as dim_detail_code4 from (
                  select * from e7_sta_dim_detail where dim_code = 'Business_type') 
                  start with dim_detail_code = 'Oil_and_gas_fields'
                  connect by  parent_dim_detail_code = prior dim_detail_code) tt2 where tt.dim_detail_code = tt2.dim_detail_code and tt.dim_detail_code4 = tt2.dim_detail_code4 )
             
                 group by index_code,
                       dim_detail_code2,
                       dim_detail_code3,
                       dim_detail_code4
                       ) t2
    on decode(t1.dim_detail_code,
              'Gen_bitu_coal',
              'Raw_coal',
              t1.dim_detail_code) = t2.dim_detail_code4),
              --购进实物量费用
              temp2 as (
select  t1.repinst_id,
       P_RPTORGID org_id,
       'C0121' as report_code,
       P_RPTYEAR report_year,
       to_char(to_date(P_RPTYEAR||lpad(P_RPTMONTH,2,0),'yyyyMM'), 'q' ) as report_quarter,
       P_RPTMONTH report_month,
       t1.report_frequent_code,
       t1.status,
       t1.sta_index_inst_id,
       t1.index_code,
       t2.index_value,
       t1.unit_code,
       t1.index_inst_orderno,
       t1.composited_index_code,
       t1.repinst_dtl_dimen,
       t1.dim_code,
       t1.dim_detail_code,
       t1.repinst_dtl_dimen2,
       t1.dim_code2,
       t1.dim_detail_code2,
       t1.repinst_dtl_dimen3,
       t1.dim_code3,
       t1.dim_detail_code3,
       t1.repinst_dtl_dimen4,
       t1.dim_code4,
       'No_listing' as dim_detail_code4,
       t1.repinst_dtl_dimen5,
       t1.dim_code5,
       t1.dim_detail_code5 as dim_detail_code5

  from (select *
          from e7_sta_report_trans
         where index_code in ('Buy_in_engy_cost')
           and dim_detail_code in
               ('Natural_gas', 'Elec', 'Gen_bitu_coal', 'Gsl', 'Dies')) t1
  left join (
  select index_code,dim_detail_code2,dim_detail_code3,dim_detail_code4,sum(index_value) index_value from (
  select index_code,dim_detail_code,
                    dim_detail_code2,
                    dim_detail_code3,
                    dim_detail_code4,
                    sum(index_value) index_value
               from a
              where index_code = 'Engy_csmp_cost'
                 and dim_detail_code2 = 'No_listing'
                 and (dim_detail_code5 not in( 'Transportation_amount_D', 'Transportation_amount_G') or dim_detail_code5 is null)
              group by index_code,
              dim_detail_code,
                       dim_detail_code2,
                       dim_detail_code3,
                       dim_detail_code4) tt
                        where not exists (select * from (
                  select dim_detail_code,'Natural_gas' as dim_detail_code4 from (
                  select * from e7_sta_dim_detail where dim_code = 'Business_type') 
                  start with dim_detail_code = 'Oil_and_gas_fields'
                  connect by  parent_dim_detail_code = prior dim_detail_code) tt2 where tt.dim_detail_code = tt2.dim_detail_code and tt.dim_detail_code4 = tt2.dim_detail_code4 )
             
                 group by index_code,
                       dim_detail_code2,
                       dim_detail_code3,
                       dim_detail_code4
                       ) t2
    on t1.dim_detail_code =decode( t2.dim_detail_code4, 'Raw_coal','Gen_bitu_coal',t2.dim_detail_code4)),
    --用于原材料
    temp3 as (
    
    
select  t1.repinst_id,
       P_RPTORGID org_id,
       'C0121' as report_code,
       P_RPTYEAR report_year,
       to_char(to_date(P_RPTYEAR||lpad(P_RPTMONTH,2,0),'yyyyMM'), 'q' ) as report_quarter,
       P_RPTMONTH report_month,
       t1.report_frequent_code,
       t1.status,
       t1.sta_index_inst_id,
       t1.index_code,
       t2.index_value,
       t1.unit_code,
       t1.index_inst_orderno,
       t1.composited_index_code,
       t1.repinst_dtl_dimen,
       t1.dim_code,
       t1.dim_detail_code,
       t1.repinst_dtl_dimen2,
       t1.dim_code2,
       t1.dim_detail_code2,
       t1.repinst_dtl_dimen3,
       t1.dim_code3,
       t1.dim_detail_code3,
       t1.repinst_dtl_dimen4,
       t1.dim_code4,
       'No_listing' as dim_detail_code4,
       t1.repinst_dtl_dimen5,
       t1.dim_code5,
       t1.dim_detail_code5 as dim_detail_code5

  from (select *
          from e7_sta_report_trans
         where index_code in ('Engy_used_amt_pratl')
           and dim_detail_code in
               ('Natural_gas', 'Elec', 'Gen_bitu_coal', 'Gsl', 'Dies')
               and dim_detail_code3 = 'E_cons_as_raw_materi'
               ) t1
  left join (select index_code,
                    dim_detail_code2,
                    dim_detail_code3,
                    dim_detail_code4,
                    sum(index_value) index_value
               from a
              where index_code = 'Engy_csmp_amt_pratl'
                 and dim_detail_code2 = 'No_listing'
                 and dim_detail_code3 = 'Industry'
                 and dim_detail_code6 = 'Material_own_amount_N'
                               group by index_code,
                       dim_detail_code2,
                       dim_detail_code3,
                       dim_detail_code4) t2
    on t1.dim_detail_code =decode( t2.dim_detail_code4, 'Raw_coal','Gen_bitu_coal',t2.dim_detail_code4)
    
    
          ) ,
          --非工业消费
          temp4 as (
          
    
    
select  t1.repinst_id,
       P_RPTORGID org_id,
       'C0121' as report_code,
       P_RPTYEAR report_year,
       to_char(to_date(P_RPTYEAR||lpad(P_RPTMONTH,2,0),'yyyyMM'), 'q' ) as report_quarter,
       P_RPTMONTH report_month,
       t1.report_frequent_code,
       t1.status,
       t1.sta_index_inst_id,
       t1.index_code,
       t2.index_value,
       t1.unit_code,
       t1.index_inst_orderno,
       t1.composited_index_code,
       t1.repinst_dtl_dimen,
       t1.dim_code,
       t1.dim_detail_code,
       t1.repinst_dtl_dimen2,
       t1.dim_code2,
       t1.dim_detail_code2,
       t1.repinst_dtl_dimen3,
       t1.dim_code3,
       t1.dim_detail_code3,
       t1.repinst_dtl_dimen4,
       t1.dim_code4,
       'No_listing' as dim_detail_code4,
       t1.repinst_dtl_dimen5,
       t1.dim_code5,
       t1.dim_detail_code5 as dim_detail_code5

  from (select *
          from e7_sta_report_trans
         where index_code in ('Engy_used_amt_pratl')
           and dim_detail_code in
               ('Natural_gas', 'Elec', 'Gen_bitu_coal', 'Gsl', 'Dies')
               and dim_detail_code3 = 'Non_Indust_prod_cons'
               ) t1
  left join (select index_code,
                    dim_detail_code2,
                    dim_detail_code3,
                    dim_detail_code4,
                    sum(index_value) index_value
               from a
              where index_code = 'Engy_csmp_amt_pratl'
                 and dim_detail_code2 = 'No_listing'
                 and dim_detail_code3 = 'Non_industrial'
                 and (dim_detail_code5 not in( 'Transportation_amount_D', 'Transportation_amount_G') or dim_detail_code5 is null)
                -- and dim_detail_code
                               group by index_code,
                       dim_detail_code2,
                       dim_detail_code3,
                       dim_detail_code4) t2
    on t1.dim_detail_code =decode( t2.dim_detail_code4, 'Raw_coal','Gen_bitu_coal',t2.dim_detail_code4)
    ),
    --运输消费
          temp5 as (
          select 
           t1.repinst_id,
       P_RPTORGID as org_id,
       'C0121' as report_code,
       P_RPTYEAR report_year,
       to_char(to_date(P_RPTYEAR||lpad(P_RPTMONTH,2,0),'yyyyMM'), 'q' ) as report_quarter,
       P_RPTMONTH report_month,
       t1.report_frequent_code,
       t1.status,
       t1.sta_index_inst_id,
       t1.index_code,
       t2.index_value,
       t1.unit_code,
       t1.index_inst_orderno,
       t1.composited_index_code,
       t1.repinst_dtl_dimen,
       t1.dim_code,
       t1.dim_detail_code,
       t1.repinst_dtl_dimen2,
       t1.dim_code2,
       t1.dim_detail_code2,
       t1.repinst_dtl_dimen3,
       t1.dim_code3,
       t1.dim_detail_code3,
       t1.repinst_dtl_dimen4,
       t1.dim_code4,
       'No_listing' as dim_detail_code4,
       t1.repinst_dtl_dimen5,
       t1.dim_code5,
       t1.dim_detail_code5 as dim_detail_code5
  from (select *
          from e7_sta_report_trans
         where index_code in ('Engy_used_amt_pratl')
           and dim_detail_code in
               ('Natural_gas', 'Elec', 'Gen_bitu_coal', 'Gsl', 'Dies')
               and dim_detail_code2 = 'Trans_cons'
               ) t1
  left join (select index_code,
                    dim_detail_code2,
                    dim_detail_code3,
                    dim_detail_code4,
                    sum(index_value) index_value
               from a
              where index_code = 'Engy_csmp_amt_pratl'
                 and dim_detail_code2 = 'No_listing'
                 and (dim_detail_code5 in ( 'Transportation_amount_D','Transportation_amount_G') or dim_detail_code6 = 'Transportation_amount_N')
                               group by index_code,
                       dim_detail_code2,
                       dim_detail_code3,
                       dim_detail_code4) t2
    on t1.dim_detail_code =decode( t2.dim_detail_code4, 'Raw_coal','Gen_bitu_coal',t2.dim_detail_code4)),
    
    --工业消费其他的值
    value_industOther as (
    select dim_detail_code4,nvl(value1,0)-nvl(value2,0)-nvl(value3,0) as index_value from (
     select 
     t1.dim_detail_code4,
    t1.index_value as value1,
    t2.index_value as value2,
    t3.index_value as value3
      from (
     
     select 
                    dim_detail_code4,
                    sum(index_value) index_value
               from a
              where index_code = 'Engy_csmp_amt_pratl'
                 and dim_detail_code2 = 'No_listing'
                 and (dim_detail_code5 not in  ('Transportation_amount_D','Transportation_amount_G') or dim_detail_code5 is null)
                group by dim_detail_code4
     
     ) t1 --总消耗
     ,
     
     (
     select 
                    dim_detail_code4,
                    sum(index_value) index_value
               from a
              where index_code = 'Engy_csmp_amt_pratl'
                 and dim_detail_code2 = 'No_listing'
                 and dim_detail_code3 = 'Non_industrial'
                 and (dim_detail_code5 not in  ('Transportation_amount_D','Transportation_amount_G') or dim_detail_code5 is null)
                -- and dim_detail_code
                               group by 
                       dim_detail_code4
     ) t2 --非工业消耗
     
     ,
     (select 
                    dim_detail_code4,
                    sum(index_value) index_value
               from a
              where index_code = 'Engy_csmp_amt_pratl'
                 and dim_detail_code2 = 'No_listing'
                 and dim_detail_code3 = 'Industry'
                 and dim_detail_code6 = 'Material_own_amount_N'
                               group by 
                       dim_detail_code4
     ) t3 --原材料
     where t1.dim_detail_code4 = t2.dim_detail_code4 (+)
     and t1.dim_detail_code4 = t3.dim_detail_code4(+)
     )
     
    
    ),
    
    --工业生产消费中的其他
    temp6 as (
          select
         t1.repinst_id,
       P_RPTORGID org_id,
       'C0121' as report_code,
       P_RPTYEAR report_year,
       to_char(to_date(P_RPTYEAR||lpad(P_RPTMONTH,2,0),'yyyyMM'), 'q' ) as report_quarter,
       P_RPTMONTH report_month,
       t1.report_frequent_code,
       t1.status,
       t1.sta_index_inst_id,
       t1.index_code,
       t2.index_value,
       t1.unit_code,
       t1.index_inst_orderno,
       t1.composited_index_code,
       t1.repinst_dtl_dimen,
       t1.dim_code,
       t1.dim_detail_code,
       t1.repinst_dtl_dimen2,
       t1.dim_code2,
       t1.dim_detail_code2,
       t1.repinst_dtl_dimen3,
       t1.dim_code3,
       t1.dim_detail_code3,
       t1.repinst_dtl_dimen4,
       t1.dim_code4,
       'No_listing' as dim_detail_code4,
       t1.repinst_dtl_dimen5,
       t1.dim_code5,
       t1.dim_detail_code5 as dim_detail_code5
  from (select *
          from e7_sta_report_trans
         where index_code in ('Engy_used_amt_pratl')
           and dim_detail_code in
               ('Natural_gas', 'Elec', 'Gen_bitu_coal', 'Gsl', 'Dies')
               and dim_detail_code3 = 'Other_consum'
               ) t1
  left join value_industOther t2
    on t1.dim_detail_code =decode( t2.dim_detail_code4, 'Raw_coal','Gen_bitu_coal',t2.dim_detail_code4)
    ),
    --合计的另一半
    temp7 as (
    
          select
        t1.repinst_id,
       P_RPTORGID org_id,
       'C0121' as report_code,
       P_RPTYEAR report_year,
       to_char(to_date(P_RPTYEAR||lpad(P_RPTMONTH,2,0),'yyyyMM'), 'q' ) as report_quarter,
       P_RPTMONTH report_month,
       t1.report_frequent_code,
       t1.status,
       t1.sta_index_inst_id,
       t1.index_code,
       tp.index_value,
       t1.unit_code,
       t1.index_inst_orderno,
       t1.composited_index_code,
       t1.repinst_dtl_dimen,
       t1.dim_code,
       t1.dim_detail_code,
       t1.repinst_dtl_dimen2,
       t1.dim_code2,
       t1.dim_detail_code2,
       t1.repinst_dtl_dimen3,
       t1.dim_code3,
       t1.dim_detail_code3,
       t1.repinst_dtl_dimen4,
       t1.dim_code4,
       'No_listing' as dim_detail_code4,
       t1.repinst_dtl_dimen5,
       t1.dim_code5,
       t1.dim_detail_code5 as dim_detail_code5
  from (select *
          from e7_sta_report_trans
         where index_code in ('Engy_used_amt_pratl')
           and dim_detail_code in
               ('Natural_gas', 'Elec', 'Gen_bitu_coal', 'Gsl', 'Dies')
               and dim_detail_code2 = 'Other_consum'
               ) t1
  left join (
  
    select dim_detail_code4,nvl(value1,0)-nvl(value2,0) as index_value from (
     select 
     t1.dim_detail_code4,
    t1.index_value as value1,
    t2.index_value as value2
      from (
     
     select 
                    dim_detail_code4,
                    sum(index_value) index_value
               from a
              where index_code = 'Engy_csmp_amt_pratl'
                 and dim_detail_code2 = 'No_listing'
                 and (dim_detail_code5 not in  ('Transportation_amount_D','Transportation_amount_G') or dim_detail_code5 is null)
                group by dim_detail_code4
     
     ) t1 --总消耗
     left join 
     
     (
     select 
                    dim_detail_code4,
                    sum(index_value) index_value
               from a
              where index_code = 'Engy_csmp_amt_pratl'
                 and dim_detail_code2 = 'No_listing'
                 and (dim_detail_code5 in( 'Transportation_amount_D','Transportation_amount_G') or dim_detail_code6 = 'Transportation_amount_N')
                -- and dim_detail_code
                
                               group by 
                       dim_detail_code4
     ) t2 --运输消耗
     on t1.dim_detail_code4 =decode( t2.dim_detail_code4, 'Raw_coal','Gen_bitu_coal',t2.dim_detail_code4)
     )
  
  
  ) tp
  on t1.dim_detail_code =decode( tp.dim_detail_code4, 'Raw_coal','Gen_bitu_coal',tp.dim_detail_code4)
    
    ),
    --工业和非工业
    --工业
    temp8 as (
select  t1.repinst_id,
       P_RPTORGID org_id,
       'C0121' as report_code,
       P_RPTYEAR report_year,
       to_char(to_date(P_RPTYEAR||lpad(P_RPTMONTH,2,0),'yyyyMM'), 'q' ) as report_quarter,
       P_RPTMONTH report_month,
       t1.report_frequent_code,
       t1.status,
       t1.sta_index_inst_id,
       t1.index_code,
       t2.index_value,
       t1.unit_code,
       t1.index_inst_orderno,
       t1.composited_index_code,
       t1.repinst_dtl_dimen,
       t1.dim_code,
       t1.dim_detail_code,
       t1.repinst_dtl_dimen2,
       t1.dim_code2,
       t1.dim_detail_code2,
       t1.repinst_dtl_dimen3,
       t1.dim_code3,
       t1.dim_detail_code3,
       t1.repinst_dtl_dimen4,
       t1.dim_code4,
       'No_listing' as dim_detail_code4,
       t1.repinst_dtl_dimen5,
       t1.dim_code5,
       t1.dim_detail_code5 as dim_detail_code5

  from (select *
          from e7_sta_report_trans
         where index_code in ('Comph_engy_csmp_amt')
          and dim_detail_code5 = 'Industry'
               ) t1
  left join (select index_code,
                    dim_detail_code2,
                    dim_detail_code3,
                    dim_detail_code4,
                    sum(index_value) index_value
               from a
              where index_code = 'Engy_csmp_amt_stadc'
                 and dim_detail_code2 = 'No_listing'
                 and dim_detail_code3 = 'Industry'
                 and (dim_detail_code5 not in  ('Transportation_amount_D','Transportation_amount_G') or dim_detail_code5 is null)
                -- and dim_detail_code
                               group by index_code,
                       dim_detail_code2,
                       dim_detail_code3,
                       dim_detail_code4) t2
    on t1.index_code =decode( t2.index_code, 'Engy_csmp_amt_stadc','Comph_engy_csmp_amt',t2.dim_detail_code4)
    
          
    ),
    --非工业
    temp9 as (
select t1.repinst_id,
       P_RPTORGID org_id,
       'C0121' as report_code,
       P_RPTYEAR report_year,
       to_char(to_date(P_RPTYEAR||lpad(P_RPTMONTH,2,0),'yyyyMM'), 'q' ) as report_quarter,
       P_RPTMONTH report_month,
       t1.report_frequent_code,
       t1.status,
       t1.sta_index_inst_id,
       t1.index_code,
       t2.index_value,
       t1.unit_code,
       t1.index_inst_orderno,
       t1.composited_index_code,
       t1.repinst_dtl_dimen,
       t1.dim_code,
       t1.dim_detail_code,
       t1.repinst_dtl_dimen2,
       t1.dim_code2,
       t1.dim_detail_code2,
       t1.repinst_dtl_dimen3,
       t1.dim_code3,
       t1.dim_detail_code3,
       t1.repinst_dtl_dimen4,
       t1.dim_code4,
       'No_listing' as dim_detail_code4,
       t1.repinst_dtl_dimen5,
       t1.dim_code5,
       t1.dim_detail_code5 as dim_detail_code5

  from (select *
          from e7_sta_report_trans
         where index_code in ('Comph_engy_csmp_amt')
          and dim_detail_code5 = 'Non_industrial'
               ) t1
  left join (select index_code,
                    dim_detail_code2,
                    dim_detail_code3,
                    dim_detail_code4,
                    sum(index_value) index_value
               from a
              where index_code = 'Engy_csmp_amt_stadc'
                 and dim_detail_code2 = 'No_listing'
                 and dim_detail_code3 = 'Non_industrial'
                 and (dim_detail_code5 not in  ('Transportation_amount_D','Transportation_amount_G') or dim_detail_code5 is null)
                -- and dim_detail_code
                               group by index_code,
                       dim_detail_code2,
                       dim_detail_code3,
                       dim_detail_code4) t2
    on t1.index_code =decode( t2.index_code, 'Engy_csmp_amt_stadc','Comph_engy_csmp_amt',t2.dim_detail_code4)
          
    ),
    --折标系数
    temp10 as (
    SELECT 
          t1.repinst_id,
       P_RPTORGID org_id,
       'C0121' as report_code,
       P_RPTYEAR report_year,
       to_char(to_date(P_RPTYEAR||lpad(P_RPTMONTH,2,0),'yyyyMM'), 'q' )  report_quarter,
       P_RPTMONTH report_month,
       t1.report_frequent_code,
       t1.status,
       t1.sta_index_inst_id,
       t1.index_code,
       t1.index_value,
       t1.unit_code,
       t1.index_inst_orderno,
       t1.composited_index_code,
       t1.repinst_dtl_dimen,
       t1.dim_code,
       t1.dim_detail_code,
       t1.repinst_dtl_dimen2,
       t1.dim_code2,
       t1.dim_detail_code2,
       t1.repinst_dtl_dimen3,
       t1.dim_code3,
       t1.dim_detail_code3,
       t1.repinst_dtl_dimen4,
       t1.dim_code4,
       'No_listing' as dim_detail_code4,
       t1.repinst_dtl_dimen5,
       t1.dim_code5,
       t1.dim_detail_code5 as dim_detail_code5
       FROM E7_STA_REPORT_TRANS t1 WHERE INDEX_CODE in( 'Stadc_coef','Ybegin_stor_engy_amt_pratl','Latest_stor_engy_amt_pratl')
    ),
    results as (
    select 
     repinst_id,
       org_id,
      report_code,
      report_year,
       report_quarter,
       report_month,
       report_frequent_code,
       status,
       DECODE(STA_INDEX_INST_ID,NULL,NULL,sta_index_inst_id) sta_index_inst_id,
       index_code,
       index_value,
       unit_code,
       index_inst_orderno,
       composited_index_code,
       DECODE(repinst_dtl_dimen,NULL,NULL,repinst_dtl_dimen) repinst_dtl_dimen,
       dim_code,
       dim_detail_code,
       DECODE(repinst_dtl_dimen2,NULL,NULL,repinst_dtl_dimen2) repinst_dtl_dimen2,
       dim_code2,
       dim_detail_code2,
       DECODE(repinst_dtl_dimen3,NULL,NULL,repinst_dtl_dimen3) repinst_dtl_dimen3,
       dim_code3,
       dim_detail_code3,
       DECODE(repinst_dtl_dimen4,NULL,NULL,repinst_dtl_dimen4) repinst_dtl_dimen4,
       dim_code4,
       dim_detail_code4,
       DECODE(repinst_dtl_dimen5,NULL,NULL,repinst_dtl_dimen5) repinst_dtl_dimen5,
       dim_code5,
       dim_detail_code5
     from (
          select * from temp1 
          union all
          select * from temp2
          union all
          select * from temp3
          union all
          select * from temp4
          union all
          select * from temp5
          union all
          select * from temp6
          union all
          select * from temp7
          union all
          select * from temp8
          union all
          select * from temp9
          union all
          select * from temp10
          
          )
          )
          select 
          distinct 
          'NoTRANS'||P_RPTORGID||STA_INDEX_INST_ID AS STA_INDEX_INST_ID,
          INDEX_CODE,
          ORG_ID,
          REPORT_YEAR,
          REPORT_QUARTER,
          REPORT_MONTH,
          REPORT_FREQUENT_CODE,
          sum(INDEX_VALUE) index_value,
          UNIT_CODE,
          null as REMARK,
          INDEX_INST_ORDERNO,
          composited_index_code,
          null as create_time,
          null as update_time
          from results
          group by sta_index_inst_id,
          index_code,
          org_id,
          report_year,
          report_quarter,
          report_month,
          report_frequent_code,
          unit_code,
          index_inst_orderno,
          composited_index_code
          
    );
    CURSOR INDEXINSTDIMEN IS SELECT * FROM (
    with a as
 (SELECT AA.REPINST_ID, BB.*
    FROM (SELECT REPINST_ID
            FROM E7_STA_REPINST
           WHERE ORG_ID = P_RPTORGID
             AND REPORT_CODE = P_RPTCODE
             AND REPORT_YEAR = P_RPTYEAR
             AND REPORT_MONTH = P_RPTMONTH) AA,
         (select repinst.org_id,
                 repinst.report_year,
                 P_RPTMONTH AS report_month,
                 MAX(indexinst.sta_index_inst_id) STA_INDEX_INST_ID,
                 indexinst.index_code,
                 sum(indexinst.index_value) index_value,
                 indexinst.COMPOSITED_INDEX_CODE,
                 dimeninst.dim_code as dim_code,
                 dimeninst.dim_detail_code as dim_detail_code,
                 dimeninst2.dim_code as dim_code2,
                 dimeninst2.dim_detail_code as dim_detail_code2,
                 dimeninst3.dim_code as dim_code3,
                 dimeninst3.dim_detail_code as dim_detail_code3,
                 dimeninst4.dim_code as dim_code4,
                 dimeninst4.dim_detail_code as dim_detail_code4,
                 dimeninst5.dim_code as dim_code5,
                 dimeninst5.dim_detail_code as dim_detail_code5,
                 dimeninst6.dim_code as dim_code6,
                 dimeninst6.dim_detail_code as dim_detail_code6
            from e7_sta_repinst repinst
            left join e7_sta_rpt_index_inst rptindexinst
              on repinst.repinst_id = rptindexinst.repinst_id
            left join e7_sta_index_inst indexinst
              on rptindexinst.sta_index_inst_id = indexinst.sta_index_inst_id
            left join e7_sta_index_inst_dimen dimeninst
              on dimeninst.dim_code = 'Business_type'
             and indexinst.sta_index_inst_id = dimeninst.sta_index_inst_id
            left join e7_sta_index_inst_dimen dimeninst2
              on dimeninst2.dim_code = 'Assets_type'
             and indexinst.sta_index_inst_id = dimeninst2.sta_index_inst_id
            left join e7_sta_index_inst_dimen dimeninst3
              on dimeninst3.dim_code = 'Industry_type'
             and indexinst.sta_index_inst_id = dimeninst3.sta_index_inst_id
            left join e7_sta_index_inst_dimen dimeninst4
              on dimeninst4.dim_code = 'Cru_oil_E_cons_typ'
             and indexinst.sta_index_inst_id = dimeninst4.sta_index_inst_id
            left join e7_sta_index_inst_dimen dimeninst5
              on dimeninst5.dim_code = 'Custom_dimen_first'
             and indexinst.sta_index_inst_id = dimeninst5.sta_index_inst_id
            left join e7_sta_index_inst_dimen dimeninst6
              on dimeninst6.dim_code = 'Custom_dimen_second'
             and indexinst.sta_index_inst_id = dimeninst6.sta_index_inst_id
           where repinst.report_code = P_RPTCODE
             and repinst.org_id = P_RPTORGID
             and indexinst.COMPOSITED_INDEX_CODE = P_RPTORGID
             and repinst.report_year = P_RPTYEAR
             and repinst.report_month <= P_RPTMONTH
           group by repinst.org_id,
                    repinst.report_year,
                    indexinst.index_code,
                    indexinst.COMPOSITED_INDEX_CODE,
                    dimeninst.dim_code,
                    dimeninst.dim_detail_code,
                    dimeninst2.dim_code,
                    dimeninst2.dim_detail_code,
                    dimeninst3.dim_code,
                    dimeninst3.dim_detail_code,
                    dimeninst4.dim_code,
                    dimeninst4.dim_detail_code,
                    dimeninst5.dim_code,
                    dimeninst5.dim_detail_code,
                    dimeninst6.dim_code,
                    dimeninst6.dim_detail_code) BB
                    ),
                    --购进实物量
                    temp1 as (
select  t1.repinst_id,
       P_RPTORGID org_id,
       'C0121' as report_code,
       P_RPTYEAR report_year,
       to_char(to_date(P_RPTYEAR||lpad(P_RPTMONTH,2,0),'yyyyMM'), 'q' ) as report_quarter,
       P_RPTMONTH report_month,
       t1.report_frequent_code,
       t1.status,
       t1.sta_index_inst_id,
       t1.index_code,
       t2.index_value,
       t1.unit_code,
       t1.index_inst_orderno,
       t1.composited_index_code,
       t1.repinst_dtl_dimen,
       t1.dim_code,
       t1.dim_detail_code,
       t1.repinst_dtl_dimen2,
       t1.dim_code2,
       t1.dim_detail_code2,
       t1.repinst_dtl_dimen3,
       t1.dim_code3,
       t1.dim_detail_code3,
       t1.repinst_dtl_dimen4,
       t1.dim_code4,
       'No_listing' as dim_detail_code4,
       t1.repinst_dtl_dimen5,
       t1.dim_code5,
       t1.dim_detail_code5 as dim_detail_code5

  from (select *
          from e7_sta_report_trans
         where index_code in ('Buy_in_engy_amt_pratl')
           and dim_detail_code in
               ('Natural_gas', 'Elec', 'Gen_bitu_coal', 'Gsl', 'Dies')) t1
  left join (
  select index_code,dim_detail_code2,dim_detail_code3,dim_detail_code4,sum(index_value) index_value from (
  select index_code,
  dim_detail_code,
                    dim_detail_code2,
                    dim_detail_code3,
                    dim_detail_code4,
                    sum(index_value) index_value
               from a
              where index_code = 'Engy_csmp_amt_pratl'
              
                 and dim_detail_code2 = 'No_listing'
                 and (dim_detail_code5 not in( 'Transportation_amount_D', 'Transportation_amount_G') or dim_detail_code5 is null)
              group by index_code,
              dim_detail_code,
                       dim_detail_code2,
                       dim_detail_code3,
                       dim_detail_code4) tt
                        where not exists (select * from (
                  select dim_detail_code,'Natural_gas' as dim_detail_code4 from (
                  select * from e7_sta_dim_detail where dim_code = 'Business_type') 
                  start with dim_detail_code = 'Oil_and_gas_fields'
                  connect by  parent_dim_detail_code = prior dim_detail_code) tt2 where tt.dim_detail_code = tt2.dim_detail_code and tt.dim_detail_code4 = tt2.dim_detail_code4 )
             
                 group by index_code,
                       dim_detail_code2,
                       dim_detail_code3,
                       dim_detail_code4
                       ) t2
    on decode(t1.dim_detail_code,
              'Gen_bitu_coal',
              'Raw_coal',
              t1.dim_detail_code) = t2.dim_detail_code4),
              --购进实物量费用
              temp2 as (
select  t1.repinst_id,
       P_RPTORGID org_id,
       'C0121' as report_code,
       P_RPTYEAR report_year,
       to_char(to_date(P_RPTYEAR||lpad(P_RPTMONTH,2,0),'yyyyMM'), 'q' ) as report_quarter,
       P_RPTMONTH report_month,
       t1.report_frequent_code,
       t1.status,
       t1.sta_index_inst_id,
       t1.index_code,
       t2.index_value,
       t1.unit_code,
       t1.index_inst_orderno,
       t1.composited_index_code,
       t1.repinst_dtl_dimen,
       t1.dim_code,
       t1.dim_detail_code,
       t1.repinst_dtl_dimen2,
       t1.dim_code2,
       t1.dim_detail_code2,
       t1.repinst_dtl_dimen3,
       t1.dim_code3,
       t1.dim_detail_code3,
       t1.repinst_dtl_dimen4,
       t1.dim_code4,
       'No_listing' as dim_detail_code4,
       t1.repinst_dtl_dimen5,
       t1.dim_code5,
       t1.dim_detail_code5 as dim_detail_code5

  from (select *
          from e7_sta_report_trans
         where index_code in ('Buy_in_engy_cost')
           and dim_detail_code in
               ('Natural_gas', 'Elec', 'Gen_bitu_coal', 'Gsl', 'Dies')) t1
  left join (
  select index_code,dim_detail_code2,dim_detail_code3,dim_detail_code4,sum(index_value) index_value from (
  select index_code,dim_detail_code,
                    dim_detail_code2,
                    dim_detail_code3,
                    dim_detail_code4,
                    sum(index_value) index_value
               from a
              where index_code = 'Engy_csmp_cost'
                 and dim_detail_code2 = 'No_listing'
                 and (dim_detail_code5 not in( 'Transportation_amount_D', 'Transportation_amount_G') or dim_detail_code5 is null)
              group by index_code,
              dim_detail_code,
                       dim_detail_code2,
                       dim_detail_code3,
                       dim_detail_code4) tt
                        where not exists (select * from (
                  select dim_detail_code,'Natural_gas' as dim_detail_code4 from (
                  select * from e7_sta_dim_detail where dim_code = 'Business_type') 
                  start with dim_detail_code = 'Oil_and_gas_fields'
                  connect by  parent_dim_detail_code = prior dim_detail_code) tt2 where tt.dim_detail_code = tt2.dim_detail_code and tt.dim_detail_code4 = tt2.dim_detail_code4 )
             
                 group by index_code,
                       dim_detail_code2,
                       dim_detail_code3,
                       dim_detail_code4
                       ) t2
    on t1.dim_detail_code =decode( t2.dim_detail_code4, 'Raw_coal','Gen_bitu_coal',t2.dim_detail_code4)),
    --用于原材料
    temp3 as (
    
    
select  t1.repinst_id,
       P_RPTORGID org_id,
       'C0121' as report_code,
       P_RPTYEAR report_year,
       to_char(to_date(P_RPTYEAR||lpad(P_RPTMONTH,2,0),'yyyyMM'), 'q' ) as report_quarter,
       P_RPTMONTH report_month,
       t1.report_frequent_code,
       t1.status,
       t1.sta_index_inst_id,
       t1.index_code,
       t2.index_value,
       t1.unit_code,
       t1.index_inst_orderno,
       t1.composited_index_code,
       t1.repinst_dtl_dimen,
       t1.dim_code,
       t1.dim_detail_code,
       t1.repinst_dtl_dimen2,
       t1.dim_code2,
       t1.dim_detail_code2,
       t1.repinst_dtl_dimen3,
       t1.dim_code3,
       t1.dim_detail_code3,
       t1.repinst_dtl_dimen4,
       t1.dim_code4,
       'No_listing' as dim_detail_code4,
       t1.repinst_dtl_dimen5,
       t1.dim_code5,
       t1.dim_detail_code5 as dim_detail_code5

  from (select *
          from e7_sta_report_trans
         where index_code in ('Engy_used_amt_pratl')
           and dim_detail_code in
               ('Natural_gas', 'Elec', 'Gen_bitu_coal', 'Gsl', 'Dies')
               and dim_detail_code3 = 'E_cons_as_raw_materi'
               ) t1
  left join (select index_code,
                    dim_detail_code2,
                    dim_detail_code3,
                    dim_detail_code4,
                    sum(index_value) index_value
               from a
              where index_code = 'Engy_csmp_amt_pratl'
                 and dim_detail_code2 = 'No_listing'
                 and dim_detail_code3 = 'Industry'
                 and dim_detail_code6 = 'Material_own_amount_N'
                               group by index_code,
                       dim_detail_code2,
                       dim_detail_code3,
                       dim_detail_code4) t2
    on t1.dim_detail_code =decode( t2.dim_detail_code4, 'Raw_coal','Gen_bitu_coal',t2.dim_detail_code4)
    
    
          ) ,
          --非工业消费
          temp4 as (
          
    
    
select  t1.repinst_id,
       P_RPTORGID org_id,
       'C0121' as report_code,
       P_RPTYEAR report_year,
       to_char(to_date(P_RPTYEAR||lpad(P_RPTMONTH,2,0),'yyyyMM'), 'q' ) as report_quarter,
       P_RPTMONTH report_month,
       t1.report_frequent_code,
       t1.status,
       t1.sta_index_inst_id,
       t1.index_code,
       t2.index_value,
       t1.unit_code,
       t1.index_inst_orderno,
       t1.composited_index_code,
       t1.repinst_dtl_dimen,
       t1.dim_code,
       t1.dim_detail_code,
       t1.repinst_dtl_dimen2,
       t1.dim_code2,
       t1.dim_detail_code2,
       t1.repinst_dtl_dimen3,
       t1.dim_code3,
       t1.dim_detail_code3,
       t1.repinst_dtl_dimen4,
       t1.dim_code4,
       'No_listing' as dim_detail_code4,
       t1.repinst_dtl_dimen5,
       t1.dim_code5,
       t1.dim_detail_code5 as dim_detail_code5

  from (select *
          from e7_sta_report_trans
         where index_code in ('Engy_used_amt_pratl')
           and dim_detail_code in
               ('Natural_gas', 'Elec', 'Gen_bitu_coal', 'Gsl', 'Dies')
               and dim_detail_code3 = 'Non_Indust_prod_cons'
               ) t1
  left join (select index_code,
                    dim_detail_code2,
                    dim_detail_code3,
                    dim_detail_code4,
                    sum(index_value) index_value
               from a
              where index_code = 'Engy_csmp_amt_pratl'
                 and dim_detail_code2 = 'No_listing'
                 and dim_detail_code3 = 'Non_industrial'
                 and (dim_detail_code5 not in( 'Transportation_amount_D', 'Transportation_amount_G') or dim_detail_code5 is null)
                -- and dim_detail_code
                               group by index_code,
                       dim_detail_code2,
                       dim_detail_code3,
                       dim_detail_code4) t2
    on t1.dim_detail_code =decode( t2.dim_detail_code4, 'Raw_coal','Gen_bitu_coal',t2.dim_detail_code4)
    ),
    --运输消费
          temp5 as (
          select 
           t1.repinst_id,
       P_RPTORGID as org_id,
       'C0121' as report_code,
       P_RPTYEAR report_year,
       to_char(to_date(P_RPTYEAR||lpad(P_RPTMONTH,2,0),'yyyyMM'), 'q' ) as report_quarter,
       P_RPTMONTH report_month,
       t1.report_frequent_code,
       t1.status,
       t1.sta_index_inst_id,
       t1.index_code,
       t2.index_value,
       t1.unit_code,
       t1.index_inst_orderno,
       t1.composited_index_code,
       t1.repinst_dtl_dimen,
       t1.dim_code,
       t1.dim_detail_code,
       t1.repinst_dtl_dimen2,
       t1.dim_code2,
       t1.dim_detail_code2,
       t1.repinst_dtl_dimen3,
       t1.dim_code3,
       t1.dim_detail_code3,
       t1.repinst_dtl_dimen4,
       t1.dim_code4,
       'No_listing' as dim_detail_code4,
       t1.repinst_dtl_dimen5,
       t1.dim_code5,
       t1.dim_detail_code5 as dim_detail_code5
  from (select *
          from e7_sta_report_trans
         where index_code in ('Engy_used_amt_pratl')
           and dim_detail_code in
               ('Natural_gas', 'Elec', 'Gen_bitu_coal', 'Gsl', 'Dies')
               and dim_detail_code2 = 'Trans_cons'
               ) t1
  left join (select index_code,
                    dim_detail_code2,
                    dim_detail_code3,
                    dim_detail_code4,
                    sum(index_value) index_value
               from a
              where index_code = 'Engy_csmp_amt_pratl'
                 and dim_detail_code2 = 'No_listing'
                 and (dim_detail_code5 in ( 'Transportation_amount_D','Transportation_amount_G') or dim_detail_code6 = 'Transportation_amount_N')
                               group by index_code,
                       dim_detail_code2,
                       dim_detail_code3,
                       dim_detail_code4) t2
    on t1.dim_detail_code =decode( t2.dim_detail_code4, 'Raw_coal','Gen_bitu_coal',t2.dim_detail_code4)),
    
    --工业消费其他的值
    value_industOther as (
    select dim_detail_code4,nvl(value1,0)-nvl(value2,0)-nvl(value3,0) as index_value from (
     select 
     t1.dim_detail_code4,
    t1.index_value as value1,
    t2.index_value as value2,
    t3.index_value as value3
      from (
     
     select 
                    dim_detail_code4,
                    sum(index_value) index_value
               from a
              where index_code = 'Engy_csmp_amt_pratl'
                 and dim_detail_code2 = 'No_listing'
                 and (dim_detail_code5 not in  ('Transportation_amount_D','Transportation_amount_G') or dim_detail_code5 is null)
                group by dim_detail_code4
     
     ) t1 --总消耗
     ,
     
     (
     select 
                    dim_detail_code4,
                    sum(index_value) index_value
               from a
              where index_code = 'Engy_csmp_amt_pratl'
                 and dim_detail_code2 = 'No_listing'
                 and dim_detail_code3 = 'Non_industrial'
                 and (dim_detail_code5 not in  ('Transportation_amount_D','Transportation_amount_G') or dim_detail_code5 is null)
                -- and dim_detail_code
                               group by 
                       dim_detail_code4
     ) t2 --非工业消耗
     
     ,
     (select 
                    dim_detail_code4,
                    sum(index_value) index_value
               from a
              where index_code = 'Engy_csmp_amt_pratl'
                 and dim_detail_code2 = 'No_listing'
                 and dim_detail_code3 = 'Industry'
                 and dim_detail_code6 = 'Material_own_amount_N'
                               group by 
                       dim_detail_code4
     ) t3 --原材料
     where t1.dim_detail_code4 = t2.dim_detail_code4 (+)
     and t1.dim_detail_code4 = t3.dim_detail_code4(+)
     )
     
    
    ),
    
    --工业生产消费中的其他
    temp6 as (
          select
         t1.repinst_id,
       P_RPTORGID org_id,
       'C0121' as report_code,
       P_RPTYEAR report_year,
       to_char(to_date(P_RPTYEAR||lpad(P_RPTMONTH,2,0),'yyyyMM'), 'q' ) as report_quarter,
       P_RPTMONTH report_month,
       t1.report_frequent_code,
       t1.status,
       t1.sta_index_inst_id,
       t1.index_code,
       t2.index_value,
       t1.unit_code,
       t1.index_inst_orderno,
       t1.composited_index_code,
       t1.repinst_dtl_dimen,
       t1.dim_code,
       t1.dim_detail_code,
       t1.repinst_dtl_dimen2,
       t1.dim_code2,
       t1.dim_detail_code2,
       t1.repinst_dtl_dimen3,
       t1.dim_code3,
       t1.dim_detail_code3,
       t1.repinst_dtl_dimen4,
       t1.dim_code4,
       'No_listing' as dim_detail_code4,
       t1.repinst_dtl_dimen5,
       t1.dim_code5,
       t1.dim_detail_code5 as dim_detail_code5
  from (select *
          from e7_sta_report_trans
         where index_code in ('Engy_used_amt_pratl')
           and dim_detail_code in
               ('Natural_gas', 'Elec', 'Gen_bitu_coal', 'Gsl', 'Dies')
               and dim_detail_code3 = 'Other_consum'
               ) t1
  left join value_industOther t2
    on t1.dim_detail_code =decode( t2.dim_detail_code4, 'Raw_coal','Gen_bitu_coal',t2.dim_detail_code4)
    ),
    --合计的另一半
    temp7 as (
    
          select
        t1.repinst_id,
       P_RPTORGID org_id,
       'C0121' as report_code,
       P_RPTYEAR report_year,
       to_char(to_date(P_RPTYEAR||lpad(P_RPTMONTH,2,0),'yyyyMM'), 'q' ) as report_quarter,
       P_RPTMONTH report_month,
       t1.report_frequent_code,
       t1.status,
       t1.sta_index_inst_id,
       t1.index_code,
       tp.index_value,
       t1.unit_code,
       t1.index_inst_orderno,
       t1.composited_index_code,
       t1.repinst_dtl_dimen,
       t1.dim_code,
       t1.dim_detail_code,
       t1.repinst_dtl_dimen2,
       t1.dim_code2,
       t1.dim_detail_code2,
       t1.repinst_dtl_dimen3,
       t1.dim_code3,
       t1.dim_detail_code3,
       t1.repinst_dtl_dimen4,
       t1.dim_code4,
       'No_listing' as dim_detail_code4,
       t1.repinst_dtl_dimen5,
       t1.dim_code5,
       t1.dim_detail_code5 as dim_detail_code5
  from (select *
          from e7_sta_report_trans
         where index_code in ('Engy_used_amt_pratl')
           and dim_detail_code in
               ('Natural_gas', 'Elec', 'Gen_bitu_coal', 'Gsl', 'Dies')
               and dim_detail_code2 = 'Other_consum'
               ) t1
  left join (
  
    select dim_detail_code4,nvl(value1,0)-nvl(value2,0) as index_value from (
     select 
     t1.dim_detail_code4,
    t1.index_value as value1,
    t2.index_value as value2
      from (
     
     select 
                    dim_detail_code4,
                    sum(index_value) index_value
               from a
              where index_code = 'Engy_csmp_amt_pratl'
                 and dim_detail_code2 = 'No_listing'
                 and (dim_detail_code5 not in  ('Transportation_amount_D','Transportation_amount_G') or dim_detail_code5 is null)
                group by dim_detail_code4
     
     ) t1 --总消耗
     left join 
     
     (
     select 
                    dim_detail_code4,
                    sum(index_value) index_value
               from a
              where index_code = 'Engy_csmp_amt_pratl'
                 and dim_detail_code2 = 'No_listing'
                 and (dim_detail_code5 in( 'Transportation_amount_D','Transportation_amount_G') or dim_detail_code6 = 'Transportation_amount_N')
                -- and dim_detail_code
                
                               group by 
                       dim_detail_code4
     ) t2 --运输消耗
     on t1.dim_detail_code4 =decode( t2.dim_detail_code4, 'Raw_coal','Gen_bitu_coal',t2.dim_detail_code4)
     )
  
  
  ) tp
  on t1.dim_detail_code =decode( tp.dim_detail_code4, 'Raw_coal','Gen_bitu_coal',tp.dim_detail_code4)
    
    ),
    --工业和非工业
    --工业
    temp8 as (
select  t1.repinst_id,
       P_RPTORGID org_id,
       'C0121' as report_code,
       P_RPTYEAR report_year,
       to_char(to_date(P_RPTYEAR||lpad(P_RPTMONTH,2,0),'yyyyMM'), 'q' ) as report_quarter,
       P_RPTMONTH report_month,
       t1.report_frequent_code,
       t1.status,
       t1.sta_index_inst_id,
       t1.index_code,
       t2.index_value,
       t1.unit_code,
       t1.index_inst_orderno,
       t1.composited_index_code,
       t1.repinst_dtl_dimen,
       t1.dim_code,
       t1.dim_detail_code,
       t1.repinst_dtl_dimen2,
       t1.dim_code2,
       t1.dim_detail_code2,
       t1.repinst_dtl_dimen3,
       t1.dim_code3,
       t1.dim_detail_code3,
       t1.repinst_dtl_dimen4,
       t1.dim_code4,
       'No_listing' as dim_detail_code4,
       t1.repinst_dtl_dimen5,
       t1.dim_code5,
       t1.dim_detail_code5 as dim_detail_code5

  from (select *
          from e7_sta_report_trans
         where index_code in ('Comph_engy_csmp_amt')
          and dim_detail_code5 = 'Industry'
               ) t1
  left join (select index_code,
                    dim_detail_code2,
                    dim_detail_code3,
                    dim_detail_code4,
                    sum(index_value) index_value
               from a
              where index_code = 'Engy_csmp_amt_stadc'
                 and dim_detail_code2 = 'No_listing'
                 and dim_detail_code3 = 'Industry'
                 and (dim_detail_code5 not in  ('Transportation_amount_D','Transportation_amount_G') or dim_detail_code5 is null)
                -- and dim_detail_code
                               group by index_code,
                       dim_detail_code2,
                       dim_detail_code3,
                       dim_detail_code4) t2
    on t1.index_code =decode( t2.index_code, 'Engy_csmp_amt_stadc','Comph_engy_csmp_amt',t2.dim_detail_code4)
    
          
    ),
    --非工业
    temp9 as (
select t1.repinst_id,
       P_RPTORGID org_id,
       'C0121' as report_code,
       P_RPTYEAR report_year,
       to_char(to_date(P_RPTYEAR||lpad(P_RPTMONTH,2,0),'yyyyMM'), 'q' ) as report_quarter,
       P_RPTMONTH report_month,
       t1.report_frequent_code,
       t1.status,
       t1.sta_index_inst_id,
       t1.index_code,
       t2.index_value,
       t1.unit_code,
       t1.index_inst_orderno,
       t1.composited_index_code,
       t1.repinst_dtl_dimen,
       t1.dim_code,
       t1.dim_detail_code,
       t1.repinst_dtl_dimen2,
       t1.dim_code2,
       t1.dim_detail_code2,
       t1.repinst_dtl_dimen3,
       t1.dim_code3,
       t1.dim_detail_code3,
       t1.repinst_dtl_dimen4,
       t1.dim_code4,
       'No_listing' as dim_detail_code4,
       t1.repinst_dtl_dimen5,
       t1.dim_code5,
       t1.dim_detail_code5 as dim_detail_code5

  from (select *
          from e7_sta_report_trans
         where index_code in ('Comph_engy_csmp_amt')
          and dim_detail_code5 = 'Non_industrial'
               ) t1
  left join (select index_code,
                    dim_detail_code2,
                    dim_detail_code3,
                    dim_detail_code4,
                    sum(index_value) index_value
               from a
              where index_code = 'Engy_csmp_amt_stadc'
                 and dim_detail_code2 = 'No_listing'
                 and dim_detail_code3 = 'Non_industrial'
                 and (dim_detail_code5 not in  ('Transportation_amount_D','Transportation_amount_G') or dim_detail_code5 is null)
                -- and dim_detail_code
                               group by index_code,
                       dim_detail_code2,
                       dim_detail_code3,
                       dim_detail_code4) t2
    on t1.index_code =decode( t2.index_code, 'Engy_csmp_amt_stadc','Comph_engy_csmp_amt',t2.dim_detail_code4)
          
    ),
    --折标系数
    temp10 as (
    SELECT 
          t1.repinst_id,
       P_RPTORGID org_id,
       'C0121' as report_code,
       P_RPTYEAR report_year,
       to_char(to_date(P_RPTYEAR||lpad(P_RPTMONTH,2,0),'yyyyMM'), 'q' )  report_quarter,
       P_RPTMONTH report_month,
       t1.report_frequent_code,
       t1.status,
       t1.sta_index_inst_id,
       t1.index_code,
       t1.index_value,
       t1.unit_code,
       t1.index_inst_orderno,
       t1.composited_index_code,
       t1.repinst_dtl_dimen,
       t1.dim_code,
       t1.dim_detail_code,
       t1.repinst_dtl_dimen2,
       t1.dim_code2,
       t1.dim_detail_code2,
       t1.repinst_dtl_dimen3,
       t1.dim_code3,
       t1.dim_detail_code3,
       t1.repinst_dtl_dimen4,
       t1.dim_code4,
       'No_listing' as dim_detail_code4,
       t1.repinst_dtl_dimen5,
       t1.dim_code5,
       t1.dim_detail_code5 as dim_detail_code5
       FROM E7_STA_REPORT_TRANS t1 WHERE INDEX_CODE in( 'Stadc_coef','Ybegin_stor_engy_amt_pratl','Latest_stor_engy_amt_pratl')
    ),
    results as (
    select 
     repinst_id,
       org_id,
      report_code,
      report_year,
       report_quarter,
       report_month,
       report_frequent_code,
       status,
       DECODE(STA_INDEX_INST_ID,NULL,NULL,sta_index_inst_id) sta_index_inst_id,
       index_code,
       index_value,
       unit_code,
       index_inst_orderno,
       composited_index_code,
       DECODE(repinst_dtl_dimen,NULL,NULL,repinst_dtl_dimen) repinst_dtl_dimen,
       dim_code,
       dim_detail_code,
       DECODE(repinst_dtl_dimen2,NULL,NULL,repinst_dtl_dimen2) repinst_dtl_dimen2,
       dim_code2,
       dim_detail_code2,
       DECODE(repinst_dtl_dimen3,NULL,NULL,repinst_dtl_dimen3) repinst_dtl_dimen3,
       dim_code3,
       dim_detail_code3,
       DECODE(repinst_dtl_dimen4,NULL,NULL,repinst_dtl_dimen4) repinst_dtl_dimen4,
       dim_code4,
       dim_detail_code4,
       DECODE(repinst_dtl_dimen5,NULL,NULL,repinst_dtl_dimen5) repinst_dtl_dimen5,
       dim_code5,
       dim_detail_code5
     from (
          select * from temp1 
          union all
          select * from temp2
          union all
          select * from temp3
          union all
          select * from temp4
          union all
          select * from temp5
          union all
          select * from temp6
          union all
          select * from temp7
          union all
          select * from temp8
          union all
          select * from temp9
          union all
          select * from temp10
          
          )
          )
          select 
          distinct 
          'NoTRANS'||P_RPTORGID||repinst_dtl_dimen AS REPINST_DTL_DIMEN,
          'NoTRANS'||P_RPTORGID||sta_index_inst_id AS STA_INDEX_INST_ID,
          dim_code ,
          dim_detail_code,
          NULL AS dim_source,
          NULL AS dim_deteail_id,
          NULL AS dim_deteail_id2,
          unit_code,
          NULL AS composite_dim_code,
          SYSDATE AS create_time,
          SYSDATE AS update_time
          from results WHERE repinst_dtl_dimen IS NOT NULL
          UNION ALL
          select 
          distinct 
          'NoTRANS'||P_RPTORGID||repinst_dtl_dimen2,
          'NoTRANS'||P_RPTORGID||sta_index_inst_id,
          dim_code2 ,
          dim_detail_code2,
          NULL AS dim_source,
          NULL AS dim_deteail_id,
          NULL AS dim_deteail_id2,
          unit_code,
          NULL AS composite_dim_code,
          SYSDATE AS create_time,
          SYSDATE AS update_time
          from results WHERE repinst_dtl_dimen2 IS NOT NULL
          UNION ALL
          select 
          distinct 
          'NoTRANS'||P_RPTORGID||repinst_dtl_dimen3,
          'NoTRANS'||P_RPTORGID||sta_index_inst_id,
          dim_code3 ,
          dim_detail_code3,
          NULL AS dim_source,
          NULL AS dim_deteail_id,
          NULL AS dim_deteail_id2,
          unit_code,
          NULL AS composite_dim_code,
          SYSDATE AS create_time,
          SYSDATE AS update_time
          from results WHERE repinst_dtl_dimen3 IS NOT NULL
          UNION ALL
          select 
          distinct 
          'NoTRANS'||P_RPTORGID||repinst_dtl_dimen4,
          'NoTRANS'||P_RPTORGID||sta_index_inst_id,
          dim_code4 ,
          dim_detail_code4,
          NULL AS dim_source,
          NULL AS dim_deteail_id,
          NULL AS dim_deteail_id2,
          unit_code,
          NULL AS composite_dim_code,
          SYSDATE AS create_time,
          SYSDATE AS update_time
          from results WHERE repinst_dtl_dimen4 IS NOT NULL
          UNION ALL
          select 
          distinct 
          'NoTRANS'||P_RPTORGID||repinst_dtl_dimen5,
          'NoTRANS'||P_RPTORGID||sta_index_inst_id,
          dim_code5 ,
          dim_detail_code5,
          NULL AS dim_source,
          NULL AS dim_deteail_id,
          NULL AS dim_deteail_id2,
          unit_code,
          NULL AS composite_dim_code,
          SYSDATE AS create_time,
          SYSDATE AS update_time
          from results WHERE repinst_dtl_dimen5 IS NOT NULL
          
    );
    
       RPTINDEXINSTT E7_STA_RPT_INDEX_INST%ROWTYPE;
      STAINDEXINST E7_STA_INDEX_INST%ROWTYPE;
      STAINDEXINSTDIMEN E7_STA_INDEX_INST_DIMEN%ROWTYPE;
      AUTH NUMBER(10);
      STATUS NUMBER(10);
      BEGIN
        AUTH:=ISAUTH(P_RPTORGID,P_RPTCODE);
        STATUS:=SJUDGESTATUS('C0121',P_RPTYEAR,P_RPTMONTH,P_RPTORGID);
        IF AUTH >0 THEN
          IF STATUS =0 THEN
        DELDATAS('C0121',P_RPTYEAR ,P_RPTMONTH,P_RPTORGID );
       CREATE_XNNWREPINST('C0121', P_RPTYEAR,P_RPTMONTH,P_RPTORGID);

       FOR E7STARPTINDEXINST IN RPTINDEXINST LOOP
                RPTINDEXINSTT.REPINST_ID:='QY'||'C0121'||P_RPTORGID||P_RPTYEAR||lpad(P_RPTMONTH,2,0);
                RPTINDEXINSTT.STA_INDEX_INST_ID:=E7STARPTINDEXINST.STA_INDEX_INST_ID||P_RPTMONTH;
                RPTINDEXINSTT.CREATE_TIME:=SYSDATE;
                RPTINDEXINSTT.UPDATE_TIME:=SYSDATE;
                INSERT INTO E7_STA_RPT_INDEX_INST VALUES RPTINDEXINSTT;
       END LOOP;
       COMMIT;


        FOR E7STAINDEXINST IN INDEXINST LOOP
                STAINDEXINST.STA_INDEX_INST_ID:=E7STAINDEXINST.STA_INDEX_INST_ID||P_RPTMONTH;
                STAINDEXINST.INDEX_CODE:=E7STAINDEXINST.INDEX_CODE;
                STAINDEXINST.ORG_ID:=P_RPTORGID;
                STAINDEXINST.REPORT_YEAR:=P_RPTYEAR;
                STAINDEXINST.REPORT_QUARTER:=to_char(to_date(P_RPTYEAR||lpad(P_RPTMONTH,2,0),'yyyyMM'), 'Q');
                STAINDEXINST.REPORT_MONTH:=P_RPTMONTH;
                STAINDEXINST.REPORT_FREQUENT_CODE:=3;
                STAINDEXINST.INDEX_VALUE:=E7STAINDEXINST.INDEX_VALUE;
                STAINDEXINST.UNIT_CODE:= NULL;
                STAINDEXINST.REMARK:=NULL;
                STAINDEXINST.INDEX_INST_ORDERNO:=NULL;
                STAINDEXINST.COMPOSITED_INDEX_CODE:=NULL;
                STAINDEXINST.CREATE_TIME:=SYSDATE;
                STAINDEXINST.UPDATE_TIME:=SYSDATE;
                INSERT INTO E7_STA_INDEX_INST VALUES STAINDEXINST;
       END LOOP;
       COMMIT;

      -- DATAQYINDEXDIMEN(P_RPTYEAR,P_RPTMONTH,P_RPTORGID);
      FOR E7STAINDEXINSTDIMEN IN INDEXINSTDIMEN LOOP
          STAINDEXINSTDIMEN.repinst_dtl_dimen  :=E7STAINDEXINSTDIMEN.repinst_dtl_dimen||P_RPTMONTH ;
          STAINDEXINSTDIMEN.sta_index_inst_id  :=E7STAINDEXINSTDIMEN.sta_index_inst_id||P_RPTMONTH ;
          STAINDEXINSTDIMEN.dim_code           :=E7STAINDEXINSTDIMEN.dim_code          ;
          STAINDEXINSTDIMEN.dim_detail_code    :=E7STAINDEXINSTDIMEN.dim_detail_code   ;
          STAINDEXINSTDIMEN.dim_source         := NULL       ;
          STAINDEXINSTDIMEN.dim_deteail_id     := NULL   ;
          STAINDEXINSTDIMEN.dim_deteail_id2    := NULL   ;
          STAINDEXINSTDIMEN.unit_code          := NULL        ;
          STAINDEXINSTDIMEN.composite_dim_code := NULL;
          STAINDEXINSTDIMEN.create_time        := SYSDATE       ;
          STAINDEXINSTDIMEN.update_time        := SYSDATE       ;
          IF STAINDEXINSTDIMEN.repinst_dtl_dimen IS NOT NULL then
          INSERT INTO E7_STA_INDEX_INST_DIMEN VALUES STAINDEXINSTDIMEN;
          END IF;
          END LOOP;
          COMMIT;
          END IF;
          END IF;
        EXCEPTION WHEN OTHERS THEN
          DBMS_OUTPUT.put_line(SQLERRM);
                ROLLBACK;
       END;
 
--XNNW台帐能耗数据转换功能
  PROCEDURE DATATransXNNWSE(P_RPTCODE  IN VARCHAR2,
                     P_RPTYEAR  IN VARCHAR2,
                     P_RPTMONTH IN VARCHAR2,
                     P_RPTORGID IN VARCHAR2,
                     P_RPTUSERID in VARCHAR2,
                     P_RPTUSERNAME IN VARCHAR2
                     ) AS

CURSOR E_STAREPINST IS SELECT * FROM  (with aa as (
SELECT AA.REPINST_ID,
BB.*
 FROM 
(SELECT REPINST_ID FROM E7_STA_REPINST WHERE ORG_ID = P_RPTORGID AND REPORT_CODE =P_RPTCODE AND REPORT_YEAR = P_RPTYEAR AND REPORT_MONTH = P_RPTMONTH) AA,
(
select 
       repinst.org_id,
       repinst.report_year,
       P_RPTMONTH AS report_month,
       MAX(indexinst.sta_index_inst_id) STA_INDEX_INST_ID,
       indexinst.index_code,
       sum(indexinst.index_value) index_value,
       indexinst.COMPOSITED_INDEX_CODE,
       dimeninst.dim_code              as dim_code,
       dimeninst.dim_detail_code       as dim_detail_code,
       dimeninst2.dim_code             as dim_code2,
       dimeninst2.dim_detail_code      as dim_detail_code2,
       dimeninst3.dim_code             as dim_code3,
       dimeninst3.dim_detail_code      as dim_detail_code3,
       dimeninst4.dim_code             as dim_code4,
       dimeninst4.dim_detail_code      as dim_detail_code4,
       dimeninst5.dim_code             as dim_code5,
       dimeninst5.dim_detail_code      as dim_detail_code5,
       dimeninst6.dim_code             as dim_code6,
       dimeninst6.dim_detail_code      as dim_detail_code6
  from e7_sta_repinst repinst
  left join e7_sta_rpt_index_inst rptindexinst
    on repinst.repinst_id = rptindexinst.repinst_id
  left join e7_sta_index_inst indexinst
    on rptindexinst.sta_index_inst_id = indexinst.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst
    on dimeninst.dim_code = 'Business_type'
   and indexinst.sta_index_inst_id = dimeninst.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst2
    on dimeninst2.dim_code = 'Assets_type'
   and indexinst.sta_index_inst_id = dimeninst2.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst3
    on dimeninst3.dim_code = 'Industry_type'
   and indexinst.sta_index_inst_id = dimeninst3.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst4
    on dimeninst4.dim_code = 'Cru_oil_E_cons_typ'
   and indexinst.sta_index_inst_id = dimeninst4.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst5
    on dimeninst5.dim_code = 'Custom_dimen_first'
   and indexinst.sta_index_inst_id = dimeninst5.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst6
    on dimeninst6.dim_code = 'Custom_dimen_second'
   and indexinst.sta_index_inst_id = dimeninst6.sta_index_inst_id
   
 where repinst.report_code = P_RPTCODE
   and repinst.org_id = P_RPTORGID
   and  indexinst.COMPOSITED_INDEX_CODE =P_RPTORGID
   and repinst.report_year = P_RPTYEAR
   and repinst.report_month <= P_RPTMONTH
 group by
          repinst.org_id,
          repinst.report_year,
          indexinst.index_code,
          indexinst.COMPOSITED_INDEX_CODE,
          dimeninst.dim_code,
          dimeninst.dim_detail_code,
          dimeninst2.dim_code,
          dimeninst2.dim_detail_code,
          dimeninst3.dim_code,
          dimeninst3.dim_detail_code,
          dimeninst4.dim_code,
          dimeninst4.dim_detail_code,
          dimeninst5.dim_code,
          dimeninst5.dim_detail_code,
          dimeninst6.dim_code,
          dimeninst6.dim_detail_code
          ) BB where dim_detail_code6 != 'Material_own_amount_N' OR dim_detail_code6 IS NULL
          ),
          RES3 AS (
        
SELECT AA.REPINST_ID,
BB.*
 FROM 
(SELECT REPINST_ID FROM E7_STA_REPINST WHERE ORG_ID = P_RPTORGID AND REPORT_CODE =P_RPTCODE AND REPORT_YEAR = P_RPTYEAR AND REPORT_MONTH = P_RPTMONTH) AA,
(
select 
       repinst.org_id,
       repinst.report_year,
       P_RPTMONTH AS report_month,
       MAX(indexinst.sta_index_inst_id) STA_INDEX_INST_ID,
       indexinst.index_code,
       sum(indexinst.index_value) index_value,
       indexinst.COMPOSITED_INDEX_CODE,
       dimeninst.dim_code              as dim_code,
       dimeninst.dim_detail_code       as dim_detail_code,
       dimeninst2.dim_code             as dim_code2,
       dimeninst2.dim_detail_code      as dim_detail_code2,
       dimeninst3.dim_code             as dim_code3,
       dimeninst3.dim_detail_code      as dim_detail_code3,
       dimeninst4.dim_code             as dim_code4,
       dimeninst4.dim_detail_code      as dim_detail_code4,
       dimeninst5.dim_code             as dim_code5,
       dimeninst5.dim_detail_code      as dim_detail_code5,
       dimeninst6.dim_code             as dim_code6,
       dimeninst6.dim_detail_code      as dim_detail_code6
  from e7_sta_repinst repinst
  left join e7_sta_rpt_index_inst rptindexinst
    on repinst.repinst_id = rptindexinst.repinst_id
  left join e7_sta_index_inst indexinst
    on rptindexinst.sta_index_inst_id = indexinst.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst
    on dimeninst.dim_code = 'Business_type'
   and indexinst.sta_index_inst_id = dimeninst.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst2
    on dimeninst2.dim_code = 'Assets_type'
   and indexinst.sta_index_inst_id = dimeninst2.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst3
    on dimeninst3.dim_code = 'Industry_type'
   and indexinst.sta_index_inst_id = dimeninst3.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst4
    on dimeninst4.dim_code = 'Cru_oil_E_cons_typ'
   and indexinst.sta_index_inst_id = dimeninst4.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst5
    on dimeninst5.dim_code = 'Custom_dimen_first'
   and indexinst.sta_index_inst_id = dimeninst5.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst6
    on dimeninst6.dim_code = 'Custom_dimen_second'
   and indexinst.sta_index_inst_id = dimeninst6.sta_index_inst_id
   
 where repinst.report_code = P_RPTCODE
   and repinst.org_id = P_RPTORGID
   and  indexinst.COMPOSITED_INDEX_CODE =P_RPTORGID
   and repinst.report_year = P_RPTYEAR
   and repinst.report_month <= P_RPTMONTH
 group by
          repinst.org_id,
          repinst.report_year,
          indexinst.index_code,
          indexinst.COMPOSITED_INDEX_CODE,
          dimeninst.dim_code,
          dimeninst.dim_detail_code,
          dimeninst2.dim_code,
          dimeninst2.dim_detail_code,
          dimeninst3.dim_code,
          dimeninst3.dim_detail_code,
          dimeninst4.dim_code,
          dimeninst4.dim_detail_code,
          dimeninst5.dim_code,
          dimeninst5.dim_detail_code,
          dimeninst6.dim_code,
          dimeninst6.dim_detail_code
          ) BB
          ),
          AMT as
          (SELECT *
           FROM RES3 WHERE DIM_DETAIL_CODE IN (
          SELECT DIM_DETAIL_CODE FROM E7_STA_DIM_DETAIL 
                START WITH DIM_DETAIL_CODE = 'Chemical'
                CONNECT BY PARENT_DIM_DETAIL_CODE = PRIOR DIM_DETAIL_CODE
          )  AND DIM_DETAIL_CODE4 = 'Natural_gas' AND INDEX_CODE = 'Engy_csmp_amt_pratl' and index_value is not null) ,
          COST as
          (SELECT *
           FROM RES3 WHERE DIM_DETAIL_CODE IN (
          SELECT DIM_DETAIL_CODE FROM E7_STA_DIM_DETAIL 
                START WITH DIM_DETAIL_CODE = 'Chemical'
                CONNECT BY PARENT_DIM_DETAIL_CODE = PRIOR DIM_DETAIL_CODE
          )  AND DIM_DETAIL_CODE4 = 'Natural_gas' AND INDEX_CODE = 'Engy_csmp_cost'),
          natural_price as (
          select b.index_value/a.index_value as index_value from 
          (select sum(index_value) as index_value from amt) a,
          (select sum(index_value) as index_value from cost) b
          ),
          insert_col as (
          select 
          repinst_id,org_id,report_year,report_month,sta_index_inst_id||'I' as sta_index_inst_id,'Engy_csmp_cost' AS index_code ,
          round( -1 * a.index_value * natural_price.index_value,5) as index_value,
          composited_index_code,dim_code,dim_detail_code,
          dim_code2,dim_detail_code2,
          dim_code3,dim_detail_code3,
          dim_code4,dim_detail_code4,
          dim_code5,dim_detail_code5,
          dim_code6,dim_detail_code6
           from amt a ,natural_price where dim_detail_code6 = 'Material_own_amount_N'),
           a as (
           select *
            from aa 
           union all
            select * from insert_col
           ),
          res as (
              select repinst_id,
              report_year,
              report_month,
              sta_index_inst_id,
              index_code,
              index_value,
              composited_index_code,
              dim_code,
              dim_detail_code,
              dim_code2,
              dim_detail_code2,
              dim_code3,
              dim_detail_code3,
              dim_code4,
              dim_detail_code4
              from a
              union all
              select repinst_id,
              report_year,
              report_month,
              sta_index_inst_id,
              index_code,
              index_value,
              composited_index_code,
              dim_code,
              dim_detail_code,

              dim_code2,
              dim_detail_code2,
              dim_code3,
              dim_detail_code3,
              dim_code5,
              dim_detail_code5
              from a
              union all
              select repinst_id,
              report_year,
              report_month,
              sta_index_inst_id,
              index_code,
              index_value,
              composited_index_code,
              dim_code,
              dim_detail_code,

              dim_code2,
              dim_detail_code2,
              dim_code3,
              dim_detail_code3,
              dim_code6,
              dim_detail_code6
              from a
                ),
                res1 as (
                select res.repinst_id,
                res.report_year,
                res.report_month,
                res.sta_index_inst_id,
                relation.index_code,
                res.index_value,
                res.composited_index_code,
                res.dim_code,
                res.dim_detail_code,
                res.dim_code2,
                res.dim_detail_code2,
                res.dim_code3,
                res.dim_detail_code3,
                relation.dim_code dim_code4,
                relation.dim_detail_code dim_detail_code4

                 from res
                 left join
                 (select * from e7_xn_dim_relation) relation
                on res.index_code||res.dim_code4||res.dim_detail_code4 = relation.xn_index_code||relation.xn_dim_code||relation.xn_dim_detail_code
               ),
               res2 as (

          select * from res1 where index_code is not null
          union all
          select distinct * from res where index_code = 'Engy_csmp_amt_stadc'
          ),
          resultt as (
          select rrss.*,stadc.param_value from (
          select t.*,nvl(detail.parent_dim_detail_code,t.dim_detail_code4) as org_dim_detail_code from (
          select
          max(a .repinst_id)  repinst_id,
          report_year,
          report_month,
          max(sta_index_inst_id) sta_index_inst_id,
          index_code,
          sum(index_value) index_value,
          composited_index_code,
          report_code,
          dim_code,
          dim_detail_code,
          dim_code2,
          dim_detail_code2,
          dim_code3,
          dim_detail_code3,
          dim_code4,
          dim_detail_code4
           from (
          select  r.repinst_id,
          r.report_year,
          r.report_month,
          r.sta_index_inst_id,
          r.index_code,
          r.index_value,
          r.composited_index_code,
          linkxn.report_code,
          linkxn.dim_code,
          linkxn.dim_detail_code,
          r.dim_code2,
          r.dim_detail_code2,
          r.dim_code3,
          r.dim_detail_code3,
          r.dim_code4,
          r.dim_detail_code4
           from res2 r
           left join e7_business_link_xn linkxn
           on r.dim_detail_code = linkxn.business_type

           and linkxn.report_type = 'E'
           where r.index_code not in (
              'Fresh_water_consu_amt','Fresh_water_consu_cost'
           )
           ) a
           group by
          report_year,
          report_month,
          index_code,
          composited_index_code,
          report_code,
          dim_code,
          dim_detail_code,
          dim_code2,
          dim_detail_code2,
          dim_code3,
          dim_detail_code3,
          dim_code4,
          dim_detail_code4
           ) t
           left join e7_sta_dim_detail detail on t.dim_code4 = detail.dim_code
           and t.dim_detail_code4 = detail.dim_detail_code

           ) rrss left join (
                select dim_detail_code,param_value from e7_sta_base_param where dim_code = 'Orig_energy_type'and param_type_code = '02' and dim_detail_code in (
                  select dim_detail_code from e7_sta_rep_index_dimen where report_code = 'XNNW01' and dim_code = 'Cru_oil_E_cons_typ'
                  ) and org_id = 1
           ) stadc on rrss.org_dim_detail_code = stadc.dim_detail_code
           and rrss.index_code = 'Engy_csmp_amt_pratl'
           ),
           results as (
           SELECT 
            repinst_id,
            report_year,
            report_month,
            sta_index_inst_id,
            index_code,
            index_value,
            composited_index_code,
            report_code,
            cc.dim_code,cc.dim_detail_code,
            dim_code2,dim_detail_code2,
            dim_code3,dim_detail_code3,
            dim_code4,
            decode(index_code,'Stadc_coef',nvl(dd.parent_dim_detail_code,dim_detail_code4),dim_detail_code4) as dim_detail_code4,
            dimen_orderno
           FROM (
           SELECT aa.*,bb.dimen_orderno FROM (
           SELECT * FROM (
           select repinst_id,
           report_year,
           report_month,
           sta_index_inst_id||'ST' as sta_index_inst_id,
           'Stadc_coef' as index_code,
           param_value as index_value,
           composited_index_code,
           report_code,
           dim_code,
           dim_detail_code,
           dim_code2,
           dim_detail_code2,
           dim_code3,
           dim_detail_code3,
           dim_code4,
           dim_detail_code4 
            from resultt where param_value is not null
            union all
            select repinst_id,
            report_year,
            report_month,
            sta_index_inst_id,
            index_code,
            index_value,
            composited_index_code,
            report_code,dim_code,
           dim_detail_code,
           dim_code2,
           dim_detail_code2,
           dim_code3,
           dim_detail_code3,
           dim_code4,
            dim_detail_code4
           
           from resultt) WHERE  REPORT_CODE IS NOT NULL 
           ) aa,
           (select * from e7_sta_rep_index_dimen where report_code = 'C0002' and index_code = 'Engy_csmp_amt_pratl' and dim_code = 'Cru_oil_E_cons_typ') bb
           where aa.dim_detail_code4 = bb.dim_detail_code
           order by aa.dim_detail_code,bb.dimen_orderno
           ) cc 
           left join 
           (select * from e7_sta_dim_detail where dim_detail_code in (
           select dim_detail_code from e7_sta_rep_index_dimen where report_code = 'C0002' and dim_code = 'Cru_oil_E_cons_typ'
           ) and dim_code = 'Cru_oil_E_cons_typ' ) dd
          on cc.dim_detail_code4 = dd.dim_detail_code
          where report_code in( select report_code from e7_sta_rpt_auth where org_id = P_RPTORGID)
            )
           select DISTINCT
          replace(repinst_id,'XNNW',results.report_code)  as repinst_id,
        composited_index_code as org_id,
         results.report_code,
         report_year,
        to_char(to_date(REPORT_YEAR||lpad(REPORT_MONTH,2,0),'yyyyMM'), 'Q') as report_quarter,
        REPORT_MONTH as report_month,
        3 as report_frequent_code,
        '02' as status,
        nvl(auth.entry_person,null) as writer,
        sysdate as write_date,
        nvl(auth.verify_person,null) as checker,
        sysdate as check_date,
        null as condition,
        null as verify_note,
        P_RPTUSERID as create_user_id,
        P_RPTUSERNAME as create_user_name,
        sysdate as create_time,
        P_RPTUSERID as update_user_id,
       P_RPTUSERNAME as update_user_name,
        sysdate as update_time
        from results LEFT JOIN E7_STA_RPT_AUTH AUTH
        ON results.report_code = auth.report_code
        and results.composited_index_code = auth.org_id
        );

        CURSOR E_STARPTINDEXINST IS SELECT * FROM (
        with aa as (
SELECT AA.REPINST_ID,
BB.*
 FROM 
(SELECT REPINST_ID FROM E7_STA_REPINST WHERE ORG_ID = P_RPTORGID AND REPORT_CODE =P_RPTCODE AND REPORT_YEAR = P_RPTYEAR AND REPORT_MONTH = P_RPTMONTH) AA,
(
select 
       repinst.org_id,
       repinst.report_year,
       P_RPTMONTH AS report_month,
       MAX(indexinst.sta_index_inst_id) STA_INDEX_INST_ID,
       indexinst.index_code,
       sum(indexinst.index_value) index_value,
       indexinst.COMPOSITED_INDEX_CODE,
       dimeninst.dim_code              as dim_code,
       dimeninst.dim_detail_code       as dim_detail_code,
       dimeninst2.dim_code             as dim_code2,
       dimeninst2.dim_detail_code      as dim_detail_code2,
       dimeninst3.dim_code             as dim_code3,
       dimeninst3.dim_detail_code      as dim_detail_code3,
       dimeninst4.dim_code             as dim_code4,
       dimeninst4.dim_detail_code      as dim_detail_code4,
       dimeninst5.dim_code             as dim_code5,
       dimeninst5.dim_detail_code      as dim_detail_code5,
       dimeninst6.dim_code             as dim_code6,
       dimeninst6.dim_detail_code      as dim_detail_code6
  from e7_sta_repinst repinst
  left join e7_sta_rpt_index_inst rptindexinst
    on repinst.repinst_id = rptindexinst.repinst_id
  left join e7_sta_index_inst indexinst
    on rptindexinst.sta_index_inst_id = indexinst.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst
    on dimeninst.dim_code = 'Business_type'
   and indexinst.sta_index_inst_id = dimeninst.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst2
    on dimeninst2.dim_code = 'Assets_type'
   and indexinst.sta_index_inst_id = dimeninst2.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst3
    on dimeninst3.dim_code = 'Industry_type'
   and indexinst.sta_index_inst_id = dimeninst3.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst4
    on dimeninst4.dim_code = 'Cru_oil_E_cons_typ'
   and indexinst.sta_index_inst_id = dimeninst4.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst5
    on dimeninst5.dim_code = 'Custom_dimen_first'
   and indexinst.sta_index_inst_id = dimeninst5.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst6
    on dimeninst6.dim_code = 'Custom_dimen_second'
   and indexinst.sta_index_inst_id = dimeninst6.sta_index_inst_id
   
 where repinst.report_code = P_RPTCODE
   and repinst.org_id = P_RPTORGID
   and  indexinst.COMPOSITED_INDEX_CODE =P_RPTORGID
   and repinst.report_year = P_RPTYEAR
   and repinst.report_month <= P_RPTMONTH
 group by
          repinst.org_id,
          repinst.report_year,
          indexinst.index_code,
          indexinst.COMPOSITED_INDEX_CODE,
          dimeninst.dim_code,
          dimeninst.dim_detail_code,
          dimeninst2.dim_code,
          dimeninst2.dim_detail_code,
          dimeninst3.dim_code,
          dimeninst3.dim_detail_code,
          dimeninst4.dim_code,
          dimeninst4.dim_detail_code,
          dimeninst5.dim_code,
          dimeninst5.dim_detail_code,
          dimeninst6.dim_code,
          dimeninst6.dim_detail_code
          ) BB
      where dim_detail_code6 != 'Material_own_amount_N' OR dim_detail_code6 IS NULL
          ),
          RES3 AS (
        
SELECT AA.REPINST_ID,
BB.*
 FROM 
(SELECT REPINST_ID FROM E7_STA_REPINST WHERE ORG_ID = P_RPTORGID AND REPORT_CODE =P_RPTCODE AND REPORT_YEAR = P_RPTYEAR AND REPORT_MONTH = P_RPTMONTH) AA,
(
select 
       repinst.org_id,
       repinst.report_year,
       P_RPTMONTH AS report_month,
       MAX(indexinst.sta_index_inst_id) STA_INDEX_INST_ID,
       indexinst.index_code,
       sum(indexinst.index_value) index_value,
       indexinst.COMPOSITED_INDEX_CODE,
       dimeninst.dim_code              as dim_code,
       dimeninst.dim_detail_code       as dim_detail_code,
       dimeninst2.dim_code             as dim_code2,
       dimeninst2.dim_detail_code      as dim_detail_code2,
       dimeninst3.dim_code             as dim_code3,
       dimeninst3.dim_detail_code      as dim_detail_code3,
       dimeninst4.dim_code             as dim_code4,
       dimeninst4.dim_detail_code      as dim_detail_code4,
       dimeninst5.dim_code             as dim_code5,
       dimeninst5.dim_detail_code      as dim_detail_code5,
       dimeninst6.dim_code             as dim_code6,
       dimeninst6.dim_detail_code      as dim_detail_code6
  from e7_sta_repinst repinst
  left join e7_sta_rpt_index_inst rptindexinst
    on repinst.repinst_id = rptindexinst.repinst_id
  left join e7_sta_index_inst indexinst
    on rptindexinst.sta_index_inst_id = indexinst.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst
    on dimeninst.dim_code = 'Business_type'
   and indexinst.sta_index_inst_id = dimeninst.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst2
    on dimeninst2.dim_code = 'Assets_type'
   and indexinst.sta_index_inst_id = dimeninst2.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst3
    on dimeninst3.dim_code = 'Industry_type'
   and indexinst.sta_index_inst_id = dimeninst3.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst4
    on dimeninst4.dim_code = 'Cru_oil_E_cons_typ'
   and indexinst.sta_index_inst_id = dimeninst4.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst5
    on dimeninst5.dim_code = 'Custom_dimen_first'
   and indexinst.sta_index_inst_id = dimeninst5.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst6
    on dimeninst6.dim_code = 'Custom_dimen_second'
   and indexinst.sta_index_inst_id = dimeninst6.sta_index_inst_id
   
 where repinst.report_code = P_RPTCODE
   and repinst.org_id = P_RPTORGID
   and  indexinst.COMPOSITED_INDEX_CODE =P_RPTORGID
   and repinst.report_year = P_RPTYEAR
   and repinst.report_month <= P_RPTMONTH
 group by
          repinst.org_id,
          repinst.report_year,
          indexinst.index_code,
          indexinst.COMPOSITED_INDEX_CODE,
          dimeninst.dim_code,
          dimeninst.dim_detail_code,
          dimeninst2.dim_code,
          dimeninst2.dim_detail_code,
          dimeninst3.dim_code,
          dimeninst3.dim_detail_code,
          dimeninst4.dim_code,
          dimeninst4.dim_detail_code,
          dimeninst5.dim_code,
          dimeninst5.dim_detail_code,
          dimeninst6.dim_code,
          dimeninst6.dim_detail_code
          ) BB
          ),
          AMT as
          (SELECT *
           FROM RES3 WHERE DIM_DETAIL_CODE IN (
          SELECT DIM_DETAIL_CODE FROM E7_STA_DIM_DETAIL 
                START WITH DIM_DETAIL_CODE = 'Chemical'
                CONNECT BY PARENT_DIM_DETAIL_CODE = PRIOR DIM_DETAIL_CODE
          )  AND DIM_DETAIL_CODE4 = 'Natural_gas' AND INDEX_CODE = 'Engy_csmp_amt_pratl' and index_value is not null) ,
          COST as
          (SELECT *
           FROM RES3 WHERE DIM_DETAIL_CODE IN (
          SELECT DIM_DETAIL_CODE FROM E7_STA_DIM_DETAIL 
                START WITH DIM_DETAIL_CODE = 'Chemical'
                CONNECT BY PARENT_DIM_DETAIL_CODE = PRIOR DIM_DETAIL_CODE
          )  AND DIM_DETAIL_CODE4 = 'Natural_gas' AND INDEX_CODE = 'Engy_csmp_cost'),
          natural_price as (
          select b.index_value/a.index_value as index_value from 
          (select sum(index_value) as index_value from amt) a,
          (select sum(index_value) as index_value from cost) b
          ),
          insert_col as (
          select 
          repinst_id,org_id,report_year,report_month,sta_index_inst_id||'I' as sta_index_inst_id,'Engy_csmp_cost' as index_code ,
          round( -1 * a.index_value * natural_price.index_value,5) as index_value,
          composited_index_code,dim_code,dim_detail_code,
          dim_code2,dim_detail_code2,
          dim_code3,dim_detail_code3,
          dim_code4,dim_detail_code4,
          dim_code5,dim_detail_code5,
          dim_code6,dim_detail_code6
           from amt a ,natural_price where dim_detail_code6 = 'Material_own_amount_N'),
           a as 
           (select *
            from aa 
           union all select *
            from insert_col),
          res as (
              select repinst_id,
              report_year,
              report_month,
              sta_index_inst_id,
              index_code,
              index_value,
              composited_index_code,
              dim_code,
              dim_detail_code,
              dim_code2,
              dim_detail_code2,
              dim_code3,
              dim_detail_code3,
              dim_code4,
              dim_detail_code4
              from a
              union all
              select repinst_id,
              report_year,
              report_month,
              sta_index_inst_id,
              index_code,
              index_value,
              composited_index_code,
              dim_code,
              dim_detail_code,

              dim_code2,
              dim_detail_code2,
              dim_code3,
              dim_detail_code3,
              dim_code5,
              dim_detail_code5
              from a
              union all
              select repinst_id,
              report_year,
              report_month,
              sta_index_inst_id,
              index_code,
              index_value,
              composited_index_code,
              dim_code,
              dim_detail_code,

              dim_code2,
              dim_detail_code2,
              dim_code3,
              dim_detail_code3,
              dim_code6,
              dim_detail_code6
              from a
                ),
                res1 as (
                select res.repinst_id,
                res.report_year,
                res.report_month,
                res.sta_index_inst_id,
                relation.index_code,
                res.index_value,
                res.composited_index_code,
                res.dim_code,
                res.dim_detail_code,
                res.dim_code2,
                res.dim_detail_code2,
                res.dim_code3,
                res.dim_detail_code3,
                relation.dim_code dim_code4,
                relation.dim_detail_code dim_detail_code4

                 from res
                 left join
                 (select * from e7_xn_dim_relation) relation
                on res.index_code||res.dim_code4||res.dim_detail_code4 = relation.xn_index_code||relation.xn_dim_code||relation.xn_dim_detail_code
               ),
               res2 as (

          select * from res1 where index_code is not null
          union all
          select distinct * from res where index_code = 'Engy_csmp_amt_stadc'
          ),
          resultt as (
          select rrss.*,stadc.param_value from (
          select t.*,nvl(detail.parent_dim_detail_code,t.dim_detail_code4) as org_dim_detail_code from (
          select
          max(a .repinst_id)  repinst_id,
          report_year,
          report_month,
          max(sta_index_inst_id) sta_index_inst_id,
          index_code,
          sum(index_value) index_value,
          composited_index_code,
          report_code,
          dim_code,
          dim_detail_code,
          dim_code2,
          dim_detail_code2,
          dim_code3,
          dim_detail_code3,
          dim_code4,
          dim_detail_code4
           from (
          select  r.repinst_id,
          r.report_year,
          r.report_month,
          r.sta_index_inst_id,
          r.index_code,
          r.index_value,
          r.composited_index_code,
          linkxn.report_code,
          linkxn.dim_code,
          linkxn.dim_detail_code,
          r.dim_code2,
          r.dim_detail_code2,
          r.dim_code3,
          r.dim_detail_code3,
          r.dim_code4,
          r.dim_detail_code4
           from res2 r
           left join e7_business_link_xn linkxn
           on r.dim_detail_code = linkxn.business_type

           and linkxn.report_type = 'E'
           where r.index_code not in (
              'Fresh_water_consu_amt','Fresh_water_consu_cost'
           )
           ) a
           group by
          report_year,
          report_month,
          index_code,
          composited_index_code,
          report_code,
          dim_code,
          dim_detail_code,
          dim_code2,
          dim_detail_code2,
          dim_code3,
          dim_detail_code3,
          dim_code4,
          dim_detail_code4
           ) t
           left join e7_sta_dim_detail detail on t.dim_code4 = detail.dim_code
           and t.dim_detail_code4 = detail.dim_detail_code

           ) rrss left join (
                select dim_detail_code,param_value from e7_sta_base_param where dim_code = 'Orig_energy_type'and param_type_code = '02' and dim_detail_code in (
                  select dim_detail_code from e7_sta_rep_index_dimen where report_code = 'XNNW01' and dim_code = 'Cru_oil_E_cons_typ'
                  ) and org_id = 1
           ) stadc on rrss.org_dim_detail_code = stadc.dim_detail_code
           and rrss.index_code = 'Engy_csmp_amt_pratl'
           ),
           results as (
           SELECT 
            repinst_id,
            report_year,
            report_month,
            sta_index_inst_id,
            index_code,
            index_value,
            composited_index_code,
            report_code,
            cc.dim_code,cc.dim_detail_code,
            dim_code2,dim_detail_code2,
            dim_code3,dim_detail_code3,
            dim_code4,
            decode(index_code,'Stadc_coef',nvl(dd.parent_dim_detail_code,dim_detail_code4),dim_detail_code4) as dim_detail_code4,
            dimen_orderno
           FROM (
           SELECT aa.*,bb.dimen_orderno FROM (
           SELECT * FROM (
           select repinst_id,
           report_year,
           report_month,
           sta_index_inst_id||'ST' as sta_index_inst_id,
           'Stadc_coef' as index_code,
           param_value as index_value,
           composited_index_code,
           report_code,
           dim_code,
           dim_detail_code,
           dim_code2,
           dim_detail_code2,
           dim_code3,
           dim_detail_code3,
           dim_code4,
           dim_detail_code4 
            from resultt where param_value is not null
            union all
            select repinst_id,
            report_year,
            report_month,
            sta_index_inst_id,
            index_code,
            index_value,
            composited_index_code,
            report_code,dim_code,
           dim_detail_code,
           dim_code2,
           dim_detail_code2,
           dim_code3,
           dim_detail_code3,
           dim_code4,
            dim_detail_code4
           
           from resultt) WHERE REPORT_CODE IS NOT NULL
           ) aa,
           (select * from e7_sta_rep_index_dimen where report_code = 'C0002' and index_code = 'Engy_csmp_amt_pratl' and dim_code = 'Cru_oil_E_cons_typ') bb
           where aa.dim_detail_code4 = bb.dim_detail_code
           order by aa.dim_detail_code,bb.dimen_orderno
           ) cc 
           left join 
           (select * from e7_sta_dim_detail where dim_detail_code in (
           select dim_detail_code from e7_sta_rep_index_dimen where report_code = 'C0002' and dim_code = 'Cru_oil_E_cons_typ'
           ) and dim_code = 'Cru_oil_E_cons_typ' ) dd
          on cc.dim_detail_code4 = dd.dim_detail_code
           where report_code in( select report_code from e7_sta_rpt_auth where org_id = P_RPTORGID)
            )
           select DISTINCT
          replace(repinst_id,'XNNW',results.report_code)  as repinst_id,--REPINST_ID
        REPLACE(STA_INDEX_INST_ID,'XNNW',REPORT_CODE)||composited_index_code as STA_INDEX_INST_ID,--STA_INDEX_INST_ID ||P_RPTORGID||P_RPTYEAR||P_RPTMONTH
        sysdate as create_time,
        sysdate as update_time
        FROM RESULTS

        );

        CURSOR E_STAINDEXINST IS SELECT * FROM (with aa as (
SELECT AA.REPINST_ID,
BB.*
 FROM 
(SELECT REPINST_ID FROM E7_STA_REPINST WHERE ORG_ID = P_RPTORGID AND REPORT_CODE =P_RPTCODE AND REPORT_YEAR = P_RPTYEAR AND REPORT_MONTH = P_RPTMONTH) AA,
(
select 
       repinst.org_id,
       repinst.report_year,
       P_RPTMONTH AS report_month,
       MAX(indexinst.sta_index_inst_id) STA_INDEX_INST_ID,
       indexinst.index_code,
       sum(indexinst.index_value) index_value,
       indexinst.COMPOSITED_INDEX_CODE,
       dimeninst.dim_code              as dim_code,
       dimeninst.dim_detail_code       as dim_detail_code,
       dimeninst2.dim_code             as dim_code2,
       dimeninst2.dim_detail_code      as dim_detail_code2,
       dimeninst3.dim_code             as dim_code3,
       dimeninst3.dim_detail_code      as dim_detail_code3,
       dimeninst4.dim_code             as dim_code4,
       dimeninst4.dim_detail_code      as dim_detail_code4,
       dimeninst5.dim_code             as dim_code5,
       dimeninst5.dim_detail_code      as dim_detail_code5,
       dimeninst6.dim_code             as dim_code6,
       dimeninst6.dim_detail_code      as dim_detail_code6
  from e7_sta_repinst repinst
  left join e7_sta_rpt_index_inst rptindexinst
    on repinst.repinst_id = rptindexinst.repinst_id
  left join e7_sta_index_inst indexinst
    on rptindexinst.sta_index_inst_id = indexinst.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst
    on dimeninst.dim_code = 'Business_type'
   and indexinst.sta_index_inst_id = dimeninst.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst2
    on dimeninst2.dim_code = 'Assets_type'
   and indexinst.sta_index_inst_id = dimeninst2.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst3
    on dimeninst3.dim_code = 'Industry_type'
   and indexinst.sta_index_inst_id = dimeninst3.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst4
    on dimeninst4.dim_code = 'Cru_oil_E_cons_typ'
   and indexinst.sta_index_inst_id = dimeninst4.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst5
    on dimeninst5.dim_code = 'Custom_dimen_first'
   and indexinst.sta_index_inst_id = dimeninst5.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst6
    on dimeninst6.dim_code = 'Custom_dimen_second'
   and indexinst.sta_index_inst_id = dimeninst6.sta_index_inst_id
   
 where repinst.report_code = P_RPTCODE
   and repinst.org_id = P_RPTORGID
   and  indexinst.COMPOSITED_INDEX_CODE =P_RPTORGID
   and repinst.report_year = P_RPTYEAR
   and repinst.report_month <= P_RPTMONTH
 group by
          repinst.org_id,
          repinst.report_year,
          indexinst.index_code,
          indexinst.COMPOSITED_INDEX_CODE,
          dimeninst.dim_code,
          dimeninst.dim_detail_code,
          dimeninst2.dim_code,
          dimeninst2.dim_detail_code,
          dimeninst3.dim_code,
          dimeninst3.dim_detail_code,
          dimeninst4.dim_code,
          dimeninst4.dim_detail_code,
          dimeninst5.dim_code,
          dimeninst5.dim_detail_code,
          dimeninst6.dim_code,
          dimeninst6.dim_detail_code
          ) BB
          where dim_detail_code6 != 'Material_own_amount_N' OR dim_detail_code6 IS NULL
          ),
          RES3 AS (
        
SELECT AA.REPINST_ID,
BB.*
 FROM 
(SELECT REPINST_ID FROM E7_STA_REPINST WHERE ORG_ID = P_RPTORGID AND REPORT_CODE =P_RPTCODE AND REPORT_YEAR = P_RPTYEAR AND REPORT_MONTH = P_RPTMONTH) AA,
(
select 
       repinst.org_id,
       repinst.report_year,
       P_RPTMONTH AS report_month,
       MAX(indexinst.sta_index_inst_id) STA_INDEX_INST_ID,
       indexinst.index_code,
       sum(indexinst.index_value) index_value,
       indexinst.COMPOSITED_INDEX_CODE,
       dimeninst.dim_code              as dim_code,
       dimeninst.dim_detail_code       as dim_detail_code,
       dimeninst2.dim_code             as dim_code2,
       dimeninst2.dim_detail_code      as dim_detail_code2,
       dimeninst3.dim_code             as dim_code3,
       dimeninst3.dim_detail_code      as dim_detail_code3,
       dimeninst4.dim_code             as dim_code4,
       dimeninst4.dim_detail_code      as dim_detail_code4,
       dimeninst5.dim_code             as dim_code5,
       dimeninst5.dim_detail_code      as dim_detail_code5,
       dimeninst6.dim_code             as dim_code6,
       dimeninst6.dim_detail_code      as dim_detail_code6
  from e7_sta_repinst repinst
  left join e7_sta_rpt_index_inst rptindexinst
    on repinst.repinst_id = rptindexinst.repinst_id
  left join e7_sta_index_inst indexinst
    on rptindexinst.sta_index_inst_id = indexinst.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst
    on dimeninst.dim_code = 'Business_type'
   and indexinst.sta_index_inst_id = dimeninst.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst2
    on dimeninst2.dim_code = 'Assets_type'
   and indexinst.sta_index_inst_id = dimeninst2.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst3
    on dimeninst3.dim_code = 'Industry_type'
   and indexinst.sta_index_inst_id = dimeninst3.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst4
    on dimeninst4.dim_code = 'Cru_oil_E_cons_typ'
   and indexinst.sta_index_inst_id = dimeninst4.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst5
    on dimeninst5.dim_code = 'Custom_dimen_first'
   and indexinst.sta_index_inst_id = dimeninst5.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst6
    on dimeninst6.dim_code = 'Custom_dimen_second'
   and indexinst.sta_index_inst_id = dimeninst6.sta_index_inst_id
   
 where repinst.report_code = P_RPTCODE
   and repinst.org_id = P_RPTORGID
   and  indexinst.COMPOSITED_INDEX_CODE =P_RPTORGID
   and repinst.report_year = P_RPTYEAR
   and repinst.report_month <= P_RPTMONTH
 group by
          repinst.org_id,
          repinst.report_year,
          indexinst.index_code,
          indexinst.COMPOSITED_INDEX_CODE,
          dimeninst.dim_code,
          dimeninst.dim_detail_code,
          dimeninst2.dim_code,
          dimeninst2.dim_detail_code,
          dimeninst3.dim_code,
          dimeninst3.dim_detail_code,
          dimeninst4.dim_code,
          dimeninst4.dim_detail_code,
          dimeninst5.dim_code,
          dimeninst5.dim_detail_code,
          dimeninst6.dim_code,
          dimeninst6.dim_detail_code
          ) BB
          ),
          AMT as
          (SELECT *
           FROM RES3 WHERE DIM_DETAIL_CODE IN (
          SELECT DIM_DETAIL_CODE FROM E7_STA_DIM_DETAIL 
                START WITH DIM_DETAIL_CODE = 'Chemical'
                CONNECT BY PARENT_DIM_DETAIL_CODE = PRIOR DIM_DETAIL_CODE
          )  AND DIM_DETAIL_CODE4 = 'Natural_gas' AND INDEX_CODE = 'Engy_csmp_amt_pratl' and index_value is not null) ,
          COST as
          (SELECT *
           FROM RES3 WHERE DIM_DETAIL_CODE IN (
          SELECT DIM_DETAIL_CODE FROM E7_STA_DIM_DETAIL 
                START WITH DIM_DETAIL_CODE = 'Chemical'
                CONNECT BY PARENT_DIM_DETAIL_CODE = PRIOR DIM_DETAIL_CODE
          )  AND DIM_DETAIL_CODE4 = 'Natural_gas' AND INDEX_CODE = 'Engy_csmp_cost'),
          natural_price as (
          select b.index_value/a.index_value as index_value from 
          (select sum(index_value) as index_value from amt) a,
          (select sum(index_value) as index_value from cost) b
          ),
          insert_col as (
          select 
          repinst_id,org_id,report_year,report_month,sta_index_inst_id||'I' as sta_index_inst_id,'Engy_csmp_cost' as index_code ,
          round( -1 * a.index_value * natural_price.index_value,5) as index_value,
          composited_index_code,dim_code,dim_detail_code,
          dim_code2,dim_detail_code2,
          dim_code3,dim_detail_code3,
          dim_code4,dim_detail_code4,
          dim_code5,dim_detail_code5,
          dim_code6,dim_detail_code6
           from amt a ,natural_price where dim_detail_code6 = 'Material_own_amount_N'),
           a as (select * from aa union all select * from insert_col),
          res as (
              select repinst_id,
              report_year,
              report_month,
              sta_index_inst_id,
              index_code,
              index_value,
              composited_index_code,
              dim_code,
              dim_detail_code,
              dim_code2,
              dim_detail_code2,
              dim_code3,
              dim_detail_code3,
              dim_code4,
              dim_detail_code4
              from a
              union all
              select repinst_id,
              report_year,
              report_month,
              sta_index_inst_id,
              index_code,
              index_value,
              composited_index_code,
              dim_code,
              dim_detail_code,

              dim_code2,
              dim_detail_code2,
              dim_code3,
              dim_detail_code3,
              dim_code5,
              dim_detail_code5
              from a
              union all
              select repinst_id,
              report_year,
              report_month,
              sta_index_inst_id,
              index_code,
              index_value,
              composited_index_code,
              dim_code,
              dim_detail_code,

              dim_code2,
              dim_detail_code2,
              dim_code3,
              dim_detail_code3,
              dim_code6,
              dim_detail_code6
              from a
                ),
                res1 as (
                select res.repinst_id,
                res.report_year,
                res.report_month,
                res.sta_index_inst_id,
                relation.index_code,
                res.index_value,
                res.composited_index_code,
                res.dim_code,
                res.dim_detail_code,
                res.dim_code2,
                res.dim_detail_code2,
                res.dim_code3,
                res.dim_detail_code3,
                relation.dim_code dim_code4,
                relation.dim_detail_code dim_detail_code4

                 from res
                 left join
                 (select * from e7_xn_dim_relation) relation
                on res.index_code||res.dim_code4||res.dim_detail_code4 = relation.xn_index_code||relation.xn_dim_code||relation.xn_dim_detail_code
               ),
               res2 as (

          select * from res1 where index_code is not null
          union all
          select distinct * from res where index_code = 'Engy_csmp_amt_stadc'
          ),
          resultt as (
          select rrss.*,stadc.param_value from (
          select t.*,nvl(detail.parent_dim_detail_code,t.dim_detail_code4) as org_dim_detail_code from (
          select
          max(a .repinst_id)  repinst_id,
          report_year,
          report_month,
          max(sta_index_inst_id) sta_index_inst_id,
          index_code,
          sum(index_value) index_value,
          composited_index_code,
          report_code,
          dim_code,
          dim_detail_code,
          dim_code2,
          dim_detail_code2,
          dim_code3,
          dim_detail_code3,
          dim_code4,
          dim_detail_code4
           from (
          select  r.repinst_id,
          r.report_year,
          r.report_month,
          r.sta_index_inst_id,
          r.index_code,
          r.index_value,
          r.composited_index_code,
          linkxn.report_code,
          linkxn.dim_code,
          linkxn.dim_detail_code,
          r.dim_code2,
          r.dim_detail_code2,
          r.dim_code3,
          r.dim_detail_code3,
          r.dim_code4,
          r.dim_detail_code4
           from res2 r
           left join e7_business_link_xn linkxn
           on r.dim_detail_code = linkxn.business_type

           and linkxn.report_type = 'E'
           where r.index_code not in (
              'Fresh_water_consu_amt','Fresh_water_consu_cost'
           )
           ) a
           group by
          report_year,
          report_month,
          index_code,
          composited_index_code,
          report_code,
          dim_code,
          dim_detail_code,
          dim_code2,
          dim_detail_code2,
          dim_code3,
          dim_detail_code3,
          dim_code4,
          dim_detail_code4
           ) t
           left join e7_sta_dim_detail detail on t.dim_code4 = detail.dim_code
           and t.dim_detail_code4 = detail.dim_detail_code

           ) rrss left join (
                select dim_detail_code,param_value from e7_sta_base_param where dim_code = 'Orig_energy_type'and param_type_code = '02' and dim_detail_code in (
                  select dim_detail_code from e7_sta_rep_index_dimen where report_code = 'XNNW01' and dim_code = 'Cru_oil_E_cons_typ'
                  ) and org_id = 1
           ) stadc on rrss.org_dim_detail_code = stadc.dim_detail_code
           and rrss.index_code = 'Engy_csmp_amt_pratl'
           ),
           results as (
           SELECT 
            repinst_id,
            report_year,
            report_month,
            sta_index_inst_id,
            index_code,
            index_value,
            composited_index_code,
            report_code,
            cc.dim_code,cc.dim_detail_code,
            dim_code2,dim_detail_code2,
            dim_code3,dim_detail_code3,
            dim_code4,
            decode(index_code,'Stadc_coef',nvl(dd.parent_dim_detail_code,dim_detail_code4),dim_detail_code4) as dim_detail_code4,
            dimen_orderno
           FROM (
           SELECT aa.*,bb.dimen_orderno FROM (
           SELECT * FROM (
           select repinst_id,
           report_year,
           report_month,
           sta_index_inst_id||'ST' as sta_index_inst_id,
           'Stadc_coef' as index_code,
           param_value as index_value,
           composited_index_code,
           report_code,
           dim_code,
           dim_detail_code,
           dim_code2,
           dim_detail_code2,
           dim_code3,
           dim_detail_code3,
           dim_code4,
           dim_detail_code4 
            from resultt where param_value is not null
            union all
            select repinst_id,
            report_year,
            report_month,
            sta_index_inst_id,
            index_code,
            index_value,
            composited_index_code,
            report_code,dim_code,
           dim_detail_code,
           dim_code2,
           dim_detail_code2,
           dim_code3,
           dim_detail_code3,
           dim_code4,
           dim_detail_code4
           
           from resultt) WHERE  REPORT_CODE IS NOT NULL 
           ) aa,
           (select * from e7_sta_rep_index_dimen where report_code = 'C0002' and index_code = 'Engy_csmp_amt_pratl' and dim_code = 'Cru_oil_E_cons_typ') bb
           where aa.dim_detail_code4 = bb.dim_detail_code
           order by aa.dim_detail_code,bb.dimen_orderno
           ) cc 
           left join 
           (select * from e7_sta_dim_detail where dim_detail_code in (
           select dim_detail_code from e7_sta_rep_index_dimen where report_code = 'C0002' and dim_code = 'Cru_oil_E_cons_typ'
           ) and dim_code = 'Cru_oil_E_cons_typ' ) dd
          on cc.dim_detail_code4 = dd.dim_detail_code
           where report_code in( select report_code from e7_sta_rpt_auth where org_id = P_RPTORGID)
            )
          SELECT DISTINCT
          --||P_RPTORGID||P_RPTYEAR||P_RPTMONTH
        REPLACE(STA_INDEX_INST_ID,'XNNW',REPORT_CODE)||composited_index_code as STA_INDEX_INST_ID,
        INDEX_CODE,
        COMPOSITED_INDEX_CODE AS ORG_ID,
        REPORT_YEAR,
        to_char(to_date(REPORT_YEAR||lpad(REPORT_MONTH,2,0),'yyyyMM'), 'Q') as report_quarter,
        REPORT_MONTH,
        3 AS REPORT_FREQUENT_CODE,
        INDEX_VALUE,
        NULL AS UNIT_CODE,
        NULL AS REMARK,
        row_number() over(partition by index_code order by report_code,dim_detail_code,dim_detail_code2,dim_detail_code3,dimen_orderno) AS INDEX_INST_ORDERNO,
        NULL AS COMPOSITED_INDEX_CODE,
        SYSDATE AS CREATE_TIME,
        SYSDATE AS UPDATE_TIME
        FROM (select 
        repinst_id,
        report_year,
        report_month,
        sta_index_inst_id,
        index_code,
        index_value,
        composited_index_code,
        report_code,
        dim_detail_code,
        dim_code2,
        dim_detail_code2,
        dim_code3,
        dim_detail_code3,
        decode(report_code,'C0045',decode(dim_detail_code4,'Since_the_amo_N','Natural_gas','Los_quaity_N','Natural_gas',dim_detail_code4),
           'C0105',decode(dim_detail_code4,'Since_the_amo_N','Natural_gas','Los_quaity_N','Natural_gas',dim_detail_code4),
           'C0115',decode(dim_detail_code4,'Since_the_amo_N','Natural_gas','Los_quaity_N','Natural_gas',dim_detail_code4),dim_detail_code4) dim_detail_code4,
           dimen_orderno
         from RESULTS
          
          )

        );

        CURSOR E_STAINDEXINSTDIMEN IS SELECT * FROM (with aa as (
SELECT AA.REPINST_ID,
BB.*
 FROM 
(SELECT REPINST_ID FROM E7_STA_REPINST WHERE ORG_ID = P_RPTORGID AND REPORT_CODE =P_RPTCODE AND REPORT_YEAR = P_RPTYEAR AND REPORT_MONTH = P_RPTMONTH) AA,
(
select 
       repinst.org_id,
       repinst.report_year,
       P_RPTMONTH AS report_month,
       MAX(indexinst.sta_index_inst_id) STA_INDEX_INST_ID,
       indexinst.index_code,
       sum(indexinst.index_value) index_value,
       indexinst.COMPOSITED_INDEX_CODE,
       dimeninst.dim_code              as dim_code,
       dimeninst.dim_detail_code       as dim_detail_code,
       dimeninst2.dim_code             as dim_code2,
       dimeninst2.dim_detail_code      as dim_detail_code2,
       dimeninst3.dim_code             as dim_code3,
       dimeninst3.dim_detail_code      as dim_detail_code3,
       dimeninst4.dim_code             as dim_code4,
       dimeninst4.dim_detail_code      as dim_detail_code4,
       dimeninst5.dim_code             as dim_code5,
       dimeninst5.dim_detail_code      as dim_detail_code5,
       dimeninst6.dim_code             as dim_code6,
       dimeninst6.dim_detail_code      as dim_detail_code6
  from e7_sta_repinst repinst
  left join e7_sta_rpt_index_inst rptindexinst
    on repinst.repinst_id = rptindexinst.repinst_id
  left join e7_sta_index_inst indexinst
    on rptindexinst.sta_index_inst_id = indexinst.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst
    on dimeninst.dim_code = 'Business_type'
   and indexinst.sta_index_inst_id = dimeninst.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst2
    on dimeninst2.dim_code = 'Assets_type'
   and indexinst.sta_index_inst_id = dimeninst2.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst3
    on dimeninst3.dim_code = 'Industry_type'
   and indexinst.sta_index_inst_id = dimeninst3.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst4
    on dimeninst4.dim_code = 'Cru_oil_E_cons_typ'
   and indexinst.sta_index_inst_id = dimeninst4.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst5
    on dimeninst5.dim_code = 'Custom_dimen_first'
   and indexinst.sta_index_inst_id = dimeninst5.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst6
    on dimeninst6.dim_code = 'Custom_dimen_second'
   and indexinst.sta_index_inst_id = dimeninst6.sta_index_inst_id
   
 where repinst.report_code = P_RPTCODE
   and repinst.org_id = P_RPTORGID
   and  indexinst.COMPOSITED_INDEX_CODE =P_RPTORGID
   and repinst.report_year = P_RPTYEAR
   and repinst.report_month <= P_RPTMONTH
 group by
          repinst.org_id,
          repinst.report_year,
          indexinst.index_code,
          indexinst.COMPOSITED_INDEX_CODE,
          dimeninst.dim_code,
          dimeninst.dim_detail_code,
          dimeninst2.dim_code,
          dimeninst2.dim_detail_code,
          dimeninst3.dim_code,
          dimeninst3.dim_detail_code,
          dimeninst4.dim_code,
          dimeninst4.dim_detail_code,
          dimeninst5.dim_code,
          dimeninst5.dim_detail_code,
          dimeninst6.dim_code,
          dimeninst6.dim_detail_code
          ) BB
          where dim_detail_code6 != 'Material_own_amount_N' OR dim_detail_code6 IS NULL
          ),
          RES3 AS (
        
SELECT AA.REPINST_ID,
BB.*
 FROM 
(SELECT REPINST_ID FROM E7_STA_REPINST WHERE ORG_ID = P_RPTORGID AND REPORT_CODE =P_RPTCODE AND REPORT_YEAR = P_RPTYEAR AND REPORT_MONTH = P_RPTMONTH) AA,
(
select 
       repinst.org_id,
       repinst.report_year,
       P_RPTMONTH AS report_month,
       MAX(indexinst.sta_index_inst_id) STA_INDEX_INST_ID,
       indexinst.index_code,
       sum(indexinst.index_value) index_value,
       indexinst.COMPOSITED_INDEX_CODE,
       dimeninst.dim_code              as dim_code,
       dimeninst.dim_detail_code       as dim_detail_code,
       dimeninst2.dim_code             as dim_code2,
       dimeninst2.dim_detail_code      as dim_detail_code2,
       dimeninst3.dim_code             as dim_code3,
       dimeninst3.dim_detail_code      as dim_detail_code3,
       dimeninst4.dim_code             as dim_code4,
       dimeninst4.dim_detail_code      as dim_detail_code4,
       dimeninst5.dim_code             as dim_code5,
       dimeninst5.dim_detail_code      as dim_detail_code5,
       dimeninst6.dim_code             as dim_code6,
       dimeninst6.dim_detail_code      as dim_detail_code6
  from e7_sta_repinst repinst
  left join e7_sta_rpt_index_inst rptindexinst
    on repinst.repinst_id = rptindexinst.repinst_id
  left join e7_sta_index_inst indexinst
    on rptindexinst.sta_index_inst_id = indexinst.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst
    on dimeninst.dim_code = 'Business_type'
   and indexinst.sta_index_inst_id = dimeninst.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst2
    on dimeninst2.dim_code = 'Assets_type'
   and indexinst.sta_index_inst_id = dimeninst2.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst3
    on dimeninst3.dim_code = 'Industry_type'
   and indexinst.sta_index_inst_id = dimeninst3.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst4
    on dimeninst4.dim_code = 'Cru_oil_E_cons_typ'
   and indexinst.sta_index_inst_id = dimeninst4.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst5
    on dimeninst5.dim_code = 'Custom_dimen_first'
   and indexinst.sta_index_inst_id = dimeninst5.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst6
    on dimeninst6.dim_code = 'Custom_dimen_second'
   and indexinst.sta_index_inst_id = dimeninst6.sta_index_inst_id
   
 where repinst.report_code = P_RPTCODE
   and repinst.org_id = P_RPTORGID
   and  indexinst.COMPOSITED_INDEX_CODE =P_RPTORGID
   and repinst.report_year = P_RPTYEAR
   and repinst.report_month <= P_RPTMONTH
 group by
          repinst.org_id,
          repinst.report_year,
          indexinst.index_code,
          indexinst.COMPOSITED_INDEX_CODE,
          dimeninst.dim_code,
          dimeninst.dim_detail_code,
          dimeninst2.dim_code,
          dimeninst2.dim_detail_code,
          dimeninst3.dim_code,
          dimeninst3.dim_detail_code,
          dimeninst4.dim_code,
          dimeninst4.dim_detail_code,
          dimeninst5.dim_code,
          dimeninst5.dim_detail_code,
          dimeninst6.dim_code,
          dimeninst6.dim_detail_code
          ) BB
          ),
          AMT as
          (SELECT *
           FROM RES3 WHERE DIM_DETAIL_CODE IN (
          SELECT DIM_DETAIL_CODE FROM E7_STA_DIM_DETAIL 
                START WITH DIM_DETAIL_CODE = 'Chemical'
                CONNECT BY PARENT_DIM_DETAIL_CODE = PRIOR DIM_DETAIL_CODE
          )  AND DIM_DETAIL_CODE4 = 'Natural_gas' AND INDEX_CODE = 'Engy_csmp_amt_pratl' and index_value is not null) ,
          COST as
          (SELECT *
           FROM RES3 WHERE DIM_DETAIL_CODE IN (
          SELECT DIM_DETAIL_CODE FROM E7_STA_DIM_DETAIL 
                START WITH DIM_DETAIL_CODE = 'Chemical'
                CONNECT BY PARENT_DIM_DETAIL_CODE = PRIOR DIM_DETAIL_CODE
          )  AND DIM_DETAIL_CODE4 = 'Natural_gas' AND INDEX_CODE = 'Engy_csmp_cost'),
          natural_price as (
          select b.index_value/a.index_value as index_value from 
          (select sum(index_value) as index_value from amt) a,
          (select sum(index_value) as index_value from cost) b
          ),
          insert_col as (
          select 
          repinst_id,org_id,report_year,report_month,sta_index_inst_id||'I' as sta_index_inst_id,'Engy_csmp_cost' as index_code ,
          round( -1 * a.index_value * natural_price.index_value,5) as index_value,
          composited_index_code,dim_code,dim_detail_code,
          dim_code2,dim_detail_code2,
          dim_code3,dim_detail_code3,
          dim_code4,dim_detail_code4,
          dim_code5,dim_detail_code5,
          dim_code6,dim_detail_code6
           from amt a ,natural_price where dim_detail_code6 = 'Material_own_amount_N'),
           a as (select * from aa union all select * from insert_col),
          res as (
              select repinst_id,
              report_year,
              report_month,
              sta_index_inst_id,
              index_code,
              index_value,
              composited_index_code,
              dim_code,
              dim_detail_code,
              dim_code2,
              dim_detail_code2,
              dim_code3,
              dim_detail_code3,
              dim_code4,
              dim_detail_code4
              from a
              union all
              select repinst_id,
              report_year,
              report_month,
              sta_index_inst_id,
              index_code,
              index_value,
              composited_index_code,
              dim_code,
              dim_detail_code,

              dim_code2,
              dim_detail_code2,
              dim_code3,
              dim_detail_code3,
              dim_code5,
              dim_detail_code5
              from a
              union all
              select repinst_id,
              report_year,
              report_month,
              sta_index_inst_id,
              index_code,
              index_value,
              composited_index_code,
              dim_code,
              dim_detail_code,

              dim_code2,
              dim_detail_code2,
              dim_code3,
              dim_detail_code3,
              dim_code6,
              dim_detail_code6
              from a
                ),
                res1 as (
                select res.repinst_id,
                res.report_year,
                res.report_month,
                res.sta_index_inst_id,
                relation.index_code,
                res.index_value,
                res.composited_index_code,
                res.dim_code,
                res.dim_detail_code,
                res.dim_code2,
                res.dim_detail_code2,
                res.dim_code3,
                res.dim_detail_code3,
                relation.dim_code dim_code4,
                relation.dim_detail_code dim_detail_code4

                 from res
                 left join
                 (select * from e7_xn_dim_relation) relation
                on res.index_code||res.dim_code4||res.dim_detail_code4 = relation.xn_index_code||relation.xn_dim_code||relation.xn_dim_detail_code
               ),
               res2 as (

          select * from res1 where index_code is not null
          union all
          select distinct * from res where index_code = 'Engy_csmp_amt_stadc'
          ),
          resultt as (
          select rrss.*,stadc.param_value from (
          select t.*,nvl(detail.parent_dim_detail_code,t.dim_detail_code4) as org_dim_detail_code from (
          select
          max(a .repinst_id)  repinst_id,
          report_year,
          report_month,
          max(sta_index_inst_id) sta_index_inst_id,
          index_code,
          sum(index_value) index_value,
          composited_index_code,
          report_code,
          dim_code,
          dim_detail_code,
          dim_code2,
          dim_detail_code2,
          dim_code3,
          dim_detail_code3,
          dim_code4,
          dim_detail_code4
           from (
          select  r.repinst_id,
          r.report_year,
          r.report_month,
          r.sta_index_inst_id,
          r.index_code,
          r.index_value,
          r.composited_index_code,
          linkxn.report_code,
          linkxn.dim_code,
          linkxn.dim_detail_code,
          r.dim_code2,
          r.dim_detail_code2,
          r.dim_code3,
          r.dim_detail_code3,
          r.dim_code4,
          r.dim_detail_code4
           from res2 r
           left join e7_business_link_xn linkxn
           on r.dim_detail_code = linkxn.business_type

           and linkxn.report_type = 'E'
           where r.index_code not in (
              'Fresh_water_consu_amt','Fresh_water_consu_cost'
           )
           ) a
           group by
          report_year,
          report_month,
          index_code,
          composited_index_code,
          report_code,
          dim_code,
          dim_detail_code,
          dim_code2,
          dim_detail_code2,
          dim_code3,
          dim_detail_code3,
          dim_code4,
          dim_detail_code4
           ) t
           left join e7_sta_dim_detail detail on t.dim_code4 = detail.dim_code
           and t.dim_detail_code4 = detail.dim_detail_code

           ) rrss left join (
                select dim_detail_code,param_value from e7_sta_base_param where dim_code = 'Orig_energy_type'and param_type_code = '02' and dim_detail_code in (
                  select dim_detail_code from e7_sta_rep_index_dimen where report_code = 'XNNW01' and dim_code = 'Cru_oil_E_cons_typ'
                  ) and org_id = 1
           ) stadc on rrss.org_dim_detail_code = stadc.dim_detail_code
           and rrss.index_code = 'Engy_csmp_amt_pratl'
           ),
           results as (
           SELECT 
            repinst_id,
            report_year,
            report_month,
            sta_index_inst_id,
            index_code,
            index_value,
            composited_index_code,
            report_code,
            cc.dim_code,cc.dim_detail_code,
            dim_code2,dim_detail_code2,
            dim_code3,dim_detail_code3,
            dim_code4,
            decode(index_code,'Stadc_coef',nvl(dd.parent_dim_detail_code,dim_detail_code4),dim_detail_code4) as dim_detail_code4,
            dimen_orderno
           FROM (
           SELECT aa.*,bb.dimen_orderno FROM (
           SELECT * FROM (
           select repinst_id,
           report_year,
           report_month,
           sta_index_inst_id||'ST' as sta_index_inst_id,
           'Stadc_coef' as index_code,
           param_value as index_value,
           composited_index_code,
           report_code,
           dim_code,
           dim_detail_code,
           dim_code2,
           dim_detail_code2,
           dim_code3,
           dim_detail_code3,
           dim_code4,
           dim_detail_code4 
            from resultt where param_value is not null
            union all
            select repinst_id,
            report_year,
            report_month,
            sta_index_inst_id,
            index_code,
            index_value,
            composited_index_code,
            report_code,dim_code,
           dim_detail_code,
           dim_code2,
           dim_detail_code2,
           dim_code3,
           dim_detail_code3,
           dim_code4,
           dim_detail_code4
           
           from resultt) WHERE  REPORT_CODE IS NOT NULL  

           ) aa,
           (select * from e7_sta_rep_index_dimen where report_code = 'C0002' and index_code = 'Engy_csmp_amt_pratl' and dim_code = 'Cru_oil_E_cons_typ') bb
           where aa.dim_detail_code4 = bb.dim_detail_code
           order by aa.dim_detail_code,bb.dimen_orderno
           ) cc 
           left join 
           (select * from e7_sta_dim_detail where dim_detail_code in (
           select dim_detail_code from e7_sta_rep_index_dimen where report_code = 'C0002' and dim_code = 'Cru_oil_E_cons_typ'
           ) and dim_code = 'Cru_oil_E_cons_typ' ) dd
          on cc.dim_detail_code4 = dd.dim_detail_code
           where report_code in( select report_code from e7_sta_rpt_auth where org_id = P_RPTORGID)
            ),
           DIMENS AS (
         SELECT DISTINCT * FROM (
            SELECT
            --||P_RPTORGID||P_RPTYEAR||P_RPTMONTH||
        REPLACE(STA_INDEX_INST_ID,'XNNW',REPORT_CODE)||composited_index_code||'D1' as REPINST_DTL_DIMEN,
        REPLACE(STA_INDEX_INST_ID,'XNNW',REPORT_CODE)||composited_index_code as STA_INDEX_INST_ID,
        DIM_CODE,
        DIM_DETAIL_CODE,
        NULL DIM_SOURCE,
        NULL dim_deteail_id,
        NULL dim_deteail_id2,
        NULL AS UNIT_CODE,
        null AS COMPOSITE_DIM_CODE,
        SYSDATE AS CREATE_TIME,
        SYSDATE AS UPDATE_TIME
         FROM (
         SELECT R.*,D.PARENT_DIM_DETAIL_CODE FROM RESULTS R
         LEFT JOIN E7_STA_DIM_DETAIL D
        ON R.DIM_CODE4 = D.DIM_CODE
        AND R.DIM_DETAIL_CODE4 = D.DIM_DETAIL_CODE )
        UNION ALL
        SELECT
        REPLACE(STA_INDEX_INST_ID,'XNNW',REPORT_CODE)||composited_index_code||'D2' as REPINST_DTL_DIMEN,
        REPLACE(STA_INDEX_INST_ID,'XNNW',REPORT_CODE)||composited_index_code as STA_INDEX_INST_ID,
        DIM_CODE2,
        DIM_DETAIL_CODE2,
        NULL DIM_SOURCE,
        NULL dim_deteail_id,
        NULL dim_deteail_id2,
        NULL AS UNIT_CODE,
        null AS COMPOSITE_DIM_CODE,
        SYSDATE AS CREATE_TIME,
        SYSDATE AS UPDATE_TIME
         FROM (
         SELECT R.*,D.PARENT_DIM_DETAIL_CODE FROM RESULTS R
         LEFT JOIN E7_STA_DIM_DETAIL D
        ON R.DIM_CODE4 = D.DIM_CODE
        AND R.DIM_DETAIL_CODE4 = D.DIM_DETAIL_CODE )
        UNION ALL
        SELECT
        REPLACE(STA_INDEX_INST_ID,'XNNW',REPORT_CODE)||composited_index_code||'D3' as REPINST_DTL_DIMEN,
        REPLACE(STA_INDEX_INST_ID,'XNNW',REPORT_CODE)||composited_index_code as STA_INDEX_INST_ID,
        DIM_CODE3,
        DIM_DETAIL_CODE3,
        NULL DIM_SOURCE,
        NULL dim_deteail_id,
        NULL dim_deteail_id2,
        NULL AS UNIT_CODE,
        null AS COMPOSITE_DIM_CODE,
        SYSDATE AS CREATE_TIME,
        SYSDATE AS UPDATE_TIME
         FROM (
         SELECT R.*,D.PARENT_DIM_DETAIL_CODE FROM RESULTS R
         LEFT JOIN E7_STA_DIM_DETAIL D
        ON R.DIM_CODE4 = D.DIM_CODE
        AND R.DIM_DETAIL_CODE4 = D.DIM_DETAIL_CODE )
        UNION ALL
        SELECT
        REPLACE(STA_INDEX_INST_ID,'XNNW',REPORT_CODE)||composited_index_code||'D4' as REPINST_DTL_DIMEN,
        REPLACE(STA_INDEX_INST_ID,'XNNW',REPORT_CODE)||composited_index_code as STA_INDEX_INST_ID,
        DIM_CODE4,
        decode(report_code,'C0045',decode(dim_detail_code4,'Since_the_amo_N','Natural_gas','Los_quaity_N','Natural_gas',dim_detail_code4),
           'C0105',decode(dim_detail_code4,'Since_the_amo_N','Natural_gas','Los_quaity_N','Natural_gas',dim_detail_code4),
           'C0115',decode(dim_detail_code4,'Since_the_amo_N','Natural_gas','Los_quaity_N','Natural_gas',dim_detail_code4),dim_detail_code4) dim_detail_code4,
        NULL DIM_SOURCE,
        NULL dim_deteail_id,
        NULL dim_deteail_id2,
        NULL AS UNIT_CODE,
        null AS COMPOSITE_DIM_CODE,
        SYSDATE AS CREATE_TIME,
        SYSDATE AS UPDATE_TIME
         FROM (
         SELECT R.*,D.PARENT_DIM_DETAIL_CODE FROM RESULTS R
         LEFT JOIN E7_STA_DIM_DETAIL D
        ON R.DIM_CODE4 = D.DIM_CODE
        AND R.DIM_DETAIL_CODE4 = D.DIM_DETAIL_CODE )
        )),
        DIMENS_PART AS (
             SELECT  REPLACE(D.REPINST_DTL_DIMEN,'D','P') AS REPINST_DTL_DIMEN,D.STA_INDEX_INST_ID,D.DIM_CODE,D1.PARENT_DIM_DETAIL_CODE AS DIM_DETAIL_CODE,D.DIM_SOURCE,D.dim_deteail_id,D.dim_deteail_id2,D.UNIT_CODE,D.DIM_DETAIL_CODE AS composite_dim_code,D.CREATE_TIME,D.UPDATE_TIME FROM DIMENS D
             LEFT JOIN E7_STA_DIM_DETAIL D1 ON D.DIM_DETAIL_CODE = D1.DIM_DETAIL_CODE AND D.DIM_CODE = D1.DIM_CODE
              WHERE D.DIM_CODE = 'Cru_oil_E_cons_typ' AND D.DIM_DETAIL_CODE IN ('Since_the_amo_N','Los_quaity_N','Etp_exter_pur_qua_E')
        )
        SELECT * FROM DIMENS_PART UNION ALL SELECT * FROM DIMENS);
        

        V_STAREPINST E7_STA_REPINST%ROWTYPE;
        V_STARPTINDEXINST E7_STA_RPT_INDEX_INST%ROWTYPE;
        V_STAINDEXINST E7_STA_INDEX_INST%ROWTYPE;
        V_STAINDEXINSTDIMEN E7_STA_INDEX_INST_DIMEN%ROWTYPE;
           --E7_STA_REPINST
           BEGIN
           DATATransXNNWDELETE(P_RPTCODE,P_RPTYEAR,P_RPTMONTH,P_RPTORGID);
             FOR VSTAREPINST IN E_STAREPINST LOOP
                V_STAREPINST.repinst_id           := VSTAREPINST.repinst_id           ;
                V_STAREPINST.org_id               := VSTAREPINST.org_id               ;
                V_STAREPINST.report_code          := VSTAREPINST.report_code          ;
                V_STAREPINST.report_year          := VSTAREPINST.report_year          ;
                V_STAREPINST.report_quarter       := VSTAREPINST.report_quarter       ;
                V_STAREPINST.report_month         := VSTAREPINST.report_month         ;
                V_STAREPINST.report_frequent_code := VSTAREPINST.report_frequent_code ;
                V_STAREPINST.status               := VSTAREPINST.status               ;
                V_STAREPINST.writer               := VSTAREPINST.writer               ;
                V_STAREPINST.write_date           := VSTAREPINST.write_date           ;
                V_STAREPINST.checker              := VSTAREPINST.checker              ;
                V_STAREPINST.check_date           := VSTAREPINST.check_date           ;
                V_STAREPINST.condition            := VSTAREPINST.condition            ;
                V_STAREPINST.verify_note          := VSTAREPINST.verify_note          ;
                V_STAREPINST.create_user_id       := VSTAREPINST.create_user_id       ;
                V_STAREPINST.create_user_name     := VSTAREPINST.create_user_name     ;
                V_STAREPINST.create_time          := VSTAREPINST.create_time          ;
                V_STAREPINST.update_user_id       := VSTAREPINST.update_user_id       ;
                V_STAREPINST.update_user_name     := VSTAREPINST.update_user_name     ;
                V_STAREPINST.update_time          := VSTAREPINST.update_time          ;
                INSERT INTO E7_STA_REPINST VALUES V_STAREPINST;
                COMMIT;
             END LOOP;
             --E7_STA_RPT_INDEX_INST
             FOR VSTARPTINDEXINST IN E_STARPTINDEXINST LOOP
                V_STARPTINDEXINST.repinst_id       :=VSTARPTINDEXINST.repinst_id       ;
                V_STARPTINDEXINST.sta_index_inst_id:=VSTARPTINDEXINST.sta_index_inst_id||P_RPTMONTH;
                V_STARPTINDEXINST.create_time      :=VSTARPTINDEXINST.create_time      ;
                V_STARPTINDEXINST.update_time      :=VSTARPTINDEXINST.update_time      ;
               INSERT INTO E7_STA_RPT_INDEX_INST VALUES V_STARPTINDEXINST;
               COMMIT;
              END LOOP;
              --E7_STA_INDEX_INST
              FOR VSTAINDEXINST IN E_STAINDEXINST LOOP
                V_STAINDEXINST.sta_index_inst_id     := VSTAINDEXINST.sta_index_inst_id||P_RPTMONTH    ;
                V_STAINDEXINST.index_code            := VSTAINDEXINST.index_code           ;
                V_STAINDEXINST.org_id                := VSTAINDEXINST.org_id               ;
                V_STAINDEXINST.report_year           := VSTAINDEXINST.report_year          ;
                V_STAINDEXINST.report_quarter        := VSTAINDEXINST.report_quarter       ;
                V_STAINDEXINST.report_month          := VSTAINDEXINST.report_month         ;
                V_STAINDEXINST.report_frequent_code  := VSTAINDEXINST.report_frequent_code ;
                V_STAINDEXINST.index_value           := VSTAINDEXINST.index_value          ;
                V_STAINDEXINST.unit_code             := VSTAINDEXINST.unit_code            ;
                V_STAINDEXINST.remark                := VSTAINDEXINST.remark               ;
                V_STAINDEXINST.index_inst_orderno    := VSTAINDEXINST.index_inst_orderno   ;
                V_STAINDEXINST.composited_index_code := VSTAINDEXINST.composited_index_code;
                V_STAINDEXINST.create_time           := VSTAINDEXINST.create_time          ;
                V_STAINDEXINST.update_time           := VSTAINDEXINST.update_time          ;

              INSERT INTO E7_STA_INDEX_INST VALUES V_STAINDEXINST;
              COMMIT;
              END LOOP;
              --E7_STA_INDEX_INST_DIMEN
              FOR VSTAINDEXINSTDIMEN IN E_STAINDEXINSTDIMEN LOOP
                V_STAINDEXINSTDIMEN.repinst_dtl_dimen  :=VSTAINDEXINSTDIMEN.repinst_dtl_dimen||P_RPTMONTH ;
                V_STAINDEXINSTDIMEN.sta_index_inst_id  :=VSTAINDEXINSTDIMEN.sta_index_inst_id||P_RPTMONTH ;
                V_STAINDEXINSTDIMEN.dim_code           :=VSTAINDEXINSTDIMEN.dim_code          ;
                V_STAINDEXINSTDIMEN.dim_detail_code    :=VSTAINDEXINSTDIMEN.dim_detail_code   ;
                V_STAINDEXINSTDIMEN.dim_source         :=VSTAINDEXINSTDIMEN.dim_source        ;
                V_STAINDEXINSTDIMEN.dim_deteail_id     :=VSTAINDEXINSTDIMEN.dim_deteail_id    ;
                V_STAINDEXINSTDIMEN.dim_deteail_id2    :=VSTAINDEXINSTDIMEN.dim_deteail_id2   ;
                V_STAINDEXINSTDIMEN.unit_code          :=VSTAINDEXINSTDIMEN.unit_code         ;
                V_STAINDEXINSTDIMEN.composite_dim_code :=VSTAINDEXINSTDIMEN.composite_dim_code;
                V_STAINDEXINSTDIMEN.create_time        :=VSTAINDEXINSTDIMEN.create_time       ;
                V_STAINDEXINSTDIMEN.update_time        :=VSTAINDEXINSTDIMEN.update_time       ;
              INSERT INTO E7_STA_INDEX_INST_DIMEN VALUES V_STAINDEXINSTDIMEN;
              COMMIT;
              END LOOP;
              EXCEPTION WHEN OTHERS THEN
                DBMS_OUTPUT.put_line(SQLERRM);
                ROLLBACK;

             END;



            --XNNW台帐能耗数据转换功能
 PROCEDURE DATATransXNNWSW(P_RPTCODE  IN VARCHAR2,
                     P_RPTYEAR  IN VARCHAR2,
                     P_RPTMONTH IN VARCHAR2,
                     P_RPTORGID IN VARCHAR2,
                     P_RPTUSERID in VARCHAR2,
                     P_RPTUSERNAME IN VARCHAR2
                     ) AS

CURSOR E_STAREPINST IS SELECT * FROM  (with a as (
SELECT AA.REPINST_ID,
BB.*
 FROM 
(SELECT REPINST_ID FROM E7_STA_REPINST WHERE ORG_ID = P_RPTORGID AND REPORT_CODE =P_RPTCODE AND REPORT_YEAR = P_RPTYEAR AND REPORT_MONTH = P_RPTMONTH) AA,
(
select 
       repinst.org_id,
       repinst.report_year,
       P_RPTMONTH AS report_month,
       MAX(indexinst.sta_index_inst_id) STA_INDEX_INST_ID,
       indexinst.index_code,
       sum(indexinst.index_value) index_value,
       indexinst.COMPOSITED_INDEX_CODE,
       dimeninst.dim_code              as dim_code,
       dimeninst.dim_detail_code       as dim_detail_code,
       dimeninst2.dim_code             as dim_code2,
       dimeninst2.dim_detail_code      as dim_detail_code2,
       dimeninst3.dim_code             as dim_code3,
       dimeninst3.dim_detail_code      as dim_detail_code3,
       dimeninst4.dim_code             as dim_code4,
       dimeninst4.dim_detail_code      as dim_detail_code4,
       dimeninst5.dim_code             as dim_code5,
       dimeninst5.dim_detail_code      as dim_detail_code5,
       dimeninst6.dim_code             as dim_code6,
       dimeninst6.dim_detail_code      as dim_detail_code6
  from e7_sta_repinst repinst
  left join e7_sta_rpt_index_inst rptindexinst
    on repinst.repinst_id = rptindexinst.repinst_id
  left join e7_sta_index_inst indexinst
    on rptindexinst.sta_index_inst_id = indexinst.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst
    on dimeninst.dim_code = 'Business_type'
   and indexinst.sta_index_inst_id = dimeninst.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst2
    on dimeninst2.dim_code = 'Assets_type'
   and indexinst.sta_index_inst_id = dimeninst2.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst3
    on dimeninst3.dim_code = 'Industry_type'
   and indexinst.sta_index_inst_id = dimeninst3.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst4
    on dimeninst4.dim_code = 'Cru_oil_E_cons_typ'
   and indexinst.sta_index_inst_id = dimeninst4.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst5
    on dimeninst5.dim_code = 'Custom_dimen_first'
   and indexinst.sta_index_inst_id = dimeninst5.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst6
    on dimeninst6.dim_code = 'Custom_dimen_second'
   and indexinst.sta_index_inst_id = dimeninst6.sta_index_inst_id
 where repinst.report_code = P_RPTCODE
   and repinst.org_id = P_RPTORGID
   and  indexinst.COMPOSITED_INDEX_CODE =P_RPTORGID
   and repinst.report_year = P_RPTYEAR
   and repinst.report_month <= P_RPTMONTH
 group by
          repinst.org_id,
          repinst.report_year,
          indexinst.index_code,
          indexinst.COMPOSITED_INDEX_CODE,
          dimeninst.dim_code,
          dimeninst.dim_detail_code,
          dimeninst2.dim_code,
          dimeninst2.dim_detail_code,
          dimeninst3.dim_code,
          dimeninst3.dim_detail_code,
          dimeninst4.dim_code,
          dimeninst4.dim_detail_code,
          dimeninst5.dim_code,
          dimeninst5.dim_detail_code,
          dimeninst6.dim_code,
          dimeninst6.dim_detail_code
          ) BB
          ),
          res as (
              select repinst_id,
              report_year,
              report_month,
              sta_index_inst_id,
              index_code,
              index_value,
              composited_index_code,
              dim_code,
              dim_detail_code,
              dim_code2,
              dim_detail_code2,
              dim_code3,
              dim_detail_code3,
              dim_code4,
              dim_detail_code4
              from a
              union all
              select repinst_id,
              report_year,
              report_month,
              sta_index_inst_id,
              index_code,
              index_value,
              composited_index_code,
              dim_code,
              dim_detail_code,

              dim_code2,
              dim_detail_code2,
              dim_code3,
              dim_detail_code3,
              dim_code5,
              dim_detail_code5
              from a
              union all
              select repinst_id,
              report_year,
              report_month,
              sta_index_inst_id,
              index_code,
              index_value,
              composited_index_code,
              dim_code,
              dim_detail_code,

              dim_code2,
              dim_detail_code2,
              dim_code3,
              dim_detail_code3,
              dim_code6,
              dim_detail_code6
              from a
                ),
                res1 as (
                select res.repinst_id,
                res.report_year,
                res.report_month,
                res.sta_index_inst_id,
                relation.index_code,
                res.index_value,
                res.composited_index_code,
                res.dim_code,
                res.dim_detail_code,
                res.dim_code2,
                res.dim_detail_code2,
                res.dim_code3,
                res.dim_detail_code3,
                relation.dim_code dim_code4,
                relation.dim_detail_code dim_detail_code4

                 from res
                 left join
                 (select * from e7_xn_dim_relation) relation
                on res.index_code||res.dim_code4||res.dim_detail_code4 = relation.xn_index_code||relation.xn_dim_code||relation.xn_dim_detail_code
               ),
               res2 as (

          select * from res1 where index_code is not null
         /* union all
          select distinct * from res where index_code = 'Engy_csmp_amt_stadc'*/
          ),
          results1 as (
         SELECT  row_number() over(partition by tt.report_code,tt.index_code order by tt.index_code,tt.dim_detail_code,tt.dim_detail_code2,tt.dim_detail_code3,tt.dim_detail_code4) rowr,tt.* FROM (
          select t.* from (
          select
          max(a .repinst_id)  repinst_id,
          report_year,
          report_month,
          max(sta_index_inst_id) sta_index_inst_id,
          index_code,
          sum(index_value) index_value,
          composited_index_code,
          report_code,
          dim_code,
          dim_detail_code,
          dim_code2,
          dim_detail_code2,
          dim_code3,
          dim_detail_code3,
          dim_code4,
          dim_detail_code4
           from (
          select  r.repinst_id,
          r.report_year,
          r.report_month,
          r.sta_index_inst_id,
          r.index_code,
          r.index_value,
          r.composited_index_code,
          linkxn.report_code,
          linkxn.dim_code,
          linkxn.dim_detail_code,
          r.dim_code2,
          r.dim_detail_code2,
          r.dim_code3,
          r.dim_detail_code3,
          r.dim_code4,
          r.dim_detail_code4
           from res2 r
           left join e7_business_link_xn linkxn
           on r.dim_detail_code = linkxn.business_type

           and linkxn.report_type = 'W'
           where r.index_code in (
               'Fresh_water_consu_amt','Fresh_water_consu_cost',
              'Recycled_water_amt','Recycled_water_cost','Steam_conden_reco_amt',
              'Steam_conden_reco_cost','Ind_wastew_gene_amt','Ind_wastew_treat_amt',
              'Ind_wastew_treat_cost','Ind_wastew_disch_amt','Ind_wastew_disch_cost',
              'Ind_wastew_rech_amt','Ind_wastew_rech_cost',
              'Ind_wastew_reu_amt','Ind_wastew_reu_cost'
           )
           ) a
           group by
          report_year,
          report_month,
          index_code,
          composited_index_code,
          report_code,
          dim_code,
          dim_detail_code,
          dim_code2,
          dim_detail_code2,
          dim_code3,
          dim_detail_code3,
          dim_code4,
          dim_detail_code4
          order by dim_code,dim_detail_code
           ) t) tt WHERE  REPORT_CODE IS NOT NULL
          
           and  report_code in( select report_code from e7_sta_rpt_auth where org_id = P_RPTORGID)
           ),
          results2 as (
           select dense_rank() over(order by t.rowr) rowr, 
           t.repinst_id,report_year,report_month,sta_index_inst_id,index_code,index_value,composited_index_code,
          report_code,
          dim_code,
          dim_detail_code,
          dim_code2,
          dim_detail_code2,
          dim_code3,
          dim_detail_code3,
          dim_code4,
          dim_detail_code4 from results1 t
           where t.index_value is not null),
           results_p1 as (
           select * from results2 a  where a.dim_detail_code4 is not null
            ),
           results_p2 as  
           (select c.index_orderno + dense_rank() over( order by b.dim_detail_code) as index_orderno,
            b.repinst_id,
            b.report_year,
            b.report_month,
            b.sta_index_inst_id,
            b.index_code,
            b.index_value,
            b.composited_index_code,
          b.report_code,
          b.dim_code,
          b.dim_detail_code,
          b.dim_code2,
          b.dim_detail_code2,
          b.dim_code3,
          b.dim_detail_code3,
          b.dim_code4,
          b.dim_detail_code4
            from results2 b 
           left join e7_sta_report_index c on b.index_code = c.index_code 
           where b.dim_detail_code4 is null and c.report_code = 'C0013'
           group by c.index_orderno,
           b.repinst_id,
            b.report_year,
            b.report_month,
            b.sta_index_inst_id,
            b.index_code,
            b.index_value,
            b.composited_index_code,
          b.report_code,
          b.dim_code,
          b.dim_detail_code,
          b.dim_code2,
          b.dim_detail_code2,
          b.dim_code3,
          b.dim_detail_code3,
          b.dim_code4,
          b.dim_detail_code4
           order by c.index_orderno  
           ),
           results as (
           select * from results_p1
           union all
           select * from results_p2 )
           select DISTINCT
          replace(repinst_id,'XNNW',results.report_code)  as repinst_id,
        composited_index_code as org_id,
         results.report_code,
         report_year,
        to_char(to_date(REPORT_YEAR||lpad(REPORT_MONTH,2,0),'yyyyMM'), 'Q') as report_quarter,
        REPORT_MONTH as report_month,
        3 as report_frequent_code,
        '02' as status,
        nvl(auth.entry_person,null) as writer,
        sysdate as write_date,
        nvl(auth.verify_person,null) as checker,
        sysdate as check_date,
        null as condition,
        null as verify_note,
        P_RPTUSERID as create_user_id,
        P_RPTUSERNAME as create_user_name,
        sysdate as create_time,
        P_RPTUSERID as update_user_id,
       P_RPTUSERNAME as update_user_name,
        sysdate as update_time
        from results LEFT JOIN E7_STA_RPT_AUTH AUTH
        ON results.report_code = auth.report_code
        and results.composited_index_code = auth.org_id);

        CURSOR E_STARPTINDEXINST IS SELECT * FROM (
        with a as (
SELECT AA.REPINST_ID,
BB.*
 FROM 
(SELECT REPINST_ID FROM E7_STA_REPINST WHERE ORG_ID = P_RPTORGID AND REPORT_CODE =P_RPTCODE AND REPORT_YEAR = P_RPTYEAR AND REPORT_MONTH = P_RPTMONTH) AA,
(
select 
       repinst.org_id,
       repinst.report_year,
       P_RPTMONTH AS report_month,
       MAX(indexinst.sta_index_inst_id) STA_INDEX_INST_ID,
       indexinst.index_code,
       sum(indexinst.index_value) index_value,
       indexinst.COMPOSITED_INDEX_CODE,
       dimeninst.dim_code              as dim_code,
       dimeninst.dim_detail_code       as dim_detail_code,
       dimeninst2.dim_code             as dim_code2,
       dimeninst2.dim_detail_code      as dim_detail_code2,
       dimeninst3.dim_code             as dim_code3,
       dimeninst3.dim_detail_code      as dim_detail_code3,
       dimeninst4.dim_code             as dim_code4,
       dimeninst4.dim_detail_code      as dim_detail_code4,
       dimeninst5.dim_code             as dim_code5,
       dimeninst5.dim_detail_code      as dim_detail_code5,
       dimeninst6.dim_code             as dim_code6,
       dimeninst6.dim_detail_code      as dim_detail_code6
  from e7_sta_repinst repinst
  left join e7_sta_rpt_index_inst rptindexinst
    on repinst.repinst_id = rptindexinst.repinst_id
  left join e7_sta_index_inst indexinst
    on rptindexinst.sta_index_inst_id = indexinst.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst
    on dimeninst.dim_code = 'Business_type'
   and indexinst.sta_index_inst_id = dimeninst.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst2
    on dimeninst2.dim_code = 'Assets_type'
   and indexinst.sta_index_inst_id = dimeninst2.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst3
    on dimeninst3.dim_code = 'Industry_type'
   and indexinst.sta_index_inst_id = dimeninst3.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst4
    on dimeninst4.dim_code = 'Cru_oil_E_cons_typ'
   and indexinst.sta_index_inst_id = dimeninst4.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst5
    on dimeninst5.dim_code = 'Custom_dimen_first'
   and indexinst.sta_index_inst_id = dimeninst5.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst6
    on dimeninst6.dim_code = 'Custom_dimen_second'
   and indexinst.sta_index_inst_id = dimeninst6.sta_index_inst_id
 where repinst.report_code = P_RPTCODE
   and repinst.org_id = P_RPTORGID
   and  indexinst.COMPOSITED_INDEX_CODE =P_RPTORGID
   and repinst.report_year = P_RPTYEAR
   and repinst.report_month <= P_RPTMONTH
 group by
          repinst.org_id,
          repinst.report_year,
          indexinst.index_code,
          indexinst.COMPOSITED_INDEX_CODE,
          dimeninst.dim_code,
          dimeninst.dim_detail_code,
          dimeninst2.dim_code,
          dimeninst2.dim_detail_code,
          dimeninst3.dim_code,
          dimeninst3.dim_detail_code,
          dimeninst4.dim_code,
          dimeninst4.dim_detail_code,
          dimeninst5.dim_code,
          dimeninst5.dim_detail_code,
          dimeninst6.dim_code,
          dimeninst6.dim_detail_code
          ) BB
          ),
          res as (
              select repinst_id,
              report_year,
              report_month,
              sta_index_inst_id,
              index_code,
              index_value,
              composited_index_code,
              dim_code,
              dim_detail_code,
              dim_code2,
              dim_detail_code2,
              dim_code3,
              dim_detail_code3,
              dim_code4,
              dim_detail_code4
              from a
              union all
              select repinst_id,
              report_year,
              report_month,
              sta_index_inst_id,
              index_code,
              index_value,
              composited_index_code,
              dim_code,
              dim_detail_code,

              dim_code2,
              dim_detail_code2,
              dim_code3,
              dim_detail_code3,
              dim_code5,
              dim_detail_code5
              from a
              union all
              select repinst_id,
              report_year,
              report_month,
              sta_index_inst_id,
              index_code,
              index_value,
              composited_index_code,
              dim_code,
              dim_detail_code,

              dim_code2,
              dim_detail_code2,
              dim_code3,
              dim_detail_code3,
              dim_code6,
              dim_detail_code6
              from a
                ),
                res1 as (
                select res.repinst_id,
                res.report_year,
                res.report_month,
                res.sta_index_inst_id,
                relation.index_code,
                res.index_value,
                res.composited_index_code,
                res.dim_code,
                res.dim_detail_code,
                res.dim_code2,
                res.dim_detail_code2,
                res.dim_code3,
                res.dim_detail_code3,
                relation.dim_code dim_code4,
                relation.dim_detail_code dim_detail_code4

                 from res
                 left join
                 (select * from e7_xn_dim_relation) relation
                on res.index_code||res.dim_code4||res.dim_detail_code4 = relation.xn_index_code||relation.xn_dim_code||relation.xn_dim_detail_code
               ),
               res2 as (

          select * from res1 where index_code is not null
         /* union all
          select distinct * from res where index_code = 'Engy_csmp_amt_stadc'*/
          ),
           results1 as (
         SELECT  row_number() over(partition by tt.report_code,tt.index_code order by tt.index_code,tt.dim_detail_code,tt.dim_detail_code2,tt.dim_detail_code3,tt.dim_detail_code4) rowr,tt.* FROM (
          select t.* from (
          select
          max(a .repinst_id)  repinst_id,
          report_year,
          report_month,
          max(sta_index_inst_id) sta_index_inst_id,
          index_code,
          sum(index_value) index_value,
          composited_index_code,
          report_code,
          dim_code,
          dim_detail_code,
          dim_code2,
          dim_detail_code2,
          dim_code3,
          dim_detail_code3,
          dim_code4,
          dim_detail_code4
           from (
          select  r.repinst_id,
          r.report_year,
          r.report_month,
          r.sta_index_inst_id,
          r.index_code,
          r.index_value,
          r.composited_index_code,
          linkxn.report_code,
          linkxn.dim_code,
          linkxn.dim_detail_code,
          r.dim_code2,
          r.dim_detail_code2,
          r.dim_code3,
          r.dim_detail_code3,
          r.dim_code4,
          r.dim_detail_code4
           from res2 r
           left join e7_business_link_xn linkxn
           on r.dim_detail_code = linkxn.business_type

           and linkxn.report_type = 'W'
           where r.index_code in (
              'Fresh_water_consu_amt','Fresh_water_consu_cost',
              'Recycled_water_amt','Recycled_water_cost','Steam_conden_reco_amt',
              'Steam_conden_reco_cost','Ind_wastew_gene_amt','Ind_wastew_treat_amt',
              'Ind_wastew_treat_cost','Ind_wastew_disch_amt','Ind_wastew_disch_cost',
              'Ind_wastew_rech_amt','Ind_wastew_rech_cost',
              'Ind_wastew_reu_amt','Ind_wastew_reu_cost'
           )
           ) a
           group by
          report_year,
          report_month,
          index_code,
          composited_index_code,
          report_code,
          dim_code,
          dim_detail_code,
          dim_code2,
          dim_detail_code2,
          dim_code3,
          dim_detail_code3,
          dim_code4,
          dim_detail_code4
          order by dim_code,dim_detail_code
           ) t) tt WHERE  REPORT_CODE IS NOT NULL
          
           and  report_code in( select report_code from e7_sta_rpt_auth where org_id = P_RPTORGID)
           ),
           results2 as (
           select dense_rank() over(order by t.rowr) rowr, 
           t.repinst_id,report_year,report_month,sta_index_inst_id,index_code,index_value,composited_index_code,
          report_code,
          dim_code,
          dim_detail_code,
          dim_code2,
          dim_detail_code2,
          dim_code3,
          dim_detail_code3,
          dim_code4,
          dim_detail_code4 from results1 t
           where t.index_value is not null),
           results_p1 as (
           select * from results2 a  where a.dim_detail_code4 is not null
            ),
           results_p2 as  
           (select c.index_orderno + dense_rank() over( order by b.dim_detail_code) as index_orderno,
            b.repinst_id,
            b.report_year,
            b.report_month,
            b.sta_index_inst_id,
            b.index_code,
            b.index_value,
            b.composited_index_code,
          b.report_code,
          b.dim_code,
          b.dim_detail_code,
          b.dim_code2,
          b.dim_detail_code2,
          b.dim_code3,
          b.dim_detail_code3,
          b.dim_code4,
          b.dim_detail_code4
            from results2 b 
           left join e7_sta_report_index c on b.index_code = c.index_code 
           where b.dim_detail_code4 is null and c.report_code = 'C0013'
           group by c.index_orderno,
           b.repinst_id,
            b.report_year,
            b.report_month,
            b.sta_index_inst_id,
            b.index_code,
            b.index_value,
            b.composited_index_code,
          b.report_code,
          b.dim_code,
          b.dim_detail_code,
          b.dim_code2,
          b.dim_detail_code2,
          b.dim_code3,
          b.dim_detail_code3,
          b.dim_code4,
          b.dim_detail_code4
           order by c.index_orderno  
           ),
           results as (
           select * from results_p1
           union all
           select * from results_p2 )
           select DISTINCT
          replace(repinst_id,'XNNW',results.report_code)  as repinst_id,--REPINST_ID
        REPLACE(STA_INDEX_INST_ID,'XNNW',REPORT_CODE)||composited_index_code as STA_INDEX_INST_ID,--STA_INDEX_INST_ID
        sysdate as create_time,
        sysdate as update_time
        FROM RESULTS

        );

        CURSOR E_STAINDEXINST IS SELECT * FROM (with a as (
SELECT AA.REPINST_ID,
BB.*
 FROM 
(SELECT REPINST_ID FROM E7_STA_REPINST WHERE ORG_ID = P_RPTORGID AND REPORT_CODE =P_RPTCODE AND REPORT_YEAR = P_RPTYEAR AND REPORT_MONTH = P_RPTMONTH) AA,
(
select 
       repinst.org_id,
       repinst.report_year,
       P_RPTMONTH AS report_month,
       MAX(indexinst.sta_index_inst_id) STA_INDEX_INST_ID,
       indexinst.index_code,
       sum(indexinst.index_value) index_value,
       indexinst.COMPOSITED_INDEX_CODE,
       dimeninst.dim_code              as dim_code,
       dimeninst.dim_detail_code       as dim_detail_code,
       dimeninst2.dim_code             as dim_code2,
       dimeninst2.dim_detail_code      as dim_detail_code2,
       dimeninst3.dim_code             as dim_code3,
       dimeninst3.dim_detail_code      as dim_detail_code3,
       dimeninst4.dim_code             as dim_code4,
       dimeninst4.dim_detail_code      as dim_detail_code4,
       dimeninst5.dim_code             as dim_code5,
       dimeninst5.dim_detail_code      as dim_detail_code5,
       dimeninst6.dim_code             as dim_code6,
       dimeninst6.dim_detail_code      as dim_detail_code6
  from e7_sta_repinst repinst
  left join e7_sta_rpt_index_inst rptindexinst
    on repinst.repinst_id = rptindexinst.repinst_id
  left join e7_sta_index_inst indexinst
    on rptindexinst.sta_index_inst_id = indexinst.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst
    on dimeninst.dim_code = 'Business_type'
   and indexinst.sta_index_inst_id = dimeninst.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst2
    on dimeninst2.dim_code = 'Assets_type'
   and indexinst.sta_index_inst_id = dimeninst2.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst3
    on dimeninst3.dim_code = 'Industry_type'
   and indexinst.sta_index_inst_id = dimeninst3.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst4
    on dimeninst4.dim_code = 'Cru_oil_E_cons_typ'
   and indexinst.sta_index_inst_id = dimeninst4.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst5
    on dimeninst5.dim_code = 'Custom_dimen_first'
   and indexinst.sta_index_inst_id = dimeninst5.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst6
    on dimeninst6.dim_code = 'Custom_dimen_second'
   and indexinst.sta_index_inst_id = dimeninst6.sta_index_inst_id
 where repinst.report_code = P_RPTCODE
   and repinst.org_id = P_RPTORGID
   and  indexinst.COMPOSITED_INDEX_CODE =P_RPTORGID
   and repinst.report_year = P_RPTYEAR
   and repinst.report_month <= P_RPTMONTH
 group by
          repinst.org_id,
          repinst.report_year,
          indexinst.index_code,
          indexinst.COMPOSITED_INDEX_CODE,
          dimeninst.dim_code,
          dimeninst.dim_detail_code,
          dimeninst2.dim_code,
          dimeninst2.dim_detail_code,
          dimeninst3.dim_code,
          dimeninst3.dim_detail_code,
          dimeninst4.dim_code,
          dimeninst4.dim_detail_code,
          dimeninst5.dim_code,
          dimeninst5.dim_detail_code,
          dimeninst6.dim_code,
          dimeninst6.dim_detail_code
          ) BB
          ),
          res as (
              select repinst_id,
              report_year,
              report_month,
              sta_index_inst_id,
              index_code,
              index_value,
              composited_index_code,
              dim_code,
              dim_detail_code,
              dim_code2,
              dim_detail_code2,
              dim_code3,
              dim_detail_code3,
              dim_code4,
              dim_detail_code4
              from a
              union all
              select repinst_id,
              report_year,
              report_month,
              sta_index_inst_id,
              index_code,
              index_value,
              composited_index_code,
              dim_code,
              dim_detail_code,

              dim_code2,
              dim_detail_code2,
              dim_code3,
              dim_detail_code3,
              dim_code5,
              dim_detail_code5
              from a
              union all
              select repinst_id,
              report_year,
              report_month,
              sta_index_inst_id,
              index_code,
              index_value,
              composited_index_code,
              dim_code,
              dim_detail_code,

              dim_code2,
              dim_detail_code2,
              dim_code3,
              dim_detail_code3,
              dim_code6,
              dim_detail_code6
              from a
                ),
                res1 as (
                select res.repinst_id,
                res.report_year,
                res.report_month,
                res.sta_index_inst_id,
                relation.index_code,
                res.index_value,
                res.composited_index_code,
                res.dim_code,
                res.dim_detail_code,
                res.dim_code2,
                res.dim_detail_code2,
                res.dim_code3,
                res.dim_detail_code3,
                relation.dim_code dim_code4,
                relation.dim_detail_code dim_detail_code4

                 from res
                 left join
                 (select * from e7_xn_dim_relation) relation
                on res.index_code||res.dim_code4||res.dim_detail_code4 = relation.xn_index_code||relation.xn_dim_code||relation.xn_dim_detail_code
               ),
               res2 as (

          select * from res1 where index_code is not null
          /*union all
          select distinct * from res where index_code = 'Engy_csmp_amt_stadc'*/
          ),
           results1 as (
         SELECT  row_number() over(partition by tt.report_code,tt.index_code order by tt.index_code,tt.dim_detail_code,tt.dim_detail_code2,tt.dim_detail_code3,tt.dim_detail_code4) rowr,tt.* FROM (
          select t.* from (
          select
          max(a .repinst_id)  repinst_id,
          report_year,
          report_month,
          max(sta_index_inst_id) sta_index_inst_id,
          index_code,
          sum(index_value) index_value,
          composited_index_code,
          report_code,
          dim_code,
          dim_detail_code,
          dim_code2,
          dim_detail_code2,
          dim_code3,
          dim_detail_code3,
          dim_code4,
          dim_detail_code4
           from (
          select  r.repinst_id,
          r.report_year,
          r.report_month,
          r.sta_index_inst_id,
          r.index_code,
          r.index_value,
          r.composited_index_code,
          linkxn.report_code,
          linkxn.dim_code,
          linkxn.dim_detail_code,
          r.dim_code2,
          r.dim_detail_code2,
          r.dim_code3,
          r.dim_detail_code3,
          r.dim_code4,
          r.dim_detail_code4
           from res2 r
           left join e7_business_link_xn linkxn
           on r.dim_detail_code = linkxn.business_type

           and linkxn.report_type = 'W'
           where r.index_code in (
               'Fresh_water_consu_amt','Fresh_water_consu_cost',
              'Recycled_water_amt','Recycled_water_cost','Steam_conden_reco_amt',
              'Steam_conden_reco_cost','Ind_wastew_gene_amt','Ind_wastew_treat_amt',
              'Ind_wastew_treat_cost','Ind_wastew_disch_amt','Ind_wastew_disch_cost',
              'Ind_wastew_rech_amt','Ind_wastew_rech_cost',
              'Ind_wastew_reu_amt','Ind_wastew_reu_cost'
           )
           ) a
           group by
          report_year,
          report_month,
          index_code,
          composited_index_code,
          report_code,
          dim_code,
          dim_detail_code,
          dim_code2,
          dim_detail_code2,
          dim_code3,
          dim_detail_code3,
          dim_code4,
          dim_detail_code4
          order by dim_code,dim_detail_code
           ) t) tt WHERE  REPORT_CODE IS NOT NULL
          
           and  report_code in( select report_code from e7_sta_rpt_auth where org_id = P_RPTORGID)
           ),
          results2 as (
           select dense_rank() over(order by t.rowr) rowr, 
           t.repinst_id,report_year,report_month,sta_index_inst_id,index_code,index_value,composited_index_code,
          report_code,
          dim_code,
          dim_detail_code,
          dim_code2,
          dim_detail_code2,
          dim_code3,
          dim_detail_code3,
          dim_code4,
          dim_detail_code4 from results1 t
           where t.index_value is not null),
           results_p1 as (
           select * from results2 a  where a.dim_detail_code4 is not null
            ),
           results_p2 as  
           (select c.index_orderno + dense_rank() over( order by b.dim_detail_code) as index_orderno,
            b.repinst_id,
            b.report_year,
            b.report_month,
            b.sta_index_inst_id,
            b.index_code,
            b.index_value,
            b.composited_index_code,
          b.report_code,
          b.dim_code,
          b.dim_detail_code,
          b.dim_code2,
          b.dim_detail_code2,
          b.dim_code3,
          b.dim_detail_code3,
          b.dim_code4,
          b.dim_detail_code4
            from results2 b 
           left join e7_sta_report_index c on b.index_code = c.index_code 
           where b.dim_detail_code4 is null and c.report_code = 'C0013'
           group by c.index_orderno,
           b.repinst_id,
            b.report_year,
            b.report_month,
            b.sta_index_inst_id,
            b.index_code,
            b.index_value,
            b.composited_index_code,
          b.report_code,
          b.dim_code,
          b.dim_detail_code,
          b.dim_code2,
          b.dim_detail_code2,
          b.dim_code3,
          b.dim_detail_code3,
          b.dim_code4,
          b.dim_detail_code4
           order by c.index_orderno  
           ),
           results as (
           select * from results_p1
           union all
           select * from results_p2 )
          SELECT DISTINCT
        REPLACE(RESULTS.STA_INDEX_INST_ID,'XNNW',RESULTS.REPORT_CODE)||RESULTS.composited_index_code as STA_INDEX_INST_ID,
        RESULTS.INDEX_CODE,
        RESULTS.COMPOSITED_INDEX_CODE AS ORG_ID,
        RESULTS.REPORT_YEAR,
        to_char(to_date(RESULTS.REPORT_YEAR||lpad(RESULTS.REPORT_MONTH,2,0),'yyyyMM'), 'Q') as report_quarter,
        RESULTS.REPORT_MONTH,
        3 AS REPORT_FREQUENT_CODE,
        RESULTS.index_value as index_value,
        UNITS.UNIT_CODE UNIT_CODE,
        NULL AS REMARK,
        rowr AS INDEX_INST_ORDERNO,
        NULL AS COMPOSITED_INDEX_CODE,
        SYSDATE AS CREATE_TIME,
        SYSDATE AS UPDATE_TIME
        FROM RESULTS,
        (select * from e7_sta_report_index where report_code = 'C0003') UNITS 
        WHERE RESULTS.INDEX_CODE = UNITS.INDEX_CODE
        

        );

        CURSOR E_STAINDEXINSTDIMEN IS SELECT * FROM (with a as (
SELECT AA.REPINST_ID,
BB.*
 FROM 
(SELECT REPINST_ID FROM E7_STA_REPINST WHERE ORG_ID = P_RPTORGID AND REPORT_CODE =P_RPTCODE AND REPORT_YEAR = P_RPTYEAR AND REPORT_MONTH = P_RPTMONTH) AA,
(
select 
       repinst.org_id,
       repinst.report_year,
       P_RPTMONTH AS report_month,
       MAX(indexinst.sta_index_inst_id) STA_INDEX_INST_ID,
       indexinst.index_code,
       sum(indexinst.index_value) index_value,
       indexinst.COMPOSITED_INDEX_CODE,
       dimeninst.dim_code              as dim_code,
       dimeninst.dim_detail_code       as dim_detail_code,
       dimeninst2.dim_code             as dim_code2,
       dimeninst2.dim_detail_code      as dim_detail_code2,
       dimeninst3.dim_code             as dim_code3,
       dimeninst3.dim_detail_code      as dim_detail_code3,
       dimeninst4.dim_code             as dim_code4,
       dimeninst4.dim_detail_code      as dim_detail_code4,
       dimeninst5.dim_code             as dim_code5,
       dimeninst5.dim_detail_code      as dim_detail_code5,
       dimeninst6.dim_code             as dim_code6,
       dimeninst6.dim_detail_code      as dim_detail_code6
  from e7_sta_repinst repinst
  left join e7_sta_rpt_index_inst rptindexinst
    on repinst.repinst_id = rptindexinst.repinst_id
  left join e7_sta_index_inst indexinst
    on rptindexinst.sta_index_inst_id = indexinst.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst
    on dimeninst.dim_code = 'Business_type'
   and indexinst.sta_index_inst_id = dimeninst.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst2
    on dimeninst2.dim_code = 'Assets_type'
   and indexinst.sta_index_inst_id = dimeninst2.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst3
    on dimeninst3.dim_code = 'Industry_type'
   and indexinst.sta_index_inst_id = dimeninst3.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst4
    on dimeninst4.dim_code = 'Cru_oil_E_cons_typ'
   and indexinst.sta_index_inst_id = dimeninst4.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst5
    on dimeninst5.dim_code = 'Custom_dimen_first'
   and indexinst.sta_index_inst_id = dimeninst5.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst6
    on dimeninst6.dim_code = 'Custom_dimen_second'
   and indexinst.sta_index_inst_id = dimeninst6.sta_index_inst_id
 where repinst.report_code = P_RPTCODE
   and repinst.org_id = P_RPTORGID
   and  indexinst.COMPOSITED_INDEX_CODE =P_RPTORGID
   and repinst.report_year = P_RPTYEAR
   and repinst.report_month <= P_RPTMONTH
 group by
          repinst.org_id,
          repinst.report_year,
          indexinst.index_code,
          indexinst.COMPOSITED_INDEX_CODE,
          dimeninst.dim_code,
          dimeninst.dim_detail_code,
          dimeninst2.dim_code,
          dimeninst2.dim_detail_code,
          dimeninst3.dim_code,
          dimeninst3.dim_detail_code,
          dimeninst4.dim_code,
          dimeninst4.dim_detail_code,
          dimeninst5.dim_code,
          dimeninst5.dim_detail_code,
          dimeninst6.dim_code,
          dimeninst6.dim_detail_code
          ) BB
           ),
          res as (
              select repinst_id,
              report_year,
              report_month,
              sta_index_inst_id,
              index_code,
              index_value,
              composited_index_code,
              dim_code,
              dim_detail_code,
              dim_code2,
              dim_detail_code2,
              dim_code3,
              dim_detail_code3,
              dim_code4,
              dim_detail_code4
              from a
              union all
              select repinst_id,
              report_year,
              report_month,
              sta_index_inst_id,
              index_code,
              index_value,
              composited_index_code,
              dim_code,
              dim_detail_code,

              dim_code2,
              dim_detail_code2,
              dim_code3,
              dim_detail_code3,
              dim_code5,
              dim_detail_code5
              from a
              union all
              select repinst_id,
              report_year,
              report_month,
              sta_index_inst_id,
              index_code,
              index_value,
              composited_index_code,
              dim_code,
              dim_detail_code,

              dim_code2,
              dim_detail_code2,
              dim_code3,
              dim_detail_code3,
              dim_code6,
              dim_detail_code6
              from a
                ),
                res1 as (
                select res.repinst_id,
                res.report_year,
                res.report_month,
                res.sta_index_inst_id,
                relation.index_code,
                res.index_value,
                res.composited_index_code,
                res.dim_code,
                res.dim_detail_code,
                res.dim_code2,
                res.dim_detail_code2,
                res.dim_code3,
                res.dim_detail_code3,
                relation.dim_code dim_code4,
                relation.dim_detail_code dim_detail_code4

                 from res
                 left join
                 (select * from e7_xn_dim_relation) relation
                on res.index_code||res.dim_code4||res.dim_detail_code4 = relation.xn_index_code||relation.xn_dim_code||relation.xn_dim_detail_code
               ),
               res2 as (

          select * from res1 where index_code is not null
         /* union all
          select distinct * from res where index_code = 'Engy_csmp_amt_stadc'*/
          ),
           results1 as (
         SELECT  row_number() over(partition by tt.report_code,tt.index_code order by tt.index_code,tt.dim_detail_code,tt.dim_detail_code2,tt.dim_detail_code3,tt.dim_detail_code4) rowr,tt.* FROM (
          select t.* from (
          select
          max(a .repinst_id)  repinst_id,
          report_year,
          report_month,
          max(sta_index_inst_id) sta_index_inst_id,
          index_code,
          sum(index_value) index_value,
          composited_index_code,
          report_code,
          dim_code,
          dim_detail_code,
          dim_code2,
          dim_detail_code2,
          dim_code3,
          dim_detail_code3,
          dim_code4,
          dim_detail_code4
           from (
          select  r.repinst_id,
          r.report_year,
          r.report_month,
          r.sta_index_inst_id,
          r.index_code,
          r.index_value,
          r.composited_index_code,
          linkxn.report_code,
          linkxn.dim_code,
          linkxn.dim_detail_code,
          r.dim_code2,
          r.dim_detail_code2,
          r.dim_code3,
          r.dim_detail_code3,
          r.dim_code4,
          r.dim_detail_code4
           from res2 r
           left join e7_business_link_xn linkxn
           on r.dim_detail_code = linkxn.business_type

           and linkxn.report_type = 'W'
           where r.index_code in (
              'Fresh_water_consu_amt','Fresh_water_consu_cost',
              'Recycled_water_amt','Recycled_water_cost','Steam_conden_reco_amt',
              'Steam_conden_reco_cost','Ind_wastew_gene_amt','Ind_wastew_treat_amt',
              'Ind_wastew_treat_cost','Ind_wastew_disch_amt','Ind_wastew_disch_cost',
              'Ind_wastew_rech_amt','Ind_wastew_rech_cost',
              'Ind_wastew_reu_amt','Ind_wastew_reu_cost'
           )
           ) a
           group by
          report_year,
          report_month,
          index_code,
          composited_index_code,
          report_code,
          dim_code,
          dim_detail_code,
          dim_code2,
          dim_detail_code2,
          dim_code3,
          dim_detail_code3,
          dim_code4,
          dim_detail_code4
          order by dim_code,dim_detail_code
           ) t) tt WHERE  REPORT_CODE IS NOT NULL
          
           and  report_code in( select report_code from e7_sta_rpt_auth where org_id = P_RPTORGID)
           ),
           results2 as (
           select dense_rank() over(order by t.rowr) rowr, 
           t.repinst_id,report_year,report_month,sta_index_inst_id,index_code,index_value,composited_index_code,
          report_code,
          dim_code,
          dim_detail_code,
          dim_code2,
          dim_detail_code2,
          dim_code3,
          dim_detail_code3,
          dim_code4,
          dim_detail_code4 from results1 t
           where t.index_value is not null),
           results_p1 as (
           select * from results2 a  where a.dim_detail_code4 is not null
            ),
           results_p2 as  
           (select c.index_orderno + dense_rank() over( order by b.dim_detail_code) as index_orderno,
            b.repinst_id,
            b.report_year,
            b.report_month,
            b.sta_index_inst_id,
            b.index_code,
            b.index_value,
            b.composited_index_code,
          b.report_code,
          b.dim_code,
          b.dim_detail_code,
          b.dim_code2,
          b.dim_detail_code2,
          b.dim_code3,
          b.dim_detail_code3,
          b.dim_code4,
          b.dim_detail_code4
            from results2 b 
           left join e7_sta_report_index c on b.index_code = c.index_code 
           where b.dim_detail_code4 is null and c.report_code = 'C0013'
           group by c.index_orderno,
           b.repinst_id,
            b.report_year,
            b.report_month,
            b.sta_index_inst_id,
            b.index_code,
            b.index_value,
            b.composited_index_code,
          b.report_code,
          b.dim_code,
          b.dim_detail_code,
          b.dim_code2,
          b.dim_detail_code2,
          b.dim_code3,
          b.dim_detail_code3,
          b.dim_code4,
          b.dim_detail_code4
           order by c.index_orderno  
           ),
           results as (
           select * from results_p1
           union all
           select * from results_p2 )
           SELECT DISTINCT * FROM (
            SELECT
        REPLACE(STA_INDEX_INST_ID,'XNNW',REPORT_CODE)||composited_index_code||'D1' as REPINST_DTL_DIMEN,
        REPLACE(STA_INDEX_INST_ID,'XNNW',REPORT_CODE)||composited_index_code as STA_INDEX_INST_ID,
        DIM_CODE,
        DIM_DETAIL_CODE,
        NULL DIM_SOURCE,
        NULL dim_deteail_id,
        NULL dim_deteail_id2,
        NULL AS UNIT_CODE,
        PARENT_DIM_DETAIL_CODE AS COMPOSITE_DIM_CODE,
        SYSDATE AS CREATE_TIME,
        SYSDATE AS UPDATE_TIME
         FROM (
         SELECT R.*,D.PARENT_DIM_DETAIL_CODE FROM RESULTS R
         LEFT JOIN E7_STA_DIM_DETAIL D
        ON R.DIM_CODE4 = D.DIM_CODE
        AND R.DIM_DETAIL_CODE4 = D.DIM_DETAIL_CODE )
        UNION ALL
        SELECT
        REPLACE(STA_INDEX_INST_ID,'XNNW',REPORT_CODE)||composited_index_code||'D2' as REPINST_DTL_DIMEN,
        REPLACE(STA_INDEX_INST_ID,'XNNW',REPORT_CODE)||composited_index_code as STA_INDEX_INST_ID,
        DIM_CODE2,
        DIM_DETAIL_CODE2,
        NULL DIM_SOURCE,
        NULL dim_deteail_id,
        NULL dim_deteail_id2,
        NULL AS UNIT_CODE,
        PARENT_DIM_DETAIL_CODE AS COMPOSITE_DIM_CODE,
        SYSDATE AS CREATE_TIME,
        SYSDATE AS UPDATE_TIME
         FROM (
         SELECT R.*,D.PARENT_DIM_DETAIL_CODE FROM RESULTS R
         LEFT JOIN E7_STA_DIM_DETAIL D
        ON R.DIM_CODE4 = D.DIM_CODE
        AND R.DIM_DETAIL_CODE4 = D.DIM_DETAIL_CODE )
        UNION ALL
        SELECT
        REPLACE(STA_INDEX_INST_ID,'XNNW',REPORT_CODE)||composited_index_code||'D3' as REPINST_DTL_DIMEN,
        REPLACE(STA_INDEX_INST_ID,'XNNW',REPORT_CODE)||composited_index_code as STA_INDEX_INST_ID,
        DIM_CODE3,
        DIM_DETAIL_CODE3,
        NULL DIM_SOURCE,
        NULL dim_deteail_id,
        NULL dim_deteail_id2,
        NULL AS UNIT_CODE,
        PARENT_DIM_DETAIL_CODE AS COMPOSITE_DIM_CODE,
        SYSDATE AS CREATE_TIME,
        SYSDATE AS UPDATE_TIME
         FROM (
         SELECT R.*,D.PARENT_DIM_DETAIL_CODE FROM RESULTS R
         LEFT JOIN E7_STA_DIM_DETAIL D
        ON R.DIM_CODE4 = D.DIM_CODE
        AND R.DIM_DETAIL_CODE4 = D.DIM_DETAIL_CODE )
        UNION ALL
        SELECT
        REPLACE(STA_INDEX_INST_ID,'XNNW',REPORT_CODE)||composited_index_code||'D4' as REPINST_DTL_DIMEN,
        REPLACE(STA_INDEX_INST_ID,'XNNW',REPORT_CODE)||composited_index_code as STA_INDEX_INST_ID,
        DIM_CODE4,
        DIM_DETAIL_CODE4,
        NULL DIM_SOURCE,
        NULL dim_deteail_id,
        NULL dim_deteail_id2,
        NULL AS UNIT_CODE,
        PARENT_DIM_DETAIL_CODE AS COMPOSITE_DIM_CODE,
        SYSDATE AS CREATE_TIME,
        SYSDATE AS UPDATE_TIME
         FROM (
         SELECT R.*,D.PARENT_DIM_DETAIL_CODE FROM RESULTS R
         LEFT JOIN E7_STA_DIM_DETAIL D
        ON R.DIM_CODE4 = D.DIM_CODE
        AND R.DIM_DETAIL_CODE4 = D.DIM_DETAIL_CODE )
        ));

        
        V_STAREPINST E7_STA_REPINST%ROWTYPE;
        V_STARPTINDEXINST E7_STA_RPT_INDEX_INST%ROWTYPE;
        V_STAINDEXINST E7_STA_INDEX_INST%ROWTYPE;
        V_STAINDEXINSTDIMEN E7_STA_INDEX_INST_DIMEN%ROWTYPE;
           --E7_STA_REPINST
           BEGIN
             DATATransXNNWDELETEW(P_RPTCODE,P_RPTYEAR,P_RPTMONTH,P_RPTORGID);
             FOR VSTAREPINST IN E_STAREPINST LOOP
                V_STAREPINST.repinst_id           := VSTAREPINST.repinst_id           ;
                V_STAREPINST.org_id               := VSTAREPINST.org_id               ;
                V_STAREPINST.report_code          := VSTAREPINST.report_code          ;
                V_STAREPINST.report_year          := VSTAREPINST.report_year          ;
                V_STAREPINST.report_quarter       := VSTAREPINST.report_quarter       ;
                V_STAREPINST.report_month         := VSTAREPINST.report_month         ;
                V_STAREPINST.report_frequent_code := VSTAREPINST.report_frequent_code ;
                V_STAREPINST.status               := VSTAREPINST.status               ;
                V_STAREPINST.writer               := VSTAREPINST.writer               ;
                V_STAREPINST.write_date           := VSTAREPINST.write_date           ;
                V_STAREPINST.checker              := VSTAREPINST.checker              ;
                V_STAREPINST.check_date           := VSTAREPINST.check_date           ;
                V_STAREPINST.condition            := VSTAREPINST.condition            ;
                V_STAREPINST.verify_note          := VSTAREPINST.verify_note          ;
                V_STAREPINST.create_user_id       := VSTAREPINST.create_user_id       ;
                V_STAREPINST.create_user_name     := VSTAREPINST.create_user_name     ;
                V_STAREPINST.create_time          := VSTAREPINST.create_time          ;
                V_STAREPINST.update_user_id       := VSTAREPINST.update_user_id       ;
                V_STAREPINST.update_user_name     := VSTAREPINST.update_user_name     ;
                V_STAREPINST.update_time          := VSTAREPINST.update_time          ;
                INSERT INTO E7_STA_REPINST VALUES V_STAREPINST;
                COMMIT;
             END LOOP;
             --E7_STA_RPT_INDEX_INST
             FOR VSTARPTINDEXINST IN E_STARPTINDEXINST LOOP
                V_STARPTINDEXINST.repinst_id       :=VSTARPTINDEXINST.repinst_id       ;
                V_STARPTINDEXINST.sta_index_inst_id:=VSTARPTINDEXINST.sta_index_inst_id||P_RPTMONTH;
                V_STARPTINDEXINST.create_time      :=VSTARPTINDEXINST.create_time      ;
                V_STARPTINDEXINST.update_time      :=VSTARPTINDEXINST.update_time      ;
               INSERT INTO E7_STA_RPT_INDEX_INST VALUES V_STARPTINDEXINST;
               COMMIT;
              END LOOP;
              --E7_STA_INDEX_INST
              FOR VSTAINDEXINST IN E_STAINDEXINST LOOP
                V_STAINDEXINST.sta_index_inst_id     := VSTAINDEXINST.sta_index_inst_id||P_RPTMONTH    ;
                V_STAINDEXINST.index_code            := VSTAINDEXINST.index_code           ;
                V_STAINDEXINST.org_id                := VSTAINDEXINST.org_id               ;
                V_STAINDEXINST.report_year           := VSTAINDEXINST.report_year          ;
                V_STAINDEXINST.report_quarter        := VSTAINDEXINST.report_quarter       ;
                V_STAINDEXINST.report_month          := VSTAINDEXINST.report_month         ;
                V_STAINDEXINST.report_frequent_code  := VSTAINDEXINST.report_frequent_code ;
                V_STAINDEXINST.index_value           := VSTAINDEXINST.index_value          ;
                V_STAINDEXINST.unit_code             := VSTAINDEXINST.unit_code            ;
                V_STAINDEXINST.remark                := VSTAINDEXINST.remark               ;
                V_STAINDEXINST.index_inst_orderno    := VSTAINDEXINST.index_inst_orderno   ;
                V_STAINDEXINST.composited_index_code := VSTAINDEXINST.composited_index_code;
                V_STAINDEXINST.create_time           := VSTAINDEXINST.create_time          ;
                V_STAINDEXINST.update_time           := VSTAINDEXINST.update_time          ;

              INSERT INTO E7_STA_INDEX_INST VALUES V_STAINDEXINST;
              COMMIT;
              END LOOP;
              --E7_STA_INDEX_INST_DIMEN
              FOR VSTAINDEXINSTDIMEN IN E_STAINDEXINSTDIMEN LOOP
                V_STAINDEXINSTDIMEN.repinst_dtl_dimen  :=VSTAINDEXINSTDIMEN.repinst_dtl_dimen||P_RPTMONTH ;
                V_STAINDEXINSTDIMEN.sta_index_inst_id  :=VSTAINDEXINSTDIMEN.sta_index_inst_id||P_RPTMONTH ;
                V_STAINDEXINSTDIMEN.dim_code           :=VSTAINDEXINSTDIMEN.dim_code          ;
                V_STAINDEXINSTDIMEN.dim_detail_code    :=VSTAINDEXINSTDIMEN.dim_detail_code   ;
                V_STAINDEXINSTDIMEN.dim_source         :=VSTAINDEXINSTDIMEN.dim_source        ;
                V_STAINDEXINSTDIMEN.dim_deteail_id     :=VSTAINDEXINSTDIMEN.dim_deteail_id    ;
                V_STAINDEXINSTDIMEN.dim_deteail_id2    :=VSTAINDEXINSTDIMEN.dim_deteail_id2   ;
                V_STAINDEXINSTDIMEN.unit_code          :=VSTAINDEXINSTDIMEN.unit_code         ;
                V_STAINDEXINSTDIMEN.composite_dim_code :=VSTAINDEXINSTDIMEN.composite_dim_code;
                V_STAINDEXINSTDIMEN.create_time        :=VSTAINDEXINSTDIMEN.create_time       ;
                V_STAINDEXINSTDIMEN.update_time        :=VSTAINDEXINSTDIMEN.update_time       ;
              INSERT INTO E7_STA_INDEX_INST_DIMEN VALUES V_STAINDEXINSTDIMEN;
              COMMIT;
              END LOOP;
              EXCEPTION WHEN OTHERS THEN
                DBMS_OUTPUT.put_line(SQLERRM);
                ROLLBACK;
             END;
        PROCEDURE DATATransXNNWDELETE(P_RPTCODE  IN VARCHAR2,
                     P_RPTYEAR  IN VARCHAR2,
                     P_RPTMONTH IN VARCHAR2,
                     P_RPTORGID IN VARCHAR2
                     ) AS

CURSOR E_STAREPINST IS SELECT * FROM  (with a as (
select max(repinst.repinst_id) repinst_id,
       repinst.org_id,
       repinst.report_year,
       repinst.report_month,
       indexinst.sta_index_inst_id,
       indexinst.index_code,
       sum(indexinst.index_value) index_value,
       indexinst.COMPOSITED_INDEX_CODE,
       dimeninst.dim_code              as dim_code,
       dimeninst.dim_detail_code       as dim_detail_code,
       dimeninst2.dim_code             as dim_code2,
       dimeninst2.dim_detail_code      as dim_detail_code2,
       dimeninst3.dim_code             as dim_code3,
       dimeninst3.dim_detail_code      as dim_detail_code3,
       dimeninst4.dim_code             as dim_code4,
       dimeninst4.dim_detail_code      as dim_detail_code4,
       dimeninst5.dim_code             as dim_code5,
       dimeninst5.dim_detail_code      as dim_detail_code5,
       dimeninst6.dim_code             as dim_code6,
       dimeninst6.dim_detail_code      as dim_detail_code6
  from e7_sta_repinst repinst
  left join e7_sta_rpt_index_inst rptindexinst
    on repinst.repinst_id = rptindexinst.repinst_id
  left join e7_sta_index_inst indexinst
    on rptindexinst.sta_index_inst_id = indexinst.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst
    on dimeninst.dim_code = 'Business_type'
   and indexinst.sta_index_inst_id = dimeninst.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst2
    on dimeninst2.dim_code = 'Assets_type'
   and indexinst.sta_index_inst_id = dimeninst2.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst3
    on dimeninst3.dim_code = 'Industry_type'
   and indexinst.sta_index_inst_id = dimeninst3.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst4
    on dimeninst4.dim_code = 'Cru_oil_E_cons_typ'
   and indexinst.sta_index_inst_id = dimeninst4.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst5
    on dimeninst5.dim_code = 'Custom_dimen_first'
   and indexinst.sta_index_inst_id = dimeninst5.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst6
    on dimeninst6.dim_code = 'Custom_dimen_second'
   and indexinst.sta_index_inst_id = dimeninst6.sta_index_inst_id
 where repinst.report_code = P_RPTCODE
   and repinst.org_id = P_RPTORGID
   and  indexinst.COMPOSITED_INDEX_CODE =P_RPTORGID
   and repinst.report_year = P_RPTYEAR
   and repinst.report_month = P_RPTMONTH
 group by
          repinst.org_id,
          repinst.report_year,
          repinst.report_month,
          indexinst.sta_index_inst_id,
          indexinst.index_code,
          indexinst.index_value,
          indexinst.COMPOSITED_INDEX_CODE,
          dimeninst.dim_code,
          dimeninst.dim_detail_code,

          dimeninst2.dim_code,
          dimeninst2.dim_detail_code,
          dimeninst3.dim_code,
          dimeninst3.dim_detail_code,
          dimeninst4.dim_code,
          dimeninst4.dim_detail_code,
          dimeninst5.dim_code,
          dimeninst5.dim_detail_code,
          dimeninst6.dim_code,
          dimeninst6.dim_detail_code
          ),
          res as (
              select repinst_id,
              report_year,
              report_month,
              sta_index_inst_id,
              index_code,
              index_value,
              composited_index_code,
              dim_code,
              dim_detail_code,
              dim_code2,
              dim_detail_code2,
              dim_code3,
              dim_detail_code3,
              dim_code4,
              dim_detail_code4
              from a
              union all
              select repinst_id,
              report_year,
              report_month,
              sta_index_inst_id,
              index_code,
              index_value,
              composited_index_code,
              dim_code,
              dim_detail_code,

              dim_code2,
              dim_detail_code2,
              dim_code3,
              dim_detail_code3,
              dim_code5,
              dim_detail_code5
              from a
              union all
              select repinst_id,
              report_year,
              report_month,
              sta_index_inst_id,
              index_code,
              index_value,
              composited_index_code,
              dim_code,
              dim_detail_code,

              dim_code2,
              dim_detail_code2,
              dim_code3,
              dim_detail_code3,
              dim_code6,
              dim_detail_code6
              from a
                ),
                res1 as (
                select res.repinst_id,
                res.report_year,
                res.report_month,
                res.sta_index_inst_id,
                relation.index_code,
                res.index_value,
                res.composited_index_code,
                res.dim_code,
                res.dim_detail_code,
                res.dim_code2,
                res.dim_detail_code2,
                res.dim_code3,
                res.dim_detail_code3,
                relation.dim_code dim_code4,
                relation.dim_detail_code dim_detail_code4

                 from res
                 left join
                 (select * from e7_xn_dim_relation) relation
                on res.index_code||res.dim_code4||res.dim_detail_code4 = relation.xn_index_code||relation.xn_dim_code||relation.xn_dim_detail_code
               ),
               res2 as (

          select * from res1 where index_code is not null
          union all
          select distinct * from res where index_code = 'Engy_csmp_amt_stadc'
          ),
          results as (
          select rownum,t.* from (
          select
          max(a .repinst_id)  repinst_id,
          report_year,
          report_month,
          max(sta_index_inst_id) sta_index_inst_id,
          index_code,
          sum(index_value) index_value,
          composited_index_code,
          report_code,
          dim_code,
          dim_detail_code,
          dim_code2,
          dim_detail_code2,
          dim_code3,
          dim_detail_code3,
          dim_code4,
          dim_detail_code4
           from (
          select  r.repinst_id,
          r.report_year,
          r.report_month,
          r.sta_index_inst_id,
          r.index_code,
          r.index_value,
          r.composited_index_code,
          linkxn.report_code,
          linkxn.dim_code,
          linkxn.dim_detail_code,
          r.dim_code2,
          r.dim_detail_code2,
          r.dim_code3,
          r.dim_detail_code3,
          r.dim_code4,
          r.dim_detail_code4
           from res2 r
           left join e7_business_link_xn linkxn
           on r.dim_detail_code = linkxn.business_type

           and linkxn.report_type = 'E'
           where r.index_code not in (
              'Fresh_water_consu_amt','Fresh_water_consu_cost'
           )
           ) a
           group by
          report_year,
          report_month,
          index_code,
          composited_index_code,
          report_code,
          dim_code,
          dim_detail_code,
          dim_code2,
          dim_detail_code2,
          dim_code3,
          dim_detail_code3,
          dim_code4,
          dim_detail_code4
           ) t
           )
           select DISTINCT results.report_code from results);

           BEGIN
              --E7_STA_INDEX_INST_DIMEN
              FOR v_report IN E_STAREPINST LOOP
                  DELDATAXN(v_report.Report_Code,P_RPTYEAR,P_RPTMONTH,P_RPTORGID);
              END LOOP;
EXCEPTION
    WHEN OTHERS THEN
      DBMS_OUTPUT.put_line(SQLERRM);
      ROLLBACK;

             END;


PROCEDURE DATATransXNNWDELETEW(P_RPTCODE  IN VARCHAR2,
                     P_RPTYEAR  IN VARCHAR2,
                     P_RPTMONTH IN VARCHAR2,
                     P_RPTORGID IN VARCHAR2
                     ) AS

CURSOR E_STAREPINST IS SELECT * FROM  (with a as (
select max(repinst.repinst_id) repinst_id,
       repinst.org_id,
       repinst.report_year,
       repinst.report_month,
       indexinst.sta_index_inst_id,
       indexinst.index_code,
       sum(indexinst.index_value) index_value,
       indexinst.COMPOSITED_INDEX_CODE,
       dimeninst.dim_code              as dim_code,
       dimeninst.dim_detail_code       as dim_detail_code,
       dimeninst2.dim_code             as dim_code2,
       dimeninst2.dim_detail_code      as dim_detail_code2,
       dimeninst3.dim_code             as dim_code3,
       dimeninst3.dim_detail_code      as dim_detail_code3,
       dimeninst4.dim_code             as dim_code4,
       dimeninst4.dim_detail_code      as dim_detail_code4,
       dimeninst5.dim_code             as dim_code5,
       dimeninst5.dim_detail_code      as dim_detail_code5,
       dimeninst6.dim_code             as dim_code6,
       dimeninst6.dim_detail_code      as dim_detail_code6
  from e7_sta_repinst repinst
  left join e7_sta_rpt_index_inst rptindexinst
    on repinst.repinst_id = rptindexinst.repinst_id
  left join e7_sta_index_inst indexinst
    on rptindexinst.sta_index_inst_id = indexinst.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst
    on dimeninst.dim_code = 'Business_type'
   and indexinst.sta_index_inst_id = dimeninst.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst2
    on dimeninst2.dim_code = 'Assets_type'
   and indexinst.sta_index_inst_id = dimeninst2.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst3
    on dimeninst3.dim_code = 'Industry_type'
   and indexinst.sta_index_inst_id = dimeninst3.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst4
    on dimeninst4.dim_code = 'Cru_oil_E_cons_typ'
   and indexinst.sta_index_inst_id = dimeninst4.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst5
    on dimeninst5.dim_code = 'Custom_dimen_first'
   and indexinst.sta_index_inst_id = dimeninst5.sta_index_inst_id
  left join e7_sta_index_inst_dimen dimeninst6
    on dimeninst6.dim_code = 'Custom_dimen_second'
   and indexinst.sta_index_inst_id = dimeninst6.sta_index_inst_id
 where repinst.report_code = P_RPTCODE
   and repinst.org_id = P_RPTORGID
   and  indexinst.COMPOSITED_INDEX_CODE =P_RPTORGID
   and repinst.report_year = P_RPTYEAR
   and repinst.report_month = P_RPTMONTH
 group by
          repinst.org_id,
          repinst.report_year,
          repinst.report_month,
          indexinst.sta_index_inst_id,
          indexinst.index_code,
          indexinst.index_value,
          indexinst.COMPOSITED_INDEX_CODE,
          dimeninst.dim_code,
          dimeninst.dim_detail_code,

          dimeninst2.dim_code,
          dimeninst2.dim_detail_code,
          dimeninst3.dim_code,
          dimeninst3.dim_detail_code,
          dimeninst4.dim_code,
          dimeninst4.dim_detail_code,
          dimeninst5.dim_code,
          dimeninst5.dim_detail_code,
          dimeninst6.dim_code,
          dimeninst6.dim_detail_code
          ),
          res as (
              select repinst_id,
              report_year,
              report_month,
              sta_index_inst_id,
              index_code,
              index_value,
              composited_index_code,
              dim_code,
              dim_detail_code,
              dim_code2,
              dim_detail_code2,
              dim_code3,
              dim_detail_code3,
              dim_code4,
              dim_detail_code4
              from a
              union all
              select repinst_id,
              report_year,
              report_month,
              sta_index_inst_id,
              index_code,
              index_value,
              composited_index_code,
              dim_code,
              dim_detail_code,

              dim_code2,
              dim_detail_code2,
              dim_code3,
              dim_detail_code3,
              dim_code5,
              dim_detail_code5
              from a
              union all
              select repinst_id,
              report_year,
              report_month,
              sta_index_inst_id,
              index_code,
              index_value,
              composited_index_code,
              dim_code,
              dim_detail_code,

              dim_code2,
              dim_detail_code2,
              dim_code3,
              dim_detail_code3,
              dim_code6,
              dim_detail_code6
              from a
                ),
                res1 as (
                select res.repinst_id,
                res.report_year,
                res.report_month,
                res.sta_index_inst_id,
                relation.index_code,
                res.index_value,
                res.composited_index_code,
                res.dim_code,
                res.dim_detail_code,
                res.dim_code2,
                res.dim_detail_code2,
                res.dim_code3,
                res.dim_detail_code3,
                relation.dim_code dim_code4,
                relation.dim_detail_code dim_detail_code4

                 from res
                 left join
                 (select * from e7_xn_dim_relation) relation
                on res.index_code||res.dim_code4||res.dim_detail_code4 = relation.xn_index_code||relation.xn_dim_code||relation.xn_dim_detail_code
               ),
               res2 as (

          select * from res1 where index_code is not null
         /* union all
          select distinct * from res where index_code = 'Engy_csmp_amt_stadc'*/
          ),
          results as (
          select rownum,t.* from (
          select
          max(a .repinst_id)  repinst_id,
          report_year,
          report_month,
          max(sta_index_inst_id) sta_index_inst_id,
          index_code,
          sum(index_value) index_value,
          composited_index_code,
          report_code,
          dim_code,
          dim_detail_code,
          dim_code2,
          dim_detail_code2,
          dim_code3,
          dim_detail_code3,
          dim_code4,
          dim_detail_code4
           from (
          select  r.repinst_id,
          r.report_year,
          r.report_month,
          r.sta_index_inst_id,
          r.index_code,
          r.index_value,
          r.composited_index_code,
          linkxn.report_code,
          linkxn.dim_code,
          linkxn.dim_detail_code,
          r.dim_code2,
          r.dim_detail_code2,
          r.dim_code3,
          r.dim_detail_code3,
          r.dim_code4,
          r.dim_detail_code4
           from res2 r
           left join e7_business_link_xn linkxn
           on r.dim_detail_code = linkxn.business_type

           and linkxn.report_type = 'W'
           where r.index_code in (
              'Fresh_water_consu_amt','Fresh_water_consu_cost'
           )
           ) a
           group by
          report_year,
          report_month,
          index_code,
          composited_index_code,
          report_code,
          dim_code,
          dim_detail_code,
          dim_code2,
          dim_detail_code2,
          dim_code3,
          dim_detail_code3,
          dim_code4,
          dim_detail_code4
           ) t
           )
           select DISTINCT results.report_code from results);

           BEGIN
              --E7_STA_INDEX_INST_DIMEN
              FOR v_report IN E_STAREPINST LOOP
                  DELDATAXN(v_report.Report_Code,P_RPTYEAR,P_RPTMONTH,P_RPTORGID);
              END LOOP;
EXCEPTION
    WHEN OTHERS THEN
      DBMS_OUTPUT.put_line(SQLERRM);
      ROLLBACK;

             END;




END DataRUNXN;
/

