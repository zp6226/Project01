CREATE PACKAGE DataRUNXN IS

  PROCEDURE DataM_RUNXNNW01(P_RPTYEAR  IN VARCHAR2,
                            P_RPTMONTH IN VARCHAR2,
                            P_RPTORGID IN VARCHAR2);
  PROCEDURE DataM_RUNXNNW02(P_RPTYEAR  IN VARCHAR2,
                            P_RPTMONTH IN VARCHAR2,
                            P_RPTORGID IN VARCHAR2);
  PROCEDURE DELDATASXNNW(P_RPTCODE  IN VARCHAR2,
                         P_RPTYEAR  IN VARCHAR2,
                         P_RPTMONTH IN VARCHAR2,
                         P_RPTORGID IN VARCHAR2);

  PROCEDURE DataQYXNNW01(P_RPTCODE  IN VARCHAR2,
                         P_RPTYEAR  IN VARCHAR2,
                         P_RPTMONTH IN VARCHAR2,
                         P_RPTORGID IN VARCHAR2);
  PROCEDURE DataQYXNNW02(P_RPTCODE  IN VARCHAR2,
                         P_RPTYEAR  IN VARCHAR2,
                         P_RPTMONTH IN VARCHAR2,
                         P_RPTORGID IN VARCHAR2);                         
  PROCEDURE DATAQYINDEXDIMEN(P_RPTYEAR  IN VARCHAR2,
                             P_RPTMONTH IN VARCHAR2,
                             P_RPTORGID IN VARCHAR2);
  PROCEDURE CREATE_XNNWREPINST(P_RPTCODE  IN VARCHAR2,
                               P_RPTYEAR  IN VARCHAR2,
                               P_RPTMONTH IN VARCHAR2,
                               P_RPTORGID IN VARCHAR2);                              
  PROCEDURE DELDATAS(P_RPTCODE  IN VARCHAR2,
                     P_RPTYEAR  IN VARCHAR2,
                     P_RPTMONTH IN VARCHAR2,
                     P_RPTORGID IN VARCHAR2);
PROCEDURE DATATransJXCLising(P_RPTCODE     IN VARCHAR2,
                            P_RPTYEAR     IN VARCHAR2,
                            P_RPTMONTH    IN VARCHAR2,
                            P_RPTORGID    IN VARCHAR2);
 PROCEDURE DATATransJXCNoLising(P_RPTCODE     IN VARCHAR2,
                            P_RPTYEAR     IN VARCHAR2,
                            P_RPTMONTH    IN VARCHAR2,
                            P_RPTORGID    IN VARCHAR2);
                                              
  PROCEDURE DATATransXNNWSE(P_RPTCODE     IN VARCHAR2,
                            P_RPTYEAR     IN VARCHAR2,
                            P_RPTMONTH    IN VARCHAR2,
                            P_RPTORGID    IN VARCHAR2,
                            P_RPTUSERID   in VARCHAR2,
                            P_RPTUSERNAME IN VARCHAR2);
  PROCEDURE DATATransXNNWSW(P_RPTCODE     IN VARCHAR2,
                            P_RPTYEAR     IN VARCHAR2,
                            P_RPTMONTH    IN VARCHAR2,
                            P_RPTORGID    IN VARCHAR2,
                            P_RPTUSERID   in VARCHAR2,
                            P_RPTUSERNAME IN VARCHAR2);                         
  PROCEDURE DATATransXNNWDELETE(P_RPTCODE  IN VARCHAR2,
                                P_RPTYEAR  IN VARCHAR2,
                                P_RPTMONTH IN VARCHAR2,
                                P_RPTORGID IN VARCHAR2);
  PROCEDURE DATATransXNNWDELETEW(P_RPTCODE  IN VARCHAR2,
                                P_RPTYEAR  IN VARCHAR2,
                                P_RPTMONTH IN VARCHAR2,
                                P_RPTORGID IN VARCHAR2);

  PROCEDURE DELDATAXN(P_RPTCODE  IN VARCHAR2,
                         P_RPTYEAR  IN VARCHAR2,
                         P_RPTMONTH IN VARCHAR2,
                         P_RPTORGID IN VARCHAR2);
END DataRUNXN;
/

