CREATE procedure data_extend
(
--源，分别表示机构ID，报表编号，年，月
          orgid in number
          ,reportCode in varchar2
          ,tyear in number
          ,tmonth in number
--目标，分别表示
          ,year_from in number,year_to in number,month_from in number,month_to in number
)
is
    --机构
    cursor curOrg is select distinct org_id from e7_sys_org where org_id in (13);
    --报表实例表
    cursor curRepinst is
         select * from E7_STA_REPINST
                where org_id in (orgid) and report_code in (reportCode) and report_year=tyear and report_month=tmonth;
    --报表指标关联表
    cursor curRptIndex is
         select * from E7_STA_RPT_INDEX_INST where repinst_id in (
          select repinst_id from E7_STA_REPINST where org_id in (orgid) and report_code in (reportCode) and report_year=tyear and report_month=tmonth
          );
    --指标实例表
    cursor curIndex is
                select * from E7_STA_INDEX_INST where sta_index_inst_id  in (
                select sta_index_inst_id from E7_STA_RPT_INDEX_INST where repinst_id in (
                select repinst_id from E7_STA_REPINST where org_id in (orgid) and report_code in (reportCode) and report_year=tyear and report_month=tmonth
                )) ;
    --维度表
  cursor curIndexDimen(v_id in varchar2) is
          select * from E7_STA_INDEX_INST_DIMEN where sta_index_inst_id in (
          select sta_index_inst_id from E7_STA_RPT_INDEX_INST where repinst_id in (
          select repinst_id from E7_STA_REPINST where org_id in (orgid) and report_code in (reportCode) and report_year=tyear and report_month=tmonth
          )) and STA_INDEX_INST_ID = v_id;
  --T0001001001 20130502 140776 5012595
  --EXT01001020 13050903 051110 0000000
  str_id varchar2(9) := 'EXT010010';
  --select to_char(sysdate,'yyyyMMddHHmmSS') from dual;
  num_id number := 100000001;
  repinstId varchar2(50) ;

  tempRepinstId varchar2(50);
  tempIndexId varchar2(50);
begin
   for varOrg in curOrg loop
       for year_f in year_from .. year_to loop
           for month_f in month_from .. month_to loop
               --插入前先执行删除操作
               begin
                       select repinst_id into repinstId
                       from e7_sta_repinst
                       where org_id = varOrg.org_id
                       and report_year = year_f
                       and report_month = month_f
                       and report_code = reportCode;
               exception
                       when others then
                       dbms_output.put_line('报错!');
               end;

               --开始删除
               DELETE FROM e7_sta_index_inst_dimen siid WHERE siid.sta_index_inst_id IN
				                 (SELECT sta_index_inst_id FROM E7_STA_RPT_INDEX_INST srii WHERE srii.repinst_id = repinstId);
               DELETE FROM E7_STA_RPT_INDEX_INST srii WHERE srii.repinst_id = repinstId ;
		           delete from E7_STA_REPINST sr WHERE sr.REPINST_ID = repinstId;
		           DELETE FROM e7_sta_index_inst sii WHERE sii.sta_index_inst_id IN
				                 (SELECT srii.sta_index_inst_id FROM E7_STA_RPT_INDEX_INST srii WHERE srii.repinst_id= repinstId);
               --删除结束


               tempRepinstId := str_id||to_char(sysdate,'yyyyMMddHHmmSS')||to_char(num_id);
               insert into E7_STA_REPINST
                      ( REPINST_ID, ORG_ID, REPORT_YEAR, REPORT_MONTH, REPORT_FREQUENT_CODE,
                      REPORT_CODE,STATUS,WRITER,CHECKER,CREATE_USER_NAME,UPDATE_USER_NAME,
                      WRITE_DATE,CHECK_DATE,CREATE_TIME,UPDATE_TIME)
					            values (tempRepinstId, varOrg.org_id,
                      year_f, month_f, '03', reportCode,'05',
                      '系统管理员',null,'系统管理员','系统管理员',
                      sysdate,sysdate,sysdate,sysdate);
                commit;
               num_id := num_id+1;
               --指标实例
               for varIndex in curIndex loop
                    tempIndexId := str_id||to_char(sysdate,'yyyyMMddHHmmSS')||to_char(num_id);
                    insert into E7_STA_INDEX_INST
                      ( STA_INDEX_INST_ID, INDEX_CODE, ORG_ID, REPORT_YEAR, REPORT_MONTH, REPORT_FREQUENT_CODE,
                           UNIT_CODE, INDEX_VALUE, INDEX_INST_ORDERNO,COMPOSITED_INDEX_CODE,CREATE_TIME,UPDATE_TIME)
                     values (tempIndexId,
                     varIndex.index_code, varOrg.org_id, year_f, month_f, '03',
                     varIndex.unit_code, varIndex.index_value, varIndex.INDEX_INST_ORDERNO,
                     varIndex.COMPOSITED_INDEX_CODE,sysdate,sysdate);
                     num_id := num_id+1;
                     commit;

                     --维度实例
                     for varIndexDimen in curIndexDimen(varIndex.STA_INDEX_INST_ID) loop
                         insert into E7_STA_INDEX_INST_DIMEN
                                 ( REPINST_DTL_DIMEN, STA_INDEX_INST_ID, DIM_CODE,
                                 DIM_DETAIL_CODE, UNIT_CODE, COMPOSITE_DIM_CODE,
                                 DIM_SOURCE, DIM_DETEAIL_ID,CREATE_TIME,UPDATE_TIME)
                                 values (str_id||to_char(sysdate,'yyyyMMddHHmmSS')||to_char(num_id),
                                 tempIndexId, varIndexDimen.DIM_CODE,
                                 varIndexDimen.DIM_DETAIL_CODE, varIndexDimen.UNIT_CODE,
                                 varIndexDimen.COMPOSITE_DIM_CODE, varIndexDimen.DIM_SOURCE,
                                 varIndexDimen.DIM_DETEAIL_ID ,sysdate,sysdate);
                          num_id := num_id+1;
                     end loop;
                     commit;
                     --报表指标关联
                     insert into E7_STA_RPT_INDEX_INST ( REPINST_ID, STA_INDEX_INST_ID ,CREATE_TIME,UPDATE_TIME)
                                 values (tempRepinstId,tempIndexId ,sysdate,sysdate);
                     commit;
                     num_id := num_id+1;
               end loop;
               --外层条件循环结束
           end loop;
       end loop;
   end loop;
   null;
end;
/

