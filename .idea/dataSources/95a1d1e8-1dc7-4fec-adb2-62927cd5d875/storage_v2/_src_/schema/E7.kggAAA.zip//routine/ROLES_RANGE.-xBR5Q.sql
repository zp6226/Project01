CREATE PROCEDURE roles_range
as
  total number;
  mytotal number;
  hasnum number :=0 ;
  flag number :=0 ;
  rname_1 varchar(100);
  rname_2 varchar(100);
  cursor c_roles
    is select distinct lianxi.role_id role_id  from e7_sys_role_res lianxi 
    where  lianxi.role_id in(select e7_sys_role.role_id from e7_sys_role where e7_sys_role.role_type='01' and e7_sys_role.modual='Y01');
  cursor c_roles_1
    is select distinct lianxi.role_id role_id  from e7_sys_role_res lianxi
      where  lianxi.role_id in(select e7_sys_role.role_id from e7_sys_role where e7_sys_role.role_type='01' and e7_sys_role.modual='Y01');
  cursor c_res (id number)
    is select lianxi.res_id res_id  from e7_sys_role_res lianxi where lianxi.role_id=id;
BEGIN
    DBMS_OUTPUT.ENABLE (buffer_size=>null); 
    FOR rol_1 IN c_roles()LOOP
       select count(1) into total from e7_sys_role_res lianxi  where lianxi.role_id=rol_1.role_id;
       for rol_2 in c_roles_1()LOOP
         IF (rol_1.role_id !=rol_2.role_id)
         then
           select count(1) into mytotal from e7_sys_role_res lianxi  where lianxi.role_id=rol_2.role_id;
           for res in c_res(rol_2.role_id)LOOP
             select count(1) into flag  from e7_sys_role_res lianxi where lianxi.role_id=rol_1.role_id and lianxi.res_id=res.res_id;
             IF  flag>0
              then hasnum :=hasnum+1;flag:=0;
              else flag:=0;
             END IF;
           END LOOP;
           IF (hasnum=total)
           then 
             select r.role_name into rname_2 from e7_sys_role r where r.role_id=rol_2.role_id;
             select r.role_name into rname_1 from e7_sys_role r where r.role_id=rol_1.role_id;
             IF (total=mytotal)
               THEN 
                dbms_output.put_line(rol_2.role_id||':'||rname_2||'等于'||rol_1.role_id||':'||rname_1);
               ELSE
                dbms_output.put_line(rol_2.role_id||':'||rname_2||'包含'||rol_1.role_id||':'||rname_2);
             END IF;
           END IF;
           hasnum:=0;
         END IF;   
       END LOOP;
       total:=0;
    END LOOP;
END;
/

