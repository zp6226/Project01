CREATE procedure pro1(ORGID in varchar2)
begin
  while ORGID <6 do
    select * from e7_sys_org t order by t.org_id;
end while;
end;
/

