CREATE VIEW V_E7_SYS_ORG_AUTH AS
  select org.org_id org_id,org.org_id_str org_id_str
  from e7_sys_role_org rg, e7_sys_org org ,e7_sys_role ro
  where  rg.role_id= ro.role_id and rg.org_id=org.org_id and ro.role_type='02' and ro.status_code='02' and org.status_code='02'
/

