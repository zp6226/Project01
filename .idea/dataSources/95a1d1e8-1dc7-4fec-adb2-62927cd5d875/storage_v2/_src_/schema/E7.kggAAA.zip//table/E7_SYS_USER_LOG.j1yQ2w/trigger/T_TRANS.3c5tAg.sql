CREATE TRIGGER T_TRANS
  BEFORE INSERT
  ON E7_SYS_USER_LOG
  begin
  update e7_sys_user_log set user_action='success' where user_action='failed';
end t_trans;
/

