CREATE PACKAGE DataTrans IS

  -- Author  : 黄志威
  -- Created : 2014/3/6 17:35:11
  -- Purpose : E7用户数据经处理后，保存到int用户，供Cognos表查询。

  PROCEDURE DataTransREPINST(P_RPTYEAR  IN VARCHAR2,
                             P_RPTMONTH IN VARCHAR2,
                             P_RPTCODE  IN VARCHAR2);
  PROCEDURE DataTransRPTINDEXINST(P_RPTYEAR  IN VARCHAR2,
                                  P_RPTMONTH IN VARCHAR2,
                                  P_RPTCODE  IN VARCHAR2);
  PROCEDURE DataTransINDEXINST(P_RPTYEAR  IN VARCHAR2,
                               P_RPTMONTH IN VARCHAR2,
                               P_RPTCODE  IN VARCHAR2);
  PROCEDURE DataTransINDEXINSTDIMEN(P_RPTYEAR  IN VARCHAR2,
                                    P_RPTMONTH IN VARCHAR2,
                                    P_RPTCODE  IN VARCHAR2);
  PROCEDURE DELDATASXNNW(P_RPTCODE  IN VARCHAR2,
                         P_RPTYEAR  IN VARCHAR2,
                         P_RPTMONTH IN VARCHAR2);
END DataTrans;
/

