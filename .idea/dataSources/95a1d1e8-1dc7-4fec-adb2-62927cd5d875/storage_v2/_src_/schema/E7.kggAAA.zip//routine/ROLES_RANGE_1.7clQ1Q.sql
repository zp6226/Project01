CREATE PROCEDURE roles_range_1
as
  total number;
  hasnum number :=1 ;
  flag number;
  cursor c_roles
    is select distinct lianxi.role_id role_id  from e7_sys_role_res lianxi;
  cursor c_roles_1
    is select distinct lianxi.role_id role_id  from e7_sys_role_res lianxi;
  cursor c_res (role_id number)
    is select lianxi.res_id res_id  from e7_sys_role_res lianxi where lianxi.role_id=role_id;
BEGIN
       select count(1) into total from e7_sys_role_res lianxi  where lianxi.role_id=100;
       for rol_2 in c_roles_1()LOOP
         for res in c_res(rol_2.role_id)LOOP
           select count(1) into flag  from e7_sys_role_res lianxi where lianxi.role_id=100 and lianxi.res_id=res.res_id;
           IF  flag>0
            then hasnum :=hasnum+1;
           END IF;
         END LOOP;
         IF (hasnum=total)
         then dbms_output.put_line(rol_2.role_id||'包含');
         END IF;
       END LOOP;
END;
/

