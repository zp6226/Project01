CREATE PACKAGE BODY DataRUNXNNWTOC0127 IS
FUNCTION ISAUTH(P_RPTORGID IN VARCHAR2)
  return   number is
  authresult number(10);
  begin
   authresult:=0;
   SELECT count(1) into authresult  FROM E7_STA_RPT_AUTH AUTH WHERE 'C0127' = auth.report_code and P_RPTORGID= auth.org_id ;
   return authresult;
  end;
FUNCTION JUDGESTATUS(P_RPTYEAR  IN VARCHAR2,
                     P_RPTMONTH IN VARCHAR2,
                     P_RPTORGID IN VARCHAR2)
return   number is
statusResult number(2);
begin
  statusResult:=0;
  SELECT COUNT(1)  into statusResult FROM e7_sta_repinst repinst
  WHERE repinst.report_year= P_RPTYEAR and repinst.report_month=P_RPTMONTH
        and repinst.report_code='C0127' and repinst.org_id=P_RPTORGID
        and (repinst.status='03'or repinst.status='05');
 return statusResult;
end;
PROCEDURE DELDATAXNNW( P_RPTYEAR  IN VARCHAR2,
                       P_RPTMONTH IN VARCHAR2,
                       P_RPTORGID IN VARCHAR2) AS
BEGIN
  delete from e7_sta_index_inst_dimen
   where sta_index_inst_id in
         (select sta_index_inst_id
            from e7_sta_index_inst
           where sta_index_inst_id in
                 (select sta_index_inst_id
                    from e7_sta_rpt_index_inst
                   where repinst_id in
                         (select repinst_id
                            from e7_sta_repinst
                           where report_code =  'C0127'
                             and org_id = P_RPTORGID
                             and report_year = P_RPTYEAR
                             and report_month = P_RPTMONTH
                             and STATUS in ('02','04'))
                     ) );
  COMMIT;

  delete from e7_sta_index_inst
   where sta_index_inst_id in
         (select sta_index_inst_id
            from e7_sta_rpt_index_inst
           where repinst_id in
                 (select repinst_id
                    from e7_sta_repinst
                   where report_code =  'C0127'
                     and org_id = P_RPTORGID
                     and report_year = P_RPTYEAR
                     and report_month = P_RPTMONTH
                     and STATUS in ('02','04'))
             );
  COMMIT;
  delete from e7_sta_rpt_index_inst
   where repinst_id in (select repinst_id
                          from e7_sta_repinst
                         where report_code = 'C0127'
                           and org_id = P_RPTORGID
                           and report_year = P_RPTYEAR
                           and report_month = P_RPTMONTH
                           and STATUS in ('02','04'));
  COMMIT;
  delete from e7_sta_repinst
        where report_code = 'C0127'
         and org_id = P_RPTORGID
         and report_year = P_RPTYEAR
         and report_month = P_RPTMONTH
         and STATUS in ('02','04') ;

  COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
END;

PROCEDURE DataM_RUNXNNW01(
  P_RPTCODE  IN VARCHAR2,
   P_RPTYEAR IN VARCHAR2,
     P_RPTMONTH IN VARCHAR2,
     P_RPTORGID IN VARCHAR2,
     P_RPTUSERNAME IN VARCHAR2)  AS
  CURSOR REPINDEXINST IS
  SELECT
    distinct sta_index_inst_id,
    repinst_id,
    sysdate create_time,
    sysdate update_time
  FROM ( select  'TRANSC0127'|| P_RPTORGID|| P_RPTYEAR|| P_RPTMONTH as repinst_id,repinst.org_id,
            max(replace(rptindexinst.sta_index_inst_id,P_RPTCODE,'C0127')|| P_RPTORGID|| P_RPTYEAR|| P_RPTMONTH) as sta_index_inst_id,
            sum(indexinst.index_value) ,
            indexinst.index_code,
            indexinst.unit_code,
            max(replace(dimeninst.repinst_dtl_dimen,P_RPTCODE,'C0127')|| P_RPTORGID|| P_RPTYEAR|| P_RPTMONTH)   as repinst_dtl_dimen,
            dimeninst.dim_code              as dim_code,
            dimeninst.dim_detail_code       as dim_detail_code,
            max(replace(dimeninst1.repinst_dtl_dimen,P_RPTCODE,'C0127')|| P_RPTORGID|| P_RPTYEAR|| P_RPTMONTH||'2')    as repinst_dtl_dimen1,
            dimeninst1.dim_code             as dim_code1,
            dimeninst1.dim_detail_code      as dim_detail_code1
        from e7_sta_repinst repinst
             left join e7_sta_rpt_index_inst  rptindexinst on repinst.repinst_id=rptindexinst.repinst_id
             left join e7_sta_index_inst indexinst on rptindexinst.sta_index_inst_id=indexinst.sta_index_inst_id
             left join e7_sta_index_inst_dimen dimeninst on indexinst.sta_index_inst_id=dimeninst.sta_index_inst_id and dimeninst.dim_code='Industry_type'
             left join e7_sta_index_inst_dimen dimeninst1 on indexinst.sta_index_inst_id=dimeninst1.sta_index_inst_id and dimeninst1.dim_code='Cru_oil_E_cons_typ'
             left join e7_sta_index_inst_dimen dimeninst2 on indexinst.sta_index_inst_id=dimeninst2.sta_index_inst_id and dimeninst2.dim_code='Custom_dimen_first'
             left join e7_sta_index_inst_dimen dimeninst3 on indexinst.sta_index_inst_id=dimeninst3.sta_index_inst_id and dimeninst3.dim_code='Custom_dimen_second'
        where repinst.report_code=P_RPTCODE
              and repinst.org_id =   P_RPTORGID
              and repinst.report_year =   P_RPTYEAR
              and repinst.report_month < =P_RPTMONTH
              and (dimeninst2.dim_detail_code not in ('Transportation_amount_G','Transportation_amount_D') or dimeninst2.dim_detail_code is null)
              and( dimeninst3.dim_detail_code <> 'Material_own_amount_N' or  dimeninst3.dim_detail_code is null)
              and(( dimeninst1.dim_detail_code <> 'Underground_water'and dimeninst1.dim_detail_code <> 'Tap_water' and dimeninst1.dim_detail_code <> 'Surface_water' )or dimeninst1.dim_detail_code is null)
              and indexinst.index_code in ('Engy_csmp_amt_pratl',
                                            'Comph_engy_csmp_amt',
                                            'Fresh_water_consu_amt')
              AND INDEXINST.COMPOSITED_INDEX_CODE = P_RPTORGID
        group by repinst.org_id,
              indexinst.index_code,
              indexinst.unit_code,
              dimeninst.dim_code,
              dimeninst.dim_detail_code,
              dimeninst1.dim_code,
              dimeninst1.dim_detail_code
        UNION ALL
        --综合能源消耗
        select   'TRANSC0127'|| P_RPTORGID|| P_RPTYEAR|| P_RPTMONTH as repinst_id,repinst.org_id,
              max(replace(indexinst.sta_index_inst_id,P_RPTCODE,'C0127') || P_RPTYEAR|| P_RPTMONTH||'CO') sta_index_inst_id,
              sum(indexinst.index_value*stadc.param_value) index_value ,
              'Comph_engy_csmp_amt' as index_code,
              null as unit_code,
              max(replace(dimeninst.repinst_dtl_dimen,P_RPTCODE,'C0127') || P_RPTYEAR|| P_RPTMONTH||'CO')   as repinst_dtl_dimen,
              dimeninst.dim_code              as dim_code,
              dimeninst.dim_detail_code       as dim_detail_code,
              null    as repinst_dtl_dimen1,
              null        as dim_code1,
              null    as dim_detail_code1
        from e7_sta_repinst repinst
             left join e7_sta_rpt_index_inst  rptindexinst on repinst.repinst_id=rptindexinst.repinst_id
             left join e7_sta_index_inst indexinst on rptindexinst.sta_index_inst_id=indexinst.sta_index_inst_id
             left join e7_sta_index_inst_dimen dimeninst on indexinst.sta_index_inst_id=dimeninst.sta_index_inst_id and dimeninst.dim_code='Industry_type'
             left join e7_sta_index_inst_dimen dimeninst1 on indexinst.sta_index_inst_id=dimeninst1.sta_index_inst_id and dimeninst1.dim_code='Cru_oil_E_cons_typ'
             left join e7_sta_index_inst_dimen dimeninst2 on indexinst.sta_index_inst_id=dimeninst2.sta_index_inst_id and dimeninst2.dim_code='Custom_dimen_first'
             left join e7_sta_index_inst_dimen dimeninst3 on indexinst.sta_index_inst_id=dimeninst3.sta_index_inst_id and dimeninst3.dim_code='Custom_dimen_second'
             left join (
                        select dim_detail_code,param_value from e7_sta_base_param where dim_code = 'Orig_energy_type'and param_type_code = '02' and dim_detail_code in (
                          select dim_detail_code from e7_sta_rep_index_dimen where report_code = P_RPTCODE and dim_code = 'Cru_oil_E_cons_typ'
                          ) and org_id = 1
                   ) stadc on dimeninst1.dim_detail_code = stadc.dim_detail_code
        where repinst.report_code=P_RPTCODE
              and repinst.org_id =   P_RPTORGID
              and repinst.report_year =   P_RPTYEAR
              and repinst.report_month < = P_RPTMONTH
              AND INDEXINST.COMPOSITED_INDEX_CODE = P_RPTORGID
              and indexinst.index_code in ('Engy_csmp_amt_pratl')
              and (dimeninst2.dim_detail_code not in ('Transportation_amount_G','Transportation_amount_D') or dimeninst2.dim_detail_code is null)
              and(( dimeninst1.dim_detail_code <> 'Underground_water'and dimeninst1.dim_detail_code <> 'Tap_water' and dimeninst1.dim_detail_code <> 'Surface_water' )or dimeninst1.dim_detail_code is null)
         group by repinst.org_id,
              dimeninst.dim_code ,
              dimeninst.dim_detail_code
        --新鲜水
        union all
        select   'TRANSC0127'|| P_RPTORGID|| P_RPTYEAR|| P_RPTMONTH as repinst_id,repinst.org_id,
              max(replace(indexinst.sta_index_inst_id,P_RPTCODE,'C0127')|| P_RPTYEAR|| P_RPTMONTH||'FW') sta_index_inst_id,
              sum(indexinst.index_value) index_value ,
              'Fresh_water_consu_amt' as index_code,
              null as unit_code,
              max(replace(dimeninst.repinst_dtl_dimen,P_RPTCODE,'C0127')|| P_RPTYEAR|| P_RPTMONTH||'FW')   as repinst_dtl_dimen,
              dimeninst.dim_code              as dim_code,
              dimeninst.dim_detail_code       as dim_detail_code,
              null    as repinst_dtl_dimen1,
              null        as dim_code1,
              null    as dim_detail_code1
        from e7_sta_repinst repinst
             left join e7_sta_rpt_index_inst  rptindexinst on repinst.repinst_id=rptindexinst.repinst_id
             left join e7_sta_index_inst indexinst on rptindexinst.sta_index_inst_id=indexinst.sta_index_inst_id
             left join e7_sta_index_inst_dimen dimeninst on indexinst.sta_index_inst_id=dimeninst.sta_index_inst_id and dimeninst.dim_code='Industry_type'
             left join e7_sta_index_inst_dimen dimeninst1 on indexinst.sta_index_inst_id=dimeninst1.sta_index_inst_id and dimeninst1.dim_code='Cru_oil_E_cons_typ'
             left join e7_sta_index_inst_dimen dimeninst2 on indexinst.sta_index_inst_id=dimeninst2.sta_index_inst_id and dimeninst2.dim_code='Custom_dimen_first'
             left join e7_sta_index_inst_dimen dimeninst3 on indexinst.sta_index_inst_id=dimeninst3.sta_index_inst_id and dimeninst3.dim_code='Custom_dimen_second'
        where repinst.report_code=P_RPTCODE
              and repinst.org_id =   P_RPTORGID
              and repinst.report_year =   P_RPTYEAR
              and repinst.report_month < = P_RPTMONTH
              and indexinst.index_code in ('Engy_csmp_amt_pratl')
              AND INDEXINST.COMPOSITED_INDEX_CODE = P_RPTORGID
              and( dimeninst1.dim_detail_code = 'Underground_water'or dimeninst1.dim_detail_code = 'Tap_water' or dimeninst1.dim_detail_code= 'Surface_water' )
         group by repinst.org_id,
              dimeninst.dim_code ,
              dimeninst.dim_detail_code

      ) ;
   CURSOR indexinst IS
        SELECT
          sta_index_inst_id,
          index_code,
          P_RPTORGID org_id,
          P_RPTYEAR report_year,
          null report_quarter,
          P_RPTMONTH report_month,
          3 report_frequent_code,
          index_value index_value,
          null unit_code,
          null remark,
          null index_inst_orderno,
          P_RPTORGID composited_index_code,
          sysdate create_time,
          sysdate UPDATE_time
        FROM ( select   'TRANSC0127'|| P_RPTORGID|| P_RPTYEAR|| P_RPTMONTH as repinst_id,repinst.org_id,
                  max(replace(rptindexinst.sta_index_inst_id,P_RPTCODE,'C0127')|| P_RPTORGID|| P_RPTYEAR|| P_RPTMONTH) as sta_index_inst_id,
                  sum(indexinst.index_value) index_value ,
                  indexinst.index_code,
                  indexinst.unit_code,
                  max(replace(dimeninst.repinst_dtl_dimen,P_RPTCODE,'C0127')|| P_RPTORGID|| P_RPTYEAR|| P_RPTMONTH)   as repinst_dtl_dimen,
                  dimeninst.dim_code              as dim_code,
                  dimeninst.dim_detail_code       as dim_detail_code,
                  max(replace(dimeninst1.repinst_dtl_dimen,P_RPTCODE,'C0127')|| P_RPTORGID|| P_RPTYEAR|| P_RPTMONTH||'2')    as repinst_dtl_dimen1,
                  dimeninst1.dim_code             as dim_code1,
                  dimeninst1.dim_detail_code      as dim_detail_code1
              from e7_sta_repinst repinst
                   left join e7_sta_rpt_index_inst  rptindexinst on repinst.repinst_id=rptindexinst.repinst_id
                   left join e7_sta_index_inst indexinst on rptindexinst.sta_index_inst_id=indexinst.sta_index_inst_id
                   left join e7_sta_index_inst_dimen dimeninst on indexinst.sta_index_inst_id=dimeninst.sta_index_inst_id and dimeninst.dim_code='Industry_type'
                   left join e7_sta_index_inst_dimen dimeninst1 on indexinst.sta_index_inst_id=dimeninst1.sta_index_inst_id and dimeninst1.dim_code='Cru_oil_E_cons_typ'
                   left join e7_sta_index_inst_dimen dimeninst2 on indexinst.sta_index_inst_id=dimeninst2.sta_index_inst_id and dimeninst2.dim_code='Custom_dimen_first'
                   left join e7_sta_index_inst_dimen dimeninst3 on indexinst.sta_index_inst_id=dimeninst3.sta_index_inst_id and dimeninst3.dim_code='Custom_dimen_second'
              where repinst.report_code=P_RPTCODE
                    and repinst.org_id =   P_RPTORGID
                    and repinst.report_year =   P_RPTYEAR
                    and repinst.report_month < =P_RPTMONTH
                    and (dimeninst2.dim_detail_code not in ('Transportation_amount_G','Transportation_amount_D') or dimeninst2.dim_detail_code is null)
                    and( dimeninst3.dim_detail_code not like 'Material_own_amount_N' or  dimeninst3.dim_detail_code is null)
                    and(( dimeninst1.dim_detail_code <> 'Underground_water'and dimeninst1.dim_detail_code <> 'Tap_water' and dimeninst1.dim_detail_code <> 'Surface_water' )or dimeninst1.dim_detail_code is null)
                    and indexinst.index_code in ('Engy_csmp_amt_pratl',
                                                  'Comph_engy_csmp_amt',
                                                  'Fresh_water_consu_amt')
                                                   AND INDEXINST.COMPOSITED_INDEX_CODE = P_RPTORGID
               group by repinst.org_id,
                      indexinst.index_code,
                      indexinst.unit_code,
                      dimeninst.dim_code,
                      dimeninst.dim_detail_code,
                      dimeninst1.dim_code,
                      dimeninst1.dim_detail_code
               UNION ALL
                --综合能源消耗
                select   'TRANSC0127'|| P_RPTORGID|| P_RPTYEAR|| P_RPTMONTH as repinst_id,repinst.org_id,
                      max(replace(indexinst.sta_index_inst_id,P_RPTCODE,'C0127') || P_RPTYEAR|| P_RPTMONTH||'CO') sta_index_inst_id,
                      sum(indexinst.index_value*stadc.param_value) index_value ,
                      'Comph_engy_csmp_amt' as index_code,
                      null as unit_code,
                      max(replace(dimeninst.repinst_dtl_dimen,P_RPTCODE,'C0127') || P_RPTYEAR|| P_RPTMONTH||'CO')   as repinst_dtl_dimen,
                      dimeninst.dim_code              as dim_code,
                      dimeninst.dim_detail_code       as dim_detail_code,
                      null    as repinst_dtl_dimen1,
                      null        as dim_code1,
                      null    as dim_detail_code1
                from e7_sta_repinst repinst
                     left join e7_sta_rpt_index_inst  rptindexinst on repinst.repinst_id=rptindexinst.repinst_id
                     left join e7_sta_index_inst indexinst on rptindexinst.sta_index_inst_id=indexinst.sta_index_inst_id
                     left join e7_sta_index_inst_dimen dimeninst on indexinst.sta_index_inst_id=dimeninst.sta_index_inst_id and dimeninst.dim_code='Industry_type'
                     left join e7_sta_index_inst_dimen dimeninst1 on indexinst.sta_index_inst_id=dimeninst1.sta_index_inst_id and dimeninst1.dim_code='Cru_oil_E_cons_typ'
                     left join e7_sta_index_inst_dimen dimeninst2 on indexinst.sta_index_inst_id=dimeninst2.sta_index_inst_id and dimeninst2.dim_code='Custom_dimen_first'
                     left join e7_sta_index_inst_dimen dimeninst3 on indexinst.sta_index_inst_id=dimeninst3.sta_index_inst_id and dimeninst3.dim_code='Custom_dimen_second'
                     left join (
                                select dim_detail_code,param_value from e7_sta_base_param where dim_code = 'Orig_energy_type'and param_type_code = '02' and dim_detail_code in (
                                  select dim_detail_code from e7_sta_rep_index_dimen where report_code = P_RPTCODE and dim_code = 'Cru_oil_E_cons_typ'
                                  ) and org_id = 1
                           ) stadc on dimeninst1.dim_detail_code = stadc.dim_detail_code
                where repinst.report_code=P_RPTCODE
                      and repinst.org_id =   P_RPTORGID
                      and repinst.report_year =   P_RPTYEAR
                      and repinst.report_month <= P_RPTMONTH
                      and indexinst.index_code in ('Engy_csmp_amt_pratl')
                       AND INDEXINST.COMPOSITED_INDEX_CODE = P_RPTORGID
                       and (dimeninst2.dim_detail_code not in ('Transportation_amount_G','Transportation_amount_D') or dimeninst2.dim_detail_code is null)
                      and(( dimeninst1.dim_detail_code <> 'Underground_water'and dimeninst1.dim_detail_code <> 'Tap_water' and dimeninst1.dim_detail_code <> 'Surface_water' )or dimeninst1.dim_detail_code is null)
                 group by repinst.org_id,
                      dimeninst.dim_code ,
                      dimeninst.dim_detail_code
                --新鲜水
                union all
                select   'TRANSC0127'|| P_RPTORGID|| P_RPTYEAR|| P_RPTMONTH as repinst_id,repinst.org_id,
                      max(replace(indexinst.sta_index_inst_id,P_RPTCODE,'C0127')|| P_RPTYEAR|| P_RPTMONTH||'FW') sta_index_inst_id,
                      sum(indexinst.index_value) index_value ,
                      'Fresh_water_consu_amt' as index_code,
                      null as unit_code,
                      max(replace(dimeninst.repinst_dtl_dimen,P_RPTCODE,'C0127')|| P_RPTYEAR|| P_RPTMONTH||'FW')   as repinst_dtl_dimen,
                      dimeninst.dim_code              as dim_code,
                      dimeninst.dim_detail_code       as dim_detail_code,
                      null    as repinst_dtl_dimen1,
                      null        as dim_code1,
                      null    as dim_detail_code1
                from e7_sta_repinst repinst
                     left join e7_sta_rpt_index_inst  rptindexinst on repinst.repinst_id=rptindexinst.repinst_id
                     left join e7_sta_index_inst indexinst on rptindexinst.sta_index_inst_id=indexinst.sta_index_inst_id
                     left join e7_sta_index_inst_dimen dimeninst on indexinst.sta_index_inst_id=dimeninst.sta_index_inst_id and dimeninst.dim_code='Industry_type'
                     left join e7_sta_index_inst_dimen dimeninst1 on indexinst.sta_index_inst_id=dimeninst1.sta_index_inst_id and dimeninst1.dim_code='Cru_oil_E_cons_typ'
                     left join e7_sta_index_inst_dimen dimeninst2 on indexinst.sta_index_inst_id=dimeninst2.sta_index_inst_id and dimeninst2.dim_code='Custom_dimen_first'
                     left join e7_sta_index_inst_dimen dimeninst3 on indexinst.sta_index_inst_id=dimeninst3.sta_index_inst_id and dimeninst3.dim_code='Custom_dimen_second'
                where repinst.report_code=P_RPTCODE
                      and repinst.org_id =   P_RPTORGID
                      and repinst.report_year =   P_RPTYEAR
                      and repinst.report_month < = P_RPTMONTH
                      and indexinst.index_code in ('Engy_csmp_amt_pratl')
                      AND INDEXINST.COMPOSITED_INDEX_CODE = P_RPTORGID
                      and( dimeninst1.dim_detail_code = 'Underground_water'or dimeninst1.dim_detail_code = 'Tap_water' or dimeninst1.dim_detail_code= 'Surface_water' )
                 group by repinst.org_id,
                      dimeninst.dim_code ,
                      dimeninst.dim_detail_code

             ) ;
   CURSOR indexinstdimen IS
        SELECT repinst_dtl_dimen,
        sta_index_inst_id,
        dim_code,
        dim_detail_code,
        dim_source,
        dim_deteail_id,
        dim_deteail_id2,
        unit_code,
        composite_dim_code,
        create_time,
        update_time
        FROM (
          SELECT
            repinst_dtl_dimen repinst_dtl_dimen,
            sta_index_inst_id,
            dim_code dim_code,
            dim_detail_code dim_detail_code,
            null dim_source,
            null dim_deteail_id,
            null dim_deteail_id2,
            null unit_code,
            P_RPTORGID composite_dim_code ,
            sysdate create_time,
            sysdate update_time
          FROM ( select   'TRANSC0127'|| P_RPTORGID|| P_RPTYEAR|| P_RPTMONTH as repinst_id,repinst.org_id,
                    max(replace(rptindexinst.sta_index_inst_id,P_RPTCODE,'C0127')|| P_RPTORGID|| P_RPTYEAR|| P_RPTMONTH) as sta_index_inst_id,
                    sum(indexinst.index_value) ,
                    indexinst.index_code,
                    indexinst.unit_code,
                    max(replace(dimeninst.repinst_dtl_dimen,P_RPTCODE,'C0127')|| P_RPTORGID|| P_RPTYEAR|| P_RPTMONTH)   as repinst_dtl_dimen,
                    dimeninst.dim_code              as dim_code,
                    dimeninst.dim_detail_code       as dim_detail_code,
                    max(replace(dimeninst1.repinst_dtl_dimen,P_RPTCODE,'C0127')|| P_RPTORGID|| P_RPTYEAR|| P_RPTMONTH||'2')    as repinst_dtl_dimen1,
                    'Orig_energy_type'             as dim_code1,
                    dimeninst1.dim_detail_code      as dim_detail_code1
                from e7_sta_repinst repinst
                     left join e7_sta_rpt_index_inst  rptindexinst on repinst.repinst_id=rptindexinst.repinst_id
                     left join e7_sta_index_inst indexinst on rptindexinst.sta_index_inst_id=indexinst.sta_index_inst_id
                     left join e7_sta_index_inst_dimen dimeninst on indexinst.sta_index_inst_id=dimeninst.sta_index_inst_id and dimeninst.dim_code='Industry_type'
                     left join e7_sta_index_inst_dimen dimeninst1 on indexinst.sta_index_inst_id=dimeninst1.sta_index_inst_id and dimeninst1.dim_code='Cru_oil_E_cons_typ'
                     left join e7_sta_index_inst_dimen dimeninst2 on indexinst.sta_index_inst_id=dimeninst2.sta_index_inst_id and dimeninst2.dim_code='Custom_dimen_first'
                     left join e7_sta_index_inst_dimen dimeninst3 on indexinst.sta_index_inst_id=dimeninst3.sta_index_inst_id and dimeninst3.dim_code='Custom_dimen_second'
                where repinst.report_code=P_RPTCODE
                      and repinst.org_id =   P_RPTORGID
                      and repinst.report_year =   P_RPTYEAR
                      and repinst.report_month < = P_RPTMONTH
                      and (dimeninst2.dim_detail_code not in ('Transportation_amount_G','Transportation_amount_D') or dimeninst2.dim_detail_code is null)
                      and( dimeninst3.dim_detail_code not like 'Material_own_amount_N' or  dimeninst3.dim_detail_code is null)
                      and(( dimeninst1.dim_detail_code <> 'Underground_water'and dimeninst1.dim_detail_code <> 'Tap_water' and dimeninst1.dim_detail_code <> 'Surface_water' )or dimeninst1.dim_detail_code is null)
                      and indexinst.index_code in ('Engy_csmp_amt_pratl',
                                                    'Comph_engy_csmp_amt',
                                                    'Fresh_water_consu_amt')
                                                     AND INDEXINST.COMPOSITED_INDEX_CODE = P_RPTORGID
                  group by repinst.org_id,
                    indexinst.index_code,
                    indexinst.unit_code,
                    dimeninst.dim_code,
                    dimeninst.dim_detail_code,
                    dimeninst1.dim_code,
                    dimeninst1.dim_detail_code
                    UNION ALL
                --综合能源消耗
                select   'TRANSC0127'|| P_RPTORGID|| P_RPTYEAR|| P_RPTMONTH as repinst_id,repinst.org_id,
                      max(replace(indexinst.sta_index_inst_id,P_RPTCODE,'C0127') || P_RPTYEAR|| P_RPTMONTH||'CO') sta_index_inst_id,
                      sum(indexinst.index_value*stadc.param_value) index_value ,
                      'Comph_engy_csmp_amt' as index_code,
                      null as unit_code,
                      max(replace(dimeninst.repinst_dtl_dimen,P_RPTCODE,'C0127') || P_RPTYEAR|| P_RPTMONTH||'CO')   as repinst_dtl_dimen,
                      dimeninst.dim_code              as dim_code,
                      dimeninst.dim_detail_code       as dim_detail_code,
                      null    as repinst_dtl_dimen1,
                      null        as dim_code1,
                      null    as dim_detail_code1
                from e7_sta_repinst repinst
                     left join e7_sta_rpt_index_inst  rptindexinst on repinst.repinst_id=rptindexinst.repinst_id
                     left join e7_sta_index_inst indexinst on rptindexinst.sta_index_inst_id=indexinst.sta_index_inst_id
                     left join e7_sta_index_inst_dimen dimeninst on indexinst.sta_index_inst_id=dimeninst.sta_index_inst_id and dimeninst.dim_code='Industry_type'
                     left join e7_sta_index_inst_dimen dimeninst1 on indexinst.sta_index_inst_id=dimeninst1.sta_index_inst_id and dimeninst1.dim_code='Cru_oil_E_cons_typ'
                     left join e7_sta_index_inst_dimen dimeninst2 on indexinst.sta_index_inst_id=dimeninst2.sta_index_inst_id and dimeninst2.dim_code='Custom_dimen_first'
                     left join e7_sta_index_inst_dimen dimeninst3 on indexinst.sta_index_inst_id=dimeninst3.sta_index_inst_id and dimeninst3.dim_code='Custom_dimen_second'
                     left join (
                                select dim_detail_code,param_value from e7_sta_base_param where dim_code = 'Orig_energy_type'and param_type_code = '02' and dim_detail_code in (
                                  select dim_detail_code from e7_sta_rep_index_dimen where report_code = P_RPTCODE and dim_code = 'Cru_oil_E_cons_typ'
                                  ) and org_id = 1
                           ) stadc on dimeninst1.dim_detail_code = stadc.dim_detail_code
                where repinst.report_code=P_RPTCODE
                      and repinst.org_id =   P_RPTORGID
                      and repinst.report_year =   P_RPTYEAR
                     and repinst.report_month < = P_RPTMONTH
                      and indexinst.index_code in ('Engy_csmp_amt_pratl')
                       AND INDEXINST.COMPOSITED_INDEX_CODE = P_RPTORGID
                       and (dimeninst2.dim_detail_code not in ('Transportation_amount_G','Transportation_amount_D') or dimeninst2.dim_detail_code is null)
                      and(( dimeninst1.dim_detail_code <> 'Underground_water'and dimeninst1.dim_detail_code <> 'Tap_water' and dimeninst1.dim_detail_code <> 'Surface_water' )or dimeninst1.dim_detail_code is null)
                 group by repinst.org_id,
                      dimeninst.dim_code ,
                      dimeninst.dim_detail_code
                --新鲜水
                union all
                select   'TRANSC0127'|| P_RPTORGID|| P_RPTYEAR|| P_RPTMONTH as repinst_id ,repinst.org_id,
                      max(replace(indexinst.sta_index_inst_id,P_RPTCODE,'C0127')|| P_RPTYEAR|| P_RPTMONTH||'FW') sta_index_inst_id,
                      sum(indexinst.index_value) index_value ,
                      'Fresh_water_consu_amt' as index_code,
                      null as unit_code,
                      max(replace(dimeninst.repinst_dtl_dimen,P_RPTCODE,'C0127')|| P_RPTYEAR|| P_RPTMONTH||'FW')   as repinst_dtl_dimen,
                      dimeninst.dim_code              as dim_code,
                      dimeninst.dim_detail_code       as dim_detail_code,
                      null    as repinst_dtl_dimen1,
                      null        as dim_code1,
                      null    as dim_detail_code1
                from e7_sta_repinst repinst
                     left join e7_sta_rpt_index_inst  rptindexinst on repinst.repinst_id=rptindexinst.repinst_id
                     left join e7_sta_index_inst indexinst on rptindexinst.sta_index_inst_id=indexinst.sta_index_inst_id
                     left join e7_sta_index_inst_dimen dimeninst on indexinst.sta_index_inst_id=dimeninst.sta_index_inst_id and dimeninst.dim_code='Industry_type'
                     left join e7_sta_index_inst_dimen dimeninst1 on indexinst.sta_index_inst_id=dimeninst1.sta_index_inst_id and dimeninst1.dim_code='Cru_oil_E_cons_typ'
                     left join e7_sta_index_inst_dimen dimeninst2 on indexinst.sta_index_inst_id=dimeninst2.sta_index_inst_id and dimeninst2.dim_code='Custom_dimen_first'
                     left join e7_sta_index_inst_dimen dimeninst3 on indexinst.sta_index_inst_id=dimeninst3.sta_index_inst_id and dimeninst3.dim_code='Custom_dimen_second'
                where repinst.report_code=P_RPTCODE
                      and repinst.org_id =   P_RPTORGID
                      and repinst.report_year =   P_RPTYEAR
                      and repinst.report_month < = P_RPTMONTH
                      and indexinst.index_code in ('Engy_csmp_amt_pratl')
                      AND INDEXINST.COMPOSITED_INDEX_CODE = P_RPTORGID
                      and( dimeninst1.dim_detail_code = 'Underground_water'or dimeninst1.dim_detail_code = 'Tap_water' or dimeninst1.dim_detail_code= 'Surface_water' )
                 group by repinst.org_id,
                      dimeninst.dim_code ,
                      dimeninst.dim_detail_code
              )
        )
       WHERE repinst_dtl_dimen is not null
       union all
       SELECT repinst_dtl_dimen,
        sta_index_inst_id,
        dim_code,
        dim_detail_code,
        dim_source,
        dim_deteail_id,
        dim_deteail_id2,
        unit_code,
        composite_dim_code,
        create_time,
        update_time
        FROM (
          SELECT
            repinst_dtl_dimen1 repinst_dtl_dimen,
            sta_index_inst_id,
            dim_code1 dim_code,
            dim_detail_code1 dim_detail_code,
            null dim_source,
            null dim_deteail_id,
            null dim_deteail_id2,
            null unit_code,
            P_RPTORGID composite_dim_code ,
            sysdate create_time,
            sysdate update_time
          FROM ( select   'TRANSC0127'|| P_RPTORGID|| P_RPTYEAR|| P_RPTMONTH as repinst_id,repinst.org_id,
                    max(replace(rptindexinst.sta_index_inst_id,P_RPTCODE,'C0127')|| P_RPTORGID|| P_RPTYEAR|| P_RPTMONTH) as sta_index_inst_id,
                    sum(indexinst.index_value) ,
                    indexinst.index_code,
                    indexinst.unit_code,
                    max(replace(dimeninst.repinst_dtl_dimen,P_RPTCODE,'C0127')|| P_RPTORGID|| P_RPTYEAR|| P_RPTMONTH)   as repinst_dtl_dimen,
                    dimeninst.dim_code              as dim_code,
                    dimeninst.dim_detail_code       as dim_detail_code,
                    max(replace(dimeninst1.repinst_dtl_dimen,P_RPTCODE,'C0127')|| P_RPTORGID|| P_RPTYEAR|| P_RPTMONTH||'2')    as repinst_dtl_dimen1,
                    'Orig_energy_type'            as dim_code1,
                    dimeninst1.dim_detail_code      as dim_detail_code1
                from e7_sta_repinst repinst
                     left join e7_sta_rpt_index_inst  rptindexinst on repinst.repinst_id=rptindexinst.repinst_id
                     left join e7_sta_index_inst indexinst on rptindexinst.sta_index_inst_id=indexinst.sta_index_inst_id
                     left join e7_sta_index_inst_dimen dimeninst on indexinst.sta_index_inst_id=dimeninst.sta_index_inst_id and dimeninst.dim_code='Industry_type'
                     left join e7_sta_index_inst_dimen dimeninst1 on indexinst.sta_index_inst_id=dimeninst1.sta_index_inst_id and dimeninst1.dim_code='Cru_oil_E_cons_typ'
                     left join e7_sta_index_inst_dimen dimeninst2 on indexinst.sta_index_inst_id=dimeninst2.sta_index_inst_id and dimeninst2.dim_code='Custom_dimen_first'
                     left join e7_sta_index_inst_dimen dimeninst3 on indexinst.sta_index_inst_id=dimeninst3.sta_index_inst_id and dimeninst3.dim_code='Custom_dimen_second'
                where repinst.report_code=P_RPTCODE
                      and repinst.org_id =   P_RPTORGID
                      and repinst.report_year =   P_RPTYEAR
                      and repinst.report_month < = P_RPTMONTH
                      and (dimeninst2.dim_detail_code not in ('Transportation_amount_G','Transportation_amount_D') or dimeninst2.dim_detail_code is null)
                      and( dimeninst3.dim_detail_code not like 'Material_own_amount_N' or  dimeninst3.dim_detail_code is null)
                      and(( dimeninst1.dim_detail_code <> 'Underground_water'and dimeninst1.dim_detail_code <> 'Tap_water' and dimeninst1.dim_detail_code <> 'Surface_water' )or dimeninst1.dim_detail_code is null)
                      and indexinst.index_code in ('Engy_csmp_amt_pratl',
                                                    'Comph_engy_csmp_amt',
                                                    'Fresh_water_consu_amt')
                                                     AND INDEXINST.COMPOSITED_INDEX_CODE = P_RPTORGID
                  group by repinst.org_id,
                        indexinst.index_code,
                        indexinst.unit_code,
                        dimeninst.dim_code,
                        dimeninst.dim_detail_code,
                        dimeninst1.dim_code,
                        dimeninst1.dim_detail_code
                      )
          ）
        WHERE repinst_dtl_dimen is not null
       ;

     V_RPTINDEXINST E7_STA_RPT_INDEX_INST%ROWTYPE;
     V_INDEXINST E7_STA_INDEX_INST%ROWTYPE;
     V_INDEXINSTDIMEN E7_STA_INDEX_INST_DIMEN%ROWTYPE;
      AUTH NUMBER(10);
      STATUS NUMBER(10);
    begin
      AUTH:=ISAUTH(P_RPTORGID);
      STATUS:=JUDGESTATUS(P_RPTYEAR,P_RPTMONTH ,P_RPTORGID);
      IF  AUTH>0 THEN
        IF STATUS= 0 THEN
          DELDATAXNNW(P_RPTYEAR,P_RPTMONTH ,P_RPTORGID);
          INSERT INTO e7_sta_repinst（REPINST_ID,ORG_ID,REPORT_CODE,REPORT_YEAR,REPORT_QUARTER,REPORT_MONTH,REPORT_FREQUENT_CODE,STATUS,WRITER,CREATE_TIME,UPDATE_TIME）
                 SELECT 'TRANSC0127'|| P_RPTORGID|| P_RPTYEAR|| P_RPTMONTH,
                        ORG_ID,
                        'C0127',
                        REPORT_YEAR,
                        REPORT_QUARTER,
                        REPORT_MONTH,
                        REPORT_FREQUENT_CODE,
                        '02',
                        DECODE(P_RPTUSERNAME,NULL,NULL,NULL),
                        SYSDATE CREATE_TIME,
                        SYSDATE UPDATE_TIME
                 FROM E7_STA_REPINST
                 WHERE org_id=P_RPTORGID and report_year=P_RPTYEAR and report_month = P_RPTMONTH AND REPORT_CODE=P_RPTCODE ;
         COMMIT;
          FOR RPTINDEXINSTE IN REPINDEXINST LOOP
              V_RPTINDEXINST.REPINST_ID :=  RPTINDEXINSTE.REPINST_ID;
              V_RPTINDEXINST.STA_INDEX_INST_ID := RPTINDEXINSTE.STA_INDEX_INST_ID;
              V_RPTINDEXINST.CREATE_TIME := RPTINDEXINSTE.CREATE_TIME;
              V_RPTINDEXINST.UPDATE_TIME := RPTINDEXINSTE.UPDATE_TIME;
              INSERT INTO E7_STA_RPT_INDEX_INST VALUES V_RPTINDEXINST;
           END LOOP;
           COMMIT;

           FOR INDEXINSTE IN indexinst LOOP
              V_INDEXINST.sta_index_inst_id    :=INDEXINSTE.sta_index_inst_id;
              V_INDEXINST.index_code           :=INDEXINSTE.index_code;
              V_INDEXINST.org_id               :=INDEXINSTE.org_id;
              V_INDEXINST.report_year          :=INDEXINSTE.report_year;
              V_INDEXINST.report_quarter       :=INDEXINSTE.report_quarter;
              V_INDEXINST.report_month         :=INDEXINSTE.report_month;
              V_INDEXINST.report_frequent_code :=INDEXINSTE.report_frequent_code;
              V_INDEXINST.index_value          :=INDEXINSTE.index_value;
              V_INDEXINST.unit_code            :=INDEXINSTE.unit_code;
              V_INDEXINST.remark               :=INDEXINSTE.remark;
              V_INDEXINST.index_inst_orderno   :=INDEXINSTE.index_inst_orderno;
              V_INDEXINST.composited_index_code:=INDEXINSTE.composited_index_code;
              V_INDEXINST.create_time          :=INDEXINSTE.create_time;
              V_INDEXINST.update_time          :=INDEXINSTE.update_time;
              INSERT INTO E7_STA_INDEX_INST VALUES V_INDEXINST;
           END LOOP;
           COMMIT;

           FOR INDEXINSTDIMENE IN indexinstdimen LOOP
              V_INDEXINSTDIMEN.repinst_dtl_dimen :=INDEXINSTDIMENE.repinst_dtl_dimen;
              V_INDEXINSTDIMEN.sta_index_inst_id :=INDEXINSTDIMENE.sta_index_inst_id;
              V_INDEXINSTDIMEN.dim_code          :=INDEXINSTDIMENE.dim_code;
              V_INDEXINSTDIMEN.dim_detail_code   :=INDEXINSTDIMENE.dim_detail_code;
              V_INDEXINSTDIMEN.dim_source        :=INDEXINSTDIMENE.dim_source;
              V_INDEXINSTDIMEN.dim_deteail_id    :=INDEXINSTDIMENE.dim_deteail_id;
              V_INDEXINSTDIMEN.dim_deteail_id2   :=INDEXINSTDIMENE.dim_deteail_id2;
              V_INDEXINSTDIMEN.unit_code         :=INDEXINSTDIMENE.unit_code;
              V_INDEXINSTDIMEN.composite_dim_code:=INDEXINSTDIMENE.composite_dim_code;
              V_INDEXINSTDIMEN.create_time       :=INDEXINSTDIMENE.create_time;
              V_INDEXINSTDIMEN.update_time       :=INDEXINSTDIMENE.update_time;
              INSERT INTO E7_STA_INDEX_INST_DIMEN VALUES V_INDEXINSTDIMEN;
           END LOOP;
           COMMIT;
         END IF;
       END IF;
         EXCEPTION WHEN OTHERS THEN
          ROLLBACK;

     END;
     END DataRUNXNNWTOC0127;
/

