CREATE TRIGGER ATOB
  AFTER INSERT OR UPDATE OR DELETE
  ON ATEMP
  FOR EACH ROW
  begin
  if inserting then
    insert into int.Btemp@Int_Dblk(DEV_ID, ORG_ID, SYS_DEV_TYPE_ID, DEV_NAME, ORDER_NO, STATUS_CODE, REPORT_CODE, CREATE_USER_ID, CREATE_USER_NAME, CREATE_TIME, UPDATE_USER_ID, UPDATE_USER_NAME, UPDATE_TIME, ORDER_NO1) 
     values (:new_value.DEV_ID,
     :new_value.ORG_ID,
     :new_value.SYS_DEV_TYPE_ID,
     :new_value.DEV_NAME,
     :new_value.ORDER_NO,
     :new_value.STATUS_CODE,
     :new_value.REPORT_CODE,
     :new_value.CREATE_USER_ID,
     :new_value.CREATE_USER_NAME,
     :new_value.CREATE_TIME,
     :new_value.UPDATE_USER_ID,
     :new_value.UPDATE_USER_NAME,
     :new_value.UPDATE_TIME,
     :new_value.ORDER_NO1);
   elsif updating then
     update int.Btemp@int_dblk
            set
     DEV_ID = :new_value.DEV_ID,       
     ORG_ID = :new_value.ORG_ID,
     SYS_DEV_TYPE_ID = :new_value.SYS_DEV_TYPE_ID,
     DEV_NAME = :new_value.DEV_NAME,
     ORDER_NO = :new_value.ORDER_NO,
     STATUS_CODE = :new_value.STATUS_CODE,
     REPORT_CODE = :new_value.REPORT_CODE,
     CREATE_USER_ID = :new_value.CREATE_USER_ID,
     CREATE_USER_NAME = :new_value.CREATE_USER_NAME,
     CREATE_TIME = :new_value.CREATE_TIME,
     UPDATE_USER_ID = :new_value.UPDATE_USER_ID,
     UPDATE_USER_NAME = :new_value.UPDATE_USER_NAME,
     UPDATE_TIME = :new_value.UPDATE_TIME,
     ORDER_NO1 = :new_value.ORDER_NO1
     where DEV_ID = :old_value.DEV_ID;
   elsif deleting then
     delete from int.Btemp@int_dblk
     where DEV_ID = :old_value.DEV_ID;
   end if;
end;
/

