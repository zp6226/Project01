CREATE TRIGGER TRI_NX_USED_INDEX_INST
  AFTER INSERT
  ON E7_STA_RPT_INDEX_INST
  FOR EACH ROW
  declare
  v_report_code varchar2(50);
  v_index_report_code varchar2(50);
  v_index_report_inst varchar2(50);
  cursor c_index(rc varchar2) is select report_code, report_inst from E7_NX_INDEX_INST_NO where report_code=rc group by report_code, report_inst;

  begin
    select report_code into v_report_code from e7_sta_repinst a where a.repinst_id=:new.repinst_id;
    if (substr(v_report_code, 1, 1) = 'T' and (to_number(substr(v_report_code, 4)) <= 58 or to_number(substr(v_report_code, 4)) = 85) and substr(v_report_code, 4) <> '21' and substr(v_report_code, 4) <> '22' and substr(v_report_code, 4) <> '55' and substr(v_report_code, 4) <> '56' and substr(v_report_code, 4) <> '57') or v_report_code = 'T0108'  then
      open c_index(v_report_code);
      fetch c_index into v_index_report_code, v_index_report_inst;
      -- if c_index%found and v_index_report_inst <> :new.repinst_id then
      --   delete from E7_NX_INDEX_INST_NO where report_code=v_report_code;
      -- end if;
      if c_index%notfound or v_index_report_inst=:new.repinst_id then
        insert into E7_NX_INDEX_INST_NO(id, report_code, report_inst, index_inst_id)
        values(SEQ_NX_USED_BY_TRIG.nextval, v_report_code, :new.repinst_id, :new.sta_index_inst_id);
      end if;
      close c_index;
  end if;
  end;
/

