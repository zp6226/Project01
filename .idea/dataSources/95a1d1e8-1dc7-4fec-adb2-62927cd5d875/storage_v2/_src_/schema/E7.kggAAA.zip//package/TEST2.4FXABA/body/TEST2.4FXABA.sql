CREATE PACKAGE BODY TEST2 is

  PROCEDURE getSBZBSum (REPORTCODE IN VARCHAR2,

                    P_RPTYEAR  IN VARCHAR2,
                    P_RPTMONTH IN VARCHAR2,
                    P_RPTORGID IN VARCHAR2,
                    jsonStr OUT CLOB) IS
     cursor location(REPORTCODE varchar2)
                 is
                 SELECT ind.index_code,ind.localtion,
                 dim.dim_code dim_code,dim.dim_detail_code  dim_detail_code
                 FROM e7_excel_locationbyindex ind left join e7_excel_locationbydimen  dim
                 on ind.report_code=dim.report_code and ind.localtion=dim.localtion
                 where ind.report_code=REPORTCODE
                 and ind.is_py='N'
                 and ind.index_code<> 'Stadc_coef';
    location_info location%rowtype;
    location_code VARCHAR2(10);
    location_value number; 
    CODESQL VARCHAR2(100);
  begin
    jsonStr:= '[';
    if REPORTCODE='T0036'  THEN CODESQL:='''C0004'',''C0009'',''C0014'',''C0069'',''C0074'',''C0079''';END IF; 
    if REPORTCODE='T0037'  THEN CODESQL:='''C0037''';END IF; 
    if REPORTCODE='T0038'  THEN CODESQL:='''C0047''';END IF; 
    if REPORTCODE='T0039'  THEN CODESQL:='''C0019'',''C0024'',''C0054'',''C0059'',''C0029'',''C0097'',''C0102'',''C0107'',''C0117'' ,''C0171''';END IF; 
    for location_info in location(REPORTCODE) LOOP
    location_code :=location_info.localtion;
      begin
        /*dbms_output.put_line(CODESQL);
        dbms_output.put_line(location_info.index_code);
        dbms_output.put_line(location_info.dim_code);
                dbms_output.put_line(location_info.dim_detail_code);*/

        IF location_info.index_code='dev_efficiency_tested'
          then WITH TEMP AS(select 
                  dim_code,
                  dim_detail_code,
                  case when sum(value2)=0 then 0 else sum(value1)/sum(value2) end value1,
                  case when sum(value2)=0 then 0 else sum(value3)/sum(value2) end value2
                  from
                  (
                  select 
                  aa.report_code,
                  aa.org_id,
                  aa.dim_detail_code,
                  aa.dim_code,
                  case when aa.index_value=0 then 0 else (dd.index_value * (bb.index_value / aa.index_value * 100) * cc.index_value ) end as value1, 
                  case when aa.index_value=0 then 0 else (bb.index_value / aa.index_value * 100) * cc.index_value end as value2, 
                  case when aa.index_value=0 then 0 else (ee.index_value * (bb.index_value / aa.index_value * 100) * cc.index_value ) end as value3
                  from 
                  (
                  select 
                         repinst.report_code,
                         repinst.org_id,
                         indexinst.index_code,
                         indexinst_dim.dim_detail_code,
                         indexinst_dim.dim_code,
                         indexinst.index_value
                    from e7_sta_repinst repinst
                    left join e7_sta_rpt_index_inst repinst_indexinst
                      on repinst.repinst_id = repinst_indexinst.repinst_id
                    left join e7_sta_index_inst indexinst
                      on indexinst.sta_index_inst_id = repinst_indexinst.sta_index_inst_id and indexinst.index_code = 'dev_amt_in_use'
                    left join e7_sta_index_inst_dimen indexinst_dim
                      on indexinst_dim.sta_index_inst_id = indexinst.sta_index_inst_id
                   where repinst.report_code in  ((CODESQL))
                     and repinst.org_id in (select org_id from e7_sta_rpt_auth where v_org_id = P_RPTORGID and report_code in (CODESQL))
                     and repinst.report_year = P_RPTYEAR 
                     and repinst.report_month =P_RPTMONTH 
                     and index_code is not null 
                   ) aa 
                  left join 
                  (
                  select 
                         repinst.report_code,
                         repinst.org_id,
                         indexinst.index_code,
                         indexinst_dim.dim_detail_code,
                         indexinst_dim.dim_code,
                         indexinst.index_value
                    from e7_sta_repinst repinst
                    left join e7_sta_rpt_index_inst repinst_indexinst
                      on repinst.repinst_id = repinst_indexinst.repinst_id
                    left join e7_sta_index_inst indexinst
                      on indexinst.sta_index_inst_id = repinst_indexinst.sta_index_inst_id and indexinst.index_code = 'dev_amt_tested'
                    left join e7_sta_index_inst_dimen indexinst_dim
                      on indexinst_dim.sta_index_inst_id = indexinst.sta_index_inst_id
                   where repinst.report_code in (CODESQL)
                     and repinst.org_id in (select org_id from e7_sta_rpt_auth where v_org_id = P_RPTORGID and report_code in (CODESQL))
                     and repinst.report_year = P_RPTYEAR 
                     and repinst.report_month =P_RPTMONTH 
                     and index_code is not null 
                  )bb
                  on  aa.report_code = bb.report_code 
                  and aa.org_id = bb.org_id
                  and aa.dim_detail_code = bb.dim_detail_code
                  and aa.dim_code = bb.dim_code

                  left join 
                  (
                  select 
                         repinst.report_code,
                         repinst.org_id,
                         indexinst.index_code,
                         indexinst_dim.dim_detail_code,
                         indexinst_dim.dim_code,
                         indexinst.index_value
                    from e7_sta_repinst repinst
                    left join e7_sta_rpt_index_inst repinst_indexinst
                      on repinst.repinst_id = repinst_indexinst.repinst_id
                    left join e7_sta_index_inst indexinst
                      on indexinst.sta_index_inst_id = repinst_indexinst.sta_index_inst_id and indexinst.index_code = 'dev_capacity'
                    left join e7_sta_index_inst_dimen indexinst_dim
                      on indexinst_dim.sta_index_inst_id = indexinst.sta_index_inst_id
                   where repinst.report_code in (CODESQL)
                     and repinst.org_id in (select org_id from e7_sta_rpt_auth where v_org_id = P_RPTORGID and report_code in (CODESQL))
                     and repinst.report_year = P_RPTYEAR 
                     and repinst.report_month =P_RPTMONTH 
                     and index_code is not null  
                  )cc
                  on  aa.report_code = cc.report_code 
                  and aa.org_id = cc.org_id
                  and aa.dim_detail_code = cc.dim_detail_code
                  and aa.dim_code = cc.dim_code
                  left join 
                  (
                  select 
                         repinst.report_code,
                         repinst.org_id,
                         indexinst.index_code,
                         indexinst_dim.dim_detail_code,
                         indexinst_dim.dim_code,
                         indexinst.index_value
                    from e7_sta_repinst repinst
                    left join e7_sta_rpt_index_inst repinst_indexinst
                      on repinst.repinst_id = repinst_indexinst.repinst_id
                    left join e7_sta_index_inst indexinst
                      on indexinst.sta_index_inst_id = repinst_indexinst.sta_index_inst_id and indexinst.index_code = 'dev_efficiency_tested'
                    left join e7_sta_index_inst_dimen indexinst_dim
                      on indexinst_dim.sta_index_inst_id = indexinst.sta_index_inst_id
                   where repinst.report_code in (CODESQL)
                     and repinst.org_id in (select org_id from e7_sta_rpt_auth where v_org_id = P_RPTORGID and report_code in (CODESQL))
                     and repinst.report_year = P_RPTYEAR 
                     and repinst.report_month =P_RPTMONTH 
                     and index_code is not null 
                  )dd
                  on  aa.report_code = dd.report_code 
                  and aa.org_id = dd.org_id
                  and aa.dim_detail_code = dd.dim_detail_code
                  and aa.dim_code = dd.dim_code 
                  left join 
                  (
                  select 
                         repinst.report_code,
                         repinst.org_id,
                         indexinst.index_code,
                         indexinst_dim.dim_detail_code,
                         indexinst_dim.dim_code,
                         indexinst.index_value
                    from e7_sta_repinst repinst
                    left join e7_sta_rpt_index_inst repinst_indexinst
                      on repinst.repinst_id = repinst_indexinst.repinst_id
                    left join e7_sta_index_inst indexinst
                      on indexinst.sta_index_inst_id = repinst_indexinst.sta_index_inst_id and indexinst.index_code = 'dev_sys_efficiency_tested'
                    left join e7_sta_index_inst_dimen indexinst_dim
                      on indexinst_dim.sta_index_inst_id = indexinst.sta_index_inst_id
                  where repinst.report_code in (CODESQL)
                     and repinst.org_id in (select org_id from e7_sta_rpt_auth where v_org_id = P_RPTORGID and report_code in (CODESQL))
                     and repinst.report_year = P_RPTYEAR 
                     and repinst.report_month =P_RPTMONTH 
                     and index_code is not null  
                  )ee
                  on  aa.report_code = ee.report_code 
                  and aa.org_id = ee.org_id
                  and aa.dim_detail_code = ee.dim_detail_code
                  and aa.dim_code = ee.dim_code

                  )

                  group by dim_code,dim_detail_code)
                  SELECT VALUE1 into location_value FROM TEMP WHERE dim_detail_code=location_info.dim_detail_code;
            elsif location_info.dim_detail_code='dev_sys_efficiency_tested'
              then  WITH TEMP AS(select 
                  dim_code,
                  dim_detail_code,
                  case when sum(value2)=0 then 0 else sum(value1)/sum(value2) end value1,
                  case when sum(value2)=0 then 0 else sum(value3)/sum(value2) end value2
                  from
                  (
                  select 
                  aa.report_code,
                  aa.org_id,
                  aa.dim_detail_code,
                  aa.dim_code,
                  case when aa.index_value=0 then 0 else (dd.index_value * (bb.index_value / aa.index_value * 100) * cc.index_value ) end as value1, 
                  case when aa.index_value=0 then 0 else (bb.index_value / aa.index_value * 100) * cc.index_value end as value2, 
                  case when aa.index_value=0 then 0 else (ee.index_value * (bb.index_value / aa.index_value * 100) * cc.index_value ) end as value3
                  from 
                  (
                  select 
                         repinst.report_code,
                         repinst.org_id,
                         indexinst.index_code,
                         indexinst_dim.dim_detail_code,
                         indexinst_dim.dim_code,
                         indexinst.index_value
                    from e7_sta_repinst repinst
                    left join e7_sta_rpt_index_inst repinst_indexinst
                      on repinst.repinst_id = repinst_indexinst.repinst_id
                    left join e7_sta_index_inst indexinst
                      on indexinst.sta_index_inst_id = repinst_indexinst.sta_index_inst_id and indexinst.index_code = 'dev_amt_in_use'
                    left join e7_sta_index_inst_dimen indexinst_dim
                      on indexinst_dim.sta_index_inst_id = indexinst.sta_index_inst_id
                   where repinst.report_code in (CODESQL)
                     and repinst.org_id in (select org_id from e7_sta_rpt_auth where v_org_id = P_RPTORGID and report_code in (CODESQL))
                     and repinst.report_year = P_RPTYEAR 
                     and repinst.report_month =P_RPTMONTH 
                     and index_code is not null 
                   ) aa 
                  left join 
                  (
                  select 
                         repinst.report_code,
                         repinst.org_id,
                         indexinst.index_code,
                         indexinst_dim.dim_detail_code,
                         indexinst_dim.dim_code,
                         indexinst.index_value
                    from e7_sta_repinst repinst
                    left join e7_sta_rpt_index_inst repinst_indexinst
                      on repinst.repinst_id = repinst_indexinst.repinst_id
                    left join e7_sta_index_inst indexinst
                      on indexinst.sta_index_inst_id = repinst_indexinst.sta_index_inst_id and indexinst.index_code = 'dev_amt_tested'
                    left join e7_sta_index_inst_dimen indexinst_dim
                      on indexinst_dim.sta_index_inst_id = indexinst.sta_index_inst_id
                   where repinst.report_code in (CODESQL)
                     and repinst.org_id in (select org_id from e7_sta_rpt_auth where v_org_id = P_RPTORGID and report_code in (CODESQL))
                     and repinst.report_year = P_RPTYEAR 
                     and repinst.report_month =P_RPTMONTH 
                     and index_code is not null 
                  )bb
                  on  aa.report_code = bb.report_code 
                  and aa.org_id = bb.org_id
                  and aa.dim_detail_code = bb.dim_detail_code
                  and aa.dim_code = bb.dim_code

                  left join 
                  (
                  select 
                         repinst.report_code,
                         repinst.org_id,
                         indexinst.index_code,
                         indexinst_dim.dim_detail_code,
                         indexinst_dim.dim_code,
                         indexinst.index_value
                    from e7_sta_repinst repinst
                    left join e7_sta_rpt_index_inst repinst_indexinst
                      on repinst.repinst_id = repinst_indexinst.repinst_id
                    left join e7_sta_index_inst indexinst
                      on indexinst.sta_index_inst_id = repinst_indexinst.sta_index_inst_id and indexinst.index_code = 'dev_capacity'
                    left join e7_sta_index_inst_dimen indexinst_dim
                      on indexinst_dim.sta_index_inst_id = indexinst.sta_index_inst_id
                   where repinst.report_code in (CODESQL)
                     and repinst.org_id in (select org_id from e7_sta_rpt_auth where v_org_id = P_RPTORGID and report_code in (CODESQL))
                     and repinst.report_year = P_RPTYEAR 
                     and repinst.report_month =P_RPTMONTH 
                     and index_code is not null  
                  )cc
                  on  aa.report_code = cc.report_code 
                  and aa.org_id = cc.org_id
                  and aa.dim_detail_code = cc.dim_detail_code
                  and aa.dim_code = cc.dim_code
                  left join 
                  (
                  select 
                         repinst.report_code,
                         repinst.org_id,
                         indexinst.index_code,
                         indexinst_dim.dim_detail_code,
                         indexinst_dim.dim_code,
                         indexinst.index_value
                    from e7_sta_repinst repinst
                    left join e7_sta_rpt_index_inst repinst_indexinst
                      on repinst.repinst_id = repinst_indexinst.repinst_id
                    left join e7_sta_index_inst indexinst
                      on indexinst.sta_index_inst_id = repinst_indexinst.sta_index_inst_id and indexinst.index_code = 'dev_efficiency_tested'
                    left join e7_sta_index_inst_dimen indexinst_dim
                      on indexinst_dim.sta_index_inst_id = indexinst.sta_index_inst_id
                   where repinst.report_code in (CODESQL)
                     and repinst.org_id in (select org_id from e7_sta_rpt_auth where v_org_id = P_RPTORGID and report_code in (CODESQL))
                     and repinst.report_year = P_RPTYEAR 
                     and repinst.report_month =P_RPTMONTH 
                     and index_code is not null 
                  )dd
                  on  aa.report_code = dd.report_code 
                  and aa.org_id = dd.org_id
                  and aa.dim_detail_code = dd.dim_detail_code
                  and aa.dim_code = dd.dim_code 
                  left join 
                  (
                  select 
                         repinst.report_code,
                         repinst.org_id,
                         indexinst.index_code,
                         indexinst_dim.dim_detail_code,
                         indexinst_dim.dim_code,
                         indexinst.index_value
                    from e7_sta_repinst repinst
                    left join e7_sta_rpt_index_inst repinst_indexinst
                      on repinst.repinst_id = repinst_indexinst.repinst_id
                    left join e7_sta_index_inst indexinst
                      on indexinst.sta_index_inst_id = repinst_indexinst.sta_index_inst_id and indexinst.index_code = 'dev_sys_efficiency_tested'
                    left join e7_sta_index_inst_dimen indexinst_dim
                      on indexinst_dim.sta_index_inst_id = indexinst.sta_index_inst_id
                  where repinst.report_code in (CODESQL)
                     and repinst.org_id in (select org_id from e7_sta_rpt_auth where v_org_id = P_RPTORGID and report_code in (CODESQL))
                     and repinst.report_year = P_RPTYEAR 
                     and repinst.report_month =P_RPTMONTH 
                     and index_code is not null  
                  )ee
                  on  aa.report_code = ee.report_code 
                  and aa.org_id = ee.org_id
                  and aa.dim_detail_code = ee.dim_detail_code
                  and aa.dim_code = ee.dim_code

                  )

                  group by dim_code,dim_detail_code)
                  SELECT VALUE2 into location_value FROM TEMP WHERE dim_detail_code=location_info.dim_detail_code;
               elsif  location_info.index_code='Engy_csmp_amt_pratl' and location_info.dim_detail_code not in('Inject_pup','Oil_fir_Het_fu','Oil_pup','Oil_pup_mach','Elec_subme_pup','Air_blower','Mach_pup')--数量子项
                 then with t_temp 
                        as
                        (select 
                        repinst.org_id,
                        indexinst.sta_index_inst_id,
                               indexinst.index_inst_orderno,
                               indexinst.index_code,
                               indexinst_dim.dim_deteail_id,
                               indexinst_dim.dim_detail_code,
                               indexinst_dim.dim_code,
                               indexinst.index_value,
                               indexinst.unit_code index_unit_code,
                               indexinst_dim.repinst_dtl_dimen,
                               indexinst.remark,
                               indexinst.composited_index_code,
                               indexinst_dim.composite_dim_code
                          from e7_sta_repinst repinst
                          left join e7_sta_rpt_index_inst repinst_indexinst
                            on repinst.repinst_id = repinst_indexinst.repinst_id
                          left join e7_sta_index_inst indexinst
                            on indexinst.sta_index_inst_id = repinst_indexinst.sta_index_inst_id
                          left join e7_sta_index_inst_dimen indexinst_dim
                            on indexinst_dim.sta_index_inst_id = indexinst.sta_index_inst_id
                         where repinst.report_code in (CODESQL)
                           and repinst.org_id in (select org_id from e7_sta_rpt_auth au where au.v_org_id=P_RPTORGID )
                           and repinst.report_year = P_RPTYEAR
                           and repinst.report_month =P_RPTMONTH
                           ),
                           t_amt 
                           as 
                           (select index_code,dim_detail_code,index_value,org_id from t_temp where index_code = 'Engy_csmp_amt_pratl'),
                           t_sta
                           as
                           (select distinct index_code,dim_detail_code,index_value,org_id from t_temp where index_code = 'Stadc_coef')
                           select  a.index_value into location_value
                           from t_amt a 
                           left join t_sta b 
                           on a.dim_detail_code = b.dim_detail_code
                           and a.org_id = b.org_id
                           left join e7_sta_dim_detail c
                           on a.dim_Detail_code = c.dim_detail_code
                           WHERE  a.dim_detail_code=location_info.dim_detail_code;
                       else WITH TEMP AS( select 
                              num1.index_code,
                              num1.dim_detail_code,
                              sum(num1.index_value) index_value,
                              sum(num1.index_value2)index_value2
                          from 
                          (
                          select
                                 indexinst.index_code,
                                 indexinst_dim.dim_detail_code,
                                 indexinst.index_value,
                                 indexinst.index_value *
                                 (
                                 select
                                  MAX(decode(indexinst.index_code,'Engy_csmp_amt_pratl',indexinst_.index_value,null ))
                                  
                            from e7_sta_repinst repinst_
                            left join e7_sta_rpt_index_inst repinst_indexinst_
                              on repinst_.repinst_id = repinst_indexinst_.repinst_id
                            left join e7_sta_index_inst indexinst_
                              on indexinst_.sta_index_inst_id = repinst_indexinst_.sta_index_inst_id --and indexinst_.index_code = 'Stadc_coef'
                            left join e7_sta_index_inst_dimen indexinst_dim_
                              on indexinst_dim_.sta_index_inst_id = indexinst_.sta_index_inst_id
                           where repinst_.report_code =   repinst.report_code
                             and repinst_.org_id = repinst.org_id
                             and repinst_.report_year =  repinst.report_year
                             and repinst_.report_month = repinst.report_month
                             and indexinst_.index_code = 'Stadc_coef'
                             and indexinst_dim_.dim_detail_code = indexinst_dim.dim_detail_code   
                                 ) index_value2

                            from e7_sta_repinst repinst
                            left join e7_sta_rpt_index_inst repinst_indexinst
                              on repinst.repinst_id = repinst_indexinst.repinst_id
                            left join e7_sta_index_inst indexinst
                              on indexinst.sta_index_inst_id = repinst_indexinst.sta_index_inst_id 
                                left join e7_sta_index_inst_dimen indexinst_dim
                              on indexinst_dim.sta_index_inst_id = indexinst.sta_index_inst_id
                           where repinst.report_code in (CODESQL)
                             and repinst.org_id in (select org_id from e7_sta_rpt_auth where v_org_id = P_RPTORGID and report_code in (CODESQL))
                             and repinst.report_year = P_RPTYEAR 
                             and repinst.report_month =P_RPTMONTH 
                             and indexinst.index_code != 'Stadc_coef' 
                          )num1

                          group by index_code,dim_detail_code)
                          SELECT index_value into location_value FROM TEMP WHERE dim_detail_code=location_info.dim_detail_code
                                 And index_code=location_info.index_code;
                          
        end if;   
        exception when no_data_found then
            location_value:=0;       
      end;
      jsonStr := jsonStr || '{''location'':''' || location_code ||
                     ''',''value'':''' || to_char(location_value) || '''},';   
    end loop;  
   jsonStr:=jsonStr || ']';
   jsonStr:= replace(jsonStr,'},]','}]');
  end;
  
  PROCEDURE dataQy (REPORTCODE IN VARCHAR2,

                    P_RPTYEAR  IN VARCHAR2,
                    P_RPTMONTH IN VARCHAR2) IS
     cursor e7starepinst
                 is
                 SELECT 
                 repinst_id, 
                  org_id, 
                  report_code, 
                  report_year, 
                  report_quarter, 
                  report_month, 
                  report_frequent_code, 
                  status, 
                  writer, 
                  write_date, 
                  checker, 
                  check_date, 
                  null condition, 
                  null verify_note, 
                  null create_user_id, 
                  null create_user_name, 
                  null create_time, 
                  null update_user_id, 
                  null update_user_name, 
                  null update_time     
                 FROM e7.e7_sta_repinst@toscreal
                 where 
                 report_code=REPORTCODE
                 
                 AND report_year = P_RPTYEAR
                 AND report_MONTH = P_RPTMONTH
                 ;
      cursor e7starptindexinst
                 is
                 SELECT *
                 FROM e7.e7_sta_rpt_index_inst@toscreal
                 where repinst_id in (
                 SELECT repinst_id
                 FROM e7.e7_sta_repinst@toscreal
                 where 
                 report_code=REPORTCODE
                 
                 AND report_year = P_RPTYEAR
                 AND report_MONTH = P_RPTMONTH
                 )
                 ;
        cursor e7staindexinst
        is 
        SELECT * FROM E7.E7_STA_INDEX_INST@TOSCREAL
        WHERE STA_INDEX_INST_ID IN (

                 SELECT STA_INDEX_INST_ID
                 FROM e7.e7_sta_rpt_index_inst@toscreal
                 where repinst_id in (
                 SELECT repinst_id
                 FROM e7.e7_sta_repinst@toscreal
                 where 
                 report_code=REPORTCODE
                 
                 AND report_year = P_RPTYEAR
                 AND report_MONTH = P_RPTMONTH

        )
        );
         cursor e7staindexinstdimen
        is 
        SELECT * FROM E7.E7_STA_INDEX_INST_DIMEN@TOSCREAL
        WHERE STA_INDEX_INST_ID IN (

                 SELECT STA_INDEX_INST_ID
                 FROM e7.e7_sta_rpt_index_inst@toscreal
                 where repinst_id in (
                 SELECT repinst_id
                 FROM e7.e7_sta_repinst@toscreal
                 where 
                 report_code=REPORTCODE
                 
                 AND report_year = P_RPTYEAR
                 AND report_MONTH = P_RPTMONTH

        ));
        REPINST E7_STA_REPINST%ROWTYPE;
        RPT_INDEX_INST E7_STA_RPT_INDEX_INST%ROWTYPE;
        INDEX_INST E7_STA_INDEX_INST%ROWTYPE;
        INDEX_INST_DIMEN E7_STA_INDEX_INST_DIMEN%ROWTYPE;

  begin
    FOR ENRGY IN e7starepinst loop
    REPINST.repinst_id          := ENRGY.repinst_id             ;
    REPINST.org_id              := ENRGY.org_id                 ;
    REPINST.report_code         := ENRGY.report_code            ;
    REPINST.report_year         := ENRGY.report_year            ;
    REPINST.report_quarter      := ENRGY.report_quarter         ;
    REPINST.report_month        := ENRGY.report_month           ;
    REPINST.report_frequent_code:= ENRGY.report_frequent_code   ;
    REPINST.status              := ENRGY.status                 ;
    REPINST.writer              := ENRGY.writer                 ;
    REPINST.write_date          := ENRGY.write_date             ;
    REPINST.checker             := ENRGY.checker                ;
    REPINST.check_date          := ENRGY.check_date             ;
    REPINST.condition           := ENRGY.condition              ;
    REPINST.verify_note         := ENRGY.verify_note            ;
    REPINST.create_user_id      := ENRGY.create_user_id         ;
    REPINST.create_user_name    := ENRGY.create_user_name       ;
    REPINST.create_time         := ENRGY.create_time            ;
    REPINST.update_user_id      := ENRGY.update_user_id         ;
    REPINST.update_user_name    := ENRGY.update_user_name       ;
    REPINST.update_time         := ENRGY.update_time            ;
      insert into e7_sta_repinst values REPINST;
      commit;
      end loop;
    FOR ENRGY1 IN e7starptindexinst loop
      RPT_INDEX_INST.repinst_id        := ENRGY1.repinst_id         ;
      RPT_INDEX_INST.sta_index_inst_id := ENRGY1.sta_index_inst_id  ;
      RPT_INDEX_INST.create_time       := ENRGY1.create_time        ;
      RPT_INDEX_INST.update_time       := ENRGY1.update_time        ;
      insert into e7_sta_rpt_index_inst values RPT_INDEX_INST;
      commit;
      end loop;
    FOR ENRGY2 IN e7staindexinst loop
      INDEX_INST.sta_index_inst_id     := ENRGY2.sta_index_inst_id        ;
        INDEX_INST.index_code            := ENRGY2.index_code               ;
        INDEX_INST.org_id                := ENRGY2.org_id                   ;
        INDEX_INST.report_year           := ENRGY2.report_year              ;
        INDEX_INST.report_quarter        := ENRGY2.report_quarter           ;
        INDEX_INST.report_month          := ENRGY2.report_month             ;
        INDEX_INST.report_frequent_code  := ENRGY2.report_frequent_code     ;
        INDEX_INST.index_value           := ENRGY2.index_value              ;
        INDEX_INST.unit_code             := ENRGY2.unit_code                ;
        INDEX_INST.remark                := ENRGY2.remark                   ;
        INDEX_INST.index_inst_orderno    := ENRGY2.index_inst_orderno       ;
        INDEX_INST.composited_index_code := ENRGY2.composited_index_code    ;
        INDEX_INST.create_time           := ENRGY2.create_time              ;
        INDEX_INST.update_time           := ENRGY2.update_time              ;

      insert into e7_sta_index_inst values INDEX_INST;
      commit;
      end loop;
     FOR ENRGY3 IN e7staindexinstdimen loop
     INDEX_INST_DIMEN.repinst_dtl_dimen  := ENRGY3.repinst_dtl_dimen     ;
      INDEX_INST_DIMEN.sta_index_inst_id  := ENRGY3.sta_index_inst_id     ;
      INDEX_INST_DIMEN.dim_code           := ENRGY3.dim_code              ;
      INDEX_INST_DIMEN.dim_detail_code    := ENRGY3.dim_detail_code       ;
      INDEX_INST_DIMEN.dim_source         := ENRGY3.dim_source            ;
      INDEX_INST_DIMEN.dim_deteail_id     := ENRGY3.dim_deteail_id        ;
      INDEX_INST_DIMEN.dim_deteail_id2    := ENRGY3.dim_deteail_id2       ;
      INDEX_INST_DIMEN.unit_code          := ENRGY3.unit_code             ;
      INDEX_INST_DIMEN.composite_dim_code := ENRGY3.composite_dim_code    ;
      INDEX_INST_DIMEN.create_time        := ENRGY3.create_time           ;
      INDEX_INST_DIMEN.update_time        := ENRGY3.update_time           ;
      insert into e7_sta_index_inst_dimen values INDEX_INST_DIMEN;
      commit;
      end loop;  
         EXCEPTION WHEN OTHERS THEN
            null;   
   end;
end TEST2;
/

