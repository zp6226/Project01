CREATE PACKAGE UPDATESTALASTYEAR AS
       PROCEDURE DELETELASTYEAR(REPORTCODES in REPORTCODELIST,REPORTYEAR in varchar2,ORGID in varchar2);
       PROCEDURE UPDATELASTYEAR(REPORTCODES in REPORTCODELIST,REPORTYEAR in varchar2,ORGID in varchar2);
      PROCEDURE update_excel_report_ly_T0030(REPORTCODE in varchar2,REPORTYEAR in varchar2,ORGID in varchar2 );
       --PROCEDURE update_excel_report_ly_T0031(REPORTCODE in varchar2,REPORTYEAR in varchar2,ORGID in varchar2 ); 
       --PROCEDURE update_excel_report_ly_T0033(REPORTCODE in varchar2,REPORTYEAR in varchar2,ORGID in varchar2 );
       -- PROCEDURE update_excel_report_ly_T0053(REPORTCODE in varchar2,REPORTYEAR in varchar2,ORGID in varchar2 );
       PROCEDURE update_excel_report_ly_T0032(REPORTCODE in varchar2,REPORTYEAR in varchar2,ORGID in varchar2 );
       PROCEDURE update_excel_report_ly_T0085(REPORTCODE in varchar2,REPORTYEAR in varchar2,ORGID in varchar2 );
       PROCEDURE update_excel_report_ly_SB(REPORTCODE in varchar2,REPORTYEAR in varchar2,ORGID in varchar2 );
       PROCEDURE update_excel_report_ly_SC(REPORTCODE in varchar2,REPORTYEAR in varchar2,ORGID in varchar2 );
       PROCEDURE update_excel_report_ly_NH(REPORTCODE in varchar2,REPORTYEAR in varchar2,ORGID in varchar2 );
       PROCEDURE update_excel_report_ly_CJ(REPORTCODE in varchar2,REPORTYEAR in varchar2,ORGID in varchar2 );
       PROCEDURE update_excel_report_ly_XSNH(REPORTCODE in varchar2,REPORTYEAR in varchar2,ORGID in varchar2 );
      

END UPDATESTALASTYEAR;
/

