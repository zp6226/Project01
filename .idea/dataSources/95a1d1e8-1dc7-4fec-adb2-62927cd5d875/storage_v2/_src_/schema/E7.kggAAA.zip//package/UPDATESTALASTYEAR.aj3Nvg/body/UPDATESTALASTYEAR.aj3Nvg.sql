CREATE PACKAGE BODY UPDATESTALASTYEAR AS
       PROCEDURE DELETELASTYEAR(REPORTCODES in REPORTCODELIST,REPORTYEAR in varchar2,ORGID in varchar2)
         IS
         BEGIN
           for i in 1..REPORTCODES.Count loop
             delete  from e7_sta_lastyear_values ly where
                    ly.report_code=REPORTCODES(i)  and ly.report_year=REPORTYEAR and ly.org_id=ORGID;
             commit;
           END LOOP;
           EXCEPTION
               WHEN OTHERS THEN
                    ROLLBACK;
         END;
         PROCEDURE UPDATELASTYEAR(REPORTCODES in REPORTCODELIST,REPORTYEAR in varchar2,ORGID in varchar2)
         IS
         BEGIN
           for i in 1..REPORTCODES.Count loop
           
       
           
             --T0032
             IF(REPORTCODES(i) in ('T0032'))
             THEN
               update_excel_report_ly_T0032(REPORTCODES(i), REPORTYEAR, ORGID);
             END IF;
           
           
           
           
           
           
            --T0030  T0031 T0033 T0053 T0054
             IF(REPORTCODES(i) in ('T0030','T0031','T0033','T0053','T0054'))
             THEN
               update_excel_report_ly_T0030(REPORTCODES(i), REPORTYEAR, ORGID);
             END IF;
           
           
           
           
               --T0085
             IF(REPORTCODES(i) in ('T0085'))
             THEN
               update_excel_report_ly_T0085(REPORTCODES(i), REPORTYEAR, ORGID);
             END IF;
           
                 
             --能耗
             IF(REPORTCODES(i) in ('T0007','T0008','T0009','T0010','T0011','T0012','T0013','T0014','T0015','T0016','T0017','T0018','T0019','T0020','T0021','T0022','T0027','T0028'))
             THEN
               update_excel_report_ly_NH(REPORTCODES(i), REPORTYEAR, ORGID);
             END IF;
             IF(REPORTCODES(I) IN ('T0023','T0024','T0025','T0026'))
             THEN 
              	update_excel_report_ly_XSNH(REPORTCODES(i), REPORTYEAR, ORGID);
             END IF;
             --设备
             IF(REPORTCODES(i) in ('C0004','C0009','C0014','C0019','C0024','C0029','C0037','C0047','C0054','C0059','C0069','C0074','C0079','C0097','C0102','C0107','C0117','C0171','T0035','T0036','T0037','T0038','T0039')) 
             then 
               update_excel_report_ly_SB(REPORTCODES(i),REPORTYEAR,ORGID);
             end if;
             --生产
             IF(REPORTCODES(i) in ('C0001','C0006','C0011','C0016','C0021','C0026','C0034','C0044','C0051','C0056','C0061','C0071','C0076','C0083','C0094','C0099','C0104','C0114','C0168','T0001','T0002')) 
             then 
               update_excel_report_ly_SC(REPORTCODES(i),REPORTYEAR,ORGID);
             end if;
             --采集
             IF(REPORTCODES(i) in ('C0005','C0010','C0015','C0020','C0025','C0030','C0039','C0049','C0055','C0060','C0070','C0075','C0080','C0098','C0103','C0108','C0118','C0172')) 
             then 
               update_excel_report_ly_CJ(REPORTCODES(i),REPORTYEAR,ORGID);
             end if;
           END LOOP;
           EXCEPTION
               WHEN OTHERS THEN
                    ROLLBACK;
         END;

--T0032 上年同期  
 PROCEDURE update_excel_report_ly_T0032(REPORTCODE in varchar2,REPORTYEAR in varchar2,ORGID in varchar2 )
         IS
         --查出location 游标
                 cursor location(REPORTCODE varchar2, REPORTYEAR varchar2, ORGID in varchar2)
                 is 
  select * from (
                   with datas as (
                      select 
                      repinst.org_id,
                      repinst.report_code,
                      repinst.report_year,
                      repinst.report_month,
                      iis.index_code,
                      iis.index_value,
                      dimen1.dim_code dim_code1,
                      dimen1.dim_detail_code as dim_detail_code1
                     
                    
                       from e7_sta_repinst repinst 
                      left join e7_sta_rpt_index_inst ii on repinst.repinst_id = ii.repinst_id
                      left join e7_sta_index_inst iis on ii.sta_index_inst_id = iis.sta_index_inst_id
                      left join e7_sta_index_inst_dimen dimen1 on iis.sta_index_inst_id = dimen1.sta_index_inst_id
                      and dimen1.dim_code = 'Professional_type'
                      where repinst.report_code = REPORTCODE
                      and repinst.org_id = ORGID
                      and repinst.report_year = REPORTYEAR
                     --and repinst.report_month = 1
                      ),
                      locationindex_data as (
                      select a.*,b.localtion as index_location from datas a left join e7_excel_locationbyindex b on a.report_code = b.report_code and a.index_code = b.index_code and b.is_py = 'Y'
                      ),
                      localtiondimen1_data as (
                      select * from (
                       select dat.*,dl1.localtion as dl1_location
                        from locationindex_data dat 
                        left join e7_excel_locationbydimen dl1 on dat.report_code = dl1.report_code and  dat.dim_code1 = dl1.dim_code and dat.dim_detail_code1 = dl1.dim_detail_code
                       ) where index_location = dl1_location or dl1_location is null
                       )
                      select 
                      report_code, 
                      org_id, 
                      report_year, 
                      report_month, 
                      index_location, 
                      index_value
                       from localtiondimen1_data);  
                       	 location_info E7_STA_LASTYEAR_VALUES%rowtype;

                 BEGIN
                   FOR V_LOCATION IN LOCATION(REPORTCODE,REPORTYEAR,ORGID) LOOP
                     location_info.REPORT_CODE := V_LOCATION.REPORT_CODE;
                     location_info.org_id := V_LOCATION.ORG_ID;
                     location_info.report_year :=V_LOCATION.REPORT_YEAR;
                     location_info.report_month := V_LOCATION.REPORT_MONTH;
                     location_info.LOCATION := V_LOCATION.Index_Location;
                     location_info.index_value := V_LOCATION.Index_Value;
  /*                   open location(REPORTCODE,REPORTYEAR,ORGID);
                     --查出location
                     FETCH location INTO location_info;
                       --插入*/
                      INSERT INTO E7_STA_LASTYEAR_VALUES VALUES location_info;
                      COMMIT;
                     END LOOP;
         END ;




--T0030 T0031 T0033  T0053   T0054 上年同期 没有纬度
         PROCEDURE update_excel_report_ly_T0030(REPORTCODE in varchar2,REPORTYEAR in varchar2,ORGID in varchar2 )
         IS
         --查出location 游标
                 cursor location(REPORTCODE varchar2, REPORTYEAR varchar2, ORGID in varchar2)
                 is 
             select * from (
                   with datas as (
                      select 
                      repinst.org_id,
                      repinst.report_code,
                      repinst.report_year,
                      repinst.report_month,
                      iis.index_code,
                      iis.index_value
                     
                       from e7_sta_repinst repinst 
                      left join e7_sta_rpt_index_inst ii on repinst.repinst_id = ii.repinst_id
                      left join e7_sta_index_inst iis on ii.sta_index_inst_id = iis.sta_index_inst_id
 
                      where repinst.report_code = REPORTCODE
                      and repinst.org_id = ORGID
                      and repinst.report_year = REPORTYEAR
                    -- and repinst.report_month = 1
                      ),
                      locationindex_data as (
                      select a.*,b.localtion as index_location from datas a left join e7_excel_locationbyindex b on a.report_code = b.report_code and a.index_code = b.index_code and b.is_py = 'Y'
                      )
                      select 
                      report_code, 
                      org_id, 
                      report_year, 
                      report_month, 
                      index_location, 
                      index_value
                       from locationindex_data);               
                 	 location_info E7_STA_LASTYEAR_VALUES%rowtype;

                 BEGIN
                   FOR V_LOCATION IN LOCATION(REPORTCODE,REPORTYEAR,ORGID) LOOP
                     location_info.REPORT_CODE := V_LOCATION.REPORT_CODE;
                     location_info.org_id := V_LOCATION.ORG_ID;
                     location_info.report_year :=V_LOCATION.REPORT_YEAR;
                     location_info.report_month := V_LOCATION.REPORT_MONTH;
                     location_info.LOCATION := V_LOCATION.Index_Location;
                     location_info.index_value := V_LOCATION.Index_Value;
  /*                   open location(REPORTCODE,REPORTYEAR,ORGID);
                     --查出location
                     FETCH location INTO location_info;
                       --插入*/
                      INSERT INTO E7_STA_LASTYEAR_VALUES VALUES location_info;
                      COMMIT;
                     END LOOP;
         END ;













 --T0085 上年同期
         PROCEDURE update_excel_report_ly_T0085(REPORTCODE in varchar2,REPORTYEAR in varchar2,ORGID in varchar2 )
         IS
         --查出location 游标
                 cursor location(REPORTCODE varchar2, REPORTYEAR varchar2, ORGID in varchar2)
                 is 
                 select * from (
                   with datas as (
                      select 
                      repinst.org_id,
                      repinst.report_code,
                      repinst.report_year,
                      repinst.report_month,
                      iis.index_code,
                      iis.index_value,
                      dimen1.dim_code dim_code1,
                      dimen1.dim_detail_code as dim_detail_code1,
                      dimen2.dim_code as dim_code2,
                      dimen2.dim_detail_code as dim_detail_code2
                    
                       from e7_sta_repinst repinst 
                      left join e7_sta_rpt_index_inst ii on repinst.repinst_id = ii.repinst_id
                      left join e7_sta_index_inst iis on ii.sta_index_inst_id = iis.sta_index_inst_id
                      left join e7_sta_index_inst_dimen dimen1 on iis.sta_index_inst_id = dimen1.sta_index_inst_id
                      and dimen1.dim_code = 'Orig_energy_type'
                  
                      left join e7_sta_index_inst_dimen dimen2 on iis.sta_index_inst_id = dimen2.sta_index_inst_id
                      and dimen2.dim_code = 'Industry_type'
                
                      where repinst.report_code = REPORTCODE
                      and repinst.org_id = ORGID
                      and repinst.report_year = REPORTYEAR
                     --and repinst.report_month = 1
                      ),
                      locationindex_data as (
                      select a.*,b.localtion as index_location from datas a left join e7_excel_locationbyindex b on a.report_code = b.report_code and a.index_code = b.index_code and b.is_py = 'Y'
                      ),
                      localtiondimen1_data as (
                      select * from (
                       select dat.*,dl1.localtion as dl1_location
                        from locationindex_data dat 
                        left join e7_excel_locationbydimen dl1 on dat.report_code = dl1.report_code and  dat.dim_code1 = dl1.dim_code and dat.dim_detail_code1 = dl1.dim_detail_code
                       ) where index_location = dl1_location or dl1_location is null
                       ),
                      locationdimen2_data as ( 
                       select * from (
                       select dim1.*,dl2.localtion as dl2_location from localtiondimen1_data  dim1 
                       left join e7_excel_locationbydimen dl2 on dim1.report_code = dl2.report_code and  dim1.dim_code2 = dl2.dim_code and dim1.dim_detail_code2 = dl2.dim_detail_code 
                      ) where dl2_location is null or index_location = dl2_location
                      )
                      select 
                      report_code, 
                      org_id, 
                      report_year, 
                      report_month, 
                      index_location, 
                      index_value
                       from locationdimen2_data);                 
                 	 location_info E7_STA_LASTYEAR_VALUES%rowtype;

                 BEGIN
                   FOR V_LOCATION IN LOCATION(REPORTCODE,REPORTYEAR,ORGID) LOOP
                     location_info.REPORT_CODE := V_LOCATION.REPORT_CODE;
                     location_info.org_id := V_LOCATION.ORG_ID;
                     location_info.report_year :=V_LOCATION.REPORT_YEAR;
                     location_info.report_month := V_LOCATION.REPORT_MONTH;
                     location_info.LOCATION := V_LOCATION.Index_Location;
                     location_info.index_value := V_LOCATION.Index_Value;
  /*                   open location(REPORTCODE,REPORTYEAR,ORGID);
                     --查出location
                     FETCH location INTO location_info;
                       --插入*/
                      INSERT INTO E7_STA_LASTYEAR_VALUES VALUES location_info;
                      COMMIT;
                     END LOOP;
         END ;





         --设备取上年同期
       PROCEDURE update_excel_report_ly_SB(REPORTCODE in varchar2,REPORTYEAR in varchar2,ORGID in varchar2 )
         IS
         --查出location 游标
                 cursor location(REPORTCODE varchar2)
                 is
                 SELECT ind.report_code,ind.index_code,ind.localtion,
                         dim.dim_code dim_code,dim.dim_detail_code  dim_detail_code
                  FROM e7_excel_locationbyindex ind
                  left join e7_excel_locationbydimen  dim
                  on ind.report_code=dim.report_code and ind.localtion=dim.localtion
                  where ind.report_code=REPORTCODE
                  and ind.is_py='Y';
                  location_info location%rowtype;
                  location_value number;
                  REPORTMONTH number;


         BEGIN
               REPORTMONTH:=0;
               while(REPORTMONTH<12) LOOP
               REPORTMONTH:=REPORTMONTH+1;
                 --查出location
                 FOR location_info IN location(REPORTCODE) LOOP
                 --查出value
                 begin
                 WITH VALTEMP AS(select indexinst.sta_index_inst_id,
                       indexinst.index_inst_orderno,
                       indexinst.index_code,
                       indexinst_dim.dim_deteail_id,
                       indexinst_dim.dim_detail_code,
                       indexinst_dim.dim_code,
                       indexinst.index_value,
                       indexinst.unit_code index_unit_code,
                       indexinst_dim.repinst_dtl_dimen,
                       indexinst.remark,
                       indexinst.composited_index_code,
                       indexinst_dim.composite_dim_code,
                       repinst.report_month
                  from e7_sta_repinst repinst
                  left join e7_sta_rpt_index_inst repinst_indexinst
                    on repinst.repinst_id = repinst_indexinst.repinst_id
                  left join e7_sta_index_inst indexinst
                    on indexinst.sta_index_inst_id = repinst_indexinst.sta_index_inst_id
                  left join e7_sta_index_inst_dimen indexinst_dim
                    on indexinst_dim.sta_index_inst_id = indexinst.sta_index_inst_id
                  WHERE repinst.REPORT_CODE =REPORTCODE
                   AND repinst.ORG_ID=ORGID
                   AND repinst.REPORT_YEAR =REPORTYEAR
                   AND repinst.REPORT_MONTH =REPORTMONTH

                   )
                  SELECT max(t1.INDEX_VALUE) INTO location_value FROM 
                  VALTEMP t1 
                    WHERE t1.index_code=location_info.index_code AND
                          t1.DIM_CODE=location_info.DIM_CODE AND
                          t1.DIM_DETAIL_CODE=location_info.DIM_DETAIL_CODE;
                  exception when no_data_found then
                  location_value:=0;  
                  end;        
                     --插入
                  INSERT INTO E7_STA_LASTYEAR_VALUES(REPORT_CODE,ORG_ID,REPORT_YEAR,REPORT_MONTH,LOCATION,INDEX_VALUE) VALUES(REPORTCODE,ORGID,REPORTYEAR,REPORTMONTH,location_info.localtion,location_value);
                  COMMIT;
                   END LOOP;
                 END LOOP;
         END ;
         
         --生产取上年同期
         PROCEDURE update_excel_report_ly_SC(REPORTCODE in varchar2,REPORTYEAR in varchar2,ORGID in varchar2 )
         IS
         --查出location 游标
                 cursor location(REPORTCODE varchar2)
                 is
                 SELECT ind.report_code,ind.index_code,ind.localtion,
                         dim1.dim_code dim_code1,dim1.dim_detail_code  dim_detail_code1,
                         dim2.dim_code dim_code2,dim2.dim_detail_code  dim_detail_code2,
                         dim3.dim_code dim_code3,dim3.dim_detail_code  dim_detail_code3
                  FROM e7_excel_locationbyindex ind
                  left join e7_excel_locationbydimen  dim1
                  on ind.report_code=dim1.report_code and ind.localtion=dim1.localtion
                  and (dim1.dim_code in
                  ('Product_steam_mod','Drill_E_dissip_type',
                  'Or_Comph_engy_lost_typ',
                  'LNG_outp_vol_typ',
                  'Orig_energy_type',
                  'Long_line_type',
                  'Industry_type',
                  'Gas_stat_typ',
                  'Professional_type',
                  'Sal_pro_hl_type',
                  'Gas_stat_typ') or (dim1.dim_code='Sal_pro_amt_type' and dim1.dim_detail_code in ('Wholesale','Retail','Fuel_gas')))
                  left join e7_excel_locationbydimen  dim2
                  on ind.report_code=dim2.report_code and ind.localtion=dim2.localtion
                  and dim2.dim_code='Sal_pro_amt_type'and dim2.dim_detail_code <> dim1.dim_detail_code
                  left join e7_excel_locationbydimen  dim3
                  on ind.report_code=dim3.report_code and ind.localtion=dim3.localtion
                  and dim3.dim_code in('Sal_form1'，'Sal_form2')
                  where ind.report_code=REPORTCODE
                  and ind.is_py='Y';
                  location_info location%rowtype;
                  location_value number;
                  REPORTMONTH number;


         BEGIN
                   REPORTMONTH:=0;
                   while(REPORTMONTH<12) LOOP
                   REPORTMONTH:=REPORTMONTH+1;
                     --查出location
                     FOR location_info IN location(REPORTCODE) LOOP
                       begin
                     DBMS_OUTPUT.put_line(location_info.index_code);
                     --查出value         
                     WITH VALTEMP AS(SELECT C.INDEX_CODE,
                         C.INDEX_VALUE,
                         nvl(D.DIM_CODE,'*')              AS DIM_CODE1,
                         nvl(D.DIM_DETAIL_CODE,'*')       AS DIM_DETAIL_CODE1,
                         nvl(E.DIM_CODE ,'*')             AS DIM_CODE2,
                         nvl(E.DIM_DETAIL_CODE ,'*')      AS DIM_DETAIL_CODE2,
                         nvl(F.DIM_CODE ,'*')             AS DIM_CODE3,
                         nvl(F.DIM_DETAIL_CODE ,'*')      AS DIM_DETAIL_CODE3
                      FROM E7_STA_REPINST A
                      JOIN E7_STA_RPT_INDEX_INST B ON A.REPINST_ID = B.REPINST_ID
                      JOIN E7_STA_INDEX_INST C ON B.STA_INDEX_INST_ID = C.STA_INDEX_INST_ID
                      LEFT JOIN E7_STA_INDEX_INST_DIMEN D ON C.STA_INDEX_INST_ID = D.STA_INDEX_INST_ID AND
                      (D.dim_code in
                      ('Product_steam_mod','Drill_E_dissip_type',
                      'Or_Comph_engy_lost_typ',
                      'LNG_outp_vol_typ',
                      'Orig_energy_type',
                      'Long_line_type',
                      'Industry_type',
                      'Gas_stat_typ',
                      'Professional_type',
                      'Sal_pro_hl_type'，
                      'Gas_stat_typ') or (D.dim_code='Sal_pro_amt_type' and D.dim_detail_code in ('Wholesale','Retail','Fuel_gas')))
                      LEFT JOIN E7_STA_INDEX_INST_DIMEN E ON C.STA_INDEX_INST_ID = E.STA_INDEX_INST_ID AND  E.dim_code='Sal_pro_amt_type'and E.dim_detail_code <> D.dim_detail_code
                      LEFT JOIN E7_STA_INDEX_INST_DIMEN F ON C.STA_INDEX_INST_ID=F.STA_INDEX_INST_ID AND F.dim_code in('Sal_form1'，'Sal_form2')
                      WHERE A.REPORT_CODE =REPORTCODE
                       AND A.ORG_ID=ORGID
                       AND A.REPORT_YEAR =REPORTYEAR
                       AND A.REPORT_MONTH =REPORTMONTH

                       )
                      SELECT INDEX_VALUE INTO location_value FROM VALTEMP
                        WHERE VALTEMP.INDEX_CODE=location_info.index_code AND
                              VALTEMP.DIM_CODE1= nvl(location_info.DIM_CODE1,'*') AND
                              VALTEMP.DIM_DETAIL_CODE1= nvl(location_info.DIM_DETAIL_CODE1,'*')AND
                              VALTEMP.DIM_CODE2= nvl(location_info.DIM_CODE2,'*') AND
                              VALTEMP.DIM_DETAIL_CODE2= nvl(location_info.DIM_DETAIL_CODE2,'*') AND
                              VALTEMP.DIM_CODE3= nvl(location_info.DIM_CODE3 ,'*' ) AND
                              VALTEMP.DIM_DETAIL_CODE3= nvl(location_info.DIM_DETAIL_CODE3 ,'*' );
                         --插入
                      exception when no_data_found then
                      location_value:=0; 
                      
                      end;
                      DBMS_OUTPUT.put_line(location_value );
                      INSERT INTO E7_STA_LASTYEAR_VALUES(REPORT_CODE,ORG_ID,REPORT_YEAR,REPORT_MONTH,LOCATION,INDEX_VALUE) VALUES(REPORTCODE,ORGID,REPORTYEAR,REPORTMONTH,location_info.localtion,location_value);
                      COMMIT;
                     END LOOP;
                END LOOP;
         END ;
         
         --能耗取上年同期
         PROCEDURE update_excel_report_ly_NH(REPORTCODE in varchar2,REPORTYEAR in varchar2,ORGID in varchar2 )
         IS
         --查出location 游标
                 cursor location(REPORTCODE varchar2, REPORTYEAR varchar2, ORGID in varchar2)
                 is select * from (
                   with datas as (
                      select 
                      repinst.org_id,
                      repinst.report_code,
                      repinst.report_year,
                      repinst.report_month,
                      iis.index_code,
                      iis.index_value,
                      dimen1.dim_code dim_code1,
                      dimen1.dim_detail_code as dim_detail_code1,
                      dimen2.dim_code as dim_code2,
                      dimen2.dim_detail_code as dim_detail_code2,
                      dimen3.dim_code dim_code3,
                      dimen3.dim_detail_code as dim_detail_code3,
                      dimen4.dim_code dim_code4,
                      dimen4.dim_detail_code as dim_detail_code4
                       from e7_sta_repinst repinst 
                      left join e7_sta_rpt_index_inst ii on repinst.repinst_id = ii.repinst_id
                      left join e7_sta_index_inst iis on ii.sta_index_inst_id = iis.sta_index_inst_id
                      left join e7_sta_index_inst_dimen dimen1 on iis.sta_index_inst_id = dimen1.sta_index_inst_id
                      and dimen1.dim_code like '%_link'
                      /*left join e7_sta_index_inst_dimen dimen2 on iis.sta_index_inst_id = dimen2.sta_index_inst_id
                      and dimen2.dim_code = 'Assets_type'*/
                      left join e7_sta_index_inst_dimen dimen2 on iis.sta_index_inst_id = dimen2.sta_index_inst_id
                      and dimen2.dim_code = 'Industry_type'
                      left join e7_sta_index_inst_dimen dimen3 on iis.sta_index_inst_id = dimen3.sta_index_inst_id
                      and dimen3.dim_code = 'Cru_oil_E_cons_typ' and dimen3.dim_detail_code in(
                      select dim_detail_code from e7_sta_dim_detail where dim_code = 'Cru_oil_E_cons_typ' and parent_dim_detail_code is null
                      )
                      left join e7_sta_index_inst_dimen dimen4 on iis.sta_index_inst_id = dimen4.sta_index_inst_id
                      and dimen4.dim_code = 'Cru_oil_E_cons_typ' and dimen4.dim_detail_code in(
                      select dim_detail_code from e7_sta_dim_detail where dim_code = 'Cru_oil_E_cons_typ' and parent_dim_detail_code is not null
                      )
                      where repinst.report_code = REPORTCODE
                      and repinst.org_id = ORGID
                      and repinst.report_year = REPORTYEAR
                     -- and repinst.report_month = 1
                      ),
                      locationindex_data as (
                      select a.*,b.localtion as index_location from datas a left join e7_excel_locationbyindex b on a.report_code = b.report_code and a.index_code = b.index_code and b.is_py = 'Y'
                      ),
                      localtiondimen1_data as (
                      select * from (
                       select dat.*,dl1.localtion as dl1_location
                        from locationindex_data dat 
                        left join e7_excel_locationbydimen dl1 on dat.report_code = dl1.report_code and  dat.dim_code1 = dl1.dim_code and dat.dim_detail_code1 = dl1.dim_detail_code
                       ) where index_location = dl1_location or dl1_location is null
                       ),
                      locationdimen2_data as ( 
                       select * from (
                       select dim1.*,dl2.localtion as dl2_location from localtiondimen1_data  dim1 
                       left join e7_excel_locationbydimen dl2 on dim1.report_code = dl2.report_code and  dim1.dim_code2 = dl2.dim_code and dim1.dim_detail_code2 = dl2.dim_detail_code 
                      ) where dl2_location is null or index_location = dl2_location
                      ),
                      locationdimen3_data as ( 
                       select * from (
                       select dim2.*,dl3.localtion as dl3_location from locationdimen2_data  dim2 
                       left join e7_excel_locationbydimen dl3 on dim2.report_code = dl3.report_code and  dim2.dim_code3 = dl3.dim_code and dim2.dim_detail_code3 = dl3.dim_detail_code 
                      ) where dl3_location is null or index_location = dl3_location
                      ),
                      locationdimen4_data as ( 
                       select * from (
                       select dim3.*,dl4.localtion as dl4_location from locationdimen3_data  dim3 
                       left join e7_excel_locationbydimen dl4 on dim3.report_code = dl4.report_code and  dim3.dim_code4 = dl4.dim_code and dim3.dim_detail_code4 = dl4.dim_detail_code 
                      ) where dl4_location is null or index_location = dl4_location
                      )
                      select
                      DISTINCT 
                      report_code, 
                      org_id, 
                      report_year, 
                      report_month, 
                      index_location, 
                      index_value
                       from locationdimen4_data);
                 	 location_info E7_STA_LASTYEAR_VALUES%rowtype;

                 BEGIN
                   FOR V_LOCATION IN LOCATION(REPORTCODE,REPORTYEAR,ORGID) LOOP
                     location_info.REPORT_CODE := V_LOCATION.REPORT_CODE;
                     location_info.org_id := V_LOCATION.ORG_ID;
                     location_info.report_year :=V_LOCATION.REPORT_YEAR;
                     location_info.report_month := V_LOCATION.REPORT_MONTH;
                     location_info.LOCATION := V_LOCATION.Index_Location;
                     location_info.index_value := V_LOCATION.Index_Value;
  /*                   open location(REPORTCODE,REPORTYEAR,ORGID);
                     --查出location
                     FETCH location INTO location_info;
                       --插入*/
                      INSERT INTO E7_STA_LASTYEAR_VALUES VALUES location_info;
                      COMMIT;
                     END LOOP;
         END ;
        
         --采集取上年同期
         PROCEDURE update_excel_report_ly_CJ(REPORTCODE in varchar2,REPORTYEAR in varchar2,ORGID in varchar2 )
         IS
         --查出location 游标
                 cursor location(REPORTCODE varchar2)
                 is
                 SELECT ind.report_code,ind.index_code,ind.localtion,
                         dim1.dim_code dim_code1,dim1.dim_detail_code  dim_detail_code1
                  FROM e7_excel_locationbyindex ind
                  left join e7_excel_locationbydimen  dim1
                  on ind.report_code=dim1.report_code and ind.localtion=dim1.localtion
                  and (dim1.dim_code in
                   ('Crude_oil_alter_typ','Chemi_prod_type','Professional_type') 
                  or (dim1.dim_code='Crude_oil_alter_typ1' and dim1.dim_detail_code in ('Industry_C','Non_industrial_C','Industry_G','Non_industrial_G','Industry_O','Non_industrial_O'))
                  or(dim1.dim_code='Crude_oil_alter_typ2' and dim1.dim_detail_code in ('Coal_repl_oil_amo_C','Gas_repl_oil_amo_C','Other_repl_oil_amo_C','Coal_repl_oil_amo_G','Gas_repl_oil_amo_G','Other_repl_oil_amo_G','Coal_repl_oil_amo_R','Gas_repl_oil_amo_R','Other_repl_oil_amo_R'))
                  or(ind.index_code in('Saved_engy_amt','Saved_engy_value_amt','Saved_watr_amt','Saved_watr_value_amt') and dim1.dim_code='Industry_type')
                  )
                  where ind.report_code=REPORTCODE
                  and ind.is_py='Y';
                  location_info location%rowtype;
                  location_value number;
                  REPORTMONTH number;


         BEGIN
                   REPORTMONTH:=0;
                   while(REPORTMONTH<12) LOOP
                   REPORTMONTH:=REPORTMONTH+1;
                     --查出location
                     FOR location_info IN location(REPORTCODE) LOOP
                       begin
                     DBMS_OUTPUT.put_line(location_info.index_code);
                     --查出value         
                     WITH VALTEMP AS(SELECT rr.report_code 
                           ,r.repinst_id
                           ,r.condition
                           ,r.writer
                           ,r.write_date
                           ,r.checker
                           ,indexinst.sta_index_inst_id 
                           ,indexinst.index_code 
                           ,indexinst.index_value
                           ,indexinst.remark
                           ,indexinst.unit_code 
                           ,indexinstdimen.repinst_dtl_dimen 
                           ,nvl(indexinstdimen.dim_code，'*') DIM_CODE1 
                           ,nvl(indexinstdimen.dim_detail_code,'*') DIM_DETAIL_CODE1
                           ,indexinstdimen.unit_code AS dimenunitcode 
                            ,indexinstdimen.composite_dim_code 
                           ,indexinst.index_inst_orderno
                       FROM e7_sta_repinst r
                       LEFT JOIN e7_sta_report rr
                         ON rr.report_code = r.report_code
                       LEFT JOIN e7_sta_rpt_index_inst rptindex
                         ON r.repinst_id = rptindex.repinst_id
                      LEFT JOIN e7_sta_index_inst indexinst
                         ON rptindex.sta_index_inst_id = indexinst.sta_index_inst_id
                       LEFT JOIN e7_sta_index_inst_dimen indexinstdimen
                         ON indexinstdimen.sta_index_inst_id = indexinst.sta_index_inst_id
                        WHERE r.org_id =ORGID
                        AND r.report_year = REPORTYEAR
                        AND r.report_month = REPORTMONTH
                        and r.report_code = REPORTCODE
                       )
                      SELECT index_value INTO location_value FROM VALTEMP
                        WHERE VALTEMP.INDEX_CODE=location_info.index_code AND
                              VALTEMP.DIM_CODE1= nvl(location_info.DIM_CODE1,'*') AND
                              VALTEMP.DIM_DETAIL_CODE1= nvl(location_info.DIM_DETAIL_CODE1,'*');
                         --插入
                      exception when no_data_found then
                      location_value:=0; 
                      
                      end;
                      DBMS_OUTPUT.put_line(location_value );
                      INSERT INTO E7_STA_LASTYEAR_VALUES(REPORT_CODE,ORG_ID,REPORT_YEAR,REPORT_MONTH,LOCATION,INDEX_VALUE) VALUES(REPORTCODE,ORGID,REPORTYEAR,REPORTMONTH,location_info.localtion,location_value);
                      COMMIT;
                     END LOOP;
                END LOOP;
         END ;
         
         PROCEDURE update_excel_report_ly_XSNH(REPORTCODE in varchar2,REPORTYEAR in varchar2,ORGID in varchar2 )
         IS
         --查出location 游标
                 cursor location(REPORTCODE varchar2, REPORTYEAR varchar2, ORGID in varchar2)
                 is select * from (with datas as (
                      select 
                      repinst.org_id,
                      repinst.report_code,
                      repinst.report_year,
                      repinst.report_month,
                      iis.index_code,
                      iis.index_value,
                      dimen1.dim_code dim_code1,
                      dimen1.dim_detail_code as dim_detail_code1,
                      dimen2.dim_code as dim_code2,
                      dimen2.dim_detail_code as dim_detail_code2,
                      dimen3.dim_code dim_code3,
                      dimen3.dim_detail_code as dim_detail_code3,
                      dimen4.dim_code dim_code4,
                      dimen4.dim_detail_code as dim_detail_code4
                       from e7_sta_repinst repinst 
                      left join e7_sta_rpt_index_inst ii on repinst.repinst_id = ii.repinst_id
                      left join e7_sta_index_inst iis on ii.sta_index_inst_id = iis.sta_index_inst_id
                      left join e7_sta_index_inst_dimen dimen1 on iis.sta_index_inst_id = dimen1.sta_index_inst_id
                      and dimen1.dim_code = 'Sale_E_cons_type' and dimen1.dim_detail_code in(
                      select dim_detail_code from e7_sta_dim_detail where dim_code = 'Sale_E_cons_type' and parent_dim_detail_code is null
                      )
                      left join e7_sta_index_inst_dimen dimen2 on iis.sta_index_inst_id = dimen2.sta_index_inst_id
                      and dimen2.dim_code = 'Sale_E_cons_type' and dimen2.dim_detail_code in(
                      select dim_detail_code from e7_sta_dim_detail where dim_code = 'Sale_E_cons_type' and parent_dim_detail_code is not null
                      )
                      left join e7_sta_index_inst_dimen dimen3 on iis.sta_index_inst_id = dimen3.sta_index_inst_id
                      and dimen3.dim_code = 'Sale_E_Loss_type' and dimen3.dim_detail_code in(
                      select dim_detail_code from e7_sta_dim_detail where dim_code = 'Sale_E_Loss_type' and parent_dim_detail_code is null
                      )
                      left join e7_sta_index_inst_dimen dimen4 on iis.sta_index_inst_id = dimen4.sta_index_inst_id
                      and dimen4.dim_code = 'Sale_E_Loss_type' and dimen4.dim_detail_code in(
                      select dim_detail_code from e7_sta_dim_detail where dim_code = 'Sale_E_Loss_type' and parent_dim_detail_code is not null
                      )
                      where repinst.report_code = REPORTCODE
                      and repinst.org_id = ORGID
                      and repinst.report_year = REPORTYEAR
                     -- and repinst.report_month = 1
                      ),
                      locationindex_data as (
                      select a.*,b.localtion as index_location from datas a left join e7_excel_locationbyindex b on a.report_code = b.report_code and a.index_code = b.index_code and b.is_py = 'Y'
                      ),
                      localtiondimen1_data as (
                      select * from (
                       select dat.*,dl1.localtion as dl1_location
                        from locationindex_data dat 
                        left join e7_excel_locationbydimen dl1 on dat.report_code = dl1.report_code and  dat.dim_code1 = dl1.dim_code and dat.dim_detail_code1 = dl1.dim_detail_code
                       ) where index_location = dl1_location or dl1_location is null
                       ),
                      locationdimen2_data as ( 
                       select * from (
                       select dim1.*,dl2.localtion as dl2_location from localtiondimen1_data  dim1 
                       left join e7_excel_locationbydimen dl2 on dim1.report_code = dl2.report_code and  dim1.dim_code2 = dl2.dim_code and dim1.dim_detail_code2 = dl2.dim_detail_code 
                      ) where dl2_location is null or index_location = dl2_location
                      ),
                      locationdimen3_data as ( 
                       select * from (
                       select dim2.*,dl3.localtion as dl3_location from locationdimen2_data  dim2 
                       left join e7_excel_locationbydimen dl3 on dim2.report_code = dl3.report_code and  dim2.dim_code3 = dl3.dim_code and dim2.dim_detail_code3 = dl3.dim_detail_code 
                      ) where dl3_location is null or index_location = dl3_location
                      ),
                      locationdimen4_data as ( 
                       select * from (
                       select dim3.*,dl4.localtion as dl4_location from locationdimen3_data  dim3 
                       left join e7_excel_locationbydimen dl4 on dim3.report_code = dl4.report_code and  dim3.dim_code4 = dl4.dim_code and dim3.dim_detail_code4 = dl4.dim_detail_code 
                      ) where dl4_location is null or index_location = dl4_location
                      )
                      
                      select 
                      report_code, 
                      org_id, 
                      report_year, 
                      report_month, 
                      index_location, 
                      index_value
                       from locationdimen4_data where index_location is not null);
                 	 location_info E7_STA_LASTYEAR_VALUES%rowtype;

                 BEGIN
                   FOR V_LOCATION IN LOCATION(REPORTCODE,REPORTYEAR,ORGID) LOOP
                     location_info.REPORT_CODE := V_LOCATION.REPORT_CODE;
                     location_info.org_id := V_LOCATION.ORG_ID;
                     location_info.report_year :=V_LOCATION.REPORT_YEAR;
                     location_info.report_month := V_LOCATION.REPORT_MONTH;
                     location_info.LOCATION := V_LOCATION.Index_Location;
                     location_info.index_value := V_LOCATION.Index_Value;
  /*                   open location(REPORTCODE,REPORTYEAR,ORGID);
                     --查出location
                     FETCH location INTO location_info;
                       --插入*/
                      INSERT INTO E7_STA_LASTYEAR_VALUES VALUES location_info;
                      COMMIT;
                     END LOOP;
         END ;
END UPDATESTALASTYEAR;





/

