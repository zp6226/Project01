CREATE package body getSumValues is

procedure getSourceReportCode(P_RPTCODE IN VARCHAR2,
                       P_RPTYEAR  IN VARCHAR2,
                       P_RPTMONTH IN VARCHAR2,
                       P_RPTORGID IN VARCHAR2,jsonValue OUT VARCHAR2) 
                       --RETURN VARCHAR2
  IS
   BEGIN
     IF P_RPTCODE='T0007' THEN getT0007Sum(P_RPTCODE, P_RPTYEAR, P_RPTMONTH, P_RPTORGID, jsonValue); END IF;
     IF P_RPTCODE='T0008' THEN getT0008Sum(P_RPTCODE, P_RPTYEAR, P_RPTMONTH, P_RPTORGID, jsonValue); END IF;
     IF P_RPTCODE='T0009' THEN getT0009Sum(P_RPTCODE, P_RPTYEAR, P_RPTMONTH, P_RPTORGID, jsonValue); END IF;
     IF P_RPTCODE='T0010' THEN getT0010Sum(P_RPTCODE, P_RPTYEAR, P_RPTMONTH, P_RPTORGID, jsonValue); END IF;
     IF P_RPTCODE='T0011' THEN getT0011Sum(P_RPTCODE, P_RPTYEAR, P_RPTMONTH, P_RPTORGID, jsonValue); END IF;
     IF P_RPTCODE='T0012' THEN getT0012Sum(P_RPTCODE, P_RPTYEAR, P_RPTMONTH, P_RPTORGID, jsonValue); END IF;
     IF P_RPTCODE='T0013' THEN getT0013Sum(P_RPTCODE, P_RPTYEAR, P_RPTMONTH, P_RPTORGID, jsonValue); END IF;
     IF P_RPTCODE='T0014' THEN getT0014Sum(P_RPTCODE, P_RPTYEAR, P_RPTMONTH, P_RPTORGID, jsonValue); END IF;
     IF P_RPTCODE='T0015' THEN getT0015Sum(P_RPTCODE, P_RPTYEAR, P_RPTMONTH, P_RPTORGID, jsonValue); END IF;
     IF P_RPTCODE='T0016' THEN getT0016Sum(P_RPTCODE, P_RPTYEAR, P_RPTMONTH, P_RPTORGID, jsonValue); END IF;
     IF P_RPTCODE='T0020' THEN getT0020Sum(P_RPTCODE, P_RPTYEAR, P_RPTMONTH, P_RPTORGID, jsonValue); END IF;
     IF P_RPTCODE='T0021' THEN getT0021Sum(P_RPTCODE, P_RPTYEAR, P_RPTMONTH, P_RPTORGID, jsonValue); END IF;
     IF P_RPTCODE='T0022' THEN getT0022Sum(P_RPTCODE, P_RPTYEAR, P_RPTMONTH, P_RPTORGID, jsonValue); END IF;
     IF P_RPTCODE='T0001' THEN getT0001Sum(P_RPTCODE, P_RPTYEAR, P_RPTMONTH, P_RPTORGID, jsonValue); END IF;
     IF P_RPTCODE='T0002' THEN getT0002Sum(P_RPTCODE, P_RPTYEAR, P_RPTMONTH, P_RPTORGID, jsonValue); END IF;
     IF P_RPTCODE='T0030' THEN getT0030Sum(P_RPTCODE, P_RPTYEAR, P_RPTMONTH, P_RPTORGID, jsonValue); END IF;
     IF P_RPTCODE='T0031' THEN getT0031Sum(P_RPTCODE, P_RPTYEAR, P_RPTMONTH, P_RPTORGID, jsonValue); END IF;
     IF P_RPTCODE='T0033' THEN getT0033Sum(P_RPTCODE, P_RPTYEAR, P_RPTMONTH, P_RPTORGID, jsonValue); END IF;
     IF P_RPTCODE='T0035' THEN getT0035Sum(P_RPTCODE, P_RPTYEAR, P_RPTMONTH, P_RPTORGID, jsonValue); END IF;
     IF P_RPTCODE='T0036' THEN getSBZBSum(P_RPTCODE, P_RPTYEAR, P_RPTMONTH, P_RPTORGID, jsonValue);END IF;
     IF P_RPTCODE='T0037' THEN getSBZBSum(P_RPTCODE, P_RPTYEAR, P_RPTMONTH, P_RPTORGID, jsonValue);END IF;
     IF P_RPTCODE='T0038' THEN getSBZBSum(P_RPTCODE, P_RPTYEAR, P_RPTMONTH, P_RPTORGID, jsonValue);END IF;
     IF P_RPTCODE='T0039' THEN getSBZBSum(P_RPTCODE, P_RPTYEAR, P_RPTMONTH, P_RPTORGID, jsonValue);END IF;
     IF P_RPTCODE='T0053' THEN getT0053Sum(P_RPTCODE, P_RPTYEAR, P_RPTMONTH, P_RPTORGID, jsonValue);END IF;
     IF P_RPTCODE='T0054' THEN getT0054Sum(P_RPTCODE, P_RPTYEAR, P_RPTMONTH, P_RPTORGID, jsonValue);END IF;
     IF P_RPTCODE='T0085' THEN getT0085Sum(P_RPTCODE, P_RPTYEAR, P_RPTMONTH, P_RPTORGID, jsonValue);END IF;
     
     IF P_RPTCODE='T0042' THEN getT0085Sum(P_RPTCODE, P_RPTYEAR, P_RPTMONTH, P_RPTORGID, jsonValue);END IF;
     IF P_RPTCODE='T0043' THEN getT0085Sum(P_RPTCODE, P_RPTYEAR, P_RPTMONTH, P_RPTORGID, jsonValue);END IF;
     
     IF P_RPTCODE IN ('C0001','C0006','C0011','C0016','C0021','C0026','C0034','C0044','C0051','C0056','C0061','C0071','C0076','C0083','C0094','C0099','C0104','C0114','C0168') THEN getSCSum(P_RPTCODE, P_RPTYEAR, P_RPTMONTH, P_RPTORGID, jsonValue);END IF;
     IF P_RPTCODE IN ('C0004','C0009','C0014','C0019','C0024','C0029','C0037','C0047','C0054','C0059','C0069','C0074','C0079','C0097','C0102','C0107','C0117','C0171') THEN getSBSum(P_RPTCODE, P_RPTYEAR, P_RPTMONTH, P_RPTORGID, jsonValue);END IF;
     IF P_RPTCODE IN ('C0005','C0010','C0015','C0020','C0025','C0030','C0039','C0049','C0055','C0060','C0070','C0075','C0080','C0098','C0103','C0108','C0118','C0172') THEN getCJSum(P_RPTCODE, P_RPTYEAR, P_RPTMONTH, P_RPTORGID, jsonValue);END IF;
  END;
  
   --T0053
  
   procedure getT0053Sum(P_RPTCODE IN VARCHAR2,
                         P_RPTYEAR  IN VARCHAR2,
                         P_RPTMONTH IN VARCHAR2,
                         P_RPTORGID IN VARCHAR2,jsonStr OUT CLOB) IS
    
    Cursor return_cursor is

with collect1_L8 as(
select 
       indexinst.index_code,
       NVL(SUM(indexinst.index_value),0) index_value
  
  from e7_sta_repinst repinst
  left join e7_sta_rpt_index_inst repinst_indexinst
    on repinst.repinst_id = repinst_indexinst.repinst_id
  left join e7_sta_index_inst indexinst
    on indexinst.sta_index_inst_id = repinst_indexinst.sta_index_inst_id
  left join e7_sta_index_inst_dimen indexinst_dim
    on indexinst_dim.sta_index_inst_id = indexinst.sta_index_inst_id
 where repinst.report_code in ('T0042','T0043')
   and repinst.org_id =P_RPTORGID
   and repinst.report_year =P_RPTYEAR
   and repinst.report_month = P_RPTMONTH
  and indexinst.index_code = 'Fresh_water_consu_amt'  --新鲜水用量 >>油节水统1-1表，油节水统1-2表
  group by indexinst.index_code
  ),
   collect1_L10 as (
select 
       indexinst.index_code,
       NVL(SUM(indexinst.index_value),0) index_value
  
  from e7_sta_repinst repinst
  left join e7_sta_rpt_index_inst repinst_indexinst
    on repinst.repinst_id = repinst_indexinst.repinst_id
  left join e7_sta_index_inst indexinst
    on indexinst.sta_index_inst_id = repinst_indexinst.sta_index_inst_id
  left join e7_sta_index_inst_dimen indexinst_dim
    on indexinst_dim.sta_index_inst_id = indexinst.sta_index_inst_id
 where repinst.report_code in ('T0042')
   and repinst.org_id =P_RPTORGID
   and repinst.report_year =P_RPTYEAR
   and repinst.report_month = P_RPTMONTH
  and indexinst.index_code = 'Fresh_water_consu_amt'  --新鲜水用量 >>油节水统1-1表，油节水统1-2表
  group by indexinst.index_code
)
, collect1_L11 as (
select 
       indexinst.index_code,
       NVL(SUM(indexinst.index_value),0) index_value
  
  from e7_sta_repinst repinst
  left join e7_sta_rpt_index_inst repinst_indexinst
    on repinst.repinst_id = repinst_indexinst.repinst_id
  left join e7_sta_index_inst indexinst
    on indexinst.sta_index_inst_id = repinst_indexinst.sta_index_inst_id
  left join e7_sta_index_inst_dimen indexinst_dim
    on indexinst_dim.sta_index_inst_id = indexinst.sta_index_inst_id
 where repinst.report_code in ('T0043')
   and repinst.org_id =P_RPTORGID
   and repinst.report_year =P_RPTYEAR
   and repinst.report_month = P_RPTMONTH
  and indexinst.index_code = 'Fresh_water_consu_amt'  --新鲜水用量 >>油节水统1-1表，油节水统1-2表
  group by indexinst.index_code
)
, collect_L12 as (
select 
       rownum,
       repinst.report_code,
       indexinst.index_code,
       indexinst_dim.dim_deteail_id,
       indexinst_dim.dim_detail_code,
       indexinst_dim.dim_code,
       indexinst.index_value,
       indexinst.composited_index_code,
       indexinst_dim.composite_dim_code
  from e7_sta_repinst repinst
  left join e7_sta_rpt_index_inst repinst_indexinst
    on repinst.repinst_id = repinst_indexinst.repinst_id
  left join e7_sta_index_inst indexinst
    on indexinst.sta_index_inst_id = repinst_indexinst.sta_index_inst_id
  left join e7_sta_index_inst_dimen indexinst_dim
    on indexinst_dim.sta_index_inst_id = indexinst.sta_index_inst_id
 where repinst.report_code in('C0003' ,'C0008' ,'C0039' ,'C0049' ,'C0036' ,'C0046' )
   and repinst.org_id in (select org_id from e7_sta_rpt_auth where v_org_id =P_RPTORGID and report_code  in ('C0003' ,'C0008' ,'C0039' ,'C0049' ,'C0036' ,'C0046' ))
   and repinst.report_year =P_RPTYEAR
   and repinst.report_month = P_RPTMONTH
   
   and(
            (index_code in( 'Co_prod','Ng_prod','Watr_prod' )  and report_code in ( 'C0001','C0006') )     --产液量 >>稀油1-1表，稠油1-1表  
        -- 工业污水回注量，工业污水产生量 >>稀油1-3表，稠油1-3表
        or  ((indexinst.index_code = 'Ind_wastew_reinj_amt' or indexinst.index_code ='Ind_wastew_gene_amt' ) and report_code in('C0003','C0008') and dim_code = 'Assets_type') 
        -- 循环水浓缩倍数,重复利用率子项，重复利用率母项,蒸汽冷凝水回收率子项，母项 >>炼油1-9表,化工1-9表    
        or  (((indexinst.index_code = 'Circl_watr_concentr_ratio' or indexinst.index_code = 'watr_reuse_ratio_mole' or indexinst.index_code = 'watr_reuse_ratio_deno' or indexinst.index_code = 'Stmcond_reclaim_rate_mole' or indexinst.index_code = 'Stmcond_reclaim_rate_deno' ) and report_code in ('C0039','C0049'))  )  
        or ((index_code = 'Co_procs_unit_watr_csmp_mole' or index_code = 'sewg_unit_oil_mole' or index_code = 'Og_prod') and report_code = 'C0039') or    -- 炼油耗新水量>>炼油1-9
        (index_code = 'Og_prod' and report_code = 'C0034') or   --原油及原料油（气）加工量 >>炼油1-4
        ((index_code = 'Eth_unit_watr_csmp' or index_code = 'Ammo_unit_watr_csmp') and report_code = 'C0049') or    -- 乙烯耗新水量本期值 >>化工1-9 
        ((index_code = 'Eth_prod'or index_code = 'Synth_amm_prod') and report_code = 'C0044')  or  --乙烯>>化工1-4 
        ((index_code = 'Ind_wastew_reu_amt' or index_code = 'Ind_wastew_gene_amt' ) and report_code in ('C0036','C0046') and dim_code = 'Assets_type' ) or --工业污水会用量，工业污水回注量[回收量],工业污水产生量>> 炼油1-6，化工1-6 
        ((index_code = 'Watr_comph_lost_rate_mole' or index_code = 'Watr_comph_lost_rate_deno' ) and report_code in( 'C0039','C0049') )  --企业用水综合漏失率子项,企业用水综合漏失率母项 >>炼油1-9，化工1-9 
       )
       
       
       union all
       
       
       select 
       rownum,
       repinst.report_code,
       indexinst.index_code,
       indexinst_dim.dim_deteail_id,
       indexinst_dim.dim_detail_code,
       indexinst_dim.dim_code,
       indexinst.index_value,
       indexinst.composited_index_code,
       indexinst_dim.composite_dim_code
  from e7_sta_repinst repinst
  left join e7_sta_rpt_index_inst repinst_indexinst
    on repinst.repinst_id = repinst_indexinst.repinst_id
  left join e7_sta_index_inst indexinst
    on indexinst.sta_index_inst_id = repinst_indexinst.sta_index_inst_id
  left join e7_sta_index_inst_dimen indexinst_dim
    on indexinst_dim.sta_index_inst_id = indexinst.sta_index_inst_id
 where repinst.report_code in( 'C0001' ,'C0006' ,'C0034' ,'C0044' )
   and repinst.org_id in (select org_id from e7_sta_rpt_auth where v_org_id =P_RPTORGID and report_code  in  ( 'C0001' ,'C0006' ,'C0034' ,'C0044' ))
   and repinst.report_year =P_RPTYEAR
   and repinst.report_month = P_RPTMONTH
   
   and(
            (index_code in( 'Co_prod','Ng_prod','Watr_prod' ) and report_code in ( 'C0001','C0006') )     --产液量 >>稀油1-1表，稠油1-1表  
        -- 工业污水回注量，工业污水产生量 >>稀油1-3表，稠油1-3表
        or  ((indexinst.index_code = 'Ind_wastew_reinj_amt' or indexinst.index_code ='Ind_wastew_gene_amt' ) and report_code in('C0003','C0008') and dim_code = 'Assets_type') 
        -- 循环水浓缩倍数,重复利用率子项，重复利用率母项,蒸汽冷凝水回收率子项，母项 >>炼油1-9表,化工1-9表    
        or  (((indexinst.index_code = 'Circl_watr_concentr_ratio' or indexinst.index_code = 'watr_reuse_ratio_mole' or indexinst.index_code = 'watr_reuse_ratio_deno' or indexinst.index_code = 'Stmcond_reclaim_rate_mole' or indexinst.index_code = 'Stmcond_reclaim_rate_deno' ) and report_code in ('C0039','C0049'))  )  
        or ((index_code = 'Co_procs_unit_watr_csmp_mole' or index_code = 'sewg_unit_oil_mole' or index_code = 'Og_prod') and report_code = 'C0039') or    -- 炼油耗新水量>>炼油1-9
        (index_code = 'Og_prod' and report_code = 'C0034') or   --原油及原料油（气）加工量 >>炼油1-4
        ((index_code = 'Eth_unit_watr_csmp' or index_code = 'Ammo_unit_watr_csmp') and report_code = 'C0049') or    -- 乙烯耗新水量本期值 >>化工1-9 
        ((index_code = 'Eth_prod'or index_code = 'Synth_amm_prod') and report_code = 'C0044')  or  --乙烯>>化工1-4 
        ((index_code = 'Ind_wastew_reu_amt' or index_code = 'Ind_wastew_gene_amt' ) and report_code in ('C0036','C0046') and dim_code = 'Assets_type' ) or --工业污水会用量，工业污水回注量[回收量],工业污水产生量>> 炼油1-6，化工1-6 
        ((index_code = 'Watr_comph_lost_rate_mole' or index_code = 'Watr_comph_lost_rate_deno' ) and report_code in( 'C0039','C0049') )  --企业用水综合漏失率子项,企业用水综合漏失率母项 >>炼油1-9，化工1-9 
       )
)
, collectG_L13 as (
select 
       rownum,
       repinst.report_code,
       indexinst.index_code,
       indexinst_dim.dim_deteail_id,
       indexinst_dim.dim_detail_code,
       indexinst_dim.dim_code,
       indexinst.index_value,
       indexinst.composited_index_code,
       indexinst_dim.composite_dim_code
  from e7_sta_repinst repinst
  left join e7_sta_rpt_index_inst repinst_indexinst
    on repinst.repinst_id = repinst_indexinst.repinst_id
  left join e7_sta_index_inst indexinst
    on indexinst.sta_index_inst_id = repinst_indexinst.sta_index_inst_id
  left join e7_sta_index_inst_dimen indexinst_dim
    on indexinst_dim.sta_index_inst_id = indexinst.sta_index_inst_id
 where repinst.report_code in ('T0042','T0043','T0044','T0045')
   and repinst.org_id =P_RPTORGID
   and repinst.report_year =P_RPTYEAR
   and repinst.report_month = P_RPTMONTH
   
   union all
   
   select 
       rownum,
       repinst.report_code,
       indexinst.index_code,
       indexinst_dim.dim_deteail_id,
       indexinst_dim.dim_detail_code,
       indexinst_dim.dim_code,
       indexinst.index_value,
       indexinst.composited_index_code,
       indexinst_dim.composite_dim_code
  from e7_sta_repinst repinst
  left join e7_sta_rpt_index_inst repinst_indexinst
    on repinst.repinst_id = repinst_indexinst.repinst_id
  left join e7_sta_index_inst indexinst
    on indexinst.sta_index_inst_id = repinst_indexinst.sta_index_inst_id
  left join e7_sta_index_inst_dimen indexinst_dim
    on indexinst_dim.sta_index_inst_id = indexinst.sta_index_inst_id
 where repinst.report_code in ('T0001')
   and repinst.org_id =P_RPTORGID
   and repinst.report_year =P_RPTYEAR
   and repinst.report_month = P_RPTMONTH

)
,collect_G15 AS (


select 
       rownum,
       repinst.report_code,
       indexinst.index_code,
       indexinst_dim.dim_deteail_id,
       indexinst_dim.dim_detail_code,
       indexinst_dim.dim_code,
       indexinst.index_value,
       indexinst.composited_index_code,
       indexinst_dim.composite_dim_code
  from e7_sta_repinst repinst
  left join e7_sta_rpt_index_inst repinst_indexinst
    on repinst.repinst_id = repinst_indexinst.repinst_id
  left join e7_sta_index_inst indexinst
    on indexinst.sta_index_inst_id = repinst_indexinst.sta_index_inst_id
  left join e7_sta_index_inst_dimen indexinst_dim
    on indexinst_dim.sta_index_inst_id = indexinst.sta_index_inst_id
 where repinst.report_code in('C0003' ,'C0008' ,'C0039' ,'C0049' ,'C0036' ,'C0046' )
   and repinst.org_id in (select org_id from e7_sta_rpt_auth where v_org_id =P_RPTORGID and report_code  in ('C0003' ,'C0008' ,'C0039' ,'C0049' ,'C0036' ,'C0046' ))
   and repinst.report_year =P_RPTYEAR
   and repinst.report_month = P_RPTMONTH
   
   and(
            (index_code in( 'Co_prod','Ng_prod','Watr_prod' )  and report_code in ( 'C0001','C0006') )     --产液量 >>稀油1-1表，稠油1-1表  
        -- 工业污水回注量，工业污水产生量 >>稀油1-3表，稠油1-3表
        or  ((indexinst.index_code = 'Ind_wastew_reinj_amt' or indexinst.index_code ='Ind_wastew_gene_amt' ) and report_code in('C0003','C0008') and dim_code = 'Assets_type') 
        -- 循环水浓缩倍数,重复利用率子项，重复利用率母项,蒸汽冷凝水回收率子项，母项 >>炼油1-9表,化工1-9表    
        or  (((indexinst.index_code = 'Circl_watr_concentr_ratio' or indexinst.index_code = 'watr_reuse_ratio_mole' or indexinst.index_code = 'watr_reuse_ratio_deno' or indexinst.index_code = 'Stmcond_reclaim_rate_mole' or indexinst.index_code = 'Stmcond_reclaim_rate_deno' ) and report_code in ('C0039','C0049'))  )  
        or ((index_code = 'Co_procs_unit_watr_csmp_mole' or index_code = 'sewg_unit_oil_mole' or index_code = 'Og_prod') and report_code = 'C0039') or    -- 炼油耗新水量>>炼油1-9
        (index_code = 'Og_prod' and report_code = 'C0034') or   --原油及原料油（气）加工量 >>炼油1-4
        ((index_code = 'Eth_unit_watr_csmp' or index_code = 'Ammo_unit_watr_csmp') and report_code = 'C0049') or    -- 乙烯耗新水量本期值 >>化工1-9 
        ((index_code = 'Eth_prod'or index_code = 'Synth_amm_prod') and report_code = 'C0044')  or  --乙烯>>化工1-4 
        ((index_code = 'Ind_wastew_reu_amt' or index_code = 'Ind_wastew_gene_amt' ) and report_code in ('C0036','C0046') and dim_code = 'Assets_type' ) or --工业污水会用量，工业污水回注量[回收量],工业污水产生量>> 炼油1-6，化工1-6 
        ((index_code = 'Watr_comph_lost_rate_mole' or index_code = 'Watr_comph_lost_rate_deno' ) and report_code in( 'C0039','C0049') )  --企业用水综合漏失率子项,企业用水综合漏失率母项 >>炼油1-9，化工1-9 
       )
       
       
       union all
       
       
       select 
       rownum,
       repinst.report_code,
       indexinst.index_code,
       indexinst_dim.dim_deteail_id,
       indexinst_dim.dim_detail_code,
       indexinst_dim.dim_code,
       indexinst.index_value,
       indexinst.composited_index_code,
       indexinst_dim.composite_dim_code
  from e7_sta_repinst repinst
  left join e7_sta_rpt_index_inst repinst_indexinst
    on repinst.repinst_id = repinst_indexinst.repinst_id
  left join e7_sta_index_inst indexinst
    on indexinst.sta_index_inst_id = repinst_indexinst.sta_index_inst_id
  left join e7_sta_index_inst_dimen indexinst_dim
    on indexinst_dim.sta_index_inst_id = indexinst.sta_index_inst_id
 where repinst.report_code in( 'C0001' ,'C0006' ,'C0034' ,'C0044' )
   and repinst.org_id in (select org_id from e7_sta_rpt_auth where v_org_id =P_RPTORGID and report_code  in  ( 'C0001' ,'C0006' ,'C0034' ,'C0044' ))
   and repinst.report_year =P_RPTYEAR
   and repinst.report_month = P_RPTMONTH
   
   and(
            (index_code in( 'Co_prod','Ng_prod','Watr_prod' ) and report_code in ( 'C0001','C0006') )     --产液量 >>稀油1-1表，稠油1-1表  
        -- 工业污水回注量，工业污水产生量 >>稀油1-3表，稠油1-3表
        or  ((indexinst.index_code = 'Ind_wastew_reinj_amt' or indexinst.index_code ='Ind_wastew_gene_amt' ) and report_code in('C0003','C0008') and dim_code = 'Assets_type') 
        -- 循环水浓缩倍数,重复利用率子项，重复利用率母项,蒸汽冷凝水回收率子项，母项 >>炼油1-9表,化工1-9表    
        or  (((indexinst.index_code = 'Circl_watr_concentr_ratio' or indexinst.index_code = 'watr_reuse_ratio_mole' or indexinst.index_code = 'watr_reuse_ratio_deno' or indexinst.index_code = 'Stmcond_reclaim_rate_mole' or indexinst.index_code = 'Stmcond_reclaim_rate_deno' ) and report_code in ('C0039','C0049'))  )  
        or ((index_code = 'Co_procs_unit_watr_csmp_mole' or index_code = 'sewg_unit_oil_mole' or index_code = 'Og_prod') and report_code = 'C0039') or    -- 炼油耗新水量>>炼油1-9
        (index_code = 'Og_prod' and report_code = 'C0034') or   --原油及原料油（气）加工量 >>炼油1-4
        ((index_code = 'Eth_unit_watr_csmp' or index_code = 'Ammo_unit_watr_csmp') and report_code = 'C0049') or    -- 乙烯耗新水量本期值 >>化工1-9 
        ((index_code = 'Eth_prod'or index_code = 'Synth_amm_prod') and report_code = 'C0044')  or  --乙烯>>化工1-4 
        ((index_code = 'Ind_wastew_reu_amt' or index_code = 'Ind_wastew_gene_amt' ) and report_code in ('C0036','C0046') and dim_code = 'Assets_type' ) or --工业污水会用量，工业污水回注量[回收量],工业污水产生量>> 炼油1-6，化工1-6 
        ((index_code = 'Watr_comph_lost_rate_mole' or index_code = 'Watr_comph_lost_rate_deno' ) and report_code in( 'C0039','C0049') )  --企业用水综合漏失率子项,企业用水综合漏失率母项 >>炼油1-9，化工1-9 
       )

)
, collect3_O8 AS ( 


select 
       rownum,
       repinst.org_id,
       repinst.report_code,
       indexinst.index_code,
       indexinst_dim.dim_deteail_id,
       indexinst_dim.dim_detail_code,
       indexinst_dim.dim_code,
       indexinst.index_value,
       indexinst.composited_index_code,
       indexinst_dim.composite_dim_code
  from e7_sta_repinst repinst
  left join e7_sta_rpt_index_inst repinst_indexinst
    on repinst.repinst_id = repinst_indexinst.repinst_id
  left join e7_sta_index_inst indexinst
    on indexinst.sta_index_inst_id = repinst_indexinst.sta_index_inst_id
  left join e7_sta_index_inst_dimen indexinst_dim
    on indexinst_dim.sta_index_inst_id = indexinst.sta_index_inst_id
 where repinst.report_code in ('T0001')
   and repinst.org_id =P_RPTORGID
   and repinst.report_year =P_RPTYEAR
   and repinst.report_month =P_RPTMONTH

   and (index_code = 'Co_prod'or (index_code = 'Ng_prod' and dim_code = 'Orig_energy_type' ) or index_code = 'Liqd_prod' or index_code = 'Watr_prod')  

)
, collect_O10 AS ( 


select 
       rownum,
       repinst.report_code,
       indexinst.index_code,
       indexinst_dim.dim_deteail_id,
       indexinst_dim.dim_detail_code,
       indexinst_dim.dim_code,
       indexinst.index_value,
       indexinst.composited_index_code,
       indexinst_dim.composite_dim_code
  from e7_sta_repinst repinst
  left join e7_sta_rpt_index_inst repinst_indexinst
    on repinst.repinst_id = repinst_indexinst.repinst_id
  left join e7_sta_index_inst indexinst
    on indexinst.sta_index_inst_id = repinst_indexinst.sta_index_inst_id
  left join e7_sta_index_inst_dimen indexinst_dim
    on indexinst_dim.sta_index_inst_id = indexinst.sta_index_inst_id
 where repinst.report_code in('C0003' ,'C0008' ,'C0039' ,'C0049' ,'C0036' ,'C0046' )
   and repinst.org_id in (select org_id from e7_sta_rpt_auth where v_org_id =P_RPTORGID and report_code  in ('C0003' ,'C0008' ,'C0039' ,'C0049' ,'C0036' ,'C0046' ))
   and repinst.report_year =P_RPTYEAR
   and repinst.report_month = P_RPTMONTH
   
   and(
            (index_code in( 'Co_prod','Ng_prod','Watr_prod' )  and report_code in ( 'C0001','C0006') )     --产液量 >>稀油1-1表，稠油1-1表  
        -- 工业污水回注量，工业污水产生量 >>稀油1-3表，稠油1-3表
        or  ((indexinst.index_code = 'Ind_wastew_reinj_amt' or indexinst.index_code ='Ind_wastew_gene_amt' ) and report_code in('C0003','C0008') and dim_code = 'Assets_type') 
        -- 循环水浓缩倍数,重复利用率子项，重复利用率母项,蒸汽冷凝水回收率子项，母项 >>炼油1-9表,化工1-9表    
        or  (((indexinst.index_code = 'Circl_watr_concentr_ratio' or indexinst.index_code = 'watr_reuse_ratio_mole' or indexinst.index_code = 'watr_reuse_ratio_deno' or indexinst.index_code = 'Stmcond_reclaim_rate_mole' or indexinst.index_code = 'Stmcond_reclaim_rate_deno' ) and report_code in ('C0039','C0049'))  )  
        or ((index_code = 'Co_procs_unit_watr_csmp_mole' or index_code = 'sewg_unit_oil_mole' or index_code = 'Og_prod') and report_code = 'C0039') or    -- 炼油耗新水量>>炼油1-9
        (index_code = 'Og_prod' and report_code = 'C0034') or   --原油及原料油（气）加工量 >>炼油1-4
        ((index_code = 'Eth_unit_watr_csmp' or index_code = 'Ammo_unit_watr_csmp') and report_code = 'C0049') or    -- 乙烯耗新水量本期值 >>化工1-9 
        ((index_code = 'Eth_prod'or index_code = 'Synth_amm_prod') and report_code = 'C0044')  or  --乙烯>>化工1-4 
        ((index_code = 'Ind_wastew_reu_amt' or index_code = 'Ind_wastew_gene_amt' ) and report_code in ('C0036','C0046') and dim_code = 'Assets_type' ) or --工业污水会用量，工业污水回注量[回收量],工业污水产生量>> 炼油1-6，化工1-6 
        ((index_code = 'Watr_comph_lost_rate_mole' or index_code = 'Watr_comph_lost_rate_deno' ) and report_code in( 'C0039','C0049') )  --企业用水综合漏失率子项,企业用水综合漏失率母项 >>炼油1-9，化工1-9 
       )
       
       
       union all
       
       
       select 
       rownum,
       repinst.report_code,
       indexinst.index_code,
       indexinst_dim.dim_deteail_id,
       indexinst_dim.dim_detail_code,
       indexinst_dim.dim_code,
       indexinst.index_value,
       indexinst.composited_index_code,
       indexinst_dim.composite_dim_code
  from e7_sta_repinst repinst
  left join e7_sta_rpt_index_inst repinst_indexinst
    on repinst.repinst_id = repinst_indexinst.repinst_id
  left join e7_sta_index_inst indexinst
    on indexinst.sta_index_inst_id = repinst_indexinst.sta_index_inst_id
  left join e7_sta_index_inst_dimen indexinst_dim
    on indexinst_dim.sta_index_inst_id = indexinst.sta_index_inst_id
 where repinst.report_code in( 'C0001' ,'C0006' ,'C0034' ,'C0044' )
   and repinst.org_id in (select org_id from e7_sta_rpt_auth where v_org_id =P_RPTORGID and report_code  in  ( 'C0001' ,'C0006' ,'C0034' ,'C0044' ))
   and repinst.report_year =P_RPTYEAR
   and repinst.report_month = P_RPTMONTH
   
   and(
            (index_code in( 'Co_prod','Ng_prod','Watr_prod' ) and report_code in ( 'C0001','C0006') )     --产液量 >>稀油1-1表，稠油1-1表  
        -- 工业污水回注量，工业污水产生量 >>稀油1-3表，稠油1-3表
        or  ((indexinst.index_code = 'Ind_wastew_reinj_amt' or indexinst.index_code ='Ind_wastew_gene_amt' ) and report_code in('C0003','C0008') and dim_code = 'Assets_type') 
        -- 循环水浓缩倍数,重复利用率子项，重复利用率母项,蒸汽冷凝水回收率子项，母项 >>炼油1-9表,化工1-9表    
        or  (((indexinst.index_code = 'Circl_watr_concentr_ratio' or indexinst.index_code = 'watr_reuse_ratio_mole' or indexinst.index_code = 'watr_reuse_ratio_deno' or indexinst.index_code = 'Stmcond_reclaim_rate_mole' or indexinst.index_code = 'Stmcond_reclaim_rate_deno' ) and report_code in ('C0039','C0049'))  )  
        or ((index_code = 'Co_procs_unit_watr_csmp_mole' or index_code = 'sewg_unit_oil_mole' or index_code = 'Og_prod') and report_code = 'C0039') or    -- 炼油耗新水量>>炼油1-9
        (index_code = 'Og_prod' and report_code = 'C0034') or   --原油及原料油（气）加工量 >>炼油1-4
        ((index_code = 'Eth_unit_watr_csmp' or index_code = 'Ammo_unit_watr_csmp') and report_code = 'C0049') or    -- 乙烯耗新水量本期值 >>化工1-9 
        ((index_code = 'Eth_prod'or index_code = 'Synth_amm_prod') and report_code = 'C0044')  or  --乙烯>>化工1-4 
        ((index_code = 'Ind_wastew_reu_amt' or index_code = 'Ind_wastew_gene_amt' ) and report_code in ('C0036','C0046') and dim_code = 'Assets_type' ) or --工业污水会用量，工业污水回注量[回收量],工业污水产生量>> 炼油1-6，化工1-6 
        ((index_code = 'Watr_comph_lost_rate_mole' or index_code = 'Watr_comph_lost_rate_deno' ) and report_code in( 'C0039','C0049') )  --企业用水综合漏失率子项,企业用水综合漏失率母项 >>炼油1-9，化工1-9 
       )

)  
, collectgas_O11 AS ( 
select 
       rownum,
       repinst.report_code,
       indexinst.index_code,
       indexinst_dim.dim_deteail_id,
       indexinst_dim.dim_detail_code,
       indexinst_dim.dim_code,
       indexinst.index_value,
       indexinst.composited_index_code,
       indexinst_dim.composite_dim_code
  from e7_sta_repinst repinst
  left join e7_sta_rpt_index_inst repinst_indexinst
    on repinst.repinst_id = repinst_indexinst.repinst_id
  left join e7_sta_index_inst indexinst
    on indexinst.sta_index_inst_id = repinst_indexinst.sta_index_inst_id
  left join e7_sta_index_inst_dimen indexinst_dim
    on indexinst_dim.sta_index_inst_id = indexinst.sta_index_inst_id
 where repinst.report_code in  ('C0011')
   and repinst.org_id in (select org_id from e7_sta_rpt_auth where v_org_id =P_RPTORGID and report_code  in  ('C0011'))
   and repinst.report_year =P_RPTYEAR
   and repinst.report_month = P_RPTMONTH
and indexinst.index_code in ('Condensate_oil_prod','Ng_prod' )
)
,collectG_O13 as ( 
select 
       rownum,
       repinst.report_code,
       indexinst.index_code,
       indexinst_dim.dim_deteail_id,
       indexinst_dim.dim_detail_code,
       indexinst_dim.dim_code,
       indexinst.index_value,
       indexinst.composited_index_code,
       indexinst_dim.composite_dim_code
  from e7_sta_repinst repinst
  left join e7_sta_rpt_index_inst repinst_indexinst
    on repinst.repinst_id = repinst_indexinst.repinst_id
  left join e7_sta_index_inst indexinst
    on indexinst.sta_index_inst_id = repinst_indexinst.sta_index_inst_id
  left join e7_sta_index_inst_dimen indexinst_dim
    on indexinst_dim.sta_index_inst_id = indexinst.sta_index_inst_id
 where repinst.report_code in ('T0042','T0043','T0044','T0045')
    and repinst.org_id =P_RPTORGID
   and repinst.report_year =P_RPTYEAR
   and repinst.report_month = P_RPTMONTH
   
   union all
   
   select 
       rownum,
       repinst.report_code,
       indexinst.index_code,
       indexinst_dim.dim_deteail_id,
       indexinst_dim.dim_detail_code,
       indexinst_dim.dim_code,
       indexinst.index_value,
       indexinst.composited_index_code,
       indexinst_dim.composite_dim_code
  from e7_sta_repinst repinst
  left join e7_sta_rpt_index_inst repinst_indexinst
    on repinst.repinst_id = repinst_indexinst.repinst_id
  left join e7_sta_index_inst indexinst
    on indexinst.sta_index_inst_id = repinst_indexinst.sta_index_inst_id
  left join e7_sta_index_inst_dimen indexinst_dim
    on indexinst_dim.sta_index_inst_id = indexinst.sta_index_inst_id
 where repinst.report_code in ('T0001')
   and repinst.org_id =P_RPTORGID
   and repinst.report_year =P_RPTYEAR
   and repinst.report_month = P_RPTMONTH

)
, collectG_O18 as (
select 
       rownum,
       repinst.report_code,
       indexinst.index_code,
       indexinst_dim.dim_deteail_id,
       indexinst_dim.dim_detail_code,
       indexinst_dim.dim_code,
       indexinst.index_value,
       indexinst.composited_index_code,
       indexinst_dim.composite_dim_code
  from e7_sta_repinst repinst
  left join e7_sta_rpt_index_inst repinst_indexinst
    on repinst.repinst_id = repinst_indexinst.repinst_id
  left join e7_sta_index_inst indexinst
    on indexinst.sta_index_inst_id = repinst_indexinst.sta_index_inst_id
  left join e7_sta_index_inst_dimen indexinst_dim
    on indexinst_dim.sta_index_inst_id = indexinst.sta_index_inst_id
 where repinst.report_code in ('T0042','T0043','T0044','T0045')
    and repinst.org_id =P_RPTORGID
   and repinst.report_year =P_RPTYEAR
   and repinst.report_month = P_RPTMONTH
   
   union all
   
   select 
       rownum,
       repinst.report_code,
       indexinst.index_code,
       indexinst_dim.dim_deteail_id,
       indexinst_dim.dim_detail_code,
       indexinst_dim.dim_code,
       indexinst.index_value,
       indexinst.composited_index_code,
       indexinst_dim.composite_dim_code
  from e7_sta_repinst repinst
  left join e7_sta_rpt_index_inst repinst_indexinst
    on repinst.repinst_id = repinst_indexinst.repinst_id
  left join e7_sta_index_inst indexinst
    on indexinst.sta_index_inst_id = repinst_indexinst.sta_index_inst_id
  left join e7_sta_index_inst_dimen indexinst_dim
    on indexinst_dim.sta_index_inst_id = indexinst.sta_index_inst_id
 where repinst.report_code in ('T0001')
   and repinst.org_id =P_RPTORGID
   and repinst.report_year =P_RPTYEAR
   and repinst.report_month = P_RPTMONTH

)
,collectOil_O20 as (

select 
       rownum,
       repinst.report_code,
       indexinst.index_code,
       indexinst_dim.dim_deteail_id,
       indexinst_dim.dim_detail_code,
       indexinst_dim.dim_code,
       indexinst.index_value,
       indexinst.composited_index_code,
       indexinst_dim.composite_dim_code
  from e7_sta_repinst repinst
  left join e7_sta_rpt_index_inst repinst_indexinst
    on repinst.repinst_id = repinst_indexinst.repinst_id
  left join e7_sta_index_inst indexinst
    on indexinst.sta_index_inst_id = repinst_indexinst.sta_index_inst_id
  left join e7_sta_index_inst_dimen indexinst_dim
    on indexinst_dim.sta_index_inst_id = indexinst.sta_index_inst_id
 where repinst.report_code in  ('C0034')
   and repinst.org_id in (select org_id from e7_sta_rpt_auth where v_org_id =P_RPTORGID and report_code  in  ('C0034'))
   and repinst.report_year =P_RPTYEAR
   and repinst.report_month = P_RPTMONTH
and indexinst.index_code in ('Og_prod' )
 
)
  --L8,L9
  SELECT A.LOCALTION , B.SUMVALUE FROM  E7_EXCEL_LOCATIONBYINDEX A
   LEFT JOIN
 ( select index_code,(index_value*10000) SUMVALUE from collect1_L8) B ON  1=1
WHERE A.IS_PY ='N' AND A.REPORT_CODE=P_RPTCODE AND (A.LOCALTION ='I8'OR A.LOCALTION ='I9')
UNION
--L10
SELECT A.LOCALTION , B.SUMVALUE FROM  E7_EXCEL_LOCATIONBYINDEX A
   LEFT JOIN
 ( select index_code,(index_value*10000) SUMVALUE from collect1_L10) B ON  1=1
WHERE A.IS_PY ='N' AND A.REPORT_CODE=P_RPTCODE AND  A.LOCALTION ='I10'
UNION
--L11
SELECT A.LOCALTION , B.SUMVALUE FROM  E7_EXCEL_LOCATIONBYINDEX A
   LEFT JOIN
 ( select index_code,(index_value*10000) SUMVALUE from collect1_L11) B ON  1=1
WHERE A.IS_PY ='N' AND A.REPORT_CODE=P_RPTCODE AND  A.LOCALTION ='I11'
UNION
--L12
SELECT A.LOCALTION , B.SUMVALUE FROM  E7_EXCEL_LOCATIONBYINDEX A
   LEFT JOIN
 ( select  index_code, NVL(SUM(index_value),0) SUMVALUE  from collect_L12 where index_code = 'Watr_prod' GROUP BY INDEX_CODE) B ON  1=1
WHERE A.IS_PY ='N' AND A.REPORT_CODE=P_RPTCODE AND  A.LOCALTION ='I12'
UNION
--L13
SELECT A.LOCALTION , B.SUMVALUE FROM  E7_EXCEL_LOCATIONBYINDEX A
   LEFT JOIN
 ( 
 select  index_code,NVL(SUM(index_value),0) SUMVALUE FROM collectG_L13 WHERE REPORT_CODE ='T0042' AND INDEX_CODE ='Ind_wastew_reinj_amt'
GROUP BY INDEX_CODE
) B ON  1=1
WHERE A.IS_PY ='N' AND A.REPORT_CODE=P_RPTCODE AND  A.LOCALTION ='I13'
UNION 
--L20
SELECT A.LOCALTION , B.SUMVALUE FROM  E7_EXCEL_LOCATIONBYINDEX A
   LEFT JOIN
 ( 
 select  index_code,NVL(SUM(index_value)*10000,0) SUMVALUE FROM collectG_L13 WHERE REPORT_CODE ='T0044' AND INDEX_CODE ='Ind_wastew_disch_amt'
GROUP BY INDEX_CODE
) B ON  1=1
WHERE A.IS_PY ='N' AND A.REPORT_CODE=P_RPTCODE AND  A.LOCALTION ='I20'
UNION
--L21
SELECT A.LOCALTION , B.SUMVALUE FROM  E7_EXCEL_LOCATIONBYINDEX A
   LEFT JOIN 
 ( 
 SELECT C.SUMVALUE + D.SUMVALUE  SUMVALUE FROM
( select  index_code,NVL(SUM(index_value),0) SUMVALUE FROM collectG_L13 WHERE 
 REPORT_CODE
  IN( 'T0042','T0043','T0044' ,'T0045')
  AND (index_code = 'Ind_wastew_reu_amt' ) 
GROUP BY INDEX_CODE ) C
LEFT JOIN  
 (select  index_code,NVL(SUM(index_value),0) SUMVALUE FROM collectG_L13 WHERE 
 REPORT_CODE
  IN( 'T0042','T0043','T0044' ,'T0045')
  AND index_code = 'Ind_wastew_reinj_amt'
GROUP BY INDEX_CODE ) D  ON 1=1




) B ON  1=1
WHERE A.IS_PY ='N' AND A.REPORT_CODE=P_RPTCODE AND  A.LOCALTION ='I21'
UNION


--G14  NULL

--L15
SELECT A.LOCALTION , B.SUMVALUE FROM  E7_EXCEL_LOCATIONBYINDEX A
   LEFT JOIN
 ( 
select  NVL(SUM(INDEX_VALUE),0) SUMVALUE from collect_G15 
WHERE (report_code = 'C0039'  or report_code = 'C0049')  AND  index_code = 'watr_reuse_ratio_mole' 
) B ON  1=1
WHERE A.IS_PY ='N' AND A.REPORT_CODE=P_RPTCODE AND  A.LOCALTION ='I15'
UNION

-- L16
SELECT A.LOCALTION , B.SUMVALUE FROM  E7_EXCEL_LOCATIONBYINDEX A
   LEFT JOIN
 ( 
select  NVL(SUM(INDEX_VALUE),0) SUMVALUE from collect_G15 
WHERE (report_code = 'C0039'  or report_code = 'C0049')  AND  index_code = 'Stmcond_reclaim_rate_mole' 
) B ON  1=1
WHERE A.IS_PY ='N' AND A.REPORT_CODE=P_RPTCODE AND  A.LOCALTION ='I16'
UNION
--L17
SELECT A.LOCALTION , B.SUMVALUE FROM  E7_EXCEL_LOCATIONBYINDEX A
   LEFT JOIN
 ( 
select  NVL(SUM(INDEX_VALUE),0) SUMVALUE from collect_G15 
WHERE report_code = 'C0039'  AND  index_code = 'Co_procs_unit_watr_csmp_mole' 
) B ON  1=1
WHERE A.IS_PY ='N' AND A.REPORT_CODE=P_RPTCODE AND  A.LOCALTION ='I17'
UNION
--L18
SELECT A.LOCALTION , B.SUMVALUE FROM  E7_EXCEL_LOCATIONBYINDEX A
   LEFT JOIN
 ( 
select  NVL(SUM(INDEX_VALUE),0) SUMVALUE from collect_G15 
WHERE report_code = 'C0049'  AND  index_code = 'Eth_unit_watr_csmp' 
) B ON  1=1
WHERE A.IS_PY ='N' AND A.REPORT_CODE=P_RPTCODE AND  A.LOCALTION ='I18'
UNION
--L19
SELECT A.LOCALTION , B.SUMVALUE FROM  E7_EXCEL_LOCATIONBYINDEX A
   LEFT JOIN
 ( 
select  NVL(SUM(INDEX_VALUE),0) SUMVALUE from collect_G15 
WHERE  report_code = 'C0049'  AND  index_code = 'Ammo_unit_watr_csmp' 
) B ON  1=1
WHERE A.IS_PY ='N' AND A.REPORT_CODE=P_RPTCODE AND  A.LOCALTION ='I19' 
UNION
--L22
SELECT A.LOCALTION , B.SUMVALUE FROM  E7_EXCEL_LOCATIONBYINDEX A
   LEFT JOIN
 ( 
select  NVL(SUM(INDEX_VALUE),0) SUMVALUE from collect_G15 
WHERE (report_code = 'C0039'  or report_code = 'C0049')  AND  index_code = 'Watr_comph_lost_rate_mole' 
) B ON  1=1
WHERE A.IS_PY ='N' AND A.REPORT_CODE=P_RPTCODE AND  A.LOCALTION ='I22' 
UNION
--O22
SELECT A.LOCALTION , B.SUMVALUE FROM  E7_EXCEL_LOCATIONBYINDEX A
   LEFT JOIN
 ( 
select  NVL(SUM(INDEX_VALUE),0) SUMVALUE from collect_G15 
WHERE (report_code = 'C0039'  or report_code = 'C0049')  AND  index_code = 'Watr_comph_lost_rate_deno' 
) B ON  1=1
WHERE A.IS_PY ='N' AND A.REPORT_CODE=P_RPTCODE AND  A.LOCALTION ='J22' 
UNION


--O8 母
SELECT A.LOCALTION , B.SUMVALUE FROM  E7_EXCEL_LOCATIONBYINDEX A
   LEFT JOIN
 (  
 select C.SUMVALUE+D.SUMVALUE SUMVALUE FROM
 (select  NVL(SUM(index_value)*10000/1255,0) SUMVALUE from collect3_O8  where index_code ='Ng_prod' and index_value != 0  and DIM_CODE = 'Orig_energy_type') C
   left join 
   (select  NVL(SUM(index_value)*10000,0) SUMVALUE from collect3_O8  where index_code ='Co_prod' and index_value != 0 ) D on 1=1 
  

) B ON  1=1
WHERE A.IS_PY ='N' AND A.REPORT_CODE=P_RPTCODE AND  A.LOCALTION ='J8'
UNION
--O9
SELECT A.LOCALTION , B.SUMVALUE FROM  E7_EXCEL_LOCATIONBYINDEX A
   LEFT JOIN
 (  
 select C.SUMVALUE+D.SUMVALUE+E.SUMVALUE SUMVALUE FROM
 (select  NVL(SUM(index_value)*10000/1255,0) SUMVALUE from collect3_O8  where index_code ='Ng_prod' and index_value != 0  and DIM_CODE = 'Orig_energy_type') C
   left join 
   (select  NVL(SUM(index_value)*10000,0) SUMVALUE from collect3_O8  where index_code ='Co_prod' and index_value != 0 ) D on 1=1 
   left join
   (select  NVL(SUM(index_value)*10000,0) SUMVALUE from collect3_O8  where index_code ='Watr_prod'  ) E on 1=1 

) B ON  1=1
WHERE A.IS_PY ='N' AND A.REPORT_CODE=P_RPTCODE AND  A.LOCALTION ='J9'
UNION
--O10  
 

SELECT A.LOCALTION , B.SUMVALUE FROM  E7_EXCEL_LOCATIONBYINDEX A
   LEFT JOIN
 (  
 select C.SUMVALUE+D.SUMVALUE+E.SUMVALUE SUMVALUE FROM
 (select  NVL(SUM(index_value)*10000,0) SUMVALUE from collect_O10  where index_code ='Co_prod' and(report_code = 'C0001'  or report_code = 'C0006' )  ) C
   left join 
   (select  NVL(SUM(index_value)*10000,0) SUMVALUE from collect_O10  where index_code ='Watr_prod' and (report_code = 'C0001'  or report_code = 'C0006' )   ) D on 1=1 
   left join
   (select  NVL(SUM(index_value)*10000/1255,0) SUMVALUE from collect_O10  where index_code ='Ng_prod' and (report_code = 'C0001'  or report_code = 'C0006' )    ) E on 1=1 

) B ON  1=1
WHERE A.IS_PY ='N' AND A.REPORT_CODE=P_RPTCODE AND  A.LOCALTION ='J10'
UNION  
--O12
SELECT A.LOCALTION , B.SUMVALUE FROM  E7_EXCEL_LOCATIONBYINDEX A
   LEFT JOIN
 (  
 select C.SUMVALUE+D.SUMVALUE+E.SUMVALUE SUMVALUE FROM
 (select  NVL(SUM(index_value),0) SUMVALUE from collect_O10  where index_code ='Co_prod' and(report_code = 'C0001'  or report_code = 'C0006' )  ) C
   left join 
   (select  NVL(SUM(index_value),0) SUMVALUE from collect_O10  where index_code ='Watr_prod' and (report_code = 'C0001'  or report_code = 'C0006' )   ) D on 1=1 
   left join
   (select  NVL(SUM(index_value)/1255,0) SUMVALUE from collect_O10  where index_code ='Ng_prod' and (report_code = 'C0001'  or report_code = 'C0006' )    ) E on 1=1 

) B ON  1=1
WHERE A.IS_PY ='N' AND A.REPORT_CODE=P_RPTCODE AND  A.LOCALTION ='J12' 
UNION

--O15  
SELECT A.LOCALTION , B.SUMVALUE FROM  E7_EXCEL_LOCATIONBYINDEX A
   LEFT JOIN
 ( 
select  NVL(SUM(INDEX_VALUE),0) SUMVALUE from collect_O10
WHERE  (report_code = 'C0039'OR report_code = 'C0049' ) AND  index_code = 'watr_reuse_ratio_deno' 
) B ON  1=1
WHERE A.IS_PY ='N' AND A.REPORT_CODE=P_RPTCODE AND  A.LOCALTION ='J15' 
 
UNION
--O16
SELECT A.LOCALTION , B.SUMVALUE FROM  E7_EXCEL_LOCATIONBYINDEX A
   LEFT JOIN
 ( 
select  NVL(SUM(INDEX_VALUE),0) SUMVALUE from collect_O10
WHERE  (report_code = 'C0039'OR report_code = 'C0049' )  AND  index_code = 'Stmcond_reclaim_rate_deno' 
) B ON  1=1
WHERE A.IS_PY ='N' AND A.REPORT_CODE=P_RPTCODE AND  A.LOCALTION ='J16' 
UNION
--017
SELECT A.LOCALTION , B.SUMVALUE FROM  E7_EXCEL_LOCATIONBYINDEX A
   LEFT JOIN
 ( 
select  NVL(SUM(INDEX_VALUE),0) SUMVALUE from collect_O10
WHERE  report_code = 'C0034'  AND  index_code = 'Og_prod' 
) B ON  1=1
WHERE A.IS_PY ='N' AND A.REPORT_CODE=P_RPTCODE AND  A.LOCALTION ='J17' 
UNION



--O11


  SELECT A.LOCALTION , B.SUMVALUE FROM  E7_EXCEL_LOCATIONBYINDEX A
   LEFT JOIN
 (  
 select C.SUMVALUE+D.SUMVALUE SUMVALUE FROM
 (select  NVL(SUM(index_value)*1255,0) SUMVALUE from collectgas_O11  where index_code ='Condensate_oil_prod') C
   left join 
   (select  NVL(SUM(index_value),0) SUMVALUE from collectgas_O11  where index_code ='Ng_prod' ) D on 1=1 
 

) B ON  1=1
WHERE A.IS_PY ='N' AND A.REPORT_CODE=P_RPTCODE AND  A.LOCALTION ='J11'
UNION
--O13


SELECT A.LOCALTION , B.SUMVALUE FROM  E7_EXCEL_LOCATIONBYINDEX A
   LEFT JOIN
 ( 
select  NVL(SUM(INDEX_VALUE),0) SUMVALUE from collectG_O13 
WHERE report_code = 'T0042'  AND  index_code = 'Ind_wastew_gene_amt' 
) B ON  1=1
WHERE A.IS_PY ='N' AND A.REPORT_CODE=P_RPTCODE AND  A.LOCALTION ='J13'
UNION




--O18 

SELECT A.LOCALTION , B.SUMVALUE FROM  E7_EXCEL_LOCATIONBYINDEX A
   LEFT JOIN
 ( select  index_code, NVL(SUM(index_value)*10000,0) SUMVALUE  from collectG_O18 where index_code = 'Eth_prod'
 AND REPORT_CODE = 'T0001'
  GROUP BY INDEX_CODE) B ON  1=1
WHERE A.IS_PY ='N' AND A.REPORT_CODE=P_RPTCODE AND  A.LOCALTION ='J18'
UNION
--O19
SELECT A.LOCALTION , B.SUMVALUE FROM  E7_EXCEL_LOCATIONBYINDEX A
   LEFT JOIN
 ( select  index_code, NVL(SUM(index_value)*10000,0) SUMVALUE  from collectG_O18 where index_code = 'Synth_amm_prod'
 AND REPORT_CODE = 'T0001'
  GROUP BY INDEX_CODE) B ON  1=1
WHERE A.IS_PY ='N' AND A.REPORT_CODE=P_RPTCODE AND  A.LOCALTION ='J19'
UNION
--O21
SELECT A.LOCALTION , B.SUMVALUE FROM  E7_EXCEL_LOCATIONBYINDEX A
   LEFT JOIN
 ( select  index_code, NVL(SUM(index_value),0) SUMVALUE  from collectG_O18 where index_code = 'Ind_wastew_gene_amt'
AND (report_code = 'T0042'  or report_code = 'T0043'  or report_code = 'T0044'  or report_code = 'T0045' )
  GROUP BY INDEX_CODE) B ON  1=1
WHERE A.IS_PY ='N' AND A.REPORT_CODE=P_RPTCODE AND  A.LOCALTION ='J21'
UNION
--O22

SELECT A.LOCALTION , B.SUMVALUE FROM  E7_EXCEL_LOCATIONBYINDEX A
   LEFT JOIN
 ( select   NVL(SUM(index_value),0) SUMVALUE  from collectOil_O20
 ) 
  B ON  1=1
WHERE A.IS_PY ='N' AND A.REPORT_CODE=P_RPTCODE AND  A.LOCALTION ='J20'; 



 
  
  
  BEGIN
jsonStr := '[';
FOR T0053_Result IN return_cursor LOOP
  jsonStr := jsonStr || '{''location'':''' || T0053_Result.localtion ||
                 ''',''value'':''' || to_char(ROUND(T0053_Result.SUMVALUE,4)) || '''},';

  END LOOP;
  jsonStr := jsonStr || ']';
  jsonStr := replace(jsonStr,'},]','}]');
  dbms_output.put_line(jsonStr);
  END;
  
  --T0054
  procedure getT0054Sum(P_RPTCODE IN VARCHAR2,
                         P_RPTYEAR  IN VARCHAR2,
                         P_RPTMONTH IN VARCHAR2,
                         P_RPTORGID IN VARCHAR2,jsonStr OUT CLOB) IS
    
    Cursor return_cursor is
  --L8
WITH collect1 AS (
select 
       rownum,
       repinst.report_code,
       indexinst.index_code,
       indexinst_dim.dim_deteail_id,
       indexinst_dim.dim_detail_code,
       indexinst_dim.dim_code,
       indexinst.index_value,
       indexinst.composited_index_code,
       indexinst_dim.composite_dim_code
  from e7_sta_repinst repinst
  left join e7_sta_rpt_index_inst repinst_indexinst
    on repinst.repinst_id = repinst_indexinst.repinst_id
  left join e7_sta_index_inst indexinst
    on indexinst.sta_index_inst_id = repinst_indexinst.sta_index_inst_id
  left join e7_sta_index_inst_dimen indexinst_dim
    on indexinst_dim.sta_index_inst_id = indexinst.sta_index_inst_id
 where repinst.report_code in ('C0096','C0106','C0110')
   and repinst.org_id in (select org_id from e7_sta_rpt_auth where v_org_id = P_RPTORGID and report_code  in  ('C0096','C0106','C0110' ))
   and repinst.report_year = P_RPTYEAR
   and repinst.report_month = P_RPTMONTH
--and repinst.STATUS='04'
   and ((indexinst.index_code = 'Fresh_water_consu_amt' and (indexinst_dim.dim_detail_code = 'Power_generation' or indexinst_dim.dim_detail_code = 'Production_heat' )  and report_code in( 'C0096','C0106')) or               
        ((indexinst.index_code = 'watr_unit_elec_deno'or indexinst.index_code = 'watr_unit_htg_deno' ) and report_code in( 'C0094', 'C0104')) or
        (indexinst.index_code = 'Min_elec_supl_amt' and indexinst_dim.dim_detail_code = 'Pro' and report_code in( 'C0110')) or
        (indexinst.index_code = 'watr_unit_htg_deno'and report_code in(  'C0094', 'C0104')) 
       )
       
       union all
       select 
       rownum,
       repinst.report_code,
       indexinst.index_code,
       indexinst_dim.dim_deteail_id,
       indexinst_dim.dim_detail_code,
       indexinst_dim.dim_code,
       indexinst.index_value,
       indexinst.composited_index_code,
       indexinst_dim.composite_dim_code
  from e7_sta_repinst repinst
  left join e7_sta_rpt_index_inst repinst_indexinst
    on repinst.repinst_id = repinst_indexinst.repinst_id
  left join e7_sta_index_inst indexinst
    on indexinst.sta_index_inst_id = repinst_indexinst.sta_index_inst_id
  left join e7_sta_index_inst_dimen indexinst_dim
    on indexinst_dim.sta_index_inst_id = indexinst.sta_index_inst_id
 where repinst.report_code in ('C0094','C0104')
   and repinst.org_id in (select org_id from e7_sta_rpt_auth where v_org_id = P_RPTORGID and report_code  in  ('C0094','C0104'))
   and repinst.report_year = P_RPTYEAR
   and repinst.report_month = P_RPTMONTH
--and repinst.STATUS='04'
   and ((indexinst.index_code = 'Fresh_water_consu_amt' and (indexinst_dim.dim_detail_code = 'Power_generation' or indexinst_dim.dim_detail_code = 'Production_heat' )  and report_code in( 'C0096','C0106')) or               
        ((indexinst.index_code = 'watr_unit_elec_deno'or indexinst.index_code = 'watr_unit_htg_deno' ) and report_code in( 'C0094', 'C0104')) or
        (indexinst.index_code = 'Min_elec_supl_amt' and indexinst_dim.dim_detail_code = 'Pro' and report_code in( 'C0110')) or
        (indexinst.index_code = 'watr_unit_htg_deno'and report_code in(  'C0094', 'C0104')) 
       )

)
   ,collect2 as(
    select 
       rownum,
       repinst.report_code,
       indexinst.index_code,
       indexinst_dim.dim_deteail_id,
       indexinst_dim.dim_detail_code,
       indexinst_dim.dim_code,
       indexinst.index_value,
       indexinst.composited_index_code,
       indexinst_dim.composite_dim_code
  from e7_sta_repinst repinst
  left join e7_sta_rpt_index_inst repinst_indexinst
    on repinst.repinst_id = repinst_indexinst.repinst_id
  left join e7_sta_index_inst indexinst
    on indexinst.sta_index_inst_id = repinst_indexinst.sta_index_inst_id
  left join e7_sta_index_inst_dimen indexinst_dim
    on indexinst_dim.sta_index_inst_id = indexinst.sta_index_inst_id
 where repinst.report_code in ( 'C0020','C0025','C0055','C0060','C0172' ,'C0108','C0030','C0075','C0098','C0103','C0118')
   and repinst.org_id in (select org_id from e7_sta_rpt_auth where v_org_id = P_RPTORGID and report_code  in  (
   'C0020','C0025','C0055','C0060','C0172' ,'C0108','C0030','C0075','C0098','C0103','C0118'
   )
   and repinst.report_year = P_RPTYEAR
   and repinst.report_month = P_RPTMONTH
--and repinst.STATUS='04'
   and (index_code = 'Circl_watr_concentr_ratio' or 
        index_code = 'watr_reuse_ratio_mole'     or 
        index_code = 'watr_reuse_ratio_deno'     or 
        index_code = 'Stmcond_reclaim_rate_mole' or  
        index_code = 'Stmcond_reclaim_rate_deno' or 
        index_code = 'Watr_comph_lost_rate_mole' or 
        index_code = 'Watr_comph_lost_rate_deno' or 
        index_code = 'Saved_watr_amt'            or  
        index_code = 'Saved_watr_value_amt')
    )
 )
  ,collectWater as (
  select 
       rownum,
       repinst.report_code,
       indexinst.index_code,
       indexinst_dim.dim_deteail_id,
       indexinst_dim.dim_detail_code,
       indexinst_dim.dim_code,
       indexinst.index_value,
       indexinst.composited_index_code,
       indexinst_dim.composite_dim_code
  from e7_sta_repinst repinst
  left join e7_sta_rpt_index_inst repinst_indexinst
    on repinst.repinst_id = repinst_indexinst.repinst_id
  left join e7_sta_index_inst indexinst
    on indexinst.sta_index_inst_id = repinst_indexinst.sta_index_inst_id
  left join e7_sta_index_inst_dimen indexinst_dim
    on indexinst_dim.sta_index_inst_id = indexinst.sta_index_inst_id
 where repinst.report_code in (
 'T0046','T0047','T0048','T0049','T0050' 
 )
   and repinst.org_id = P_RPTORGID
   and repinst.report_year = P_RPTYEAR
   and repinst.report_month = P_RPTMONTH
   and (indexinst.index_code = 'Steam_conden_reco_amt' or indexinst.index_code = 'Ind_wastew_reu_amt' or indexinst.index_code = 'Ind_wastew_gene_amt')
  )
  ,collect1last as(
  select 
       rownum,
       repinst.report_code,
       indexinst.index_code,
       indexinst_dim.dim_deteail_id,
       indexinst_dim.dim_detail_code,
       indexinst_dim.dim_code,
       indexinst.index_value,
       indexinst.composited_index_code,
       indexinst_dim.composite_dim_code
  from e7_sta_repinst repinst
  left join e7_sta_rpt_index_inst repinst_indexinst
    on repinst.repinst_id = repinst_indexinst.repinst_id
  left join e7_sta_index_inst indexinst
    on indexinst.sta_index_inst_id = repinst_indexinst.sta_index_inst_id
  left join e7_sta_index_inst_dimen indexinst_dim
    on indexinst_dim.sta_index_inst_id = indexinst.sta_index_inst_id
 where repinst.report_code in ('')
   and repinst.org_id in (select org_id from e7_sta_rpt_auth where v_org_id = P_RPTORGID and report_code  in  (''))
   and repinst.report_year = P_RPTYEAR
   and repinst.report_month = P_RPTMONTH
--and repinst.STATUS='04'
   and ((indexinst.index_code = 'Fresh_water_consu_amt' and (indexinst_dim.dim_detail_code = 'Power_generation' or indexinst_dim.dim_detail_code = 'Production_heat' )  and report_code in( '')) or               
        ((indexinst.index_code = 'watr_unit_elec_deno'or indexinst.index_code = 'watr_unit_htg_deno' ) and report_code in( '')) or
        (indexinst.index_code = 'Min_elec_supl_amt' and indexinst_dim.dim_detail_code = 'Pro' and report_code in( '')) or
        (indexinst.index_code = 'watr_unit_htg_deno'and report_code in( '')) 
       )
       
       union all
       select 
       rownum,
       repinst.report_code,
       indexinst.index_code,
       indexinst_dim.dim_deteail_id,
       indexinst_dim.dim_detail_code,
       indexinst_dim.dim_code,
       indexinst.index_value,
       indexinst.composited_index_code,
       indexinst_dim.composite_dim_code
  from e7_sta_repinst repinst
  left join e7_sta_rpt_index_inst repinst_indexinst
    on repinst.repinst_id = repinst_indexinst.repinst_id
  left join e7_sta_index_inst indexinst
    on indexinst.sta_index_inst_id = repinst_indexinst.sta_index_inst_id
  left join e7_sta_index_inst_dimen indexinst_dim
    on indexinst_dim.sta_index_inst_id = indexinst.sta_index_inst_id
 where repinst.report_code in ('','')
   and repinst.org_id in (select org_id from e7_sta_rpt_auth where v_org_id = P_RPTORGID and report_code  in  ('',''))
   and repinst.report_year = P_RPTYEAR
   and repinst.report_month = P_RPTMONTH
--and repinst.STATUS='04'
   and ((indexinst.index_code = 'Fresh_water_consu_amt' and (indexinst_dim.dim_detail_code = 'Power_generation' or indexinst_dim.dim_detail_code = 'Production_heat' )  and report_code in( '')) or               
        ((indexinst.index_code = 'watr_unit_elec_deno'or indexinst.index_code = 'watr_unit_htg_deno' ) and report_code in( '')) or
        (indexinst.index_code = 'Min_elec_supl_amt' and indexinst_dim.dim_detail_code = 'Pro' and report_code in( '')) or
        (indexinst.index_code = 'watr_unit_htg_deno'and report_code in( '')) 
       )
  )
--L8
select  A.LOCALTION,B.SUMVALUE FROM E7_EXCEL_LOCATIONBYINDEX A
LEFT JOIN
(
select index_code, NVL(SUM(index_value)*10000000,0) SUMVALUE FROM collect1 
where INDEX_CODE = 'Fresh_water_consu_amt' 
 and DIM_DETAIL_CODE = 'Power_generation' and (REPORT_CODE = 'C0096' or REPORT_CODE = 'C0106') 
 group by  index_code) B ON 1=1
WHERE A.IS_PY ='N' AND A.REPORT_CODE=P_RPTCODE AND A.LOCALTION ='I8'
UNION
--L9
select  A.LOCALTION,B.SUMVALUE FROM E7_EXCEL_LOCATIONBYINDEX A
LEFT JOIN
(
select index_code, NVL(SUM(index_value)*100000,0) SUMVALUE FROM collect1
where INDEX_CODE = 'Fresh_water_consu_amt' 
 and DIM_DETAIL_CODE = 'Production_heat' and (REPORT_CODE = 'C0096' or REPORT_CODE = 'C0106') 
 group by  index_code) B ON 1=1
WHERE A.IS_PY ='N' AND A.REPORT_CODE=P_RPTCODE AND A.LOCALTION ='I9'
UNION
--L11
select  A.LOCALTION,B.SUMVALUE FROM E7_EXCEL_LOCATIONBYINDEX A
LEFT JOIN
(
select index_code, NVL(SUM(index_value),0) SUMVALUE FROM collect2
where INDEX_CODE = 'watr_reuse_ratio_mole' 
  and (
   REPORT_CODE = 'C0020'
 or REPORT_CODE = 'C0025' 
 or REPORT_CODE = 'C0055'
 or REPORT_CODE = 'C0060' 
 or REPORT_CODE = 'C0172'
 or REPORT_CODE = 'C0108' 
 or REPORT_CODE = 'C0030'
 or REPORT_CODE = 'C0075' 
 or REPORT_CODE = 'C0098' 
 or REPORT_CODE = 'C0103' 
 or REPORT_CODE = 'C0118'  
  )
 group by  index_code) B ON 1=1
WHERE A.IS_PY ='N' AND A.REPORT_CODE=P_RPTCODE AND A.LOCALTION ='I11'
UNION
--L12
select  A.LOCALTION,B.SUMVALUE FROM E7_EXCEL_LOCATIONBYINDEX A
LEFT JOIN
(
select index_code, NVL(SUM(index_value),0) SUMVALUE FROM collect2
where INDEX_CODE = 'Stmcond_reclaim_rate_mole' 
  and (
   REPORT_CODE = 'C0020'
 or REPORT_CODE = 'C0025' 
 or REPORT_CODE = 'C0055'
 or REPORT_CODE = 'C0060' 
 or REPORT_CODE = 'C0172'
 or REPORT_CODE = 'C0108' 
 or REPORT_CODE = 'C0030'
 or REPORT_CODE = 'C0075' 
 or REPORT_CODE = 'C0098' 
 or REPORT_CODE = 'C0103' 
 or REPORT_CODE = 'C0118'  
  )
 group by  index_code) B ON 1=1
WHERE A.IS_PY ='N' AND A.REPORT_CODE=P_RPTCODE AND A.LOCALTION ='I12'
UNION
--L13
select  A.LOCALTION,B.SUMVALUE FROM E7_EXCEL_LOCATIONBYINDEX A
LEFT JOIN
(
select index_code, NVL(SUM(index_value),0) SUMVALUE FROM collectWater
where INDEX_CODE = 'Ind_wastew_reu_amt' 
 group by  index_code) B ON 1=1
WHERE A.IS_PY ='N' AND A.REPORT_CODE=P_RPTCODE AND A.LOCALTION ='I13'
UNION
--L14
select  A.LOCALTION,B.SUMVALUE FROM E7_EXCEL_LOCATIONBYINDEX A
LEFT JOIN
(
select index_code, NVL(SUM(index_value),0) SUMVALUE FROM collect2
where INDEX_CODE = 'Watr_comph_lost_rate_mole' 
  and (
   REPORT_CODE = 'C0020'
 or REPORT_CODE = 'C0025' 
 or REPORT_CODE = 'C0055'
 or REPORT_CODE = 'C0060' 
 or REPORT_CODE = 'C0172'
 or REPORT_CODE = 'C0108' 
 or REPORT_CODE = 'C0030'
 or REPORT_CODE = 'C0075' 
 or REPORT_CODE = 'C0098' 
 or REPORT_CODE = 'C0103' 
 or REPORT_CODE = 'C0118'  
  )
 group by  index_code) B ON 1=1
WHERE A.IS_PY ='N' AND A.REPORT_CODE=P_RPTCODE AND A.LOCALTION ='I14'
UNION
--O8
SELECT A.LOCALTION,B.SUMVALUE FROM E7_EXCEL_LOCATIONBYINDEX  A
LEFT JOIN
(
select   (NVL(C.SUMVALUE,0)-NVL(D.SUMVALUE,0)) SUMVALUE  FROM
  
(
select index_code, NVL(SUM(index_value)*10000,0) SUMVALUE FROM collect1 
where INDEX_CODE = 'watr_unit_elec_deno' 
 and (REPORT_CODE = 'C0094' or REPORT_CODE = 'C0104')
 GROUP BY INDEX_CODE
 ) C
 LEFT JOIN
 (
 select index_code, NVL(SUM(index_value)*10000,0) SUMVALUE FROM collect1last 
where INDEX_CODE = 'watr_unit_elec_deno' 
 and (REPORT_CODE = 'C0094' or REPORT_CODE = 'C0104')
 GROUP BY INDEX_CODE) D  ON 1=1
 
 ) B ON 1=1 WHERE  A.IS_PY ='N' AND A.REPORT_CODE=P_RPTCODE AND A.LOCALTION ='J8'
 UNION
--O9 
 SELECT A.LOCALTION,B.SUMVALUE FROM E7_EXCEL_LOCATIONBYINDEX  A
LEFT JOIN
(
select   (NVL(C.SUMVALUE,0)-NVL(D.SUMVALUE,0)) SUMVALUE  FROM
  
(
select index_code, NVL(SUM(index_value),0) SUMVALUE FROM collect1 
where INDEX_CODE = 'watr_unit_htg_deno' 
 and (REPORT_CODE = 'C0094' or REPORT_CODE = 'C0104')
 GROUP BY INDEX_CODE
 ) C
 LEFT JOIN
 (
 select index_code, NVL(SUM(index_value),0) SUMVALUE FROM collect1last 
where INDEX_CODE = 'watr_unit_htg_deno' 
 and (REPORT_CODE = 'C0094' or REPORT_CODE = 'C0104')
 GROUP BY INDEX_CODE) D  ON 1=1
 
 ) B ON 1=1 WHERE  A.IS_PY ='N' AND A.REPORT_CODE=P_RPTCODE AND A.LOCALTION ='J9'
 UNION
 --O11
 select  A.LOCALTION,B.SUMVALUE FROM E7_EXCEL_LOCATIONBYINDEX A
LEFT JOIN
(
select index_code, NVL(SUM(index_value),0) SUMVALUE FROM collect2
where INDEX_CODE = 'watr_reuse_ratio_deno' 
  and (
   REPORT_CODE = 'C0020'
 or REPORT_CODE = 'C0025' 
 or REPORT_CODE = 'C0055'
 or REPORT_CODE = 'C0060' 
 or REPORT_CODE = 'C0172'
 or REPORT_CODE = 'C0108' 
 or REPORT_CODE = 'C0030'
 or REPORT_CODE = 'C0075' 
 or REPORT_CODE = 'C0098' 
 or REPORT_CODE = 'C0103' 
 or REPORT_CODE = 'C0118'  
  )
 group by  index_code) B ON 1=1
WHERE A.IS_PY ='N' AND A.REPORT_CODE=P_RPTCODE AND A.LOCALTION ='J11'
UNION
 --O12
 select  A.LOCALTION,B.SUMVALUE FROM E7_EXCEL_LOCATIONBYINDEX A
LEFT JOIN
(
select index_code, NVL(SUM(index_value),0) SUMVALUE FROM collectWater
where INDEX_CODE = 'Steam_conden_reco_amt' 
 group by  index_code) B ON 1=1
WHERE A.IS_PY ='N' AND A.REPORT_CODE=P_RPTCODE AND A.LOCALTION ='J12'
 UNION
 --O13
 select  A.LOCALTION,B.SUMVALUE FROM E7_EXCEL_LOCATIONBYINDEX A
LEFT JOIN
(
select index_code, NVL(SUM(index_value),0) SUMVALUE FROM collectWater
where INDEX_CODE = 'Ind_wastew_gene_amt' 
 group by  index_code) B ON 1=1
WHERE A.IS_PY ='N' AND A.REPORT_CODE=P_RPTCODE AND A.LOCALTION ='J13'
UNION
 --O14
 select  A.LOCALTION,B.SUMVALUE FROM E7_EXCEL_LOCATIONBYINDEX A
LEFT JOIN
(
select index_code, NVL(SUM(index_value),0) SUMVALUE FROM collect2
where INDEX_CODE = 'Watr_comph_lost_rate_deno' 
  and (
   REPORT_CODE = 'C0020'
 or REPORT_CODE = 'C0025' 
 or REPORT_CODE = 'C0055'
 or REPORT_CODE = 'C0060' 
 or REPORT_CODE = 'C0172'
 or REPORT_CODE = 'C0108' 
 or REPORT_CODE = 'C0030'
 or REPORT_CODE = 'C0075' 
 or REPORT_CODE = 'C0098' 
 or REPORT_CODE = 'C0103' 
 or REPORT_CODE = 'C0118'  
  )
 group by  index_code) B ON 1=1
WHERE A.IS_PY ='N' AND A.REPORT_CODE=P_RPTCODE AND A.LOCALTION ='J14';

BEGIN
jsonStr := '[';
FOR T0053_Result IN return_cursor LOOP
  jsonStr := jsonStr || '{''location'':''' || T0053_Result.LOCALTION ||
                 ''',''value'':''' || to_char(ROUND(T0053_Result.SUMVALUE,4)) || '''},';

  END LOOP;
  jsonStr := jsonStr || ']';
  jsonStr := replace(jsonStr,'},]','}]');
  dbms_output.put_line(jsonStr);
  END;  
  
  
  
    --T0042
  
   procedure getT0042Sum(P_RPTCODE IN VARCHAR2,
                         P_RPTYEAR  IN VARCHAR2,
                         P_RPTMONTH IN VARCHAR2,
                         P_RPTORGID IN VARCHAR2,jsonStr OUT CLOB) IS
    
    Cursor return_cursor is
 
with a as (
select 
ii.index_code,
ii.index_value,
nvl(dimen1.dim_code,'*') dim_code1 ,
nvl(dimen1.dim_detail_code,'*') dim_detail_code1,
nvl(dimen2.dim_code,'*') dim_code2,
nvl(dimen2.dim_detail_code,'*') dim_detail_code2
 from 
e7_sta_repinst repinst 
left join e7_sta_rpt_index_inst inst on repinst.repinst_id = inst.repinst_id
left join e7_sta_index_inst ii on inst.sta_index_inst_id = ii.sta_index_inst_id
left join e7_sta_index_inst_dimen dimen1 on ii.sta_index_inst_id = dimen1.sta_index_inst_id
and dimen1.dim_code = 'Industry_type'
left join e7_sta_index_inst_dimen dimen2 on ii.sta_index_inst_id = dimen2.sta_index_inst_id
and dimen2.dim_code = 'Using_water_species'
where repinst.report_code  in  ( 'C0003','C0008' )
   and repinst.org_id in (select org_id from e7_sta_rpt_auth where v_org_id =  P_RPTORGID and report_code  in  ( 'C0003','C0008'  ))
   and repinst.report_year = P_RPTYEAR
   and repinst.report_month = P_RPTMONTH
   ),

   index_dimenlocation as (
   select a.index_code,a.localtion,dimen.dim_code,dimen.dim_detail_code from e7_excel_locationbyindex a
   left join e7_excel_locationbydimen dimen on a.localtion = dimen.localtion 
   where a.report_code = P_RPTCODE
   and dimen.report_code = P_RPTCODE
   
   ),
   indexdimen as (
   select index_code,
   localtion,
   MAX(decode(dim_code,'Industry_type',dim_code,'*')) as dim_code1,
   MAX(decode(dim_code,'Industry_type',dim_detail_code,'*')) as dim_detail_code1,
   MAX(decode(dim_code,'Using_water_species',dim_code,'*')) as dim_code2,
   MAX(decode(dim_code,'Using_water_species',dim_detail_code,'*')) as dim_detail_code2
   from index_dimenlocation
   group by index_code,localtion
   )
   
   select * from a
   LEFT JOIN INDEXDIMEN b 
   on a.dim_code1 = b.dim_code1 
   and a.dim_detail_code1 = b.dim_detail_code1
   and a.index_code = b.index_code
   and a.dim_code2 = b.dim_code2
   and a.dim_detail_code2 = b.dim_detail_code2;

BEGIN
jsonStr := '[';
FOR A IN return_cursor LOOP
  jsonStr := jsonStr || '{''location'':''' || A.localtion ||
                 ''',''value'':''' || to_char(A.index_value) || '''},';

  END LOOP;
  jsonStr := jsonStr || ']';
  jsonStr := replace(jsonStr,'},]','}]');
  dbms_output.put_line(jsonStr);
  END;
  
  --T0043
    
    procedure getT0043Sum(P_RPTCODE IN VARCHAR2,
                         P_RPTYEAR  IN VARCHAR2,
                         P_RPTMONTH IN VARCHAR2,
                         P_RPTORGID IN VARCHAR2,jsonStr OUT CLOB) IS
    
    Cursor return_cursor is
    
with a as (
select 
ii.index_code,
ii.index_value,
nvl(dimen1.dim_code,'*') dim_code1 ,
nvl(dimen1.dim_detail_code,'*') dim_detail_code1,
nvl(dimen2.dim_code,'*') dim_code2,
nvl(dimen2.dim_detail_code,'*') dim_detail_code2
 from 
e7_sta_repinst repinst 
left join e7_sta_rpt_index_inst inst on repinst.repinst_id = inst.repinst_id
left join e7_sta_index_inst ii on inst.sta_index_inst_id = ii.sta_index_inst_id
left join e7_sta_index_inst_dimen dimen1 on ii.sta_index_inst_id = dimen1.sta_index_inst_id
and dimen1.dim_code = 'Industry_type'
left join e7_sta_index_inst_dimen dimen2 on ii.sta_index_inst_id = dimen2.sta_index_inst_id
and dimen2.dim_code = 'Using_water_species'
where repinst.report_code  in  ( 'C0013' )
   and repinst.org_id in (select org_id from e7_sta_rpt_auth where v_org_id =  P_RPTORGID and report_code  in  ( 'C0013'))
   and repinst.report_year = P_RPTYEAR
   and repinst.report_month = P_RPTMONTH
   ),

   index_dimenlocation as (
   select a.index_code,a.localtion,dimen.dim_code,dimen.dim_detail_code from e7_excel_locationbyindex a
   left join e7_excel_locationbydimen dimen on a.localtion = dimen.localtion 
   where a.report_code = P_RPTCODE
   and dimen.report_code = P_RPTCODE
   
   ),
   indexdimen as (
   select index_code,
   localtion,
   MAX(decode(dim_code,'Industry_type',dim_code,'*')) as dim_code1,
   MAX(decode(dim_code,'Industry_type',dim_detail_code,'*')) as dim_detail_code1,
   MAX(decode(dim_code,'Using_water_species',dim_code,'*')) as dim_code2,
   MAX(decode(dim_code,'Using_water_species',dim_detail_code,'*')) as dim_detail_code2
   from index_dimenlocation
   group by index_code,localtion
   )
   
   select * from a
   LEFT JOIN INDEXDIMEN b 
   on a.dim_code1 = b.dim_code1 
   and a.dim_detail_code1 = b.dim_detail_code1
   and a.index_code = b.index_code
   and a.dim_code2 = b.dim_code2
   and a.dim_detail_code2 = b.dim_detail_code2;

BEGIN
jsonStr := '[';
FOR A IN return_cursor LOOP
  jsonStr := jsonStr || '{''location'':''' || A.localtion ||
                 ''',''value'':''' || to_char(A.localtion) || '''},';

  END LOOP;
  jsonStr := jsonStr || ']';
  jsonStr := replace(jsonStr,'},]','}]');
  dbms_output.put_line(jsonStr);
  END;   
  
  procedure getT0044Sum(P_RPTCODE IN VARCHAR2,
                         P_RPTYEAR  IN VARCHAR2,
                         P_RPTMONTH IN VARCHAR2,
                         P_RPTORGID IN VARCHAR2,jsonStr OUT CLOB) IS
    
    Cursor return_cursor is
    
with a as (
select 
ii.index_code,
ii.index_value,
nvl(dimen1.dim_code,'*') dim_code1 ,
nvl(dimen1.dim_detail_code,'*') dim_detail_code1,
nvl(dimen2.dim_code,'*') dim_code2,
nvl(dimen2.dim_detail_code,'*') dim_detail_code2
 from 
e7_sta_repinst repinst 
left join e7_sta_rpt_index_inst inst on repinst.repinst_id = inst.repinst_id
left join e7_sta_index_inst ii on inst.sta_index_inst_id = ii.sta_index_inst_id
left join e7_sta_index_inst_dimen dimen1 on ii.sta_index_inst_id = dimen1.sta_index_inst_id
and dimen1.dim_code = 'Industry_type'
left join e7_sta_index_inst_dimen dimen2 on ii.sta_index_inst_id = dimen2.sta_index_inst_id
and dimen2.dim_code = 'Using_water_species'
where repinst.report_code  in  ( 'C0036' )
   and repinst.org_id in (select org_id from e7_sta_rpt_auth where v_org_id =  P_RPTORGID and report_code  in  ( 'C0036'))
   and repinst.report_year = P_RPTYEAR
   and repinst.report_month = P_RPTMONTH
   ),

   index_dimenlocation as (
   select a.index_code,a.localtion,dimen.dim_code,dimen.dim_detail_code from e7_excel_locationbyindex a
   left join e7_excel_locationbydimen dimen on a.localtion = dimen.localtion 
   where a.report_code = P_RPTCODE
   and dimen.report_code = P_RPTCODE
   
   ),
   indexdimen as (
   select index_code,
   localtion,
   MAX(decode(dim_code,'Industry_type',dim_code,'*')) as dim_code1,
   MAX(decode(dim_code,'Industry_type',dim_detail_code,'*')) as dim_detail_code1,
   MAX(decode(dim_code,'Using_water_species',dim_code,'*')) as dim_code2,
   MAX(decode(dim_code,'Using_water_species',dim_detail_code,'*')) as dim_detail_code2
   from index_dimenlocation
   group by index_code,localtion
   )
   
   select * from a
   LEFT JOIN INDEXDIMEN b 
   on a.dim_code1 = b.dim_code1 
   and a.dim_detail_code1 = b.dim_detail_code1
   and a.index_code = b.index_code
   and a.dim_code2 = b.dim_code2
   and a.dim_detail_code2 = b.dim_detail_code2;

BEGIN
jsonStr := '[';
FOR A IN return_cursor LOOP
  jsonStr := jsonStr || '{''location'':''' || A.LOCALTION ||
                 ''',''value'':''' || to_char(A.INDEX_VALUE) || '''},';

  END LOOP;
  jsonStr := jsonStr || ']';
  jsonStr := replace(jsonStr,'},]','}]');
  dbms_output.put_line(jsonStr);
  END;  
  
  procedure getT0045Sum(P_RPTCODE IN VARCHAR2,
                         P_RPTYEAR  IN VARCHAR2,
                         P_RPTMONTH IN VARCHAR2,
                         P_RPTORGID IN VARCHAR2,jsonStr OUT CLOB) IS
    
    Cursor return_cursor is
    
with a as (
select 
ii.index_code,
ii.index_value,
nvl(dimen1.dim_code,'*') dim_code1 ,
nvl(dimen1.dim_detail_code,'*') dim_detail_code1,
nvl(dimen2.dim_code,'*') dim_code2,
nvl(dimen2.dim_detail_code,'*') dim_detail_code2
 from 
e7_sta_repinst repinst 
left join e7_sta_rpt_index_inst inst on repinst.repinst_id = inst.repinst_id
left join e7_sta_index_inst ii on inst.sta_index_inst_id = ii.sta_index_inst_id
left join e7_sta_index_inst_dimen dimen1 on ii.sta_index_inst_id = dimen1.sta_index_inst_id
and dimen1.dim_code = 'Industry_type'
left join e7_sta_index_inst_dimen dimen2 on ii.sta_index_inst_id = dimen2.sta_index_inst_id
and dimen2.dim_code = 'Using_water_species'
where repinst.report_code  in  ( 'C0046' )
   and repinst.org_id in (select org_id from e7_sta_rpt_auth where v_org_id =  P_RPTORGID and report_code  in  ( 'C0046'))
   and repinst.report_year = P_RPTYEAR
   and repinst.report_month = P_RPTMONTH
   ),

   index_dimenlocation as (
   select a.index_code,a.localtion,dimen.dim_code,dimen.dim_detail_code from e7_excel_locationbyindex a
   left join e7_excel_locationbydimen dimen on a.localtion = dimen.localtion 
   where a.report_code = P_RPTCODE
   and dimen.report_code = P_RPTCODE
   
   ),
   indexdimen as (
   select index_code,
   localtion,
   MAX(decode(dim_code,'Industry_type',dim_code,'*')) as dim_code1,
   MAX(decode(dim_code,'Industry_type',dim_detail_code,'*')) as dim_detail_code1,
   MAX(decode(dim_code,'Using_water_species',dim_code,'*')) as dim_code2,
   MAX(decode(dim_code,'Using_water_species',dim_detail_code,'*')) as dim_detail_code2
   from index_dimenlocation
   group by index_code,localtion
   )
   
   select * from a
   LEFT JOIN INDEXDIMEN b 
   on a.dim_code1 = b.dim_code1 
   and a.dim_detail_code1 = b.dim_detail_code1
   and a.index_code = b.index_code
   and a.dim_code2 = b.dim_code2
   and a.dim_detail_code2 = b.dim_detail_code2;

BEGIN
jsonStr := '[';
FOR A IN return_cursor LOOP
  jsonStr := jsonStr || '{''location'':''' || A.LOCALTION ||
                 ''',''value'':''' || to_char(A.INDEX_VALUE) || '''},';

  END LOOP;
  jsonStr := jsonStr || ']';
  jsonStr := replace(jsonStr,'},]','}]');
  dbms_output.put_line(jsonStr);
  END;    
    
  
  procedure getT0046Sum(P_RPTCODE IN VARCHAR2,
                         P_RPTYEAR  IN VARCHAR2,
                         P_RPTMONTH IN VARCHAR2,
                         P_RPTORGID IN VARCHAR2,jsonStr OUT CLOB) IS
    
    Cursor return_cursor is
    
with a as (
select 
ii.index_code,
ii.index_value,
nvl(dimen1.dim_code,'*') dim_code1 ,
nvl(dimen1.dim_detail_code,'*') dim_detail_code1,
nvl(dimen2.dim_code,'*') dim_code2,
nvl(dimen2.dim_detail_code,'*') dim_detail_code2,
nvl(dimen3.dim_code,'*') dim_code3,
nvl(dimen3.dim_detail_code,'*') dim_detail_code3
 from 
e7_sta_repinst repinst 
left join e7_sta_rpt_index_inst inst on repinst.repinst_id = inst.repinst_id
left join e7_sta_index_inst ii on inst.sta_index_inst_id = ii.sta_index_inst_id
left join e7_sta_index_inst_dimen dimen1 on ii.sta_index_inst_id = dimen1.sta_index_inst_id and dimen1.dim_code = 'Industry_type'
left join e7_sta_index_inst_dimen dimen2 on ii.sta_index_inst_id = dimen2.sta_index_inst_id and dimen2.dim_code = 'Using_water_species'
left join e7_sta_index_inst_dimen dimen3 on ii.sta_index_inst_id = dimen3.sta_index_inst_id and dimen3.dim_code = 'Assets_type'
where repinst.report_code  in  ( 'C0018','C0023','C0170'  )
   and repinst.org_id in (select org_id from e7_sta_rpt_auth where v_org_id = P_RPTORGID and report_code  in  ( 'C0018','C0023','C0170'   ))
   and repinst.report_year = P_RPTYEAR
   and repinst.report_month = P_RPTMONTH
   ),

   index_dimenlocation as (
   select a.index_code,a.localtion,dimen.dim_code,dimen.dim_detail_code from e7_excel_locationbyindex a
   left join e7_excel_locationbydimen dimen on a.localtion = dimen.localtion 
   where a.report_code = P_RPTCODE
   and dimen.report_code = P_RPTCODE
   
   ),
   indexdimen as (
   select index_code,
   localtion,
   MAX(decode(dim_code,'Industry_type',dim_code,'*')) as dim_code1,
   MAX(decode(dim_code,'Industry_type',dim_detail_code,'*')) as dim_detail_code1,
   MAX(decode(dim_code,'Using_water_species',dim_code,'*')) as dim_code2,
   MAX(decode(dim_code,'Using_water_species',dim_detail_code,'*')) as dim_detail_code2,
   MAX(decode(dim_code,'Assets_type',dim_code,'*')) as dim_code3,
   MAX(decode(dim_code,'Assets_type',dim_detail_code,'*')) as dim_detail_code3
   from index_dimenlocation
   group by index_code,localtion
   )
   select * from a
   LEFT JOIN INDEXDIMEN b 
   on a.dim_code1 = b.dim_code1 
   and a.dim_detail_code1 = b.dim_detail_code1
   and a.index_code = b.index_code
   and a.dim_code2 = b.dim_code2
   and a.dim_detail_code2 = b.dim_detail_code2
   and a.dim_code3 = b.dim_code3
   and a.dim_detail_code3 = b.dim_detail_code3;

BEGIN
jsonStr := '[';
FOR A IN return_cursor LOOP
  jsonStr := jsonStr || '{''location'':''' || A.LOCALTION ||
                 ''',''value'':''' || to_char(A.INDEX_VALUE) || '''},';

  END LOOP;
  jsonStr := jsonStr || ']';
  jsonStr := replace(jsonStr,'},]','}]');
  dbms_output.put_line(jsonStr);
  END;  
  
    
  procedure getT0047Sum(P_RPTCODE IN VARCHAR2,
                         P_RPTYEAR  IN VARCHAR2,
                         P_RPTMONTH IN VARCHAR2,
                         P_RPTORGID IN VARCHAR2,jsonStr OUT CLOB) IS
    
    Cursor return_cursor is
    
with a as (
select 
ii.index_code,
ii.index_value,
nvl(dimen1.dim_code,'*') dim_code1 ,
nvl(dimen1.dim_detail_code,'*') dim_detail_code1,
nvl(dimen2.dim_code,'*') dim_code2,
nvl(dimen2.dim_detail_code,'*') dim_detail_code2,
nvl(dimen3.dim_code,'*') dim_code3,
nvl(dimen3.dim_detail_code,'*') dim_detail_code3
 from 
e7_sta_repinst repinst 
left join e7_sta_rpt_index_inst inst on repinst.repinst_id = inst.repinst_id
left join e7_sta_index_inst ii on inst.sta_index_inst_id = ii.sta_index_inst_id
left join e7_sta_index_inst_dimen dimen1 on ii.sta_index_inst_id = dimen1.sta_index_inst_id and dimen1.dim_code = 'Industry_type'
left join e7_sta_index_inst_dimen dimen2 on ii.sta_index_inst_id = dimen2.sta_index_inst_id and dimen2.dim_code = 'Using_water_species'
left join e7_sta_index_inst_dimen dimen3 on ii.sta_index_inst_id = dimen3.sta_index_inst_id and dimen3.dim_code = 'Assets_type'
where repinst.report_code  in  ( 'C0053' )
   and repinst.org_id in (select org_id from e7_sta_rpt_auth where v_org_id = P_RPTORGID and report_code  in  ( 'C0053' ))
   and repinst.report_year = P_RPTYEAR
   and repinst.report_month = P_RPTMONTH
   ),

   index_dimenlocation as (
   select a.index_code,a.localtion,dimen.dim_code,dimen.dim_detail_code from e7_excel_locationbyindex a
   left join e7_excel_locationbydimen dimen on a.localtion = dimen.localtion 
   where a.report_code = P_RPTCODE
   and dimen.report_code = P_RPTCODE
   
   ),
   indexdimen as (
   select index_code,
   localtion,
   MAX(decode(dim_code,'Industry_type',dim_code,'*')) as dim_code1,
   MAX(decode(dim_code,'Industry_type',dim_detail_code,'*')) as dim_detail_code1,
   MAX(decode(dim_code,'Using_water_species',dim_code,'*')) as dim_code2,
   MAX(decode(dim_code,'Using_water_species',dim_detail_code,'*')) as dim_detail_code2,
   MAX(decode(dim_code,'Assets_type',dim_code,'*')) as dim_code3,
   MAX(decode(dim_code,'Assets_type',dim_detail_code,'*')) as dim_detail_code3
   from index_dimenlocation
   group by index_code,localtion
   )
   select * from a
   LEFT JOIN INDEXDIMEN b 
   on a.dim_code1 = b.dim_code1 
   and a.dim_detail_code1 = b.dim_detail_code1
   and a.index_code = b.index_code
   and a.dim_code2 = b.dim_code2
   and a.dim_detail_code2 = b.dim_detail_code2
   and a.dim_code3 = b.dim_code3
   and a.dim_detail_code3 = b.dim_detail_code3;

BEGIN
jsonStr := '[';
FOR A IN return_cursor LOOP
  jsonStr := jsonStr || '{''location'':''' || A.LOCALTION ||
                 ''',''value'':''' || to_char(A.INDEX_VALUE) || '''},';

  END LOOP;
  jsonStr := jsonStr || ']';
  jsonStr := replace(jsonStr,'},]','}]');
  dbms_output.put_line(jsonStr);
  END; 
  
   
  procedure getT0048Sum(P_RPTCODE IN VARCHAR2,
                         P_RPTYEAR  IN VARCHAR2,
                         P_RPTMONTH IN VARCHAR2,
                         P_RPTORGID IN VARCHAR2,jsonStr OUT CLOB) IS
    
    Cursor return_cursor is
    
with a as (
select 
ii.index_code,
ii.index_value,
nvl(dimen1.dim_code,'*') dim_code1 ,
nvl(dimen1.dim_detail_code,'*') dim_detail_code1,
nvl(dimen2.dim_code,'*') dim_code2,
nvl(dimen2.dim_detail_code,'*') dim_detail_code2,
nvl(dimen3.dim_code,'*') dim_code3,
nvl(dimen3.dim_detail_code,'*') dim_detail_code3
 from 
e7_sta_repinst repinst 
left join e7_sta_rpt_index_inst inst on repinst.repinst_id = inst.repinst_id
left join e7_sta_index_inst ii on inst.sta_index_inst_id = ii.sta_index_inst_id
left join e7_sta_index_inst_dimen dimen1 on ii.sta_index_inst_id = dimen1.sta_index_inst_id and dimen1.dim_code = 'Industry_type'
left join e7_sta_index_inst_dimen dimen2 on ii.sta_index_inst_id = dimen2.sta_index_inst_id and dimen2.dim_code = 'Using_water_species'
left join e7_sta_index_inst_dimen dimen3 on ii.sta_index_inst_id = dimen3.sta_index_inst_id and dimen3.dim_code = 'Assets_type'
where repinst.report_code  in  ( 'C0058' )
   and repinst.org_id in (select org_id from e7_sta_rpt_auth where v_org_id = P_RPTORGID and report_code  in  ( 'C0058'   ))
   and repinst.report_year = P_RPTYEAR
   and repinst.report_month = P_RPTMONTH
   ),

   index_dimenlocation as (
   select a.index_code,a.localtion,dimen.dim_code,dimen.dim_detail_code from e7_excel_locationbyindex a
   left join e7_excel_locationbydimen dimen on a.localtion = dimen.localtion 
   where a.report_code = P_RPTCODE
   and dimen.report_code = P_RPTCODE
   
   ),
   indexdimen as (
   select index_code,
   localtion,
   MAX(decode(dim_code,'Industry_type',dim_code,'*')) as dim_code1,
   MAX(decode(dim_code,'Industry_type',dim_detail_code,'*')) as dim_detail_code1,
   MAX(decode(dim_code,'Using_water_species',dim_code,'*')) as dim_code2,
   MAX(decode(dim_code,'Using_water_species',dim_detail_code,'*')) as dim_detail_code2,
   MAX(decode(dim_code,'Assets_type',dim_code,'*')) as dim_code3,
   MAX(decode(dim_code,'Assets_type',dim_detail_code,'*')) as dim_detail_code3
   from index_dimenlocation
   group by index_code,localtion
   )
   select * from a
   LEFT JOIN INDEXDIMEN b 
   on a.dim_code1 = b.dim_code1 
   and a.dim_detail_code1 = b.dim_detail_code1
   and a.index_code = b.index_code
   and a.dim_code2 = b.dim_code2
   and a.dim_detail_code2 = b.dim_detail_code2
   and a.dim_code3 = b.dim_code3
   and a.dim_detail_code3 = b.dim_detail_code3;

BEGIN
jsonStr := '[';
FOR A IN return_cursor LOOP
  jsonStr := jsonStr || '{''location'':''' || A.LOCALTION ||
                 ''',''value'':''' || to_char(A.INDEX_VALUE) || '''},';

  END LOOP;
  jsonStr := jsonStr || ']';
  jsonStr := replace(jsonStr,'},]','}]');
  dbms_output.put_line(jsonStr);
  END;     
    
    
    
    
    
    
    
   
   procedure getT0033Sum(P_RPTCODE IN VARCHAR2,
                        P_RPTYEAR  IN VARCHAR2,
                       P_RPTMONTH IN VARCHAR2,
                       P_RPTORGID IN VARCHAR2,jsonStr OUT CLOB) IS
    
    Cursor return_cursor is
    
    --G10
WITH G10_dssum as (
SELECT *
  FROM (SELECT TO_CHAR(TO_CLOB(XMLAGG(XMLELEMENT(E, ',' || DIM_DETAIL_CODE || ',') ORDER BY DIM_DETAIL_CODE)
                               .EXTRACT('//text()'))) AS DIM_GROUP,
               SIID.STA_INDEX_INST_ID
          FROM E7_STA_INDEX_INST_DIMEN SIID, E7_STA_INDEX_INST SII
         WHERE EXISTS (SELECT SRII.STA_INDEX_INST_ID
                  FROM E7_STA_RPT_INDEX_INST SRII, E7_STA_REPINST SR
                 WHERE SR.REPINST_ID = SRII.REPINST_ID
                   AND SR.ORG_ID IN (select org_id from e7_sta_rpt_auth where v_org_id =P_RPTORGID and report_code = 'C0017')

                   AND SR.REPORT_YEAR = P_RPTYEAR
                   AND SR.REPORT_MONTH = P_RPTMONTH
                   AND SR.REPORT_CODE = 'C0017'
                   AND SIID.STA_INDEX_INST_ID = SRII.STA_INDEX_INST_ID)
           AND SIID.STA_INDEX_INST_ID = SII.STA_INDEX_INST_ID
           AND SII.INDEX_CODE = 'Engy_csmp_amt_pratl'
         GROUP BY SIID.STA_INDEX_INST_ID) TT
  LEFT JOIN (SELECT A.STA_INDEX_INST_ID,
                    A.VALUE_A * B.VALUE_B AS INDEX_VALUE,
                    A.DIM_DETAIL_CODE
               FROM (SELECT SR.REPINST_ID,
                            SII.STA_INDEX_INST_ID,
                            SII.INDEX_VALUE AS VALUE_A,
                            SIID.DIM_DETAIL_CODE,
                            SII.INDEX_INST_ORDERNO
                       FROM E7_STA_REPINST SR
                       LEFT JOIN E7_STA_RPT_INDEX_INST SRII
                         ON SR.REPINST_ID = SRII.REPINST_ID
                       LEFT JOIN E7_STA_INDEX_INST SII
                         ON SRII.STA_INDEX_INST_ID = SII.STA_INDEX_INST_ID
                       LEFT JOIN E7_STA_INDEX_INST_DIMEN SIID
                         ON SII.STA_INDEX_INST_ID = SIID.STA_INDEX_INST_ID
                      WHERE SR.ORG_ID IN   (select org_id from e7_sta_rpt_auth where v_org_id = P_RPTORGID and report_code = 'C0017')

                        AND SR.REPORT_YEAR = P_RPTYEAR
                        AND SR.REPORT_MONTH = P_RPTMONTH
                        AND SII.INDEX_CODE = 'Engy_csmp_amt_pratl'
                        AND SIID.DIM_DETAIL_CODE NOT IN
                            ('Lighter_hyd_los')
                        AND SR.REPORT_CODE = 'C0017') A
               LEFT JOIN (SELECT SR.REPINST_ID,
                                SII.INDEX_VALUE AS VALUE_B,
                                SIID.DIM_DETAIL_CODE,
                                SII.INDEX_INST_ORDERNO
                           FROM E7_STA_REPINST SR
                           LEFT JOIN E7_STA_RPT_INDEX_INST SRII
                             ON SR.REPINST_ID = SRII.REPINST_ID
                           LEFT JOIN E7_STA_INDEX_INST SII
                             ON SRII.STA_INDEX_INST_ID =
                                SII.STA_INDEX_INST_ID
                           LEFT JOIN E7_STA_INDEX_INST_DIMEN SIID
                             ON SII.STA_INDEX_INST_ID =
                                SIID.STA_INDEX_INST_ID
                          WHERE SR.ORG_ID IN  (select org_id from e7_sta_rpt_auth where v_org_id = P_RPTORGID and report_code = 'C0017')

                            AND SR.REPORT_YEAR =P_RPTYEAR
                            AND SR.REPORT_MONTH =P_RPTMONTH
                            AND SII.INDEX_CODE = 'Stadc_coef'
                            AND SIID.DIM_DETAIL_CODE NOT IN
                            ('Lighter_hyd_los')
                            AND SR.REPORT_CODE = 'C0017') B
                 ON A.REPINST_ID = B.REPINST_ID
                AND A.DIM_DETAIL_CODE = B.DIM_DETAIL_CODE
                AND A.INDEX_INST_ORDERNO = B.INDEX_INST_ORDERNO) ZZ
    ON TT.STA_INDEX_INST_ID = ZZ.STA_INDEX_INST_ID
 WHERE INDEX_VALUE IS NOT NULL
 )
 ,          G12_ds4 as (
SELECT *
  FROM (SELECT    TO_CHAR(TO_CLOB(XMLAGG(XMLELEMENT(E, ',' || DIM_DETAIL_CODE || ',') ORDER BY DIM_DETAIL_CODE)
                               .EXTRACT('//text()'))) AS DIM_GROUP,
               SIID.STA_INDEX_INST_ID
          FROM E7_STA_INDEX_INST_DIMEN SIID, E7_STA_INDEX_INST SII
         WHERE EXISTS (SELECT SRII.STA_INDEX_INST_ID
                  FROM E7_STA_RPT_INDEX_INST SRII, E7_STA_REPINST SR
                 WHERE SR.REPINST_ID = SRII.REPINST_ID
                   AND SR.ORG_ID  IN  (select org_id from e7_sta_rpt_auth where v_org_id = P_RPTORGID and report_code = 'C0017')

                   AND SR.REPORT_YEAR = P_RPTYEAR
                   AND SR.REPORT_MONTH = P_RPTMONTH
                   AND SR.REPORT_CODE = 'C0017'
                   AND SIID.STA_INDEX_INST_ID = SRII.STA_INDEX_INST_ID)
           AND SIID.STA_INDEX_INST_ID = SII.STA_INDEX_INST_ID
           AND SII.INDEX_CODE = 'Engy_csmp_amt_pratl'
         GROUP BY SIID.STA_INDEX_INST_ID) TT
  LEFT JOIN (SELECT A.STA_INDEX_INST_ID,
                    A.VALUE_A AS INDEX_VALUE
               FROM (SELECT SR.REPINST_ID,
                            SII.STA_INDEX_INST_ID,
                            SII.INDEX_VALUE AS VALUE_A,
                            SIID.DIM_DETAIL_CODE,
                            SII.INDEX_INST_ORDERNO
                       FROM E7_STA_REPINST SR
                       LEFT JOIN E7_STA_RPT_INDEX_INST SRII
                         ON SR.REPINST_ID = SRII.REPINST_ID
                       LEFT JOIN E7_STA_INDEX_INST SII
                         ON SRII.STA_INDEX_INST_ID = SII.STA_INDEX_INST_ID
                       LEFT JOIN E7_STA_INDEX_INST_DIMEN SIID
                         ON SII.STA_INDEX_INST_ID = SIID.STA_INDEX_INST_ID
                      WHERE SR.ORG_ID   IN  (select org_id from e7_sta_rpt_auth where v_org_id = P_RPTORGID and report_code = 'C0017')

                        AND SR.REPORT_YEAR = P_RPTYEAR
                        AND SR.REPORT_MONTH = P_RPTMONTH
                        AND SII.INDEX_CODE = 'Engy_csmp_amt_pratl'
                        AND SIID.DIM_DETAIL_CODE NOT IN
                            ('Lighter_hyd_los')
                        AND SR.REPORT_CODE = 'C0017') A 
GROUP BY A.STA_INDEX_INST_ID,A.VALUE_A) ZZ
    ON TT.STA_INDEX_INST_ID = ZZ.STA_INDEX_INST_ID
 WHERE INDEX_VALUE IS NOT NULL
)
, G13_ds3 as (
 SELECT *
  FROM (SELECT TO_CHAR(TO_CLOB(XMLAGG(XMLELEMENT(E, ',' || DIM_DETAIL_CODE || ',') ORDER BY DIM_DETAIL_CODE)
                               .EXTRACT('//text()'))) AS DIM_GROUP,
               SIID.STA_INDEX_INST_ID
          FROM E7_STA_INDEX_INST_DIMEN SIID, E7_STA_INDEX_INST SII
         WHERE EXISTS (SELECT SRII.STA_INDEX_INST_ID
                  FROM E7_STA_RPT_INDEX_INST SRII, E7_STA_REPINST SR
                 WHERE SR.REPINST_ID = SRII.REPINST_ID
                   AND SR.ORG_ID IN (select org_id from e7_sta_rpt_auth where v_org_id = P_RPTORGID and report_code in ('C0095','C0105'))

                   AND SR.REPORT_YEAR = P_RPTYEAR
                   AND SR.REPORT_MONTH = P_RPTMONTH
                   AND SR.REPORT_CODE in ('C0095','C0105')
                   AND SIID.STA_INDEX_INST_ID = SRII.STA_INDEX_INST_ID)
           AND SIID.STA_INDEX_INST_ID = SII.STA_INDEX_INST_ID
           AND SII.INDEX_CODE = 'Engy_csmp_amt_pratl'
         GROUP BY SIID.STA_INDEX_INST_ID) TT
  LEFT JOIN (SELECT A.STA_INDEX_INST_ID,
                    A.VALUE_A * B.VALUE_B AS INDEX_VALUE,
                    A.DIM_DETAIL_CODE
               FROM (SELECT SR.REPINST_ID,
                            SII.STA_INDEX_INST_ID,
                            SII.INDEX_VALUE AS VALUE_A,
                            SIID.DIM_DETAIL_CODE,
                            SII.INDEX_INST_ORDERNO
                       FROM E7_STA_REPINST SR
                       LEFT JOIN E7_STA_RPT_INDEX_INST SRII
                         ON SR.REPINST_ID = SRII.REPINST_ID
                       LEFT JOIN E7_STA_INDEX_INST SII
                         ON SRII.STA_INDEX_INST_ID = SII.STA_INDEX_INST_ID
                       LEFT JOIN E7_STA_INDEX_INST_DIMEN SIID
                         ON SII.STA_INDEX_INST_ID = SIID.STA_INDEX_INST_ID
                      WHERE SR.ORG_ID IN   (select org_id from e7_sta_rpt_auth where v_org_id = 20000 and report_code in ('C0095','C0105'))
                        AND SR.REPORT_YEAR = P_RPTYEAR
                        AND SR.REPORT_MONTH = P_RPTMONTH
                        AND SII.INDEX_CODE = 'Engy_csmp_amt_pratl'
                        AND SIID.DIM_DETAIL_CODE NOT IN
                            ('Lighter_hyd_los')
                        AND SR.REPORT_CODE in ('C0095','C0105') )A
               LEFT JOIN (SELECT SR.REPINST_ID,
                                SII.INDEX_VALUE AS VALUE_B,
                                SIID.DIM_DETAIL_CODE,
                                SII.INDEX_INST_ORDERNO
                           FROM E7_STA_REPINST SR
                           LEFT JOIN E7_STA_RPT_INDEX_INST SRII
                             ON SR.REPINST_ID = SRII.REPINST_ID
                           LEFT JOIN E7_STA_INDEX_INST SII
                             ON SRII.STA_INDEX_INST_ID =
                                SII.STA_INDEX_INST_ID
                           LEFT JOIN E7_STA_INDEX_INST_DIMEN SIID
                             ON SII.STA_INDEX_INST_ID =
                                SIID.STA_INDEX_INST_ID
                          WHERE SR.ORG_ID IN  (select org_id from e7_sta_rpt_auth where v_org_id = P_RPTORGID and report_code in ('C0095','C0105'))
                            AND SR.REPORT_YEAR =P_RPTYEAR
                            AND SR.REPORT_MONTH =P_RPTMONTH
                            AND SII.INDEX_CODE = 'Stadc_coef'
                            AND SIID.DIM_DETAIL_CODE NOT IN
                            ('Lighter_hyd_los')
                            AND SR.REPORT_CODE in ('C0095','C0105')) B
                 ON A.REPINST_ID = B.REPINST_ID
                AND A.DIM_DETAIL_CODE = B.DIM_DETAIL_CODE
                AND A.INDEX_INST_ORDERNO = B.INDEX_INST_ORDERNO) ZZ
    ON TT.STA_INDEX_INST_ID = ZZ.STA_INDEX_INST_ID
 WHERE INDEX_VALUE IS NOT NULL
 )
, temp1 as (SELECT 
       T1.ORG_ID,
      T5.DIM_DETAIL_CODE AS DIM_DETAIL_CODE2,
       sum(T3.INDEX_VALUE* INDEXINST1.INDEX_VALUE) as value       
  FROM E7_STA_REPINST T1
  LEFT JOIN E7_STA_RPT_INDEX_INST T2 ON T1.REPINST_ID = T2.REPINST_ID
  LEFT JOIN E7_STA_INDEX_INST T3 ON T2.STA_INDEX_INST_ID = T3.STA_INDEX_INST_ID
  LEFT JOIN E7_STA_INDEX_INST_DIMEN T4 ON T4.STA_INDEX_INST_ID = T2.STA_INDEX_INST_ID
  LEFT JOIN E7_STA_INDEX_INST_DIMEN T5 ON T5.STA_INDEX_INST_ID = T2.STA_INDEX_INST_ID AND T5.DIM_CODE = 'Cru_oil_E_cons_typ' AND T5.DIM_DETAIL_CODE NOT IN ('Cru_oil','Elec','Therm')
  INNER JOIN E7_STA_RPT_INDEX_INST T6 ON T1.REPINST_ID = T6.REPINST_ID 
INNER JOIN E7_STA_INDEX_INST       INDEXINST1 ON T6.STA_INDEX_INST_ID = INDEXINST1.STA_INDEX_INST_ID AND
T3.INDEX_INST_ORDERNO=INDEXINST1.INDEX_INST_ORDERNO
   and INDEXINST1.INDEX_CODE='Stadc_coef' and INDEXINST1.INDEX_VALUE IS NOT NULL
 WHERE T1.REPORT_CODE IN 'C0095'
AND T3.INDEX_CODE='Engy_csmp_amt_pratl'
 AND T1.REPORT_YEAR=P_RPTYEAR
 AND T1.REPORT_MONTH =P_RPTMONTH  
 AND T1.ORG_ID in (select org_id from e7_sta_rpt_auth where v_org_id = P_RPTORGID and report_code IN ('C0095'))  AND T4.DIM_CODE IN 'pow_gener_prod_link' and T4.DIM_DETAIL_CODE ='Production_heat' 
group by  T1.ORG_ID,T5.DIM_DETAIL_CODE
)
  ,G16_heat1 AS (
select DIM_DETAIL_CODE2,sum(value1) as value1 from (
(select temp1.ORG_ID,temp1.DIM_DETAIL_CODE2,
temp1.value*temp2.value_p as value1 from temp1,
(select  org_id,case when sum(value2)=0 then 0 else sum(value1)/sum(value2) end as value_p from (
SELECT r.org_id,
      indexinst.index_code, 
     case when indexinst.index_code='htg_ht_supl_amt' then indexinst.index_value end as value1,
     case when indexinst.index_code='ht_gener_amt' then indexinst.index_value end as value2    
  FROM e7_sta_repinst r
  LEFT JOIN e7_sta_report rr
    ON rr.report_code = r.report_code
  LEFT JOIN e7_sta_rpt_index_inst rptindex
    ON r.repinst_id = rptindex.repinst_id
  LEFT JOIN e7_sta_index_inst indexinst
    ON rptindex.sta_index_inst_id = indexinst.sta_index_inst_id
  LEFT JOIN e7_sta_index_inst_dimen indexinstdimen
    ON indexinstdimen.sta_index_inst_id = indexinst.sta_index_inst_id
 WHERE rr.report_code in ('C0094')
   AND r.org_id in (select org_id from e7_sta_rpt_auth where v_org_id = P_RPTORGID and report_code IN ('C0094'))
   AND r.report_year = P_RPTYEAR
   AND r.report_month =P_RPTMONTH
   and indexinst.index_code in ('ht_gener_amt', 'htg_ht_supl_amt'))
   group by org_id) temp2
   where temp1.ORG_ID=temp2.ORG_ID)
   ) group by ORG_ID,DIM_DETAIL_CODE2
)
 ,G16_heat2 AS(
select DIM_DETAIL_CODE2,sum(value1) as value1 from (
(select temp1.ORG_ID,temp1.DIM_DETAIL_CODE2,
temp1.value*temp2.value_p as value1 from temp1,
(select  org_id,case when sum(value2)=0 then 0 else sum(value1)/sum(value2) end as value_p from (
SELECT r.org_id,
      indexinst.index_code, 
     case when indexinst.index_code='htg_ht_supl_amt' then indexinst.index_value end as value1,
     case when indexinst.index_code='ht_gener_amt' then indexinst.index_value end as value2    
  FROM e7_sta_repinst r
  LEFT JOIN e7_sta_report rr
    ON rr.report_code = r.report_code
  LEFT JOIN e7_sta_rpt_index_inst rptindex
    ON r.repinst_id = rptindex.repinst_id
  LEFT JOIN e7_sta_index_inst indexinst
    ON rptindex.sta_index_inst_id = indexinst.sta_index_inst_id
  LEFT JOIN e7_sta_index_inst_dimen indexinstdimen
    ON indexinstdimen.sta_index_inst_id = indexinst.sta_index_inst_id
 WHERE rr.report_code in ('C0104')
   AND r.org_id in (select org_id from e7_sta_rpt_auth where v_org_id = P_RPTORGID and report_code IN ('C0104'))
   AND r.report_year = P_RPTYEAR
   AND r.report_month =P_RPTMONTH
   and indexinst.index_code in ('ht_gener_amt', 'htg_ht_supl_amt'))
   group by org_id) temp2
   where temp1.ORG_ID=temp2.ORG_ID)
   ) group by ORG_ID,DIM_DETAIL_CODE2
)

,G17_ds5 as (
 
 SELECT *
  FROM (SELECT    TO_CHAR(TO_CLOB(XMLAGG(XMLELEMENT(E, ',' || DIM_DETAIL_CODE || ',') ORDER BY DIM_DETAIL_CODE)
                               .EXTRACT('//text()'))) AS DIM_GROUP,
               SIID.STA_INDEX_INST_ID
          FROM E7_STA_INDEX_INST_DIMEN SIID, E7_STA_INDEX_INST SII
         WHERE EXISTS (SELECT SRII.STA_INDEX_INST_ID
                  FROM E7_STA_RPT_INDEX_INST SRII, E7_STA_REPINST SR
                 WHERE SR.REPINST_ID = SRII.REPINST_ID
                   AND SR.ORG_ID  IN  (select org_id from e7_sta_rpt_auth where v_org_id = P_RPTORGID and report_code in ('C0105','C0100'))

                   AND SR.REPORT_YEAR = P_RPTYEAR
                   AND SR.REPORT_MONTH = P_RPTMONTH
                   AND SR.REPORT_CODE in ('C0105','C0100')
                   AND SIID.STA_INDEX_INST_ID = SRII.STA_INDEX_INST_ID)
           AND SIID.STA_INDEX_INST_ID = SII.STA_INDEX_INST_ID
           AND SII.INDEX_CODE = 'Engy_csmp_amt_pratl'
         GROUP BY SIID.STA_INDEX_INST_ID) TT
  LEFT JOIN (SELECT A.STA_INDEX_INST_ID,
                    A.VALUE_A AS INDEX_VALUE
               FROM (SELECT SR.REPINST_ID,
                            SII.STA_INDEX_INST_ID,
                            SII.INDEX_VALUE AS VALUE_A,
                            SIID.DIM_DETAIL_CODE,
                            SII.INDEX_INST_ORDERNO
                       FROM E7_STA_REPINST SR
                       LEFT JOIN E7_STA_RPT_INDEX_INST SRII
                         ON SR.REPINST_ID = SRII.REPINST_ID
                       LEFT JOIN E7_STA_INDEX_INST SII
                         ON SRII.STA_INDEX_INST_ID = SII.STA_INDEX_INST_ID
                       LEFT JOIN E7_STA_INDEX_INST_DIMEN SIID
                         ON SII.STA_INDEX_INST_ID = SIID.STA_INDEX_INST_ID
                      WHERE SR.ORG_ID   IN  (select org_id from e7_sta_rpt_auth where v_org_id = P_RPTORGID and report_code in ('C0105','C0100'))

                        AND SR.REPORT_YEAR = P_RPTYEAR
                        AND SR.REPORT_MONTH = P_RPTMONTH
                        AND SII.INDEX_CODE = 'Engy_csmp_amt_pratl'
                        AND SIID.DIM_DETAIL_CODE NOT IN
                            ('Lighter_hyd_los')
                        AND SR.REPORT_CODE in ('C0105','C0100')) A 
GROUP BY A.STA_INDEX_INST_ID,A.VALUE_A) ZZ
    ON TT.STA_INDEX_INST_ID = ZZ.STA_INDEX_INST_ID
 WHERE INDEX_VALUE IS NOT NULL
 )

, L10_ds_producesum AS ( 
 select c.sta_index_inst_id,c.index_code,c.index_value,c.composited_index_code, d.repinst_dtl_dimen,d.dim_code,d.dim_detail_code, c.remark
       from e7.e7_sta_repinst a 
       join  e7.e7_sta_rpt_index_inst b on a.repinst_id=b.repinst_id
       join  e7.e7_sta_index_inst c on b.sta_index_inst_id=c.sta_index_inst_id
      left join e7.e7_sta_index_inst_dimen d on c.sta_index_inst_id=d.sta_index_inst_id
where a.report_code='T0001' and a.org_id=P_RPTORGID and a.report_year=P_RPTYEAR and a.report_month=P_RPTMONTH and INDEX_CODE='Wd_ftg'
 )
, L11_drill AS (
 select c.index_value,d.dim_detail_code
       from e7_sta_repinst a 
       join e7_sta_rpt_index_inst b on a.repinst_id=b.repinst_id
       join e7_sta_index_inst c on b.sta_index_inst_id=c.sta_index_inst_id
      left join e7_sta_index_inst_dimen d on c.sta_index_inst_id=d.sta_index_inst_id
where a.report_code= 'C0016' and a.org_id  IN (select org_id from e7_sta_rpt_auth where v_org_id = P_RPTORGID and report_code = 'C0016') and a.report_year=P_RPTYEAR and a.report_month=P_RPTMONTH and c.index_code='Wd_ftg'
 )
   --L13 14 15 16 17
  , L13_product AS (
  select a.report_year,a.report_month,c.index_code,case when sum(c.index_value)=0 then null else sum(c.index_value) end as index_value  from e7_sta_repinst a 
       join e7_sta_rpt_index_inst b on a.repinst_id=b.repinst_id
       join e7_sta_index_inst c on b.sta_index_inst_id=c.sta_index_inst_id
      left join e7_sta_index_inst_dimen d on c.sta_index_inst_id=d.sta_index_inst_id
where a.report_code IN ('C0094','C0099', 'C0104') and a.org_id IN (select org_id from e7_sta_rpt_auth where v_org_id = P_RPTORGID and report_code IN ('C0094','C0099', 'C0104')) and a.report_year=P_RPTYEAR and a.report_month=P_RPTMONTH and index_code not in ('Ind_outp','Entrp_added_value') 
group by a.report_year,a.report_month,c.index_code
  ) 
 --G10
 select e7_excel_locationbyindex.Localtion LOCALTION,  C.SUMVALUE    
   from   e7_excel_locationbyindex  
   left join
(
 SELECT    A.SUMVALUE-B.SUMVALUE  SUMVALUE 
 FROM 
 ( select  NVL(SUM(INDEX_VALUE),0)*1000 SUMVALUE from G10_dssum WHERE DIM_GROUP LIKE '%Well_drilling%'
 ) A
 LEFT JOIN 
 ( select   NVL(SUM(INDEX_VALUE),0)*2000 SUMVALUE from G10_dssum WHERE DIM_GROUP LIKE '%Well_drilling%'
 AND DIM_GROUP LIKE '%Well_drilling%'
 AND(DIM_GROUP lIKE '%Busi_etp_in_out_E%'  
OR   DIM_GROUP LIKE'%Busi_etp_in_out_T%' 
OR   DIM_GROUP LIKE'%Etp_exter_for_out_E%'  
OR   DIM_GROUP LIKE'%Etp_exter_out_T%')) B
  ON 1=1) C
  on 1=1
  WHERE REPORT_CODE=P_RPTCODE AND IS_PY='N' AND INDEX_CODE='Wd_ftg_unit_engy_csmp_mole'
union
 --G11 
  select e7_excel_locationbyindex.Localtion LOCALTION,  C.SUMVALUE    
   from   e7_excel_locationbyindex  
   left join(
select NVL(SUM(c.index_value),0)*1000 SUMVALUE
       from e7.e7_sta_repinst a 
       join  e7.e7_sta_rpt_index_inst b on a.repinst_id=b.repinst_id
       join  e7.e7_sta_index_inst c on b.sta_index_inst_id=c.sta_index_inst_id
      left join e7.e7_sta_index_inst_dimen d on c.sta_index_inst_id=d.sta_index_inst_id
where a.report_code='T0013' and a.org_id=P_RPTORGID and a.report_year=P_RPTYEAR and a.report_month =P_RPTMONTH and DIM_CODE = 'Cru_oil_E_cons_typ' and DIM_DETAIL_CODE = 'Drilling_consumption'  AND INDEX_CODE='Engy_csmp_amt_pratl'
 GROUP BY c.index_code) C  ON 1=1
  WHERE REPORT_CODE=P_RPTCODE AND IS_PY='N' AND INDEX_CODE='Wd_ftg_unit_d_oil_csmp_mole'
  
-- G12
union
 select e7_excel_locationbyindex.Localtion LOCALTION,  C.SUMVALUE    
   from   e7_excel_locationbyindex  
   left join
(
 SELECT    A.SUMVALUE-B.SUMVALUE  SUMVALUE 
 FROM 
 ( select  NVL(SUM(INDEX_VALUE),0)*10000 SUMVALUE from  G12_ds4 WHERE DIM_GROUP LIKE '%Well_drilling%'
  AND(
  DIM_GROUP lIKE '%Etp_pur_quaity_E%'  
  OR   DIM_GROUP LIKE'%Etp_exter_pur_qua_E%'
  )
 ) A
 LEFT JOIN 
 ( select  NVL(SUM(INDEX_VALUE),0)*10000 SUMVALUE from  G12_ds4 WHERE DIM_GROUP LIKE '%Well_drilling%'
  AND(
  DIM_GROUP lIKE  '%Etp_exter_for_out_E%'  
  OR   DIM_GROUP LIKE '%Busi_etp_in_out_E%') )B
  ON 1=1) C
  on 1=1
  WHERE REPORT_CODE=P_RPTCODE AND IS_PY='N' AND INDEX_CODE='Wd_ftg_unit_elec_csmp_mole'
  UNION
--G13
 
select e7_excel_locationbyindex.Localtion LOCALTION,  C.SUMVALUE    
   from   e7_excel_locationbyindex  
   left join
(
 SELECT    A.SUMVALUE-B.SUMVALUE  SUMVALUE 
 FROM 
 ( select  NVL(SUM(INDEX_VALUE),0)*10000 SUMVALUE from  G13_ds3 WHERE DIM_GROUP LIKE '%,Power_generation,%'
 ) A
 LEFT JOIN 
 ( select  NVL(SUM(INDEX_VALUE),0)*10000 SUMVALUE from  G13_ds3 WHERE DIM_GROUP LIKE '%,Power_generation,%'
 AND(DIM_GROUP LIKE'%Busi_etp_in_out_E%'  
OR DIM_GROUP LIKE '%Busi_etp_in_out_T%'  
OR DIM_GROUP LIKE '%Etp_exter_for_out_E%'  
OR DIM_GROUP LIKE '%Etp_exter_out_T%' 
OR DIM_GROUP LIKE '%Etp_exter_pur_qua_E%' 
OR DIM_GROUP LIKE '%Etp_exter_pur_qua_T%' 
OR DIM_GROUP LIKE '%Etp_pur_quaity_E%' 
OR DIM_GROUP LIKE '%Etp_pur_quaity_E%' )
   
   )B
  ON 1=1) C
  on 1=1
  WHERE REPORT_CODE=P_RPTCODE AND IS_PY='N' AND INDEX_CODE='elec_gener_unit_engy_csmp_mole'
  UNION
--G14

 select e7_excel_locationbyindex.Localtion LOCALTION,  C.SUMVALUE    
   from   e7_excel_locationbyindex  
   left join
(
 SELECT    A.SUMVALUE-B.SUMVALUE  SUMVALUE 
 FROM 
 ( select  NVL(SUM(INDEX_VALUE),0)*10000 SUMVALUE from  G13_ds3 WHERE DIM_GROUP LIKE '%,Power_generation,%'
 ) A
 LEFT JOIN 
 ( select  NVL(SUM(INDEX_VALUE),0)*10000 SUMVALUE from  G13_ds3 WHERE DIM_GROUP LIKE '%,Power_generation,%'
 AND(DIM_GROUP LIKE'%Busi_etp_in_out_E%'  
OR DIM_GROUP LIKE '%Busi_etp_in_out_T%'  
OR DIM_GROUP LIKE '%Etp_exter_for_out_E%'  
OR DIM_GROUP LIKE '%Etp_exter_out_T%' 
OR DIM_GROUP LIKE '%Etp_exter_pur_qua_E%' 
OR DIM_GROUP LIKE '%Etp_exter_pur_qua_T%' 
OR DIM_GROUP LIKE '%Etp_pur_quaity_E%' 
OR DIM_GROUP LIKE '%Etp_pur_quaity_E%' )  
   )B
  ON 1=1) C
  on 1=1
  WHERE REPORT_CODE=P_RPTCODE AND IS_PY='N' AND INDEX_CODE='elec_supl_unit_engy_csmp_mole'
 --G15
 UNION
select e7_excel_locationbyindex.Localtion LOCALTION,  C.SUMVALUE    
   from   e7_excel_locationbyindex  
   left join
(
 SELECT    A.SUMVALUE-B.SUMVALUE  SUMVALUE 
 FROM 
 ( select  NVL(SUM(INDEX_VALUE),0)*1000 SUMVALUE from  G13_ds3 WHERE DIM_GROUP LIKE '%,Production_heat,%'
 ) A
 LEFT JOIN 
 ( select  NVL(SUM(INDEX_VALUE),0)*1000 SUMVALUE from  G13_ds3 WHERE DIM_GROUP LIKE '%,Production_heat,%'
 AND(DIM_GROUP LIKE'%Busi_etp_in_out_E%'   
OR DIM_GROUP LIKE '%Busi_etp_in_out_T%' 
OR DIM_GROUP LIKE '%Etp_exter_for_out_E%' 
OR DIM_GROUP LIKE '%Etp_exter_out_T%' 
OR DIM_GROUP LIKE '%Etp_exter_pur_qua_E%' 
OR DIM_GROUP LIKE '%Etp_exter_pur_qua_T%' ) 
   
   )B
  ON 1=1) C
  on 1=1
  WHERE REPORT_CODE=P_RPTCODE AND IS_PY='N' AND INDEX_CODE='ht_supl_unit_engy_csmp_mole'
   UNION
 --G16
select e7_excel_locationbyindex.Localtion LOCALTION,  E.SUMVALUE    
   from   e7_excel_locationbyindex  
   left join
(
 SELECT    A.SUMVALUE - B.SUMVALUE + C.SUMVALUE - D.SUMVALUE  SUMVALUE 
 FROM 
 ( select  NVL(SUM(value1),0)*1000 SUMVALUE from G16_heat1 
 ) A 
 LEFT JOIN 
 ( select  NVL(SUM(value1),0)*2000 SUMVALUE from  G16_heat1 
 WHERE 
DIM_DETAIL_CODE2 LIKE '%Busi_etp_in_out_E%' 
OR DIM_DETAIL_CODE2 LIKE '%Busi_etp_in_out_T%' 
OR DIM_DETAIL_CODE2 LIKE '%Etp_exter_for_out_E%' 
OR DIM_DETAIL_CODE2 LIKE '%Etp_exter_out_T%' ) 
  B
  ON 1=1
  LEFT JOIN 
   ( select  NVL(SUM(value1),0)*1000 SUMVALUE from  G16_heat2 
 ) C 
  ON 1=1
  LEFT JOIN 
    ( select  NVL(SUM(value1),0)*2000 SUMVALUE from  G16_heat2 
    WHERE 
    DIM_DETAIL_CODE2 LIKE '%Busi_etp_in_out_E%' 
OR DIM_DETAIL_CODE2 LIKE '%Busi_etp_in_out_T%' 
OR DIM_DETAIL_CODE2 LIKE '%Etp_exter_for_out_E%' 
OR DIM_DETAIL_CODE2 LIKE '%Etp_exter_out_T%' ) D
  ON 1=1
  ) E
  on 1=1
  WHERE REPORT_CODE=P_RPTCODE AND IS_PY='N' AND INDEX_CODE='htg_ht_supl_unit_engy_csmp_mole'
  UNION
 --G17

 select e7_excel_locationbyindex.Localtion LOCALTION,  C.SUMVALUE    
   from   e7_excel_locationbyindex  
   left join
(
 SELECT    A.SUMVALUE-B.SUMVALUE  SUMVALUE 
 FROM 
 ( select  NVL(SUM(INDEX_VALUE),0)*10000 SUMVALUE from  G17_ds5 WHERE DIM_GROUP LIKE '%,Water_supply,%'
 AND(DIM_GROUP LIKE'%,Etp_pur_quaity_E,%'   
OR DIM_GROUP LIKE '%,Etp_exter_pur_qua_E,%' 
 ) 
 ) A
 LEFT JOIN 
( select  NVL(SUM(INDEX_VALUE),0)*10000 SUMVALUE from  G17_ds5 WHERE DIM_GROUP LIKE '%,Water_supply,%'
 AND(DIM_GROUP LIKE'%,Busi_etp_in_out_E,%'   
OR DIM_GROUP LIKE '%,Etp_exter_for_out_E,%' 
 ) 
 )B
  ON 1=1) C
  on 1=1
  WHERE REPORT_CODE=P_RPTCODE AND IS_PY='N' AND INDEX_CODE='watr_supl_unit_elec_csmp_mole'
  UNION
 --L1O  

  select e7_excel_locationbyindex.Localtion LOCALTION,  C.SUMVALUE    
   from   e7_excel_locationbyindex  
   left join
(
 SELECT    A.SUMVALUE SUMVALUE 
 FROM 
 ( select  NVL(SUM(INDEX_VALUE),0)*10000 SUMVALUE from L10_ds_producesum 
 ) A
  ) C 
  on 1=1
  WHERE REPORT_CODE=P_RPTCODE AND IS_PY='N' AND INDEX_CODE='Wd_ftg'
  UNION
 --L11

   select e7_excel_locationbyindex.Localtion LOCALTION,  C.SUMVALUE    
   from   e7_excel_locationbyindex  
   left join
(
 SELECT    A.SUMVALUE SUMVALUE 
 FROM 
 ( select  NVL(SUM(INDEX_VALUE),0) SUMVALUE from L11_drill where DIM_DETAIL_CODE = 'Dies_oil'
 ) A
  ) C 
  on 1=1
  WHERE REPORT_CODE=P_RPTCODE AND IS_PY='N' AND INDEX_CODE='Wd_ftg_unit_d_oil_csmp_deno'
  UNION
  --L12
select e7_excel_locationbyindex.Localtion LOCALTION,  C.SUMVALUE    
   from   e7_excel_locationbyindex  
   left join
(
 SELECT    A.SUMVALUE SUMVALUE 
 FROM 
 ( select  NVL(SUM(INDEX_VALUE),0) SUMVALUE from L11_drill where DIM_DETAIL_CODE = 'Elec_netw'
 ) A
  ) C 
  on 1=1
  WHERE REPORT_CODE=P_RPTCODE AND IS_PY='N' AND INDEX_CODE='Wd_ftg_unit_elec_csmp_deno'
  UNION

  --L13
  select e7_excel_locationbyindex.Localtion LOCALTION,  C.SUMVALUE    
   from   e7_excel_locationbyindex   
   left join
(
 SELECT    A.SUMVALUE SUMVALUE 
 FROM 
 ( select  NVL(SUM(INDEX_VALUE),0)*10000 SUMVALUE from L13_product where INDEX_CODE = 'watr_unit_elec_deno'
 ) A
  ) C 
  on 1=1
  WHERE REPORT_CODE=P_RPTCODE AND IS_PY='N' AND INDEX_CODE='watr_unit_elec_deno'
  UNION
  --L14
  select e7_excel_locationbyindex.Localtion LOCALTION,  C.SUMVALUE    
   from   e7_excel_locationbyindex  
   left join
(
 SELECT    A.SUMVALUE SUMVALUE 
 FROM 
 ( select  NVL(SUM(INDEX_VALUE),0)*10000 SUMVALUE from L13_product where INDEX_CODE = 'elec_supl_unit_engy_csmp_deno'
 ) A
  ) C 
  on 1=1
  WHERE REPORT_CODE=P_RPTCODE AND IS_PY='N' AND INDEX_CODE='elec_supl_unit_engy_csmp_deno'
  UNION
  --L15
  select e7_excel_locationbyindex.Localtion LOCALTION,  C.SUMVALUE    
   from   e7_excel_locationbyindex  
   left join
(
 SELECT    A.SUMVALUE SUMVALUE 
 FROM 
 ( select  NVL(SUM(INDEX_VALUE),0) SUMVALUE from L13_product where INDEX_CODE = 'watr_unit_htg_deno'
 ) A
  ) C 
  on 1=1
  WHERE REPORT_CODE=P_RPTCODE AND IS_PY='N' AND INDEX_CODE='ht_supl_unit_engy_csmp_deno'
  
  
  union
  --L16
  select e7_excel_locationbyindex.Localtion LOCALTION,  C.SUMVALUE    
   from   e7_excel_locationbyindex  
   left join
(
 SELECT    A.SUMVALUE SUMVALUE 
 FROM 
 ( select  NVL(SUM(INDEX_VALUE),0)*10000 SUMVALUE from L13_product where INDEX_CODE = 'htg_ht_supl_unit_engy_csmp_deno'
 ) A
  ) C 
  on 1=1
  WHERE REPORT_CODE=P_RPTCODE AND IS_PY='N' AND INDEX_CODE='htg_ht_supl_unit_engy_csmp_deno'
  UNION
  --L17
  select e7_excel_locationbyindex.Localtion LOCALTION,  C.SUMVALUE    
   from   e7_excel_locationbyindex  
   left join
(
 SELECT    A.SUMVALUE SUMVALUE 
 FROM 
 ( select  NVL(SUM(INDEX_VALUE),0)*10000 SUMVALUE from L13_product where INDEX_CODE = 'watr_supl_unit_elec_csmp_deno'
 ) A
  ) C 
  on 1=1
  WHERE REPORT_CODE=P_RPTCODE AND IS_PY='N' AND INDEX_CODE='watr_supl_unit_elec_csmp_deno';
    
  BEGIN
jsonStr := '[';
FOR T0033_R IN return_cursor LOOP
  jsonStr := jsonStr || '{''location'':''' || T0033_R.LOCALTION ||
                 ''',''value'':''' || to_char (ROUND(T0033_R.SUMVALUE,4))|| '''},';

  END LOOP;
  jsonStr := jsonStr || ']';
  jsonStr := replace(jsonStr,'},]','}]');
  dbms_output.put_line(jsonStr);
  END; 
  
  
  
  
  procedure getT0031Sum(P_RPTCODE IN VARCHAR2,
                        P_RPTYEAR  IN VARCHAR2,
                       P_RPTMONTH IN VARCHAR2,
                       P_RPTORGID IN VARCHAR2,jsonStr OUT CLOB) IS
    
    Cursor return_cursor is
 -- L14 P14 自动计算
--L8
with L8_ds6 as
(
SELECT
INDEX_VALUE
FROM
(SELECT 
         SII.INDEX_CODE,
            NVL(SUM(SII.INDEX_VALUE),0) INDEX_VALUE 
    FROM E7_STA_REPINST SR
    LEFT JOIN E7_STA_RPT_INDEX_INST SRII ON SR.REPINST_ID = SRII.REPINST_ID
    LEFT JOIN E7_STA_INDEX_INST SII ON SRII.STA_INDEX_INST_ID = SII.STA_INDEX_INST_ID
    LEFT JOIN E7_STA_RPT_AUTH SPA ON SR.ORG_ID = SPA.ORG_ID
     AND SPA.REPORT_CODE = SR.REPORT_CODE
     AND SPA.REPORT_CODE IN ('C0039','C0049')
     AND SPA.V_ORG_ID =P_RPTORGID 
   WHERE SII.REPORT_YEAR = P_RPTYEAR  
     AND SR.REPORT_MONTH =P_RPTMONTH 
     AND SPA.V_ORG_ID = P_RPTORGID 
     AND SII.INDEX_CODE IN('Or_engy_csmp')
      GROUP BY SII.INDEX_CODE
     )  
  
)
, L8_ds7 AS(
SELECT
    INDEX_VALUE
     FROM
   (SELECT 
         SII.INDEX_CODE,
         NVL(SUM(SII.INDEX_VALUE),0) INDEX_VALUE 
    FROM E7_STA_REPINST SR
    LEFT JOIN E7_STA_RPT_INDEX_INST SRII ON SR.REPINST_ID = SRII.REPINST_ID
    LEFT JOIN E7_STA_INDEX_INST SII ON SRII.STA_INDEX_INST_ID = SII.STA_INDEX_INST_ID
    LEFT JOIN E7_STA_INDEX_INST_DIMEN TT ON SRII.STA_INDEX_INST_ID=TT.STA_INDEX_INST_ID
    LEFT JOIN E7_STA_RPT_AUTH SPA ON SR.ORG_ID = SPA.ORG_ID
     AND SPA.REPORT_CODE = SR.REPORT_CODE
     AND SPA.REPORT_CODE IN ('C0034','C0044')
    AND SPA.V_ORG_ID =P_RPTORGID 
   WHERE SII.REPORT_YEAR = P_RPTYEAR  
     AND SR.REPORT_MONTH =P_RPTMONTH 
     AND SPA.V_ORG_ID = P_RPTORGID 
      AND SII.INDEX_CODE IN ('Og_prod')
     group by index_code
     )  
    
   
)


--L19
,L19_ds6 as(
SELECT
--A.INDEX_VALUE INDEX_VALUE,B.LOCALTION 
*
FROM
(SELECT 
         SII.INDEX_CODE index_code,
         NVL(SUM(SII.INDEX_VALUE),0) INDEX_VALUE
    FROM E7_STA_REPINST SR
    LEFT JOIN E7_STA_RPT_INDEX_INST SRII ON SR.REPINST_ID = SRII.REPINST_ID
    LEFT JOIN E7_STA_INDEX_INST SII ON SRII.STA_INDEX_INST_ID = SII.STA_INDEX_INST_ID
    LEFT JOIN E7_STA_RPT_AUTH SPA ON SR.ORG_ID = SPA.ORG_ID
     AND SPA.REPORT_CODE = SR.REPORT_CODE
     AND SPA.REPORT_CODE IN ('C0039','C0049')
   AND SPA.V_ORG_ID =P_RPTORGID 
   WHERE SII.REPORT_YEAR = P_RPTYEAR  
     AND SR.REPORT_MONTH =P_RPTMONTH 
     AND SPA.V_ORG_ID = P_RPTORGID 
      GROUP BY SII.INDEX_CODE
     ) A  
     LEFT JOIN 
   (SELECT * FROM e7_excel_locationbyindex WHERE REPORT_CODE=P_RPTCODE AND IS_PY ='N' AND localtion ='I19' ) B
    on  B.INDEX_CODE =A.INDEX_CODE
where A.INDEX_CODE='Ammo_fuel_csmp')



--L20
, L20_ds6 as( 
SELECT
--A.INDEX_VALUE INDEX_VALUE,B.LOCALTION 
*
FROM
(SELECT 
         SII.INDEX_CODE index_code,
         NVL(SUM(SII.INDEX_VALUE),0) INDEX_VALUE
    FROM E7_STA_REPINST SR
    LEFT JOIN E7_STA_RPT_INDEX_INST SRII ON SR.REPINST_ID = SRII.REPINST_ID
    LEFT JOIN E7_STA_INDEX_INST SII ON SRII.STA_INDEX_INST_ID = SII.STA_INDEX_INST_ID
    LEFT JOIN E7_STA_RPT_AUTH SPA ON SR.ORG_ID = SPA.ORG_ID
     AND SPA.REPORT_CODE = SR.REPORT_CODE
     AND SPA.REPORT_CODE IN ('C0039','C0049')
    AND SPA.V_ORG_ID =P_RPTORGID 
   WHERE SII.REPORT_YEAR = P_RPTYEAR  
     AND SR.REPORT_MONTH =P_RPTMONTH 
     AND SPA.V_ORG_ID = P_RPTORGID 
      GROUP BY SII.INDEX_CODE
     ) A  
     LEFT JOIN 
   (SELECT * FROM e7_excel_locationbyindex WHERE REPORT_CODE=P_RPTCODE AND IS_PY ='N' ) B
    on  B.INDEX_CODE =A.INDEX_CODE
where A.INDEX_CODE='Purenitro_fuel_csmp')



 
--L21
, L21_ds6 as(
SELECT
--A.INDEX_VALUE INDEX_VALUE,B.LOCALTION 
*
FROM
(SELECT 
         SII.INDEX_CODE index_code,
         NVL(SUM(SII.INDEX_VALUE),0) INDEX_VALUE
    FROM E7_STA_REPINST SR
    LEFT JOIN E7_STA_RPT_INDEX_INST SRII ON SR.REPINST_ID = SRII.REPINST_ID
    LEFT JOIN E7_STA_INDEX_INST SII ON SRII.STA_INDEX_INST_ID = SII.STA_INDEX_INST_ID
    LEFT JOIN E7_STA_RPT_AUTH SPA ON SR.ORG_ID = SPA.ORG_ID
     AND SPA.REPORT_CODE = SR.REPORT_CODE
     AND SPA.REPORT_CODE IN ('C0039','C0049')
    AND SPA.V_ORG_ID =P_RPTORGID 
   WHERE SII.REPORT_YEAR = P_RPTYEAR  
     AND SR.REPORT_MONTH =P_RPTMONTH 
     AND SPA.V_ORG_ID = P_RPTORGID 
      GROUP BY SII.INDEX_CODE
     ) A  
     LEFT JOIN 
   (SELECT * FROM e7_excel_locationbyindex WHERE REPORT_CODE=P_RPTCODE AND IS_PY ='N'  ) B
    on  B.INDEX_CODE =A.INDEX_CODE
where A.INDEX_CODE='Metha_fuel_csmp')











--L7,L10,L11,L12,L13,L15,L16,L17,L18
SELECT
B.LOCALTION,A.INDEX_VALUE SUMVALUE
FROM
(SELECT 
         SII.INDEX_CODE,
          NVL(SUM(SII.INDEX_VALUE),0) INDEX_VALUE
    FROM E7_STA_REPINST SR
    LEFT JOIN E7_STA_RPT_INDEX_INST SRII ON SR.REPINST_ID = SRII.REPINST_ID
    LEFT JOIN E7_STA_INDEX_INST SII ON SRII.STA_INDEX_INST_ID = SII.STA_INDEX_INST_ID
    LEFT JOIN E7_STA_RPT_AUTH SPA ON SR.ORG_ID = SPA.ORG_ID
     AND SPA.REPORT_CODE = SR.REPORT_CODE
     AND SPA.REPORT_CODE IN ('C0039','C0049')
    AND SPA.V_ORG_ID =P_RPTORGID 
   WHERE SII.REPORT_YEAR = P_RPTYEAR  
     AND SR.REPORT_MONTH =P_RPTMONTH 
     AND SPA.V_ORG_ID = P_RPTORGID 
      GROUP BY SII.INDEX_CODE
     ) A  
     LEFT JOIN 
   (SELECT * FROM e7_excel_locationbyindex WHERE REPORT_CODE=P_RPTCODE AND IS_PY ='N' ) B
    on  B.INDEX_CODE =A.INDEX_CODE
   WHERE A.INDEX_CODE IN('Or_engy_csmp','Eth_fuel_csmp','LowEth_fuel_csmp','HighEth_fuel_csmp','LinehEth_fuel_csmp','CohEth_fuel_csmp','Polyp_fuel_csmp','Acr_fuel_csmp','Acryl_fuel_csmp')
     UNION
     --L9, P7 ~P21
     SELECT
    B.LOCALTION, A.INDEX_VALUE SUMVALUE
     FROM
   (SELECT 
         SII.INDEX_CODE,
         NVL(SUM(SII.INDEX_VALUE),0) INDEX_VALUE
    FROM E7_STA_REPINST SR
    LEFT JOIN E7_STA_RPT_INDEX_INST SRII ON SR.REPINST_ID = SRII.REPINST_ID
    LEFT JOIN E7_STA_INDEX_INST SII ON SRII.STA_INDEX_INST_ID = SII.STA_INDEX_INST_ID
    LEFT JOIN E7_STA_INDEX_INST_DIMEN TT ON SRII.STA_INDEX_INST_ID=TT.STA_INDEX_INST_ID
    LEFT JOIN E7_STA_RPT_AUTH SPA ON SR.ORG_ID = SPA.ORG_ID
     AND SPA.REPORT_CODE = SR.REPORT_CODE
     AND SPA.REPORT_CODE IN ('C0034','C0044')
    AND SPA.V_ORG_ID =P_RPTORGID 
   WHERE SII.REPORT_YEAR = P_RPTYEAR  
     AND SR.REPORT_MONTH =P_RPTMONTH 
     AND SPA.V_ORG_ID = P_RPTORGID 
     group by index_code
     ) A 
     LEFT JOIN 
     (SELECT * FROM e7_excel_locationbyindex WHERE REPORT_CODE=P_RPTCODE AND IS_PY ='N') B
     ON A.INDEX_CODE=B.INDEX_CODE 
    WHERE A.INDEX_CODE IN ('Or_Comph_engy_lost_amt','Og_prod','Co_inco_amt','Eth_prod','LowEth_pro_amt','HighEth_pro_amt','LinehEth_pro_amt','CohEth_pro_amt','Polyp_pro_amt','Acr_pro_amt','Acryl_pro_amt','Synth_amm_prod','Purenitro_pro_amt','Metha_pro_amt')
   UNION
   
  
   
   --P8
SELECT 
E.LOCALTION,D.INDEX_VALUE SUMVALUE  FROM
( 
 SELECT 
 Localtion  
 FROM e7_excel_locationbyindex
 WHERE localtion ='J8' AND Report_Code=P_RPTCODE
)E
 LEFT JOIN (
 select c.index_value 
       from E7.e7_sta_repinst a 
       join  E7.e7_sta_rpt_index_inst b on a.repinst_id=b.repinst_id
       join  E7.e7_sta_index_inst c on b.sta_index_inst_id=c.sta_index_inst_id
      left join  E7.e7_sta_index_inst_dimen d on c.sta_index_inst_id=d.sta_index_inst_id
where a.report_code='T0062' and a.org_id='20000'and a.report_year='2017' and a.report_month='1' 
 and c.index_value is not null and c.index_code='Or_engy_fact_sum') D
ON 1=1
UNION
   
--L8
SELECT e7_excel_locationbyindex.localtion,(L8_ds6.INDEX_VALUE)/(L8_ds7.INDEX_VALUE) SUMVALUE from 
(L8_ds6)
left join
(L8_ds7)  ON 1=1
LEFT JOIN e7_excel_locationbyindex  
 on e7_excel_locationbyindex.localtion ='I8'  WHERE e7_excel_locationbyindex.REPORT_CODE=P_RPTCODE
UNION
--L19
select  e7_excel_locationbyindex.localtion,L19_ds6.INDEX_VALUE SUMVALUE from L19_ds6 left join e7_excel_locationbyindex 
on e7_excel_locationbyindex.localtion ='I19'  WHERE e7_excel_locationbyindex.REPORT_CODE=P_RPTCODE
   UNION
--L20
select  e7_excel_locationbyindex.localtion,L20_ds6.INDEX_VALUE SUMVALUE from L20_ds6 left join e7_excel_locationbyindex 
on e7_excel_locationbyindex.localtion ='I20'  WHERE e7_excel_locationbyindex.REPORT_CODE=P_RPTCODE
UNION
--L21
select  e7_excel_locationbyindex.localtion,L21_ds6.INDEX_VALUE SUMVALUE from L21_ds6 left join e7_excel_locationbyindex 
on e7_excel_locationbyindex.localtion ='I21'  WHERE e7_excel_locationbyindex.REPORT_CODE=P_RPTCODE;   
   

 BEGIN
jsonStr := '[';
FOR T0031_R IN return_cursor LOOP
  jsonStr := jsonStr || '{''location'':''' || T0031_R.LOCALTION ||
                 ''',''value'':''' || to_char (ROUND(T0031_R.SUMVALUE,4))|| '''},';

  END LOOP;
  jsonStr := jsonStr || ']';
  jsonStr := replace(jsonStr,'},]','}]');
  dbms_output.put_line(jsonStr);
  END; 
  
  
  
  
  
  procedure getT0030Sum(P_RPTCODE IN VARCHAR2,
                        P_RPTYEAR  IN VARCHAR2,
                       P_RPTMONTH IN VARCHAR2,
                       P_RPTORGID IN VARCHAR2,jsonStr OUT CLOB) IS
    
    Cursor return_cursor is

 WITH P12_ds19_1 as (
  SELECT 
MAX(RR.REPORT_CODE) REPORT_CODE,
--R.REPORT_MONTH,
      -- INDEXINST.STA_INDEX_INST_ID,
       INDEXINST.INDEX_CODE,
      NVL(SUM(indexinst.index_value)  ,0) INDEX_VALUE
      -- INDEXINST.UNIT_CODE,
      -- INDEXINST.COMPOSITED_INDEX_CODE,
      -- INDEXINSTDIMEN.REPINST_DTL_DIMEN,
     --  INDEXINSTDIMEN.DIM_CODE,
     --  INDEXINSTDIMEN.DIM_DETAIL_CODE,
     --  INDEXINSTDIMEN.UNIT_CODE AS DIMENUNITCODE,
    --   INDEXINST.INDEX_INST_ORDERNO,
    --   INDEXINSTDIMEN.COMPOSITE_DIM_CODE
  FROM E7_STA_REPINST R
  LEFT JOIN E7_STA_REPORT RR ON RR.REPORT_CODE = R.REPORT_CODE
  LEFT JOIN E7_STA_RPT_INDEX_INST RPTINDEX ON R.REPINST_ID = RPTINDEX.REPINST_ID
  LEFT JOIN E7_STA_INDEX_INST INDEXINST ON RPTINDEX.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
  LEFT JOIN E7_STA_INDEX_INST_DIMEN INDEXINSTDIMEN ON INDEXINSTDIMEN.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
 WHERE RR.REPORT_CODE IN ('T0001')
   AND R.ORG_ID = P_RPTORGID
   AND R.REPORT_YEAR = P_RPTYEAR
   AND R.REPORT_MONTH= P_RPTMONTH
   AND INDEXINST.INDEX_CODE='Watr_prod' 
   GROUP BY INDEXINST.INDEX_CODE
  ),
   P12_ds19_2 as (
    SELECT 
MAX(RR.REPORT_CODE) REPORT_CODE,
--R.REPORT_MONTH,
      -- INDEXINST.STA_INDEX_INST_ID,
       INDEXINST.INDEX_CODE,
      NVL(SUM(indexinst.index_value)  ,0) INDEX_VALUE
      -- INDEXINST.UNIT_CODE,
      -- INDEXINST.COMPOSITED_INDEX_CODE,
      -- INDEXINSTDIMEN.REPINST_DTL_DIMEN,
     --  INDEXINSTDIMEN.DIM_CODE,
     --  INDEXINSTDIMEN.DIM_DETAIL_CODE,
     --  INDEXINSTDIMEN.UNIT_CODE AS DIMENUNITCODE,
    --   INDEXINST.INDEX_INST_ORDERNO,
    --   INDEXINSTDIMEN.COMPOSITE_DIM_CODE
  FROM E7_STA_REPINST R
  LEFT JOIN E7_STA_REPORT RR ON RR.REPORT_CODE = R.REPORT_CODE
  LEFT JOIN E7_STA_RPT_INDEX_INST RPTINDEX ON R.REPINST_ID = RPTINDEX.REPINST_ID
  LEFT JOIN E7_STA_INDEX_INST INDEXINST ON RPTINDEX.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
  LEFT JOIN E7_STA_INDEX_INST_DIMEN INDEXINSTDIMEN ON INDEXINSTDIMEN.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
 WHERE RR.REPORT_CODE IN ('T0001')
   AND R.ORG_ID = P_RPTORGID
   AND R.REPORT_YEAR = P_RPTYEAR
   AND R.REPORT_MONTH= P_RPTMONTH
   AND INDEXINST.INDEX_CODE='Co_prod' 
   GROUP BY INDEXINST.INDEX_CODE
  ),
   P12_ds19_3 as (
   SELECT 
MAX(RR.REPORT_CODE) REPORT_CODE,
--R.REPORT_MONTH,
      -- INDEXINST.STA_INDEX_INST_ID,
       INDEXINST.INDEX_CODE,
       NVL(SUM(indexinst.index_value)  ,0) INDEX_VALUE
      -- INDEXINST.UNIT_CODE,
      -- INDEXINST.COMPOSITED_INDEX_CODE,
      -- INDEXINSTDIMEN.REPINST_DTL_DIMEN,
     --  INDEXINSTDIMEN.DIM_CODE,
     --  INDEXINSTDIMEN.DIM_DETAIL_CODE,
     --  INDEXINSTDIMEN.UNIT_CODE AS DIMENUNITCODE,
    --   INDEXINST.INDEX_INST_ORDERNO,
    --   INDEXINSTDIMEN.COMPOSITE_DIM_CODE
  FROM E7_STA_REPINST R
  LEFT JOIN E7_STA_REPORT RR ON RR.REPORT_CODE = R.REPORT_CODE
  LEFT JOIN E7_STA_RPT_INDEX_INST RPTINDEX ON R.REPINST_ID = RPTINDEX.REPINST_ID
  LEFT JOIN E7_STA_INDEX_INST INDEXINST ON RPTINDEX.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
  LEFT JOIN E7_STA_INDEX_INST_DIMEN INDEXINSTDIMEN ON INDEXINSTDIMEN.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
 WHERE RR.REPORT_CODE IN ('T0001')
   AND R.ORG_ID = P_RPTORGID
   AND R.REPORT_YEAR = P_RPTYEAR
   AND R.REPORT_MONTH= P_RPTMONTH
   AND INDEXINST.INDEX_CODE='Ng_prod' 
   GROUP BY INDEXINST.INDEX_CODE
  )
   ,L7_8_ds13 as(
SELECT RR.REPORT_CODE,R.REPORT_MONTH,
       INDEXINST.STA_INDEX_INST_ID,
       INDEXINST.INDEX_CODE,
       INDEXINST.INDEX_VALUE,
       INDEXINST.UNIT_CODE,
       INDEXINST.COMPOSITED_INDEX_CODE,
       INDEXINSTDIMEN.REPINST_DTL_DIMEN,
       INDEXINSTDIMEN.DIM_CODE,
       INDEXINSTDIMEN.DIM_DETAIL_CODE,
       INDEXINSTDIMEN.UNIT_CODE AS DIMENUNITCODE,
       INDEXINST.INDEX_INST_ORDERNO,
       INDEXINSTDIMEN.COMPOSITE_DIM_CODE
  FROM E7_STA_REPINST R
  LEFT JOIN E7_STA_REPORT RR ON RR.REPORT_CODE = R.REPORT_CODE
  LEFT JOIN E7_STA_RPT_INDEX_INST RPTINDEX ON R.REPINST_ID = RPTINDEX.REPINST_ID
  LEFT JOIN E7_STA_INDEX_INST INDEXINST ON RPTINDEX.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
  LEFT JOIN E7_STA_INDEX_INST_DIMEN INDEXINSTDIMEN ON INDEXINSTDIMEN.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
 WHERE RR.REPORT_CODE IN ('T0009', 'T0008', 'T0010')
    AND R.ORG_ID = P_RPTORGID
 AND R.REPORT_YEAR = P_RPTYEAR
 AND R.REPORT_MONTH=P_RPTMONTH
   AND INDEXINST.INDEX_CODE = 'Engy_csmp_amt_stadc'
AND INDEXINSTDIMEN.DIM_CODE IN ('Heav_oil_prod_link', 'Rar_oil_prod_link', 'Gas_produ_link')
)
, L9_ds13 as(
SELECT RR.REPORT_CODE,R.REPORT_MONTH,
       INDEXINST.STA_INDEX_INST_ID,
       INDEXINST.INDEX_CODE,
       INDEXINST.INDEX_VALUE,
       INDEXINST.UNIT_CODE,
       INDEXINST.COMPOSITED_INDEX_CODE,
       INDEXINSTDIMEN.REPINST_DTL_DIMEN,
       INDEXINSTDIMEN.DIM_CODE,
       INDEXINSTDIMEN.DIM_DETAIL_CODE,
       INDEXINSTDIMEN.UNIT_CODE AS DIMENUNITCODE,
       INDEXINST.INDEX_INST_ORDERNO,
       INDEXINSTDIMEN.COMPOSITE_DIM_CODE
  FROM E7_STA_REPINST R
  LEFT JOIN E7_STA_REPORT RR ON RR.REPORT_CODE = R.REPORT_CODE
  LEFT JOIN E7_STA_RPT_INDEX_INST RPTINDEX ON R.REPINST_ID = RPTINDEX.REPINST_ID
  LEFT JOIN E7_STA_INDEX_INST INDEXINST ON RPTINDEX.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
  LEFT JOIN E7_STA_INDEX_INST_DIMEN INDEXINSTDIMEN ON INDEXINSTDIMEN.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
 WHERE RR.REPORT_CODE IN ('T0009', 'T0008', 'T0010')
     AND R.ORG_ID = P_RPTORGID
 AND R.REPORT_YEAR = P_RPTYEAR
 AND R.REPORT_MONTH=P_RPTMONTH
   AND INDEXINST.INDEX_CODE = 'Engy_csmp_amt_stadc'
AND INDEXINSTDIMEN.DIM_CODE IN ('Heav_oil_prod_link', 'Rar_oil_prod_link', 'Gas_produ_link')
AND (RR.REPORT_CODE='T0008' OR RR.REPORT_CODE='T0009')
)
,L10_ds13 as(
SELECT RR.REPORT_CODE,R.REPORT_MONTH,
       INDEXINST.STA_INDEX_INST_ID,
       INDEXINST.INDEX_CODE,
       INDEXINST.INDEX_VALUE,
       INDEXINST.UNIT_CODE,
       INDEXINST.COMPOSITED_INDEX_CODE,
       INDEXINSTDIMEN.REPINST_DTL_DIMEN,
       INDEXINSTDIMEN.DIM_CODE,
       INDEXINSTDIMEN.DIM_DETAIL_CODE,
       INDEXINSTDIMEN.UNIT_CODE AS DIMENUNITCODE,
       INDEXINST.INDEX_INST_ORDERNO,
       INDEXINSTDIMEN.COMPOSITE_DIM_CODE
  FROM E7_STA_REPINST R
  LEFT JOIN E7_STA_REPORT RR ON RR.REPORT_CODE = R.REPORT_CODE
  LEFT JOIN E7_STA_RPT_INDEX_INST RPTINDEX ON R.REPINST_ID = RPTINDEX.REPINST_ID
  LEFT JOIN E7_STA_INDEX_INST INDEXINST ON RPTINDEX.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
  LEFT JOIN E7_STA_INDEX_INST_DIMEN INDEXINSTDIMEN ON INDEXINSTDIMEN.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
 WHERE RR.REPORT_CODE IN ('T0009', 'T0008', 'T0010')
   AND R.ORG_ID = P_RPTORGID
 AND R.REPORT_YEAR = P_RPTYEAR
 AND R.REPORT_MONTH=P_RPTMONTH
   AND INDEXINST.INDEX_CODE = 'Engy_csmp_amt_stadc'
AND INDEXINSTDIMEN.DIM_CODE IN ('Heav_oil_prod_link', 'Rar_oil_prod_link', 'Gas_produ_link')
AND RR.REPORT_CODE='T0008' 
)
,L11_ds13 as(
SELECT RR.REPORT_CODE,R.REPORT_MONTH,
       INDEXINST.STA_INDEX_INST_ID,
       INDEXINST.INDEX_CODE,
       INDEXINST.INDEX_VALUE,
       INDEXINST.UNIT_CODE,
       INDEXINST.COMPOSITED_INDEX_CODE,
       INDEXINSTDIMEN.REPINST_DTL_DIMEN,
       INDEXINSTDIMEN.DIM_CODE,
       INDEXINSTDIMEN.DIM_DETAIL_CODE,
       INDEXINSTDIMEN.UNIT_CODE AS DIMENUNITCODE,
       INDEXINST.INDEX_INST_ORDERNO,
       INDEXINSTDIMEN.COMPOSITE_DIM_CODE
  FROM E7_STA_REPINST R
  LEFT JOIN E7_STA_REPORT RR ON RR.REPORT_CODE = R.REPORT_CODE
  LEFT JOIN E7_STA_RPT_INDEX_INST RPTINDEX ON R.REPINST_ID = RPTINDEX.REPINST_ID
  LEFT JOIN E7_STA_INDEX_INST INDEXINST ON RPTINDEX.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
  LEFT JOIN E7_STA_INDEX_INST_DIMEN INDEXINSTDIMEN ON INDEXINSTDIMEN.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
 WHERE RR.REPORT_CODE IN ('T0009', 'T0008', 'T0010')
     AND R.ORG_ID = P_RPTORGID
 AND R.REPORT_YEAR = P_RPTYEAR
 AND R.REPORT_MONTH=P_RPTMONTH
   AND INDEXINST.INDEX_CODE = 'Engy_csmp_amt_stadc'
AND INDEXINSTDIMEN.DIM_CODE IN ('Heav_oil_prod_link', 'Rar_oil_prod_link', 'Gas_produ_link')
AND RR.REPORT_CODE='T0009' 
)
 ,L12_ds13 as(
SELECT RR.REPORT_CODE,R.REPORT_MONTH,
       INDEXINST.STA_INDEX_INST_ID,
       INDEXINST.INDEX_CODE,
       INDEXINST.INDEX_VALUE,
       INDEXINST.UNIT_CODE,
       INDEXINST.COMPOSITED_INDEX_CODE,
       INDEXINSTDIMEN.REPINST_DTL_DIMEN,
       INDEXINSTDIMEN.DIM_CODE,
       INDEXINSTDIMEN.DIM_DETAIL_CODE,
       INDEXINSTDIMEN.UNIT_CODE AS DIMENUNITCODE,
       INDEXINST.INDEX_INST_ORDERNO,
       INDEXINSTDIMEN.COMPOSITE_DIM_CODE
  FROM E7_STA_REPINST R
  LEFT JOIN E7_STA_REPORT RR ON RR.REPORT_CODE = R.REPORT_CODE
  LEFT JOIN E7_STA_RPT_INDEX_INST RPTINDEX ON R.REPINST_ID = RPTINDEX.REPINST_ID
  LEFT JOIN E7_STA_INDEX_INST INDEXINST ON RPTINDEX.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
  LEFT JOIN E7_STA_INDEX_INST_DIMEN INDEXINSTDIMEN ON INDEXINSTDIMEN.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
 WHERE RR.REPORT_CODE IN ('T0009', 'T0008', 'T0010')
   AND R.ORG_ID = P_RPTORGID
 AND R.REPORT_YEAR = P_RPTYEAR
 AND R.REPORT_MONTH=P_RPTMONTH
   AND INDEXINST.INDEX_CODE = 'Engy_csmp_amt_stadc'
AND INDEXINSTDIMEN.DIM_CODE IN ('Heav_oil_prod_link', 'Rar_oil_prod_link', 'Gas_produ_link')
AND (RR.REPORT_CODE='T0008' OR RR.REPORT_CODE='T0009')
)
,L13_ds13 as(
SELECT RR.REPORT_CODE,R.REPORT_MONTH,
       INDEXINST.STA_INDEX_INST_ID,
       INDEXINST.INDEX_CODE,
       INDEXINST.INDEX_VALUE,
       INDEXINST.UNIT_CODE,
       INDEXINST.COMPOSITED_INDEX_CODE,
       INDEXINSTDIMEN.REPINST_DTL_DIMEN,
       INDEXINSTDIMEN.DIM_CODE,
       INDEXINSTDIMEN.DIM_DETAIL_CODE,
       INDEXINSTDIMEN.UNIT_CODE AS DIMENUNITCODE,
       INDEXINST.INDEX_INST_ORDERNO,
       INDEXINSTDIMEN.COMPOSITE_DIM_CODE
  FROM E7_STA_REPINST R
  LEFT JOIN E7_STA_REPORT RR ON RR.REPORT_CODE = R.REPORT_CODE
  LEFT JOIN E7_STA_RPT_INDEX_INST RPTINDEX ON R.REPINST_ID = RPTINDEX.REPINST_ID
  LEFT JOIN E7_STA_INDEX_INST INDEXINST ON RPTINDEX.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
  LEFT JOIN E7_STA_INDEX_INST_DIMEN INDEXINSTDIMEN ON INDEXINSTDIMEN.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
 WHERE RR.REPORT_CODE IN ('T0009', 'T0008', 'T0010')
    AND R.ORG_ID = P_RPTORGID
 AND R.REPORT_YEAR = P_RPTYEAR
 AND R.REPORT_MONTH=P_RPTMONTH
   AND INDEXINST.INDEX_CODE = 'Engy_csmp_amt_stadc'
AND INDEXINSTDIMEN.DIM_CODE IN ('Heav_oil_prod_link', 'Rar_oil_prod_link', 'Gas_produ_link')
AND RR.REPORT_CODE='T0008' 
)
   ,L14_ds13 as(
SELECT RR.REPORT_CODE,R.REPORT_MONTH,
       INDEXINST.STA_INDEX_INST_ID,
       INDEXINST.INDEX_CODE,
       INDEXINST.INDEX_VALUE,
       INDEXINST.UNIT_CODE,
       INDEXINST.COMPOSITED_INDEX_CODE,
       INDEXINSTDIMEN.REPINST_DTL_DIMEN,
       INDEXINSTDIMEN.DIM_CODE,
       INDEXINSTDIMEN.DIM_DETAIL_CODE,
       INDEXINSTDIMEN.UNIT_CODE AS DIMENUNITCODE,
       INDEXINST.INDEX_INST_ORDERNO,
       INDEXINSTDIMEN.COMPOSITE_DIM_CODE
  FROM E7_STA_REPINST R
  LEFT JOIN E7_STA_REPORT RR ON RR.REPORT_CODE = R.REPORT_CODE
  LEFT JOIN E7_STA_RPT_INDEX_INST RPTINDEX ON R.REPINST_ID = RPTINDEX.REPINST_ID
  LEFT JOIN E7_STA_INDEX_INST INDEXINST ON RPTINDEX.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
  LEFT JOIN E7_STA_INDEX_INST_DIMEN INDEXINSTDIMEN ON INDEXINSTDIMEN.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
 WHERE RR.REPORT_CODE IN ('T0009', 'T0008', 'T0010')
    AND R.ORG_ID = P_RPTORGID
 AND R.REPORT_YEAR = P_RPTYEAR
 AND R.REPORT_MONTH=P_RPTMONTH
   AND INDEXINST.INDEX_CODE = 'Engy_csmp_amt_stadc'
AND INDEXINSTDIMEN.DIM_CODE IN ('Heav_oil_prod_link', 'Rar_oil_prod_link', 'Gas_produ_link')
AND RR.REPORT_CODE='T0009' 
)
 ,L15_ds15_1  as (
 SELECT
       INDEXINST.INDEX_CODE,
      NVL(SUM(indexinst.index_value)  ,0) INDEX_VALUE
      
  FROM E7_STA_REPINST R
  LEFT JOIN E7_STA_REPORT RR ON RR.REPORT_CODE = R.REPORT_CODE
  LEFT JOIN E7_STA_RPT_INDEX_INST RPTINDEX ON R.REPINST_ID = RPTINDEX.REPINST_ID
  LEFT JOIN E7_STA_INDEX_INST INDEXINST ON RPTINDEX.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
  LEFT JOIN E7_STA_INDEX_INST_DIMEN INDEXINSTDIMEN ON INDEXINSTDIMEN.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
 WHERE RR.REPORT_CODE IN ('T0009', 'T0008', 'T0010')
  AND R.ORG_ID = P_RPTORGID
 AND R.REPORT_YEAR = P_RPTYEAR
 AND R.REPORT_MONTH=P_RPTMONTH
   AND INDEXINST.INDEX_CODE IN('Engy_csmp_amt_pratl', 'Engy_csmp_amt_stadc')
  AND  INDEXINST.COMPOSITED_INDEX_CODE ='Machine_adopts' 
 AND (INDEXINSTDIMEN.DIM_DETAIL_CODE ='Etp_exter_pur_qua_E' OR INDEXINSTDIMEN.DIM_DETAIL_CODE ='Etp_pur_quaity_E')
 GROUP BY INDEXINST.INDEX_CODE
  ), 
   L15_ds15_2  as (
 SELECT
       INDEXINST.INDEX_CODE,
       NVL(SUM(indexinst.index_value)  ,0) INDEX_VALUE
      
  FROM E7_STA_REPINST R
  LEFT JOIN E7_STA_REPORT RR ON RR.REPORT_CODE = R.REPORT_CODE
  LEFT JOIN E7_STA_RPT_INDEX_INST RPTINDEX ON R.REPINST_ID = RPTINDEX.REPINST_ID
  LEFT JOIN E7_STA_INDEX_INST INDEXINST ON RPTINDEX.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
  LEFT JOIN E7_STA_INDEX_INST_DIMEN INDEXINSTDIMEN ON INDEXINSTDIMEN.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
 WHERE RR.REPORT_CODE IN ('T0009', 'T0008', 'T0010')
  AND R.ORG_ID = P_RPTORGID
 AND R.REPORT_YEAR = P_RPTYEAR
 AND R.REPORT_MONTH=P_RPTMONTH
   AND INDEXINST.INDEX_CODE IN('Engy_csmp_amt_pratl', 'Engy_csmp_amt_stadc')
  AND  INDEXINST.COMPOSITED_INDEX_CODE ='Machine_adopts' 
 AND (INDEXINSTDIMEN.DIM_DETAIL_CODE ='Etp_exter_for_out_E' OR INDEXINSTDIMEN.DIM_DETAIL_CODE ='Busi_etp_in_out_E')
 GROUP BY INDEXINST.INDEX_CODE
  )
  ,L16_ds15 as (
  SELECT RR.REPORT_CODE,R.REPORT_MONTH,
       INDEXINST.STA_INDEX_INST_ID,
       INDEXINST.INDEX_CODE,
       INDEXINST.INDEX_VALUE,
       INDEXINST.UNIT_CODE,
       INDEXINST.COMPOSITED_INDEX_CODE,
       INDEXINSTDIMEN.REPINST_DTL_DIMEN,
       INDEXINSTDIMEN.DIM_CODE,
       INDEXINSTDIMEN.DIM_DETAIL_CODE,
       INDEXINSTDIMEN.UNIT_CODE AS DIMENUNITCODE,
       INDEXINST.INDEX_INST_ORDERNO,
       INDEXINSTDIMEN.COMPOSITE_DIM_CODE
  FROM E7_STA_REPINST R
  LEFT JOIN E7_STA_REPORT RR ON RR.REPORT_CODE = R.REPORT_CODE
  LEFT JOIN E7_STA_RPT_INDEX_INST RPTINDEX ON R.REPINST_ID = RPTINDEX.REPINST_ID
  LEFT JOIN E7_STA_INDEX_INST INDEXINST ON RPTINDEX.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
  LEFT JOIN E7_STA_INDEX_INST_DIMEN INDEXINSTDIMEN ON INDEXINSTDIMEN.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
 WHERE RR.REPORT_CODE IN ('T0009', 'T0008', 'T0010')
   AND R.ORG_ID = P_RPTORGID
 AND R.REPORT_YEAR = P_RPTYEAR
 AND R.REPORT_MONTH=P_RPTMONTH
   AND INDEXINST.INDEX_CODE IN('Engy_csmp_amt_pratl', 'Engy_csmp_amt_stadc')
   AND INDEXINST.INDEX_CODE='Engy_csmp_amt_stadc' 
   AND INDEXINST.COMPOSITED_INDEX_CODE = 'Gathering_transp' 
   AND INDEXINSTDIMEN.DIM_DETAIL_CODE = 'Gathering_transp'
  )
  ,L17_ds15_1 as (
    SELECT 
   --R.REPORT_MONTH,
      -- INDEXINST.STA_INDEX_INST_ID,
      INDEXINST.INDEX_CODE,
       NVL(SUM(indexinst.index_value)  ,0) INDEX_VALUE
      -- INDEXINST.UNIT_CODE,
      -- INDEXINST.COMPOSITED_INDEX_CODE,
    --   INDEXINSTDIMEN.REPINST_DTL_DIMEN,
    --   INDEXINSTDIMEN.DIM_CODE,
    --   INDEXINSTDIMEN.DIM_DETAIL_CODE,
    --   INDEXINSTDIMEN.UNIT_CODE AS DIMENUNITCODE,
   --    INDEXINST.INDEX_INST_ORDERNO,
    --   INDEXINSTDIMEN.COMPOSITE_DIM_CODE
  FROM E7_STA_REPINST R
  LEFT JOIN E7_STA_REPORT RR ON RR.REPORT_CODE = R.REPORT_CODE
  LEFT JOIN E7_STA_RPT_INDEX_INST RPTINDEX ON R.REPINST_ID = RPTINDEX.REPINST_ID
  LEFT JOIN E7_STA_INDEX_INST INDEXINST ON RPTINDEX.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
  LEFT JOIN E7_STA_INDEX_INST_DIMEN INDEXINSTDIMEN ON INDEXINSTDIMEN.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
 WHERE RR.REPORT_CODE IN ('T0009', 'T0008', 'T0010')
  AND R.ORG_ID = P_RPTORGID
 AND R.REPORT_YEAR = P_RPTYEAR
 AND R.REPORT_MONTH=P_RPTMONTH
   AND INDEXINST.INDEX_CODE IN('Engy_csmp_amt_pratl', 'Engy_csmp_amt_stadc')
   AND  RR.REPORT_CODE!='T0010'
   AND  INDEXINST.INDEX_CODE='Engy_csmp_amt_pratl' 
   AND 
   (    INDEXINSTDIMEN.DIM_DETAIL_CODE='Etp_exter_pur_qua_E' 
    OR  INDEXINSTDIMEN.DIM_DETAIL_CODE='Etp_pur_quaity_E'  )
    GROUP BY INDEXINST.INDEX_CODE
  )
  ,
 L17_ds15_2 as (
      SELECT 
   --R.REPORT_MONTH,
      -- INDEXINST.STA_INDEX_INST_ID,
      INDEXINST.INDEX_CODE,
       NVL(SUM(indexinst.index_value)  ,0) INDEX_VALUE
      -- INDEXINST.UNIT_CODE,
      -- INDEXINST.COMPOSITED_INDEX_CODE,
    --   INDEXINSTDIMEN.REPINST_DTL_DIMEN,
    --   INDEXINSTDIMEN.DIM_CODE,
    --   INDEXINSTDIMEN.DIM_DETAIL_CODE,
    --   INDEXINSTDIMEN.UNIT_CODE AS DIMENUNITCODE,
   --    INDEXINST.INDEX_INST_ORDERNO,
    --   INDEXINSTDIMEN.COMPOSITE_DIM_CODE
  FROM E7_STA_REPINST R
  LEFT JOIN E7_STA_REPORT RR ON RR.REPORT_CODE = R.REPORT_CODE
  LEFT JOIN E7_STA_RPT_INDEX_INST RPTINDEX ON R.REPINST_ID = RPTINDEX.REPINST_ID
  LEFT JOIN E7_STA_INDEX_INST INDEXINST ON RPTINDEX.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
  LEFT JOIN E7_STA_INDEX_INST_DIMEN INDEXINSTDIMEN ON INDEXINSTDIMEN.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
 WHERE RR.REPORT_CODE IN ('T0009', 'T0008', 'T0010')
    AND R.ORG_ID = P_RPTORGID
 AND R.REPORT_YEAR = P_RPTYEAR
 AND R.REPORT_MONTH=P_RPTMONTH
   AND INDEXINST.INDEX_CODE IN('Engy_csmp_amt_pratl', 'Engy_csmp_amt_stadc')
   AND  RR.REPORT_CODE!='T0010'
   AND  INDEXINST.INDEX_CODE='Engy_csmp_amt_pratl' 
   AND 
   (    INDEXINSTDIMEN.DIM_DETAIL_CODE='Etp_exter_for_out_E' 
    OR  INDEXINSTDIMEN.DIM_DETAIL_CODE='Busi_etp_in_out_E'  )
    GROUP BY INDEXINST.INDEX_CODE
  )
  
   ,L18_ds15_1 as (
 SELECT MAX(RR.REPORT_CODE) REPORT_CODE,
   --R.REPORT_MONTH,
      -- INDEXINST.STA_INDEX_INST_ID,
      INDEXINST.INDEX_CODE,
       NVL(SUM(indexinst.index_value)  ,0) INDEX_VALUE
      -- INDEXINST.UNIT_CODE,
      -- INDEXINST.COMPOSITED_INDEX_CODE,
    --   INDEXINSTDIMEN.REPINST_DTL_DIMEN,
    --   INDEXINSTDIMEN.DIM_CODE,
    --   INDEXINSTDIMEN.DIM_DETAIL_CODE,
    --   INDEXINSTDIMEN.UNIT_CODE AS DIMENUNITCODE,
   --    INDEXINST.INDEX_INST_ORDERNO,
    --   INDEXINSTDIMEN.COMPOSITE_DIM_CODE
  FROM E7_STA_REPINST R
  LEFT JOIN E7_STA_REPORT RR ON RR.REPORT_CODE = R.REPORT_CODE
  LEFT JOIN E7_STA_RPT_INDEX_INST RPTINDEX ON R.REPINST_ID = RPTINDEX.REPINST_ID
  LEFT JOIN E7_STA_INDEX_INST INDEXINST ON RPTINDEX.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
  LEFT JOIN E7_STA_INDEX_INST_DIMEN INDEXINSTDIMEN ON INDEXINSTDIMEN.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
 WHERE RR.REPORT_CODE IN ('T0009', 'T0008', 'T0010')
  AND R.ORG_ID = P_RPTORGID
 AND R.REPORT_YEAR = P_RPTYEAR
 AND R.REPORT_MONTH=P_RPTMONTH
   AND INDEXINST.INDEX_CODE IN('Engy_csmp_amt_pratl', 'Engy_csmp_amt_stadc')
   AND INDEXINST.COMPOSITED_INDEX_CODE ='Injection_water' 
   AND (INDEXINSTDIMEN.DIM_DETAIL_CODE='Etp_exter_pur_qua_E' 
     OR INDEXINSTDIMEN.DIM_DETAIL_CODE='Etp_pur_quaity_E') 
      GROUP BY INDEXINST.INDEX_CODE
 )

 ,
   L18_ds15_2 as (
 SELECT MAX(RR.REPORT_CODE) REPORT_CODE,
   --R.REPORT_MONTH,
      -- INDEXINST.STA_INDEX_INST_ID,
      INDEXINST.INDEX_CODE,
       NVL(SUM(indexinst.index_value)  ,0) INDEX_VALUE
      -- INDEXINST.UNIT_CODE,
      -- INDEXINST.COMPOSITED_INDEX_CODE,
    --   INDEXINSTDIMEN.REPINST_DTL_DIMEN,
    --   INDEXINSTDIMEN.DIM_CODE,
    --   INDEXINSTDIMEN.DIM_DETAIL_CODE,
    --   INDEXINSTDIMEN.UNIT_CODE AS DIMENUNITCODE,
   --    INDEXINST.INDEX_INST_ORDERNO,
    --   INDEXINSTDIMEN.COMPOSITE_DIM_CODE
  FROM E7_STA_REPINST R
  LEFT JOIN E7_STA_REPORT RR ON RR.REPORT_CODE = R.REPORT_CODE
  LEFT JOIN E7_STA_RPT_INDEX_INST RPTINDEX ON R.REPINST_ID = RPTINDEX.REPINST_ID
  LEFT JOIN E7_STA_INDEX_INST INDEXINST ON RPTINDEX.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
  LEFT JOIN E7_STA_INDEX_INST_DIMEN INDEXINSTDIMEN ON INDEXINSTDIMEN.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
 WHERE RR.REPORT_CODE IN ('T0009', 'T0008', 'T0010')
  AND R.ORG_ID = P_RPTORGID
 AND R.REPORT_YEAR = P_RPTYEAR
 AND R.REPORT_MONTH=P_RPTMONTH
   AND INDEXINST.INDEX_CODE IN('Engy_csmp_amt_pratl', 'Engy_csmp_amt_stadc')
   AND INDEXINST.COMPOSITED_INDEX_CODE ='Injection_water' 
   AND (INDEXINSTDIMEN.DIM_DETAIL_CODE='Etp_exter_for_out_E' 
     OR INDEXINSTDIMEN.DIM_DETAIL_CODE='Busi_etp_in_out_E')
     GROUP BY INDEXINST.INDEX_CODE
 )
 ,L19_ds13 as (
SELECT RR.REPORT_CODE,R.REPORT_MONTH,
       INDEXINST.STA_INDEX_INST_ID,
       INDEXINST.INDEX_CODE,
       INDEXINST.INDEX_VALUE,
       INDEXINST.UNIT_CODE,
       INDEXINST.COMPOSITED_INDEX_CODE,
       INDEXINSTDIMEN.REPINST_DTL_DIMEN,
       INDEXINSTDIMEN.DIM_CODE,
       INDEXINSTDIMEN.DIM_DETAIL_CODE,
       INDEXINSTDIMEN.UNIT_CODE AS DIMENUNITCODE,
       INDEXINST.INDEX_INST_ORDERNO,
       INDEXINSTDIMEN.COMPOSITE_DIM_CODE
  FROM E7_STA_REPINST R
  LEFT JOIN E7_STA_REPORT RR ON RR.REPORT_CODE = R.REPORT_CODE
  LEFT JOIN E7_STA_RPT_INDEX_INST RPTINDEX ON R.REPINST_ID = RPTINDEX.REPINST_ID
  LEFT JOIN E7_STA_INDEX_INST INDEXINST ON RPTINDEX.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
  LEFT JOIN E7_STA_INDEX_INST_DIMEN INDEXINSTDIMEN ON INDEXINSTDIMEN.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
 WHERE RR.REPORT_CODE IN ('T0009', 'T0008', 'T0010')
    AND R.ORG_ID = P_RPTORGID
 AND R.REPORT_YEAR = P_RPTYEAR
 AND R.REPORT_MONTH=P_RPTMONTH
   AND INDEXINST.INDEX_CODE = 'Engy_csmp_amt_stadc'
   AND INDEXINSTDIMEN.DIM_CODE IN ('Heav_oil_prod_link', 'Rar_oil_prod_link', 'Gas_produ_link')
   AND RR.REPORT_CODE ='T0010'
)
,L20_ds13 as (
  SELECT RR.REPORT_CODE,R.REPORT_MONTH,
       INDEXINST.STA_INDEX_INST_ID,
       INDEXINST.INDEX_CODE,
       INDEXINST.INDEX_VALUE,
       INDEXINST.UNIT_CODE,
       INDEXINST.COMPOSITED_INDEX_CODE,
       INDEXINSTDIMEN.REPINST_DTL_DIMEN,
       INDEXINSTDIMEN.DIM_CODE,
       INDEXINSTDIMEN.DIM_DETAIL_CODE,
       INDEXINSTDIMEN.UNIT_CODE AS DIMENUNITCODE,
       INDEXINST.INDEX_INST_ORDERNO,
       INDEXINSTDIMEN.COMPOSITE_DIM_CODE
  FROM E7_STA_REPINST R
  LEFT JOIN E7_STA_REPORT RR ON RR.REPORT_CODE = R.REPORT_CODE
  LEFT JOIN E7_STA_RPT_INDEX_INST RPTINDEX ON R.REPINST_ID = RPTINDEX.REPINST_ID
  LEFT JOIN E7_STA_INDEX_INST INDEXINST ON RPTINDEX.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
  LEFT JOIN E7_STA_INDEX_INST_DIMEN INDEXINSTDIMEN ON INDEXINSTDIMEN.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
 WHERE RR.REPORT_CODE IN ('T0009', 'T0008', 'T0010')
    AND R.ORG_ID = P_RPTORGID
 AND R.REPORT_YEAR = P_RPTYEAR
 AND R.REPORT_MONTH=P_RPTMONTH
   AND INDEXINST.INDEX_CODE = 'Engy_csmp_amt_stadc'
   AND INDEXINSTDIMEN.DIM_CODE IN ('Heav_oil_prod_link', 'Rar_oil_prod_link', 'Gas_produ_link')
   AND INDEXINSTDIMEN.DIM_DETAIL_CODE ='Collecting_input'
  )
  ,L21_ds13 as (
  SELECT RR.REPORT_CODE,R.REPORT_MONTH,
       INDEXINST.STA_INDEX_INST_ID,
       INDEXINST.INDEX_CODE,
       INDEXINST.INDEX_VALUE,
       INDEXINST.UNIT_CODE,
       INDEXINST.COMPOSITED_INDEX_CODE,
       INDEXINSTDIMEN.REPINST_DTL_DIMEN,
       INDEXINSTDIMEN.DIM_CODE,
       INDEXINSTDIMEN.DIM_DETAIL_CODE,
       INDEXINSTDIMEN.UNIT_CODE AS DIMENUNITCODE,
       INDEXINST.INDEX_INST_ORDERNO,
       INDEXINSTDIMEN.COMPOSITE_DIM_CODE
  FROM E7_STA_REPINST R
  LEFT JOIN E7_STA_REPORT RR ON RR.REPORT_CODE = R.REPORT_CODE
  LEFT JOIN E7_STA_RPT_INDEX_INST RPTINDEX ON R.REPINST_ID = RPTINDEX.REPINST_ID
  LEFT JOIN E7_STA_INDEX_INST INDEXINST ON RPTINDEX.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
  LEFT JOIN E7_STA_INDEX_INST_DIMEN INDEXINSTDIMEN ON INDEXINSTDIMEN.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
 WHERE RR.REPORT_CODE IN ('T0009', 'T0008', 'T0010')
   AND R.ORG_ID = P_RPTORGID
 AND R.REPORT_YEAR = P_RPTYEAR
 AND R.REPORT_MONTH=P_RPTMONTH
   AND INDEXINST.INDEX_CODE = 'Engy_csmp_amt_stadc'
   AND INDEXINSTDIMEN.DIM_CODE IN ('Heav_oil_prod_link', 'Rar_oil_prod_link', 'Gas_produ_link')
   AND INDEXINSTDIMEN.DIM_DETAIL_CODE ='Natural_gas_proc'
  )
  , L22_ds13 as (
  SELECT RR.REPORT_CODE,R.REPORT_MONTH,
       INDEXINST.STA_INDEX_INST_ID,
       INDEXINST.INDEX_CODE,
       INDEXINST.INDEX_VALUE,
       INDEXINST.UNIT_CODE,
       INDEXINST.COMPOSITED_INDEX_CODE,
       INDEXINSTDIMEN.REPINST_DTL_DIMEN,
       INDEXINSTDIMEN.DIM_CODE,
       INDEXINSTDIMEN.DIM_DETAIL_CODE,
       INDEXINSTDIMEN.UNIT_CODE AS DIMENUNITCODE,
       INDEXINST.INDEX_INST_ORDERNO,
       INDEXINSTDIMEN.COMPOSITE_DIM_CODE
  FROM E7_STA_REPINST R
  LEFT JOIN E7_STA_REPORT RR ON RR.REPORT_CODE = R.REPORT_CODE
  LEFT JOIN E7_STA_RPT_INDEX_INST RPTINDEX ON R.REPINST_ID = RPTINDEX.REPINST_ID
  LEFT JOIN E7_STA_INDEX_INST INDEXINST ON RPTINDEX.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
  LEFT JOIN E7_STA_INDEX_INST_DIMEN INDEXINSTDIMEN ON INDEXINSTDIMEN.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
 WHERE RR.REPORT_CODE IN ('T0009', 'T0008', 'T0010')
   AND R.ORG_ID = P_RPTORGID
 AND R.REPORT_YEAR = P_RPTYEAR
 AND R.REPORT_MONTH=P_RPTMONTH
   AND INDEXINST.INDEX_CODE = 'Engy_csmp_amt_stadc'
   AND INDEXINSTDIMEN.DIM_CODE IN ('Heav_oil_prod_link', 'Rar_oil_prod_link', 'Gas_produ_link')
  )
  ,L23_ds13 as (
  SELECT RR.REPORT_CODE,R.REPORT_MONTH,
       INDEXINST.STA_INDEX_INST_ID,
       INDEXINST.INDEX_CODE,
       INDEXINST.INDEX_VALUE,
       INDEXINST.UNIT_CODE,
       INDEXINST.COMPOSITED_INDEX_CODE,
       INDEXINSTDIMEN.REPINST_DTL_DIMEN,
       INDEXINSTDIMEN.DIM_CODE,
       INDEXINSTDIMEN.DIM_DETAIL_CODE,
       INDEXINSTDIMEN.UNIT_CODE AS DIMENUNITCODE,
       INDEXINST.INDEX_INST_ORDERNO,
       INDEXINSTDIMEN.COMPOSITE_DIM_CODE
  FROM E7_STA_REPINST R
  LEFT JOIN E7_STA_REPORT RR ON RR.REPORT_CODE = R.REPORT_CODE
  LEFT JOIN E7_STA_RPT_INDEX_INST RPTINDEX ON R.REPINST_ID = RPTINDEX.REPINST_ID
  LEFT JOIN E7_STA_INDEX_INST INDEXINST ON RPTINDEX.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
  LEFT JOIN E7_STA_INDEX_INST_DIMEN INDEXINSTDIMEN ON INDEXINSTDIMEN.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
 WHERE RR.REPORT_CODE IN ('T0009', 'T0008', 'T0010')
    AND R.ORG_ID = P_RPTORGID
 AND R.REPORT_YEAR = P_RPTYEAR
 AND R.REPORT_MONTH=P_RPTMONTH
   AND INDEXINST.INDEX_CODE = 'Engy_csmp_amt_stadc'
   AND INDEXINSTDIMEN.DIM_CODE IN ('Heav_oil_prod_link', 'Rar_oil_prod_link', 'Gas_produ_link')
   AND RR.REPORT_CODE IN ('T0009', 'T0008')
  )
   ,L24_ds13 as(
  SELECT RR.REPORT_CODE,R.REPORT_MONTH,
       INDEXINST.STA_INDEX_INST_ID,
       INDEXINST.INDEX_CODE,
       INDEXINST.INDEX_VALUE,
       INDEXINST.UNIT_CODE,
       INDEXINST.COMPOSITED_INDEX_CODE,
       INDEXINSTDIMEN.REPINST_DTL_DIMEN,
       INDEXINSTDIMEN.DIM_CODE,
       INDEXINSTDIMEN.DIM_DETAIL_CODE,
       INDEXINSTDIMEN.UNIT_CODE AS DIMENUNITCODE,
       INDEXINST.INDEX_INST_ORDERNO,
       INDEXINSTDIMEN.COMPOSITE_DIM_CODE
  FROM E7_STA_REPINST R
  LEFT JOIN E7_STA_REPORT RR ON RR.REPORT_CODE = R.REPORT_CODE
  LEFT JOIN E7_STA_RPT_INDEX_INST RPTINDEX ON R.REPINST_ID = RPTINDEX.REPINST_ID
  LEFT JOIN E7_STA_INDEX_INST INDEXINST ON RPTINDEX.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
  LEFT JOIN E7_STA_INDEX_INST_DIMEN INDEXINSTDIMEN ON INDEXINSTDIMEN.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
 WHERE RR.REPORT_CODE IN ('T0009', 'T0008', 'T0010')
    AND R.ORG_ID = P_RPTORGID
 AND R.REPORT_YEAR = P_RPTYEAR
 AND R.REPORT_MONTH=P_RPTMONTH
   AND INDEXINST.INDEX_CODE = 'Engy_csmp_amt_stadc'
   AND INDEXINSTDIMEN.DIM_CODE IN ('Heav_oil_prod_link', 'Rar_oil_prod_link', 'Gas_produ_link')
   AND RR.REPORT_CODE='T0010'
  )
  ,P7_ds19_1 as (
  SELECT 
  MAX(RR.REPORT_CODE) REPORT_CODE,
  MAX(R.REPORT_MONTH),
     MAX(INDEXINST.STA_INDEX_INST_ID),
       INDEXINST.INDEX_CODE,
     NVL(SUM(indexinst.index_value)  ,0) INDEX_VALUE,
       MAX(INDEXINST.UNIT_CODE),
        MAX(INDEXINST.COMPOSITED_INDEX_CODE),
        MAX(INDEXINSTDIMEN.REPINST_DTL_DIMEN),
        MAX(INDEXINSTDIMEN.DIM_CODE),
        MAX(INDEXINSTDIMEN.DIM_DETAIL_CODE),
        MAX(INDEXINSTDIMEN.UNIT_CODE) AS DIMENUNITCODE,
        MAX(INDEXINST.INDEX_INST_ORDERNO),
        MAX(INDEXINSTDIMEN.COMPOSITE_DIM_CODE)
  FROM E7_STA_REPINST R
  LEFT JOIN E7_STA_REPORT RR ON RR.REPORT_CODE = R.REPORT_CODE
  LEFT JOIN E7_STA_RPT_INDEX_INST RPTINDEX ON R.REPINST_ID = RPTINDEX.REPINST_ID
  LEFT JOIN E7_STA_INDEX_INST INDEXINST ON RPTINDEX.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
  LEFT JOIN E7_STA_INDEX_INST_DIMEN INDEXINSTDIMEN ON INDEXINSTDIMEN.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
 WHERE RR.REPORT_CODE IN ('T0001')
    AND R.ORG_ID = P_RPTORGID
 AND R.REPORT_YEAR = P_RPTYEAR
 AND R.REPORT_MONTH=P_RPTMONTH
   AND INDEXINST.INDEX_CODE='Co_prod'
   group by  INDEXINST.INDEX_CODE
  ),
  P7_ds19_2 as(
  SELECT  MAX(RR.REPORT_CODE) REPORT_CODE,
  MAX(R.REPORT_MONTH),
     MAX(INDEXINST.STA_INDEX_INST_ID),
       INDEXINST.INDEX_CODE,
      NVL(SUM(indexinst.index_value)  ,0) INDEX_VALUE,
       MAX(INDEXINST.UNIT_CODE),
        MAX(INDEXINST.COMPOSITED_INDEX_CODE),
        MAX(INDEXINSTDIMEN.REPINST_DTL_DIMEN),
        MAX(INDEXINSTDIMEN.DIM_CODE),
        MAX(INDEXINSTDIMEN.DIM_DETAIL_CODE),
        MAX(INDEXINSTDIMEN.UNIT_CODE) AS DIMENUNITCODE,
        MAX(INDEXINST.INDEX_INST_ORDERNO),
        MAX(INDEXINSTDIMEN.COMPOSITE_DIM_CODE)
  FROM E7_STA_REPINST R
  LEFT JOIN E7_STA_REPORT RR ON RR.REPORT_CODE = R.REPORT_CODE
  LEFT JOIN E7_STA_RPT_INDEX_INST RPTINDEX ON R.REPINST_ID = RPTINDEX.REPINST_ID
  LEFT JOIN E7_STA_INDEX_INST INDEXINST ON RPTINDEX.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
  LEFT JOIN E7_STA_INDEX_INST_DIMEN INDEXINSTDIMEN ON INDEXINSTDIMEN.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
 WHERE RR.REPORT_CODE IN ('T0001')
   AND R.ORG_ID = P_RPTORGID
 AND R.REPORT_YEAR = P_RPTYEAR
 AND R.REPORT_MONTH=P_RPTMONTH
   AND INDEXINST.INDEX_CODE='Ng_prod'
   group by  INDEXINST.INDEX_CODE
  )
   ,P8_ds19 as(
 SELECT RR.REPORT_CODE,R.REPORT_MONTH,
       INDEXINST.STA_INDEX_INST_ID,
       INDEXINST.INDEX_CODE,
      INDEXINST.INDEX_VALUE INDEX_VALUE,
       INDEXINST.UNIT_CODE,
       INDEXINST.COMPOSITED_INDEX_CODE,
       INDEXINSTDIMEN.REPINST_DTL_DIMEN,
       INDEXINSTDIMEN.DIM_CODE,
       INDEXINSTDIMEN.DIM_DETAIL_CODE,
       INDEXINSTDIMEN.UNIT_CODE AS DIMENUNITCODE,
       INDEXINST.INDEX_INST_ORDERNO,
       INDEXINSTDIMEN.COMPOSITE_DIM_CODE
  FROM E7_STA_REPINST R
  LEFT JOIN E7_STA_REPORT RR ON RR.REPORT_CODE = R.REPORT_CODE
  LEFT JOIN E7_STA_RPT_INDEX_INST RPTINDEX ON R.REPINST_ID = RPTINDEX.REPINST_ID
  LEFT JOIN E7_STA_INDEX_INST INDEXINST ON RPTINDEX.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
  LEFT JOIN E7_STA_INDEX_INST_DIMEN INDEXINSTDIMEN ON INDEXINSTDIMEN.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
 WHERE RR.REPORT_CODE IN ('T0001')
   AND R.ORG_ID = P_RPTORGID
 AND R.REPORT_YEAR = P_RPTYEAR
 AND R.REPORT_MONTH=P_RPTMONTH
   AND INDEXINST.INDEX_CODE='Watr_prod'
 )
  ,P9_ds19_1 as (
  SELECT 
MAX(RR.REPORT_CODE) REPORT_CODE,
--R.REPORT_MONTH,
      -- INDEXINST.STA_INDEX_INST_ID,
       INDEXINST.INDEX_CODE,
       NVL(SUM(indexinst.index_value)  ,0) INDEX_VALUE
      -- INDEXINST.UNIT_CODE,
      -- INDEXINST.COMPOSITED_INDEX_CODE,
      -- INDEXINSTDIMEN.REPINST_DTL_DIMEN,
     --  INDEXINSTDIMEN.DIM_CODE,
     --  INDEXINSTDIMEN.DIM_DETAIL_CODE,
     --  INDEXINSTDIMEN.UNIT_CODE AS DIMENUNITCODE,
    --   INDEXINST.INDEX_INST_ORDERNO,
    --   INDEXINSTDIMEN.COMPOSITE_DIM_CODE
  FROM E7_STA_REPINST R
  LEFT JOIN E7_STA_REPORT RR ON RR.REPORT_CODE = R.REPORT_CODE
  LEFT JOIN E7_STA_RPT_INDEX_INST RPTINDEX ON R.REPINST_ID = RPTINDEX.REPINST_ID
  LEFT JOIN E7_STA_INDEX_INST INDEXINST ON RPTINDEX.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
  LEFT JOIN E7_STA_INDEX_INST_DIMEN INDEXINSTDIMEN ON INDEXINSTDIMEN.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
 WHERE RR.REPORT_CODE IN ('T0001')
   AND R.ORG_ID = P_RPTORGID
   AND R.REPORT_YEAR = P_RPTYEAR
   AND R.REPORT_MONTH= P_RPTMONTH
   AND INDEXINST.INDEX_CODE='Co_prod' 
   GROUP BY INDEXINST.INDEX_CODE
  ),
     P9_ds19_2 as (
SELECT 
MAX(RR.REPORT_CODE) REPORT_CODE,
--R.REPORT_MONTH,
      -- INDEXINST.STA_INDEX_INST_ID,
       INDEXINST.INDEX_CODE,
       NVL(SUM(indexinst.index_value)  ,0) INDEX_VALUE
      -- INDEXINST.UNIT_CODE,
      -- INDEXINST.COMPOSITED_INDEX_CODE,
      -- INDEXINSTDIMEN.REPINST_DTL_DIMEN,
     --  INDEXINSTDIMEN.DIM_CODE,
     --  INDEXINSTDIMEN.DIM_DETAIL_CODE,
     --  INDEXINSTDIMEN.UNIT_CODE AS DIMENUNITCODE,
    --   INDEXINST.INDEX_INST_ORDERNO,
    --   INDEXINSTDIMEN.COMPOSITE_DIM_CODE
  FROM E7_STA_REPINST R
  LEFT JOIN E7_STA_REPORT RR ON RR.REPORT_CODE = R.REPORT_CODE
  LEFT JOIN E7_STA_RPT_INDEX_INST RPTINDEX ON R.REPINST_ID = RPTINDEX.REPINST_ID
  LEFT JOIN E7_STA_INDEX_INST INDEXINST ON RPTINDEX.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
  LEFT JOIN E7_STA_INDEX_INST_DIMEN INDEXINSTDIMEN ON INDEXINSTDIMEN.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
 WHERE RR.REPORT_CODE IN ('T0001')
   AND R.ORG_ID = P_RPTORGID
   AND R.REPORT_YEAR = P_RPTYEAR
   AND R.REPORT_MONTH= P_RPTMONTH
   AND INDEXINST.INDEX_CODE='Ng_prod' 
   AND INDEXINSTDIMEN.DIM_DETAIL_CODE= 'Associated_gas'
   GROUP BY INDEXINST.INDEX_CODE
  )
  ,P10_ds21_1 as (
SELECT 
       MAX(r.report_code) REPORT_CODE   
      ,indexinst.index_code --指标代码
      ,NVL(SUM(indexinst.index_value)  ,0) INDEX_VALUE --指标值
--, indexinstdimen.DIM_CODE
   --   , indexinstdimen.DIM_DETAIL_CODE

  FROM e7_sta_repinst r
  LEFT JOIN e7_sta_rpt_index_inst rptindex
    ON r.repinst_id = rptindex.repinst_id
  LEFT JOIN e7_sta_index_inst indexinst
    ON rptindex.sta_index_inst_id = indexinst.sta_index_inst_id
  LEFT JOIN e7_sta_index_inst_dimen indexinstdimen
    ON indexinstdimen.sta_index_inst_id = indexinst.sta_index_inst_id
  LEFT JOIN e7_sta_rpt_auth SRA
  ON SRA.ORG_ID = R.ORG_ID
  AND SRA.REPORT_CODE = R.REPORT_CODE
  AND SRA.REPORT_CODE in ('C0001','C0006')
   AND SRA.V_ORG_ID = P_RPTORGID
 WHERE 
   SRA.V_ORG_ID = P_RPTORGID
   AND r.report_year = P_RPTYEAR
   AND r.report_month = P_RPTMONTH
   AND indexinst.index_code='Co_prod' 
   AND r.report_code  = 'C0006'
   GROUP BY indexinst.index_code
  ),
   P10_ds21_2 as(
   SELECT 
         MAX(r.report_code) REPORT_CODE  
      ,indexinst.index_code --指标代码
      ,NVL(SUM(indexinst.index_value)  ,0) INDEX_VALUE --指标值
--, indexinstdimen.DIM_CODE
   --   , indexinstdimen.DIM_DETAIL_CODE

  FROM e7_sta_repinst r
  LEFT JOIN e7_sta_rpt_index_inst rptindex
    ON r.repinst_id = rptindex.repinst_id
  LEFT JOIN e7_sta_index_inst indexinst
    ON rptindex.sta_index_inst_id = indexinst.sta_index_inst_id
  LEFT JOIN e7_sta_index_inst_dimen indexinstdimen
    ON indexinstdimen.sta_index_inst_id = indexinst.sta_index_inst_id
  LEFT JOIN e7_sta_rpt_auth SRA
  ON SRA.ORG_ID = R.ORG_ID
  AND SRA.REPORT_CODE = R.REPORT_CODE
  AND SRA.REPORT_CODE in ('C0001','C0006')
  AND SRA.V_ORG_ID = P_RPTORGID
 WHERE 
   SRA.V_ORG_ID = P_RPTORGID
   AND r.report_year = P_RPTYEAR
   AND r.report_month = P_RPTMONTH
   AND indexinst.index_code='Ng_prod' 
   AND r.report_code  = 'C0006'
   AND indexinstdimen.DIM_DETAIL_CODE = 'Associated_gas'
  GROUP BY indexinst.index_code
   )
   ,P11_ds21_1 as (
  SELECT 
       MAX(r.report_code) REPORT_CODE   
      ,indexinst.index_code --指标代码
      ,NVL(SUM(indexinst.index_value)  ,0) INDEX_VALUE --指标值
--, indexinstdimen.DIM_CODE
   --   , indexinstdimen.DIM_DETAIL_CODE

  FROM e7_sta_repinst r
  LEFT JOIN e7_sta_rpt_index_inst rptindex
    ON r.repinst_id = rptindex.repinst_id
  LEFT JOIN e7_sta_index_inst indexinst
    ON rptindex.sta_index_inst_id = indexinst.sta_index_inst_id
  LEFT JOIN e7_sta_index_inst_dimen indexinstdimen
    ON indexinstdimen.sta_index_inst_id = indexinst.sta_index_inst_id
  LEFT JOIN e7_sta_rpt_auth SRA
  ON SRA.ORG_ID = R.ORG_ID
  AND SRA.REPORT_CODE = R.REPORT_CODE
  AND SRA.REPORT_CODE in ('C0001','C0006')
 AND SRA.V_ORG_ID = P_RPTORGID
 WHERE 
   SRA.V_ORG_ID = P_RPTORGID
   AND r.report_year = P_RPTYEAR
   AND r.report_month = P_RPTMONTH
   AND indexinst.index_code='Co_prod' 
   AND r.report_code  ='C0001'
   GROUP BY INDEXINST.INDEX_CODE
  ),
  P11_ds21_2 as(
  SELECT 
         MAX(r.report_code) REPORT_CODE   
      ,indexinst.index_code --指标代码
      ,NVL(SUM(indexinst.index_value)  ,0) INDEX_VALUE  --指标值
--, indexinstdimen.DIM_CODE
   --   , indexinstdimen.DIM_DETAIL_CODE


  FROM e7_sta_repinst r
  LEFT JOIN e7_sta_rpt_index_inst rptindex
    ON r.repinst_id = rptindex.repinst_id
  LEFT JOIN e7_sta_index_inst indexinst
    ON rptindex.sta_index_inst_id = indexinst.sta_index_inst_id
  LEFT JOIN e7_sta_index_inst_dimen indexinstdimen
    ON indexinstdimen.sta_index_inst_id = indexinst.sta_index_inst_id
  LEFT JOIN e7_sta_rpt_auth SRA
  ON SRA.ORG_ID = R.ORG_ID
  AND SRA.REPORT_CODE = R.REPORT_CODE
  AND SRA.REPORT_CODE in ('C0001','C0006')
  AND SRA.V_ORG_ID = P_RPTORGID
 WHERE 
   SRA.V_ORG_ID = P_RPTORGID
   AND r.report_year = P_RPTYEAR
   AND r.report_month = P_RPTMONTH
   AND indexinst.index_code='Ng_prod' 
   AND r.report_code  ='C0001'
   AND indexinstdimen.DIM_DETAIL_CODE= 'Associated_gas' 
   GROUP BY INDEXINST.INDEX_CODE
  )
  ,P13_ds21_1 as (
  SELECT 
       MAX(r.report_code)  REPORT_CODE
      ,indexinst.index_code --指标代码
      ,NVL(SUM(indexinst.index_value)  ,0) INDEX_VALUE --指标值


  FROM e7_sta_repinst r
  LEFT JOIN e7_sta_rpt_index_inst rptindex
    ON r.repinst_id = rptindex.repinst_id
  LEFT JOIN e7_sta_index_inst indexinst
    ON rptindex.sta_index_inst_id = indexinst.sta_index_inst_id
  LEFT JOIN e7_sta_index_inst_dimen indexinstdimen
    ON indexinstdimen.sta_index_inst_id = indexinst.sta_index_inst_id
  LEFT JOIN e7_sta_rpt_auth SRA
  ON SRA.ORG_ID = R.ORG_ID
  AND SRA.REPORT_CODE = R.REPORT_CODE
  AND SRA.REPORT_CODE in ('C0001','C0006')
  AND SRA.V_ORG_ID = P_RPTORGID
 WHERE 
   SRA.V_ORG_ID = P_RPTORGID
   AND r.report_year = P_RPTYEAR
   AND r.report_month = P_RPTMONTH
 AND indexinst.index_code='Watr_prod' 
 AND  r.report_code   ='C0006'
 GROUP BY INDEXINST.INDEX_CODE
  ),
  P13_ds21_2 as (
  SELECT 
       MAX(r.report_code)  REPORT_CODE 
      ,indexinst.index_code --指标代码
      ,NVL(SUM(indexinst.index_value)  ,0) INDEX_VALUE --指标值


  FROM e7_sta_repinst r 
  LEFT JOIN e7_sta_rpt_index_inst rptindex
    ON r.repinst_id = rptindex.repinst_id
  LEFT JOIN e7_sta_index_inst indexinst
    ON rptindex.sta_index_inst_id = indexinst.sta_index_inst_id
  LEFT JOIN e7_sta_index_inst_dimen indexinstdimen
    ON indexinstdimen.sta_index_inst_id = indexinst.sta_index_inst_id
  LEFT JOIN e7_sta_rpt_auth SRA
  ON SRA.ORG_ID = R.ORG_ID
  AND SRA.REPORT_CODE = R.REPORT_CODE
  AND SRA.REPORT_CODE in ('C0001','C0006')
  AND SRA.V_ORG_ID = P_RPTORGID
 WHERE 
   SRA.V_ORG_ID = P_RPTORGID
   AND r.report_year = P_RPTYEAR
   AND r.report_month = P_RPTMONTH
 AND indexinst.index_code='Co_prod' 
 AND  r.report_code   ='C0006'
 GROUP BY INDEXINST.INDEX_CODE
  ), 
    P13_ds21_3 as (
  SELECT 
       MAX(r.report_code)   REPORT_CODE
      ,indexinst.index_code --指标代码
      ,NVL(SUM(indexinst.index_value)  ,0) INDEX_VALUE --指标值


  FROM e7_sta_repinst r
  LEFT JOIN e7_sta_rpt_index_inst rptindex
    ON r.repinst_id = rptindex.repinst_id
  LEFT JOIN e7_sta_index_inst indexinst
    ON rptindex.sta_index_inst_id = indexinst.sta_index_inst_id
  LEFT JOIN e7_sta_index_inst_dimen indexinstdimen
    ON indexinstdimen.sta_index_inst_id = indexinst.sta_index_inst_id
  LEFT JOIN e7_sta_rpt_auth SRA
  ON SRA.ORG_ID = R.ORG_ID
  AND SRA.REPORT_CODE = R.REPORT_CODE
  AND SRA.REPORT_CODE in ('C0001','C0006')
  AND SRA.V_ORG_ID = P_RPTORGID
 WHERE 
   SRA.V_ORG_ID = P_RPTORGID
   AND r.report_year = P_RPTYEAR
   AND r.report_month = P_RPTMONTH
 AND indexinst.index_code='Ng_prod' 
 AND  r.report_code   ='C0006'
 GROUP BY INDEXINST.INDEX_CODE
  )
   ,P14_ds21_1 as (
  SELECT 
       MAX(r.report_code) REPORT_CODE   
      ,indexinst.index_code --指标代码
      ,NVL(SUM(indexinst.index_value)  ,0) INDEX_VALUE--指标值
--, indexinstdimen.DIM_CODE
     -- , indexinstdimen.DIM_DETAIL_CODE

  FROM e7_sta_repinst r
  LEFT JOIN e7_sta_rpt_index_inst rptindex
    ON r.repinst_id = rptindex.repinst_id
  LEFT JOIN e7_sta_index_inst indexinst
    ON rptindex.sta_index_inst_id = indexinst.sta_index_inst_id
  LEFT JOIN e7_sta_index_inst_dimen indexinstdimen
    ON indexinstdimen.sta_index_inst_id = indexinst.sta_index_inst_id
  LEFT JOIN e7_sta_rpt_auth SRA
  ON SRA.ORG_ID = R.ORG_ID
  AND SRA.REPORT_CODE = R.REPORT_CODE
  AND SRA.REPORT_CODE in ('C0001','C0006')
   AND SRA.V_ORG_ID = P_RPTORGID
 WHERE 
   SRA.V_ORG_ID = P_RPTORGID
   AND r.report_year = P_RPTYEAR
   AND r.report_month = P_RPTMONTH
 AND indexinst.index_code='Watr_prod' 
 AND  r.report_code   ='C0001'
 GROUP BY INDEXINST.INDEX_CODE
  ),
  P14_ds21_2 as (
  SELECT 
             MAX(r.report_code) REPORT_CODE   
      ,indexinst.index_code --指标代码
      ,NVL(SUM(indexinst.index_value)  ,0) INDEX_VALUE --指标值
--, indexinstdimen.DIM_CODE
     -- , indexinstdimen.DIM_DETAIL_CODE

  FROM e7_sta_repinst r
  LEFT JOIN e7_sta_rpt_index_inst rptindex
    ON r.repinst_id = rptindex.repinst_id
  LEFT JOIN e7_sta_index_inst indexinst
    ON rptindex.sta_index_inst_id = indexinst.sta_index_inst_id
  LEFT JOIN e7_sta_index_inst_dimen indexinstdimen
    ON indexinstdimen.sta_index_inst_id = indexinst.sta_index_inst_id
  LEFT JOIN e7_sta_rpt_auth SRA
  ON SRA.ORG_ID = R.ORG_ID
  AND SRA.REPORT_CODE = R.REPORT_CODE
  AND SRA.REPORT_CODE in ('C0001','C0006')
  AND SRA.V_ORG_ID = P_RPTORGID
 WHERE 
   SRA.V_ORG_ID = P_RPTORGID
   AND r.report_year = P_RPTYEAR
   AND r.report_month = P_RPTMONTH
 AND indexinst.index_code='Co_prod' 
 AND  r.report_code   ='C0001'
 GROUP BY INDEXINST.INDEX_CODE
  ),
    P14_ds21_3 as (
    SELECT
        MAX(r.report_code) REPORT_CODE, 
      indexinst.index_code, --指标代码
      NVL(SUM(indexinst.index_value)  ,0) INDEX_VALUE --指标值
--, indexinstdimen.DIM_CODE
     -- , indexinstdimen.DIM_DETAIL_CODE

  FROM e7_sta_repinst r
  LEFT JOIN e7_sta_rpt_index_inst rptindex
    ON r.repinst_id = rptindex.repinst_id
  LEFT JOIN e7_sta_index_inst indexinst
    ON rptindex.sta_index_inst_id = indexinst.sta_index_inst_id
  LEFT JOIN e7_sta_index_inst_dimen indexinstdimen
    ON indexinstdimen.sta_index_inst_id = indexinst.sta_index_inst_id
  LEFT JOIN e7_sta_rpt_auth SRA
  ON SRA.ORG_ID = R.ORG_ID
  AND SRA.REPORT_CODE = R.REPORT_CODE
  AND SRA.REPORT_CODE in ('C0001','C0006')
 AND SRA.V_ORG_ID = P_RPTORGID
 WHERE 
   SRA.V_ORG_ID = P_RPTORGID
   AND r.report_year = P_RPTYEAR
   AND r.report_month = P_RPTMONTH
 AND indexinst.index_code='Ng_prod' 
 AND  r.report_code   ='C0001'
 GROUP BY INDEXINST.INDEX_CODE
  )
  ,P16_ds21 as  (
 SELECT 
       r.report_code   
      ,indexinst.index_code --指标代码
      ,indexinst.index_value --指标值
, indexinstdimen.DIM_CODE
      , indexinstdimen.DIM_DETAIL_CODE

  FROM e7_sta_repinst r
  LEFT JOIN e7_sta_rpt_index_inst rptindex
    ON r.repinst_id = rptindex.repinst_id
  LEFT JOIN e7_sta_index_inst indexinst
    ON rptindex.sta_index_inst_id = indexinst.sta_index_inst_id
  LEFT JOIN e7_sta_index_inst_dimen indexinstdimen
    ON indexinstdimen.sta_index_inst_id = indexinst.sta_index_inst_id
  LEFT JOIN e7_sta_rpt_auth SRA
  ON SRA.ORG_ID = R.ORG_ID 
  AND SRA.REPORT_CODE = R.REPORT_CODE
  AND SRA.REPORT_CODE in ('C0001','C0006')
  AND SRA.V_ORG_ID = P_RPTORGID
 WHERE 
   SRA.V_ORG_ID = P_RPTORGID
   AND r.report_year = P_RPTYEAR
   AND r.report_month = P_RPTMONTH
   AND indexinst.index_code = 'liqd_transpt'
 )
 , P17_ds19_1 as (
  SELECT 
  MAX(RR.REPORT_CODE) REPORT_CODE,
  --R.REPORT_MONTH,
    --   INDEXINST.STA_INDEX_INST_ID,
       INDEXINST.INDEX_CODE,
      NVL(SUM(indexinst.index_value)  ,0) INDEX_VALUE
      --INDEXINST.UNIT_CODE,
      --INDEXINST.COMPOSITED_INDEX_CODE,
      -- INDEXINSTDIMEN.REPINST_DTL_DIMEN,
      -- INDEXINSTDIMEN.DIM_CODE,
      -- INDEXINSTDIMEN.DIM_DETAIL_CODE,
      -- INDEXINSTDIMEN.UNIT_CODE AS DIMENUNITCODE,
      -- INDEXINST.INDEX_INST_ORDERNO,
     --  INDEXINSTDIMEN.COMPOSITE_DIM_CODE
  FROM E7_STA_REPINST R
  LEFT JOIN E7_STA_REPORT RR ON RR.REPORT_CODE = R.REPORT_CODE
  LEFT JOIN E7_STA_RPT_INDEX_INST RPTINDEX ON R.REPINST_ID = RPTINDEX.REPINST_ID
  LEFT JOIN E7_STA_INDEX_INST INDEXINST ON RPTINDEX.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
  LEFT JOIN E7_STA_INDEX_INST_DIMEN INDEXINSTDIMEN ON INDEXINSTDIMEN.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
 WHERE RR.REPORT_CODE IN ('T0001')
   AND R.ORG_ID = P_RPTORGID
   AND R.REPORT_YEAR = P_RPTYEAR
   AND R.REPORT_MONTH=P_RPTMONTH
   AND INDEXINST.INDEX_CODE = 'Co_prod'
   GROUP BY INDEXINST.INDEX_CODE
  ),
    P17_ds19_2 as (
  SELECT MAX(RR.REPORT_CODE) REPORT_CODE,
  --R.REPORT_MONTH,
    --   INDEXINST.STA_INDEX_INST_ID,
       INDEXINST.INDEX_CODE,
       NVL(SUM(indexinst.index_value)  ,0) INDEX_VALUE
      --INDEXINST.UNIT_CODE,
      --INDEXINST.COMPOSITED_INDEX_CODE,
      -- INDEXINSTDIMEN.REPINST_DTL_DIMEN,
      -- INDEXINSTDIMEN.DIM_CODE,
      -- INDEXINSTDIMEN.DIM_DETAIL_CODE,
      -- INDEXINSTDIMEN.UNIT_CODE AS DIMENUNITCODE,
      -- INDEXINST.INDEX_INST_ORDERNO,
     --  INDEXINSTDIMEN.COMPOSITE_DIM_CODE
  FROM E7_STA_REPINST R
  LEFT JOIN E7_STA_REPORT RR ON RR.REPORT_CODE = R.REPORT_CODE
  LEFT JOIN E7_STA_RPT_INDEX_INST RPTINDEX ON R.REPINST_ID = RPTINDEX.REPINST_ID
  LEFT JOIN E7_STA_INDEX_INST INDEXINST ON RPTINDEX.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
  LEFT JOIN E7_STA_INDEX_INST_DIMEN INDEXINSTDIMEN ON INDEXINSTDIMEN.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
 WHERE RR.REPORT_CODE IN ('T0001')
    AND R.ORG_ID = P_RPTORGID
   AND R.REPORT_YEAR = P_RPTYEAR
   AND R.REPORT_MONTH=P_RPTMONTH
   AND INDEXINST.INDEX_CODE = 'Ng_prod'
   GROUP BY INDEXINST.INDEX_CODE
  )
   ,P18_ds21 as (
    SELECT 
       r.report_code   
      ,indexinst.index_code --指标代码
      ,indexinst.index_value --指标值
, indexinstdimen.DIM_CODE
      , indexinstdimen.DIM_DETAIL_CODE

  FROM e7_sta_repinst r
  LEFT JOIN e7_sta_rpt_index_inst rptindex
    ON r.repinst_id = rptindex.repinst_id
  LEFT JOIN e7_sta_index_inst indexinst
    ON rptindex.sta_index_inst_id = indexinst.sta_index_inst_id
  LEFT JOIN e7_sta_index_inst_dimen indexinstdimen
    ON indexinstdimen.sta_index_inst_id = indexinst.sta_index_inst_id
  LEFT JOIN e7_sta_rpt_auth SRA
  ON SRA.ORG_ID = R.ORG_ID
  AND SRA.REPORT_CODE = R.REPORT_CODE
  AND SRA.REPORT_CODE in ('C0001','C0006')
  AND SRA.V_ORG_ID = P_RPTORGID
 WHERE 
   SRA.V_ORG_ID = P_RPTORGID
   AND r.report_year = P_RPTYEAR
   AND r.report_month = P_RPTMONTH
   AND indexinst.index_code = 'watr_injc_amt'
  )
  ,P19_ds20_1 as (
SELECT 
     
      indexinst.index_code --指标代码
      ,NVL(SUM(indexinst.index_value)  ,0) INDEX_VALUE--指标值
--, indexinstdimen.DIM_CODE
    --  , indexinstdimen.DIM_DETAIL_CODE

  FROM e7_sta_repinst r
  LEFT JOIN e7_sta_rpt_index_inst rptindex
    ON r.repinst_id = rptindex.repinst_id
  LEFT JOIN e7_sta_index_inst indexinst
    ON rptindex.sta_index_inst_id = indexinst.sta_index_inst_id
  LEFT JOIN e7_sta_index_inst_dimen indexinstdimen
    ON indexinstdimen.sta_index_inst_id = indexinst.sta_index_inst_id
  LEFT JOIN e7_sta_rpt_auth SRA
  ON SRA.ORG_ID = R.ORG_ID
  AND SRA.REPORT_CODE = R.REPORT_CODE
  AND SRA.REPORT_CODE in ('C0011')
  AND SRA.V_ORG_ID = P_RPTORGID
 WHERE 
   SRA.V_ORG_ID = P_RPTORGID
   AND r.report_year = P_RPTYEAR
   AND r.report_month = P_RPTMONTH
   AND indexinst.index_code='Ng_prod' 
 AND (indexinstdimen.DIM_DETAIL_CODE='Gas_fields' 
 or indexinstdimen.DIM_DETAIL_CODE='Associated_gas')
 GROUP BY INDEXINST.INDEX_CODE
   
),
P19_ds20_2 as (
SELECT 
       
      indexinst.index_code --指标代码
      ,NVL(SUM(indexinst.index_value)  ,0) INDEX_VALUE --指标值


  FROM e7_sta_repinst r
  LEFT JOIN e7_sta_rpt_index_inst rptindex
    ON r.repinst_id = rptindex.repinst_id
  LEFT JOIN e7_sta_index_inst indexinst
    ON rptindex.sta_index_inst_id = indexinst.sta_index_inst_id
  LEFT JOIN e7_sta_index_inst_dimen indexinstdimen
    ON indexinstdimen.sta_index_inst_id = indexinst.sta_index_inst_id
  LEFT JOIN e7_sta_rpt_auth SRA
  ON SRA.ORG_ID = R.ORG_ID
  AND SRA.REPORT_CODE = R.REPORT_CODE
  AND SRA.REPORT_CODE in ('C0011')
  AND SRA.V_ORG_ID = P_RPTORGID
 WHERE 
   SRA.V_ORG_ID = P_RPTORGID
   AND r.report_year = P_RPTYEAR
   AND r.report_month = P_RPTMONTH
   AND indexinst.index_code='Condensate_oil_prod'
   GROUP BY  INDEXINST.INDEX_CODE
)
 ,P20_ds20_1 as (
  SELECT 
     
      indexinst.index_code --指标代码
      ,NVL(SUM(indexinst.index_value)  ,0) INDEX_VALUE --指标值



  FROM e7_sta_repinst r
  LEFT JOIN e7_sta_rpt_index_inst rptindex
    ON r.repinst_id = rptindex.repinst_id
  LEFT JOIN e7_sta_index_inst indexinst
    ON rptindex.sta_index_inst_id = indexinst.sta_index_inst_id
  LEFT JOIN e7_sta_index_inst_dimen indexinstdimen
    ON indexinstdimen.sta_index_inst_id = indexinst.sta_index_inst_id
  LEFT JOIN e7_sta_rpt_auth SRA
  ON SRA.ORG_ID = R.ORG_ID
  AND SRA.REPORT_CODE = R.REPORT_CODE
  AND SRA.REPORT_CODE in ('C0011')
  AND SRA.V_ORG_ID = P_RPTORGID
 WHERE 
   SRA.V_ORG_ID = P_RPTORGID
   AND r.report_year = P_RPTYEAR
   AND r.report_month = P_RPTMONTH
   AND  indexinst.index_code='Ng_prod' 
   AND (INDEXINSTDIMEN.DIM_DETAIL_CODE='Gas_fields' OR INDEXINSTDIMEN.DIM_DETAIL_CODE='Associated_gas')
   GROUP BY INDEXINST.INDEX_CODE
   ),
    P20_ds20_2 as (
  SELECT 
       
      indexinst.index_code --指标代码
      ,NVL(SUM(indexinst.index_value)  ,0) INDEX_VALUE --指标值


  FROM e7_sta_repinst r
  LEFT JOIN e7_sta_rpt_index_inst rptindex
    ON r.repinst_id = rptindex.repinst_id
  LEFT JOIN e7_sta_index_inst indexinst
    ON rptindex.sta_index_inst_id = indexinst.sta_index_inst_id
  LEFT JOIN e7_sta_index_inst_dimen indexinstdimen
    ON indexinstdimen.sta_index_inst_id = indexinst.sta_index_inst_id
  LEFT JOIN e7_sta_rpt_auth SRA
  ON SRA.ORG_ID = R.ORG_ID
  AND SRA.REPORT_CODE = R.REPORT_CODE
  AND SRA.REPORT_CODE in ('C0011')
  AND SRA.V_ORG_ID = P_RPTORGID
 WHERE 
   SRA.V_ORG_ID = P_RPTORGID
   AND r.report_year = P_RPTYEAR
   AND r.report_month = P_RPTMONTH
   AND INDEXINST.INDEX_CODE='Condensate_oil_prod' 
   GROUP BY INDEXINST.INDEX_CODE
   )
   ,P21_ds20 as(
  SELECT 
       r.report_code   
      ,indexinst.index_code --指标代码
      ,indexinst.index_value --指标值
, indexinstdimen.DIM_CODE
      , indexinstdimen.DIM_DETAIL_CODE

  FROM e7_sta_repinst r
  LEFT JOIN e7_sta_rpt_index_inst rptindex
    ON r.repinst_id = rptindex.repinst_id
  LEFT JOIN e7_sta_index_inst indexinst
    ON rptindex.sta_index_inst_id = indexinst.sta_index_inst_id
  LEFT JOIN e7_sta_index_inst_dimen indexinstdimen
    ON indexinstdimen.sta_index_inst_id = indexinst.sta_index_inst_id
  LEFT JOIN e7_sta_rpt_auth SRA
  ON SRA.ORG_ID = R.ORG_ID
  AND SRA.REPORT_CODE = R.REPORT_CODE
  AND SRA.REPORT_CODE in ('C0011')
  AND SRA.V_ORG_ID = P_RPTORGID
 WHERE 
   SRA.V_ORG_ID = P_RPTORGID
   AND r.report_year = P_RPTYEAR
   AND r.report_month = P_RPTMONTH
   AND INDEXINST.INDEX_CODE ='Ng_procs_amt'  
  )
  ,P22_ds19_1 as (
 SELECT MAX(RR.REPORT_CODE) REPORT_CODE,
  MAX(R.REPORT_MONTH),
     MAX(INDEXINST.STA_INDEX_INST_ID),
       INDEXINST.INDEX_CODE,
      SUM(INDEXINST.INDEX_VALUE) INDEX_VALUE,
       MAX(INDEXINST.UNIT_CODE),
        MAX(INDEXINST.COMPOSITED_INDEX_CODE),
        MAX(INDEXINSTDIMEN.REPINST_DTL_DIMEN),
        MAX(INDEXINSTDIMEN.DIM_CODE),
        MAX(INDEXINSTDIMEN.DIM_DETAIL_CODE),
        MAX(INDEXINSTDIMEN.UNIT_CODE) AS DIMENUNITCODE,
        MAX(INDEXINST.INDEX_INST_ORDERNO),
        MAX(INDEXINSTDIMEN.COMPOSITE_DIM_CODE)
  FROM E7_STA_REPINST R
  LEFT JOIN E7_STA_REPORT RR ON RR.REPORT_CODE = R.REPORT_CODE
  LEFT JOIN E7_STA_RPT_INDEX_INST RPTINDEX ON R.REPINST_ID = RPTINDEX.REPINST_ID
  LEFT JOIN E7_STA_INDEX_INST INDEXINST ON RPTINDEX.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
  LEFT JOIN E7_STA_INDEX_INST_DIMEN INDEXINSTDIMEN ON INDEXINSTDIMEN.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
 WHERE RR.REPORT_CODE IN ('T0001')
   AND R.ORG_ID = P_RPTORGID
   AND R.REPORT_YEAR = P_RPTYEAR
   AND R.REPORT_MONTH=P_RPTMONTH
   AND INDEXINST.INDEX_CODE ='Co_bargain_amt'
   GROUP BY INDEXINST.INDEX_CODE
 ),
  P22_ds19_2 as (
   SELECT MAX(RR.REPORT_CODE) REPORT_CODE,
  MAX(R.REPORT_MONTH),
     MAX(INDEXINST.STA_INDEX_INST_ID),
       INDEXINST.INDEX_CODE,
      SUM(INDEXINST.INDEX_VALUE) INDEX_VALUE,
       MAX(INDEXINST.UNIT_CODE),
        MAX(INDEXINST.COMPOSITED_INDEX_CODE),
        MAX(INDEXINSTDIMEN.REPINST_DTL_DIMEN),
        MAX(INDEXINSTDIMEN.DIM_CODE),
        MAX(INDEXINSTDIMEN.DIM_DETAIL_CODE),
        MAX(INDEXINSTDIMEN.UNIT_CODE) AS DIMENUNITCODE,
        MAX(INDEXINST.INDEX_INST_ORDERNO),
        MAX(INDEXINSTDIMEN.COMPOSITE_DIM_CODE)
  FROM E7_STA_REPINST R
  LEFT JOIN E7_STA_REPORT RR ON RR.REPORT_CODE = R.REPORT_CODE
  LEFT JOIN E7_STA_RPT_INDEX_INST RPTINDEX ON R.REPINST_ID = RPTINDEX.REPINST_ID
  LEFT JOIN E7_STA_INDEX_INST INDEXINST ON RPTINDEX.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
  LEFT JOIN E7_STA_INDEX_INST_DIMEN INDEXINSTDIMEN ON INDEXINSTDIMEN.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
 WHERE RR.REPORT_CODE IN ('T0001')
  AND R.ORG_ID = P_RPTORGID
   AND R.REPORT_YEAR = P_RPTYEAR
   AND R.REPORT_MONTH=P_RPTMONTH
   AND INDEXINST.INDEX_CODE ='Ng_bargain_amt'
   GROUP BY INDEXINST.INDEX_CODE
  )
  ,P23_ds19 as (
  SELECT RR.REPORT_CODE,R.REPORT_MONTH,
       INDEXINST.STA_INDEX_INST_ID,
       INDEXINST.INDEX_CODE,
       INDEXINST.INDEX_VALUE,
       INDEXINST.UNIT_CODE,
       INDEXINST.COMPOSITED_INDEX_CODE,
       INDEXINSTDIMEN.REPINST_DTL_DIMEN,
       INDEXINSTDIMEN.DIM_CODE,
       INDEXINSTDIMEN.DIM_DETAIL_CODE,
       INDEXINSTDIMEN.UNIT_CODE AS DIMENUNITCODE,
       INDEXINST.INDEX_INST_ORDERNO,
       INDEXINSTDIMEN.COMPOSITE_DIM_CODE
  FROM E7_STA_REPINST R
  LEFT JOIN E7_STA_REPORT RR ON RR.REPORT_CODE = R.REPORT_CODE
  LEFT JOIN E7_STA_RPT_INDEX_INST RPTINDEX ON R.REPINST_ID = RPTINDEX.REPINST_ID
  LEFT JOIN E7_STA_INDEX_INST INDEXINST ON RPTINDEX.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
  LEFT JOIN E7_STA_INDEX_INST_DIMEN INDEXINSTDIMEN ON INDEXINSTDIMEN.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
 WHERE RR.REPORT_CODE IN ('T0001')
  AND R.ORG_ID = P_RPTORGID
   AND R.REPORT_YEAR = P_RPTYEAR
   AND R.REPORT_MONTH=P_RPTMONTH
   AND INDEXINST.INDEX_CODE = 'Co_bargain_amt'
  )
   , P24_ds19 as (
  SELECT RR.REPORT_CODE,R.REPORT_MONTH,
       INDEXINST.STA_INDEX_INST_ID,
       INDEXINST.INDEX_CODE,
       INDEXINST.INDEX_VALUE,
       INDEXINST.UNIT_CODE,
       INDEXINST.COMPOSITED_INDEX_CODE,
       INDEXINSTDIMEN.REPINST_DTL_DIMEN,
       INDEXINSTDIMEN.DIM_CODE,
       INDEXINSTDIMEN.DIM_DETAIL_CODE,
       INDEXINSTDIMEN.UNIT_CODE AS DIMENUNITCODE,
       INDEXINST.INDEX_INST_ORDERNO,
       INDEXINSTDIMEN.COMPOSITE_DIM_CODE
  FROM E7_STA_REPINST R
  LEFT JOIN E7_STA_REPORT RR ON RR.REPORT_CODE = R.REPORT_CODE
  LEFT JOIN E7_STA_RPT_INDEX_INST RPTINDEX ON R.REPINST_ID = RPTINDEX.REPINST_ID
  LEFT JOIN E7_STA_INDEX_INST INDEXINST ON RPTINDEX.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
  LEFT JOIN E7_STA_INDEX_INST_DIMEN INDEXINSTDIMEN ON INDEXINSTDIMEN.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
 WHERE RR.REPORT_CODE IN ('T0001')
  AND R.ORG_ID = P_RPTORGID
   AND R.REPORT_YEAR = P_RPTYEAR
   AND R.REPORT_MONTH=P_RPTMONTH
   AND INDEXINST.INDEX_CODE = 'Ng_bargain_amt'
  )
   --P12 单位原油(气)液量生产综合能耗  母项  N
  --L7 ~ L8 单位油气当量生产综合能耗 子项 N
select B.LOCALTION, A.SUMVALUE from
     (select SUM(index_value)*1000 SUMVALUE from L7_8_ds13) A 
     left join (
     select * from  e7_excel_locationbyindex  where report_code = P_RPTCODE 
     and index_code 
     in ('Engy_csmp_amt_stadc'
     ,'Og_liqd_unit_engy_csmp_mole'
    )
     and is_py= 'N') B 
      on 1=1
  -- L9 子项 N
UNION
select B.LOCALTION, A.SUMVALUE from
     (select SUM(index_value)*1000 SUMVALUE from L9_ds13) A 
     left join (
     select * from  e7_excel_locationbyindex  where report_code = P_RPTCODE 
     and index_code 
     in (
     'Co_unit_engy_csmp_mole'
    )
     and is_py= 'N') B 
      on 1=1
  --L10 N
  UNION
select B.LOCALTION, A.SUMVALUE from
     (select SUM(index_value)*1000 SUMVALUE from L10_ds13) A 
     left join (
     select * from  e7_excel_locationbyindex  where report_code = P_RPTCODE 
     and index_code 
     in (
     'He_unit_engy_csmp_mole'
    )
     and is_py= 'N') B 
      on 1=1 
  -- L11 N
   UNION
select B.LOCALTION, A.SUMVALUE from
     (select SUM(index_value)*1000 SUMVALUE from L11_ds13) A 
     left join (
     select * from  e7_excel_locationbyindex  where report_code = P_RPTCODE 
     and index_code 
     in (
     'Ra_unit_engy_csmp_mole'
    )
     and is_py= 'N') B 
      on 1=1 
  --L12 N
  UNION
select B.LOCALTION, A.SUMVALUE from
     (select SUM(index_value)*1000 SUMVALUE from L12_ds13) A 
     left join (
     select * from  e7_excel_locationbyindex  where report_code = P_RPTCODE 
     and index_code ='Co_liqd_deno_mole'
     and is_py= 'N') B 
      on 1=1 
  UNION
  --L13 N
select B.LOCALTION, A.SUMVALUE from
     (select SUM(index_value)*1000 SUMVALUE from L13_ds13) A 
     left join (
     select * from  e7_excel_locationbyindex  where report_code = P_RPTCODE 
     and index_code 
     in (
   'He_liqd_deno_mole'
    )
     and is_py= 'N') B 
      on 1=1 
  UNION
  --L14 N
  
select B.LOCALTION, A.SUMVALUE from
     (select SUM(index_value)*1000 SUMVALUE from L14_ds13) A 
     left join (
     select * from  e7_excel_locationbyindex  where report_code = P_RPTCODE 
     and index_code  = 'Ra_liqd_deno_mole'
     and is_py= 'N') B 
      on 1=1  
      UNION
  --L15 N
     select B.LOCALTION , C.SUMVALUE from  (
          select ( SUM(L15_ds15_1.index_value)*10000-SUM(L15_ds15_2.index_value)*10000 )SUMVALUE from L15_ds15_1  
            left join  L15_ds15_2  on  1=1
    )  C
      left join (
     select * from  e7_excel_locationbyindex  where report_code = P_RPTCODE 
     and index_code  = 'Or_liqd_unit_elec_csmp_mole'
     and is_py= 'N') B 
      on 1=1
   -- L16 N 
UNION
select B.LOCALTION, A.SUMVALUE from
     (select SUM(index_value)*1000 SUMVALUE from L16_ds15) A 
     left join (
     select * from  e7_excel_locationbyindex  where report_code = P_RPTCODE 
     and index_code  = 'Og_gather_unit_engy_csmp_mole'
     and is_py= 'N') B 
      on 1=1  
  UNION
  -- L17 N
    
   select B.LOCALTION , C.SUMVALUE from  (
          select SUM(a.index_value)*10000 -  SUM(b.index_value)*10000 SUMVALUE from  L17_ds15_1  a 
            left join  L17_ds15_2  b on 1=1
    )  C
      left join (
     select * from  e7_excel_locationbyindex  where report_code = P_RPTCODE 
     and index_code  = 'Og_unit_elec_csmp_mole'
     and is_py= 'N') B 
      on 1=1   
      UNION
   -- L18 N

    select B.LOCALTION , C.SUMVALUE from  (
          select SUM(a.index_value)*10000 -  SUM(b.index_value)*10000 SUMVALUE from  L18_ds15_1  a 
            left join  L18_ds15_2  b on 1=1
    )  C
      left join (
     select * from  e7_excel_locationbyindex  where report_code = P_RPTCODE 
     and index_code  = 'injc_unit_elec_csmp_mole'
     and is_py= 'N') B 
      on 1=1  
      UNION
  --L19  N
  select B.LOCALTION,A.SUMVALUE
   from (select SUM(INDEX_VALUE)*10000 SUMVALUE from L19_ds13) A
  LEFT JOIN  (
    select * from  e7_excel_locationbyindex  where report_code = P_RPTCODE 
     and index_code  = 'Gf_unit_engy_csmp_mole'
     and is_py= 'N') B 
      on 1=1 
      UNION 
  --L20 N
  select B.LOCALTION, A.SUMVALUE from 
  (select SUM(INDEX_VALUE)*1000 SUMVALUE from L20_ds13) A
 LEFT JOIN (
 select * from e7_excel_locationbyindex where report_code =P_RPTCODE
 and index_code = 'Gf_gather_unit_engy_csmp_mole'
 and is_py = 'N') B on 1=1
 UNION
  --L21 N
   
 select B.LOCALTION ,A.SUMVALUE from 
 (select SUM(INDEX_VALUE)*1000 SUMVALUE from L21_ds13) A
 LEFT JOIN (
 select * from e7_excel_locationbyindex where report_code =P_RPTCODE
 and index_code = 'Ng_depur_unit_engy_csmp_mole'
 and is_py = 'N') B on 1=1
  UNION
  --L22 N
   select B.LOCALTION ,A.SUMVALUE from 
 (select SUM(INDEX_VALUE)*1000 SUMVALUE from L22_ds13) A
 LEFT JOIN (
 select * from e7_excel_locationbyindex where report_code =P_RPTCODE
 and index_code = 'OilGas_bargain_mole'
 and is_py = 'N') B on 1=1
  UNION
 --L23 N 
    select B.LOCALTION ,A.SUMVALUE from 
 (select SUM(INDEX_VALUE)*1000 SUMVALUE from L23_ds13) A
 LEFT JOIN (
 select * from e7_excel_locationbyindex where report_code =P_RPTCODE
 and index_code = 'Oil_bargain_mole'
 and is_py = 'N') B on 1=1 
 UNION
  --24 N 
    select B.LOCALTION ,A.SUMVALUE from 
 (select SUM(INDEX_VALUE)*1000 SUMVALUE from L24_ds13) A
 LEFT JOIN (
 select * from e7_excel_locationbyindex where report_code =P_RPTCODE
 and index_code = 'Gas_bargain_mole'
 and is_py = 'N') B on 1=1 
  UNION
 --P7 Y 母项
select B.LOCALTION , C.SUMVALUE from  (
          select (SUM(P7_ds19_1.index_value)*10000 +  SUM(P7_ds19_2.index_value)*10000/1255) SUMVALUE from  P7_ds19_1   
           left join  P7_ds19_2   on 1=1
    )  C
     left join (
     select * from  e7_excel_locationbyindex  where report_code = P_RPTCODE 
     and index_code  = 'Og_unit_engy_csmp_deno'
     and is_py= 'N') B 
      on 1=1  
 UNION
 --P8 N 
  select  E.LOCALTION LOCALTION ,E.SUMVALUE+F.SUMVALUE SUMVLUE
   FROM   (
  select B.LOCALTION LOCALTION ,A.SUMVALUE SUMVALUE from 
 (select SUM(P8_ds19.INDEX_VALUE)*10000 SUMVALUE from P8_ds19 )
   A 
 LEFT JOIN (
 select * from e7_excel_locationbyindex where report_code =P_RPTCODE
 and index_code = 'Og_liqd_unit_engy_csmp_deno'
 and is_py = 'N') B on 1=1 )  E
 left  join 
 (select D.LOCALTION LOCALTION , C.SUMVALUE SUMVALUE from  (
          select SUM(P7_ds19_1.index_value)*10000 +  SUM(P7_ds19_2.index_value)*10000/1255 SUMVALUE from  P7_ds19_1  
            left join  P7_ds19_2   on P7_ds19_1.report_code =P7_ds19_2.report_code
    )  C
      left join (
     select * from  e7_excel_locationbyindex  where report_code = P_RPTCODE 
     and index_code  = 'Og_unit_engy_csmp_deno'
     and is_py= 'N') D 
      on 1=1) F ON 1=1
 UNION
--P9 N 
 select D.LOCALTION , C.SUMVALUE from  (
          select (SUM(P9_ds19_1.index_value)*10000 +  SUM(P9_ds19_2.index_value)*10000/1255) SUMVALUE from   P9_ds19_1   
            left join   P9_ds19_2   on 1=1
    )  C
      left join (
     select * from  e7_excel_locationbyindex  where report_code = P_RPTCODE 
     and index_code  = 'Co_unit_engy_csmp_deno'
     and is_py= 'N') D
      on 1=1 
      UNION   
 --P10 N
  select B.LOCALTION , C.SUMVALUE from  (
          select SUM(P10_ds21_1.index_value)*10000 +  SUM(P10_ds21_2.index_value)*10000/1255 SUMVALUE from  P10_ds21_1   
            left join  P10_ds21_2   on 1=1
    )  C
      left join (
     select * from  e7_excel_locationbyindex  where report_code = P_RPTCODE 
     and index_code  = 'He_unit_engy_csmp_deno'
     and is_py= 'N') B 
      on 1=1    
  UNION
  --p11
  select B.LOCALTION , C.SUMVALUE from  (
          select SUM(P11_ds21_1.index_value)*10000 +  SUM(P11_ds21_2.index_value)*10000/1255 SUMVALUE from  P11_ds21_1   
            left join  P11_ds21_2   on 1=1
    )  C
      left join (
     select * from  e7_excel_locationbyindex  where report_code = P_RPTCODE 
     and index_code  = 'Ra_unit_engy_csmp_deno'
     and is_py= 'N') B 
      on 1=1 
      UNION  
  -- P12
  select B.LOCALTION , C.SUMVALUE from  (
          select SUM(P12_ds19_1.index_value)*10000 + SUM(P12_ds19_2.index_value)*10000+  SUM(P12_ds19_3.index_value)*10000/1255 SUMVALUE from  P12_ds19_1   
            left join  P12_ds19_2    on 1=1  LEFT JOIN P12_ds19_3  on 1=1
            
    )  C
      left join (
     select * from  e7_excel_locationbyindex  where report_code = 'T0030' 
     and index_code  = 'Co_liqd_unit_engy_csmp_deno'
     and is_py= 'N') B 
      on 1=1
     
     UNION
  --P13
  
  
    select B.LOCALTION , C.SUMVALUE from  (
          select SUM(a.index_value)*10000 + SUM(b.index_value)*10000+  SUM(d.index_value)*10000/1255 SUMVALUE from  P13_ds21_1  a 
            left join  P13_ds21_2  b  on 1=1  LEFT JOIN P13_ds21_3 d on 1=1
           
    )  C
      left join (
     select * from  e7_excel_locationbyindex  where report_code = P_RPTCODE 
     and index_code  = 'He_liqd_unit_engy_csmp_deno'
     and is_py= 'N') B 
      on 1=1 
      UNION  
  -- P14 
    select B.LOCALTION , C.SUMVALUE from  (
          select SUM(a.index_value)*10000 + SUM(b.index_value)*10000+  SUM(d.index_value)*10000/1255 SUMVALUE from  P14_ds21_1  a 
            left join  P14_ds21_2  b  on 1=1 LEFT JOIN P14_ds21_3 d on 1=1
            
    )  C
      left join (
     select * from  e7_excel_locationbyindex  where report_code = P_RPTCODE 
     and index_code  = 'Ra_liqd_unit_engy_csmp_deno'
     and is_py= 'N') B 
      on 1=1 
     UNION
  -- P15   --已添加P12 
 select B.LOCALTION , C.SUMVALUE from  (
          select SUM(a.index_value)*10000 + SUM(b.index_value)*10000+  SUM(d.index_value)*10000/1255 SUMVALUE from  P12_ds19_1  a 
            left join  P12_ds19_2  b  on a.report_code =b.report_code  LEFT JOIN P12_ds19_3 d on d.report_code=a.report_code
            AND d.report_code =b.report_code
    )  C
      left join (
     select * from  e7_excel_locationbyindex  where report_code = 'T0030' 
     and index_code  = 'Liqd_prod'
     and is_py= 'N') B 
      on 1=1
   UNION
 --P16
  select B.LOCALTION, A.SUMVALUE from
     (select SUM(index_value)*10000 SUMVALUE from P16_ds21) A 
     left join (
     select * from  e7_excel_locationbyindex  where report_code = P_RPTCODE 
     and index_code = 'Og_gather_unit_engy_csmp_deno'
     and is_py= 'N') B 
      on 1=1 
      UNION
  -- P17
  
  
    select B.LOCALTION , C.SUMVALUE from  (
          select SUM(a.index_value)*10000 +  SUM(b.index_value)*10000/1255 SUMVALUE from  P17_ds19_1  a 
            left join  P17_ds19_2  b on 1=1
    )  C
      left join (
     select * from  e7_excel_locationbyindex  where report_code = P_RPTCODE 
     and index_code  = 'Og_unit_elec_csmp_deno'
     and is_py= 'N') B 
      on 1=1   
  UNION
  --P18
       select B.LOCALTION, A.SUMVALUE from
     (select SUM(index_value)*10000 SUMVALUE from P18_ds21) A 
     left join (
     select * from  e7_excel_locationbyindex  where report_code = P_RPTCODE 
     and index_code = 'watr_injc_amt'
     and is_py= 'N') B 
      on 1=1 
      UNION
 --P19

        select B.LOCALTION , C.SUMVALUE from  (
          select SUM(a.index_value) +  SUM(b.index_value)*1255 SUMVALUE from  P19_ds20_1  a 
            left join  P19_ds20_2  b on 1=1
    )  C
      left join (
     select * from  e7_excel_locationbyindex  where report_code = P_RPTCODE 
     and index_code  = 'Gf_unit_watr_csmp_deno'
     and is_py= 'N') B 
      on 1=1 
      UNION  
  --P20
  
    select B.LOCALTION , C.SUMVALUE from  (
          select SUM(a.index_value) +  SUM(b.index_value)*1255 SUMVALUE from  P20_ds20_1  a 
            left join  P20_ds20_2  b on 1=1
    )  C
      left join (
     select * from  e7_excel_locationbyindex  where report_code = P_RPTCODE 
     and index_code  = 'Gf_gather_unit_engy_csmp_deno'
     and is_py= 'N') B 
      on 1=1 
      UNION
  --P21
  
   select B.LOCALTION, A.SUMVALUE from
     (select SUM(index_value) SUMVALUE from P21_ds20) A 
     left join (
     select * from  e7_excel_locationbyindex  where report_code = P_RPTCODE 
     and index_code = 'Ng_depur_unit_engy_csmp_deno'
     and is_py= 'N') B 
      on 1=1 
      UNION
--P22

    select B.LOCALTION , C.SUMVALUE from  (
          select SUM(a.index_value)*10000+  SUM(b.index_value)*10000/1255 SUMVALUE from  P22_ds19_1  a 
            left join  P22_ds19_2  b on 1=1
    )  C
      left join (
     select * from  e7_excel_locationbyindex  where report_code = P_RPTCODE 
     and index_code  = 'OilGas_bargain_deno'
     and is_py= 'N') B 
      on 1=1
      UNION
  --P23

  
    select B.LOCALTION, A.SUMVALUE from
     (select SUM(index_value)*10000 SUMVALUE from P23_ds19) A 
     left join (
     select * from  e7_excel_locationbyindex  where report_code = P_RPTCODE 
     and index_code = 'Oil_bargain_deno'
     and is_py= 'N') B 
      on 1=1 
      UNION
  --P24
 
  
    select B.LOCALTION, A.SUMVALUE from
     (select SUM(index_value)*10000 SUMVALUE from P24_ds19) A 
     left join (
     select * from  e7_excel_locationbyindex  where report_code = P_RPTCODE 
     and index_code = 'Gas_bargain_deno'
     and is_py= 'N') B 
      on 1=1 ;
  

  
BEGIN
jsonStr := '[';
FOR T0030_R IN return_cursor LOOP
  jsonStr := jsonStr || '{''location'':''' || T0030_R.LOCALTION ||
                 ''',''value'':''' || to_char (ROUND(T0030_R.SUMVALUE,4))|| '''},';

  END LOOP;
  jsonStr := jsonStr || ']';
  jsonStr := replace(jsonStr,'},]','}]');
  dbms_output.put_line(jsonStr);
  END;
  
  
  
  
  
  
  procedure getT0085Sum(P_RPTCODE IN VARCHAR2,
                        P_RPTYEAR  IN VARCHAR2,
                       P_RPTMONTH IN VARCHAR2,
                       P_RPTORGID IN VARCHAR2,jsonStr OUT CLOB) IS
    
    Cursor return_cursor is
 SELECT 
  D.LOCALTION, D.SUMVALUE
  FROM (
SELECT A.LOCALTION,
B.LOCALTION DIMEN1 ,
c.localtion dimen2,

V.* FROM ( 
SELECT 
       indexinst.index_code --指标代码
      ,indexinstdimen.dim_code --维度代码
      ,indexinstdimen.dim_detail_code  --维值代码
      ,indexinstdimen1.dim_code as dim_code1--维度代码
      ,indexinstdimen1.dim_detail_code as dim_detail_code1  --维值代码
      ,sum(indexinst.index_value) as sumvalue --指标值
  FROM e7_sta_repinst r 
  LEFT JOIN e7_sta_rpt_index_inst rptindex
    ON r.repinst_id = rptindex.repinst_id
  LEFT JOIN e7_sta_index_inst indexinst
    ON rptindex.sta_index_inst_id = indexinst.sta_index_inst_id
  LEFT JOIN e7_sta_index_inst_dimen indexinstdimen
    ON indexinstdimen.sta_index_inst_id = indexinst.sta_index_inst_id
    and indexinstdimen.dim_code = 'Orig_energy_type'
  LEFT JOIN e7_sta_index_inst_dimen indexinstdimen1
    ON indexinstdimen1.sta_index_inst_id = indexinst.sta_index_inst_id
     and indexinstdimen1.dim_code = 'Industry_type'
 WHERE r.report_code = P_RPTCODE 
   AND r.org_id = P_RPTORGID
   AND r.report_year =  P_RPTYEAR
   AND r.report_month = P_RPTMONTH
   group by indexinst.index_code,indexinstdimen.dim_code,indexinstdimen.dim_detail_code,indexinstdimen1.dim_code,indexinstdimen1.dim_detail_code
) V 
LEFT JOIN E7_EXCEL_LOCATIONBYINDEX A ON A.INDEX_CODE = V.INDEX_CODE 
LEFT JOIN E7_EXCEL_LOCATIONBYDIMEN B ON  B.DIM_CODE = V.DIM_CODE AND B.DIM_DETAIL_CODE = V.DIM_DETAIL_CODE
LEFT JOIN E7_EXCEL_LOCATIONBYDIMEN C ON  C.DIM_CODE= V.DIM_CODE1 AND C.DIM_DETAIL_CODE = V.DIM_DETAIL_CODE1
WHERE B.DIM_CODE = 'Orig_energy_type' 
AND C.DIM_CODE = 'Industry_type'
AND B.REPORT_CODE = P_RPTCODE  
AND A.REPORT_CODE = P_RPTCODE 
AND C.REPORT_CODE = P_RPTCODE 
) D WHERE LOCALTION = DIMEN1
AND LOCALTION = DIMEN2;

BEGIN
jsonStr := '[';
FOR A IN return_cursor LOOP
  jsonStr := jsonStr || '{''location'':''' || A.LOCALTION ||
                 ''',''value'':''' || to_char(A.SUMVALUE) || '''},';

  END LOOP;
  jsonStr := jsonStr || ']';
  jsonStr := replace(jsonStr,'},]','}]');
  dbms_output.put_line(jsonStr);
  END;
  
   procedure getT0003Sum(P_RPTCODE IN VARCHAR2,
            	          P_RPTYEAR  IN VARCHAR2,
                       P_RPTMONTH IN VARCHAR2,
                       P_RPTORGID IN VARCHAR2,jsonStr OUT CLOB) IS
  Cursor return_cursor is
      SELECT *
        FROM (with datas as
 (select report_code,
         report_year,
         report_month,
         index_code,
         sum(index_value) as index_value,
         dim_code1,
         dim_detail_code1,
         dim_code2,
         dim_detail_code2,
         dim_code3,
         dim_detail_code3,
         dim_code4,
         dim_detail_code4
    from (SELECT P_RPTCODE REPORT_CODE,
                 T1.REPORT_YEAR,
                 T1.REPORT_MONTH,
                 T1.ORG_ID,
                 T3.INDEX_CODE,
                 T3.INDEX_VALUE,
                 T4.DIM_CODE AS DIM_CODE1,
                 T4.DIM_DETAIL_CODE AS DIM_DETAIL_CODE1,
                 T5.DIM_CODE AS DIM_CODE2,
                 T5.DIM_DETAIL_CODE AS DIM_DETAIL_CODE2,
                 T7.DIM_CODE AS DIM_CODE3,
                 T7.DIM_DETAIL_CODE AS DIM_DETAIL_CODE3,
                 T9.DIM_CODE AS DIM_CODE4,
                 T9.DIM_DETAIL_CODE AS DIM_DETAIL_CODE4
            FROM E7_STA_REPINST T1
            LEFT JOIN E7_STA_RPT_INDEX_INST T2
              ON T1.REPINST_ID = T2.REPINST_ID
            LEFT JOIN E7_STA_INDEX_INST T3
              ON T2.STA_INDEX_INST_ID = T3.STA_INDEX_INST_ID
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T4
              ON T2.STA_INDEX_INST_ID = T4.STA_INDEX_INST_ID
             AND T4.DIM_CODE = 'Assets_type'
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T5
              ON T2.STA_INDEX_INST_ID = T5.STA_INDEX_INST_ID
             AND T5.DIM_CODE = 'Industry_type'
          
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T7
              ON T2.STA_INDEX_INST_ID = T7.STA_INDEX_INST_ID
             AND T7.DIM_CODE = 'Energy_consu_depos_typ'
          
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T9
              ON T2.STA_INDEX_INST_ID = T9.STA_INDEX_INST_ID
             AND T9.DIM_CODE LIKE 'E_cons_classi%'
          
           WHERE T1.REPORT_CODE = 'C0119'
             AND T1.REPORT_YEAR = P_RPTYEAR
             AND T1.REPORT_MONTH = P_RPTMONTH
             AND T1.ORG_ID IN (SELECT ORG_ID
                                 FROM E7_STA_RPT_AUTH
                                WHERE V_ORG_ID = P_RPTORGID
                                  AND REPORT_CODE = 'C0119'))
  
   group by report_code,
            report_year,
            report_month,
            index_code,
            dim_code1,
            dim_detail_code1,
            dim_code2,
            dim_detail_code2,
            dim_code3,
            dim_detail_code3,
            dim_code4,
            dim_detail_code4),
LOCA_INDEX AS
 (SELECT *
    FROM E7_EXCEL_LOCATIONBYINDEX
   WHERE REPORT_CODE = 'T0003'
     AND IS_PY = 'N'),
LOCA_DIMEN AS
 (SELECT * FROM E7_EXCEL_LOCATIONBYDIMEN WHERE REPORT_CODE = 'T0003'),
LOC_INDEX AS
 (SELECT DATAS.*, LOCA_INDEX.LOCALTION LOCATION_INDEX
    FROM DATAS
    LEFT JOIN LOCA_INDEX
      ON DATAS.INDEX_CODE = LOCA_INDEX.INDEX_CODE),
LOCA_DIMEN1 AS
 (SELECT *
    FROM (SELECT LOC_INDEX.*, DIMEN1.LOCALTION LOCATION_DIMEN1
            FROM LOC_INDEX
            LEFT JOIN LOCA_DIMEN DIMEN1
              ON LOC_INDEX.DIM_DETAIL_CODE1 = DIMEN1.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN1
      OR LOCATION_DIMEN1 IS NULL),
LOCA_DIMEN2 as
 (SELECT *
    FROM (select LOCA_DIMEN1.*, DIMEN2.LOCALTION LOCATION_DIMEN2
            FROM LOCA_DIMEN1
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN2
              ON LOCA_DIMEN1.DIM_CODE2 = DIMEN2.DIM_CODE
             AND LOCA_DIMEN1.DIM_DETAIL_CODE2 = DIMEN2.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN2
      OR LOCATION_DIMEN2 IS NULL),
LOCA_DIMEN3 as
 (SELECT *
    FROM (select LOCA_DIMEN2.*, DIMEN3.LOCALTION LOCATION_DIMEN3
            FROM LOCA_DIMEN2
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN3
              ON LOCA_DIMEN2.DIM_CODE3 = DIMEN3.DIM_CODE
             AND LOCA_DIMEN2.DIM_DETAIL_CODE3 = DIMEN3.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN3
      OR LOCATION_DIMEN3 IS NULL),

LOCA_DIMEN4 as
 (SELECT *
    FROM (select LOCA_DIMEN3.*, DIMEN4.LOCALTION LOCATION_DIMEN4
            FROM LOCA_DIMEN3
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN4
              ON LOCA_DIMEN3.DIM_CODE4 = DIMEN4.DIM_CODE
             AND LOCA_DIMEN3.DIM_DETAIL_CODE4 = DIMEN4.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN4
      OR LOCATION_DIMEN4 IS NULL)
SELECT DISTINCT LOCATION_INDEX,INDEX_VALUE FROM LOCA_DIMEN4
);
        
   BEGIN
   jsonStr := '[';
   FOR V_ENRGY IN return_cursor LOOP
  jsonStr := jsonStr || '{''location'':''' || V_ENRGY.LOCATION_INDEX ||
                 ''',''value'':''' || to_char(V_ENRGY.Index_Value) || '''},';

  END LOOP;
  jsonStr := jsonStr || ']';
  jsonStr := replace(jsonStr,'},]','}]');
  dbms_output.put_line(jsonStr);
  END;  
  procedure getC0119Sum(P_RPTCODE IN VARCHAR2,
            	          P_RPTYEAR  IN VARCHAR2,
                       P_RPTMONTH IN VARCHAR2,
                       P_RPTORGID IN VARCHAR2,jsonStr OUT CLOB) IS
  Cursor return_cursor is
      SELECT *
        FROM (with datas as
 (select report_code,
         report_year,
         report_month,
         index_code,
         sum(index_value) as index_value,
         dim_code1,
         dim_detail_code1,
         dim_code2,
         dim_detail_code2,
         dim_code3,
         dim_detail_code3,
         dim_code4,
         dim_detail_code4
    from (SELECT P_RPTCODE REPORT_CODE,
                 T1.REPORT_YEAR,
                 T1.REPORT_MONTH,
                 T1.ORG_ID,
                 T3.INDEX_CODE,
                 T3.INDEX_VALUE,
                 T4.DIM_CODE AS DIM_CODE1,
                 T4.DIM_DETAIL_CODE AS DIM_DETAIL_CODE1,
                 T5.DIM_CODE AS DIM_CODE2,
                 T5.DIM_DETAIL_CODE AS DIM_DETAIL_CODE2,
                 T7.DIM_CODE AS DIM_CODE3,
                 T7.DIM_DETAIL_CODE AS DIM_DETAIL_CODE3,
                 T9.DIM_CODE AS DIM_CODE4,
                 T9.DIM_DETAIL_CODE AS DIM_DETAIL_CODE4
            FROM E7_STA_REPINST T1
            LEFT JOIN E7_STA_RPT_INDEX_INST T2
              ON T1.REPINST_ID = T2.REPINST_ID
            LEFT JOIN E7_STA_INDEX_INST T3
              ON T2.STA_INDEX_INST_ID = T3.STA_INDEX_INST_ID
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T4
              ON T2.STA_INDEX_INST_ID = T4.STA_INDEX_INST_ID
             AND T4.DIM_CODE = 'Assets_type'
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T5
              ON T2.STA_INDEX_INST_ID = T5.STA_INDEX_INST_ID
             AND T5.DIM_CODE = 'Industry_type'
          
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T7
              ON T2.STA_INDEX_INST_ID = T7.STA_INDEX_INST_ID
             AND T7.DIM_CODE = 'Energy_consu_depos_typ'
          
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T9
              ON T2.STA_INDEX_INST_ID = T9.STA_INDEX_INST_ID
             AND T9.DIM_CODE LIKE 'E_cons_classi%'
          
           WHERE T1.REPORT_CODE = 'C0119'
             AND T1.REPORT_YEAR = P_RPTYEAR
             AND T1.REPORT_MONTH = P_RPTMONTH
             AND T1.ORG_ID IN (SELECT ORG_ID
                                 FROM E7_STA_RPT_AUTH
                                WHERE V_ORG_ID = P_RPTORGID
                                  AND REPORT_CODE = 'C0119'))
  
   group by report_code,
            report_year,
            report_month,
            index_code,
            dim_code1,
            dim_detail_code1,
            dim_code2,
            dim_detail_code2,
            dim_code3,
            dim_detail_code3,
            dim_code4,
            dim_detail_code4),
LOCA_INDEX AS
 (SELECT *
    FROM E7_EXCEL_LOCATIONBYINDEX
   WHERE REPORT_CODE = 'T0003'
     AND IS_PY = 'N'),
LOCA_DIMEN AS
 (SELECT * FROM E7_EXCEL_LOCATIONBYDIMEN WHERE REPORT_CODE = 'T0003'),
LOC_INDEX AS
 (SELECT DATAS.*, LOCA_INDEX.LOCALTION LOCATION_INDEX
    FROM DATAS
    LEFT JOIN LOCA_INDEX
      ON DATAS.INDEX_CODE = LOCA_INDEX.INDEX_CODE),
LOCA_DIMEN1 AS
 (SELECT *
    FROM (SELECT LOC_INDEX.*, DIMEN1.LOCALTION LOCATION_DIMEN1
            FROM LOC_INDEX
            LEFT JOIN LOCA_DIMEN DIMEN1
              ON LOC_INDEX.DIM_DETAIL_CODE1 = DIMEN1.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN1
      OR LOCATION_DIMEN1 IS NULL),
LOCA_DIMEN2 as
 (SELECT *
    FROM (select LOCA_DIMEN1.*, DIMEN2.LOCALTION LOCATION_DIMEN2
            FROM LOCA_DIMEN1
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN2
              ON LOCA_DIMEN1.DIM_CODE2 = DIMEN2.DIM_CODE
             AND LOCA_DIMEN1.DIM_DETAIL_CODE2 = DIMEN2.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN2
      OR LOCATION_DIMEN2 IS NULL),
LOCA_DIMEN3 as
 (SELECT *
    FROM (select LOCA_DIMEN2.*, DIMEN3.LOCALTION LOCATION_DIMEN3
            FROM LOCA_DIMEN2
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN3
              ON LOCA_DIMEN2.DIM_CODE3 = DIMEN3.DIM_CODE
             AND LOCA_DIMEN2.DIM_DETAIL_CODE3 = DIMEN3.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN3
      OR LOCATION_DIMEN3 IS NULL),

LOCA_DIMEN4 as
 (SELECT *
    FROM (select LOCA_DIMEN3.*, DIMEN4.LOCALTION LOCATION_DIMEN4
            FROM LOCA_DIMEN3
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN4
              ON LOCA_DIMEN3.DIM_CODE4 = DIMEN4.DIM_CODE
             AND LOCA_DIMEN3.DIM_DETAIL_CODE4 = DIMEN4.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN4
      OR LOCATION_DIMEN4 IS NULL)
SELECT DISTINCT LOCATION_INDEX,INDEX_VALUE FROM LOCA_DIMEN4
);
        
   BEGIN
   jsonStr := '[';
   FOR V_ENRGY IN return_cursor LOOP
  jsonStr := jsonStr || '{''location'':''' || V_ENRGY.LOCATION_INDEX ||
                 ''',''value'':''' || to_char(V_ENRGY.Index_Value) || '''},';

  END LOOP;
  jsonStr := jsonStr || ']';
  jsonStr := replace(jsonStr,'},]','}]');
  dbms_output.put_line(jsonStr);
  END;     
  
  
  procedure getT0004Sum(P_RPTCODE IN VARCHAR2,
            	          P_RPTYEAR  IN VARCHAR2,
                       P_RPTMONTH IN VARCHAR2,
                       P_RPTORGID IN VARCHAR2,jsonStr OUT CLOB) IS
  Cursor return_cursor is
      SELECT *
        FROM (with datas as
 (select report_code,
         report_year,
         report_month,
         index_code,
         sum(index_value) as index_value,
         dim_code1,
         dim_detail_code1,
         dim_code2,
         dim_detail_code2,
         dim_code3,
         dim_detail_code3
    from (SELECT P_RPTCODE REPORT_CODE,
                 T1.REPORT_YEAR,
                 T1.REPORT_MONTH,
                 T1.ORG_ID,
                 T3.INDEX_CODE,
                 T3.INDEX_VALUE,
                 T4.DIM_CODE AS DIM_CODE1,
                 T4.DIM_DETAIL_CODE AS DIM_DETAIL_CODE1,
                 T5.DIM_CODE AS DIM_CODE2,
                 T5.DIM_DETAIL_CODE AS DIM_DETAIL_CODE2,
                 T7.DIM_CODE AS DIM_CODE3,
                 T7.DIM_DETAIL_CODE AS DIM_DETAIL_CODE3
            FROM E7_STA_REPINST T1
            LEFT JOIN E7_STA_RPT_INDEX_INST T2
              ON T1.REPINST_ID = T2.REPINST_ID
            LEFT JOIN E7_STA_INDEX_INST T3
              ON T2.STA_INDEX_INST_ID = T3.STA_INDEX_INST_ID
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T4
              ON T2.STA_INDEX_INST_ID = T4.STA_INDEX_INST_ID
             AND T4.DIM_CODE = 'Assets_type'
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T5
              ON T2.STA_INDEX_INST_ID = T5.STA_INDEX_INST_ID
             AND T5.DIM_CODE = 'E_convers_typ'
          
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T7
              ON T2.STA_INDEX_INST_ID = T7.STA_INDEX_INST_ID
             AND T7.DIM_CODE = 'Energy_consu_depos_typ'
         
           WHERE T1.REPORT_CODE = 'C0120'
             AND T1.REPORT_YEAR = P_RPTYEAR
             AND T1.REPORT_MONTH = P_RPTMONTH
             AND T1.ORG_ID IN (SELECT ORG_ID
                                 FROM E7_STA_RPT_AUTH
                                WHERE V_ORG_ID = P_RPTORGID
                                  AND REPORT_CODE = 'C0120'))
  
   group by report_code,
            report_year,
            report_month,
            index_code,
            dim_code1,
            dim_detail_code1,
            dim_code2,
            dim_detail_code2,
            dim_code3,
            dim_detail_code3),
LOCA_INDEX AS
 (SELECT *
    FROM E7_EXCEL_LOCATIONBYINDEX
   WHERE REPORT_CODE = 'T0004'
     AND IS_PY = 'N'),
LOCA_DIMEN AS
 (SELECT * FROM E7_EXCEL_LOCATIONBYDIMEN WHERE REPORT_CODE = 'T0004'),
LOC_INDEX AS
 (SELECT DATAS.*, LOCA_INDEX.LOCALTION LOCATION_INDEX
    FROM DATAS
    LEFT JOIN LOCA_INDEX
      ON DATAS.INDEX_CODE = LOCA_INDEX.INDEX_CODE),
LOCA_DIMEN1 AS
 (SELECT *
    FROM (SELECT LOC_INDEX.*, DIMEN1.LOCALTION LOCATION_DIMEN1
            FROM LOC_INDEX
            LEFT JOIN LOCA_DIMEN DIMEN1
              ON LOC_INDEX.DIM_DETAIL_CODE1 = DIMEN1.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN1
      OR LOCATION_DIMEN1 IS NULL),
LOCA_DIMEN2 as
 (SELECT *
    FROM (select LOCA_DIMEN1.*, DIMEN2.LOCALTION LOCATION_DIMEN2
            FROM LOCA_DIMEN1
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN2
              ON LOCA_DIMEN1.DIM_CODE2 = DIMEN2.DIM_CODE
             AND LOCA_DIMEN1.DIM_DETAIL_CODE2 = DIMEN2.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN2
      OR LOCATION_DIMEN2 IS NULL),
LOCA_DIMEN3 as
 (SELECT *
    FROM (select LOCA_DIMEN2.*, DIMEN3.LOCALTION LOCATION_DIMEN3
            FROM LOCA_DIMEN2
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN3
              ON LOCA_DIMEN2.DIM_CODE3 = DIMEN3.DIM_CODE
             AND LOCA_DIMEN2.DIM_DETAIL_CODE3 = DIMEN3.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN3
      OR LOCATION_DIMEN3 IS NULL)


     
SELECT DISTINCT LOCATION_INDEX,INDEX_VALUE FROM LOCA_DIMEN3

);
        
   BEGIN
   jsonStr := '[';
   FOR V_ENRGY IN return_cursor LOOP
  jsonStr := jsonStr || '{''location'':''' || V_ENRGY.LOCATION_INDEX ||
                 ''',''value'':''' || to_char(V_ENRGY.Index_Value) || '''},';

  END LOOP;
  jsonStr := jsonStr || ']';
  jsonStr := replace(jsonStr,'},]','}]');
  dbms_output.put_line(jsonStr);
  END;  
  procedure getC0120Sum(P_RPTCODE IN VARCHAR2,
            	          P_RPTYEAR  IN VARCHAR2,
                       P_RPTMONTH IN VARCHAR2,
                       P_RPTORGID IN VARCHAR2,jsonStr OUT CLOB) IS
  Cursor return_cursor is
      SELECT *
        FROM (with datas as
 (select report_code,
         report_year,
         report_month,
         index_code,
         sum(index_value) as index_value,
         dim_code1,
         dim_detail_code1,
         dim_code2,
         dim_detail_code2,
         dim_code3,
         dim_detail_code3
    from (SELECT P_RPTCODE REPORT_CODE,
                 T1.REPORT_YEAR,
                 T1.REPORT_MONTH,
                 T1.ORG_ID,
                 T3.INDEX_CODE,
                 T3.INDEX_VALUE,
                 T4.DIM_CODE AS DIM_CODE1,
                 T4.DIM_DETAIL_CODE AS DIM_DETAIL_CODE1,
                 T5.DIM_CODE AS DIM_CODE2,
                 T5.DIM_DETAIL_CODE AS DIM_DETAIL_CODE2,
                 T7.DIM_CODE AS DIM_CODE3,
                 T7.DIM_DETAIL_CODE AS DIM_DETAIL_CODE3
            FROM E7_STA_REPINST T1
            LEFT JOIN E7_STA_RPT_INDEX_INST T2
              ON T1.REPINST_ID = T2.REPINST_ID
            LEFT JOIN E7_STA_INDEX_INST T3
              ON T2.STA_INDEX_INST_ID = T3.STA_INDEX_INST_ID
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T4
              ON T2.STA_INDEX_INST_ID = T4.STA_INDEX_INST_ID
             AND T4.DIM_CODE = 'Assets_type'
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T5
              ON T2.STA_INDEX_INST_ID = T5.STA_INDEX_INST_ID
             AND T5.DIM_CODE = 'E_convers_typ'
          
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T7
              ON T2.STA_INDEX_INST_ID = T7.STA_INDEX_INST_ID
             AND T7.DIM_CODE = 'Energy_consu_depos_typ'
         
           WHERE T1.REPORT_CODE = 'C0120'
             AND T1.REPORT_YEAR = P_RPTYEAR
             AND T1.REPORT_MONTH = P_RPTMONTH
             AND T1.ORG_ID IN (SELECT ORG_ID
                                 FROM E7_STA_RPT_AUTH
                                WHERE V_ORG_ID = P_RPTORGID
                                  AND REPORT_CODE = 'C0120'))
  
   group by report_code,
            report_year,
            report_month,
            index_code,
            dim_code1,
            dim_detail_code1,
            dim_code2,
            dim_detail_code2,
            dim_code3,
            dim_detail_code3),
LOCA_INDEX AS
 (SELECT *
    FROM E7_EXCEL_LOCATIONBYINDEX
   WHERE REPORT_CODE = 'T0004'
     AND IS_PY = 'N'),
LOCA_DIMEN AS
 (SELECT * FROM E7_EXCEL_LOCATIONBYDIMEN WHERE REPORT_CODE = 'T0004'),
LOC_INDEX AS
 (SELECT DATAS.*, LOCA_INDEX.LOCALTION LOCATION_INDEX
    FROM DATAS
    LEFT JOIN LOCA_INDEX
      ON DATAS.INDEX_CODE = LOCA_INDEX.INDEX_CODE),
LOCA_DIMEN1 AS
 (SELECT *
    FROM (SELECT LOC_INDEX.*, DIMEN1.LOCALTION LOCATION_DIMEN1
            FROM LOC_INDEX
            LEFT JOIN LOCA_DIMEN DIMEN1
              ON LOC_INDEX.DIM_DETAIL_CODE1 = DIMEN1.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN1
      OR LOCATION_DIMEN1 IS NULL),
LOCA_DIMEN2 as
 (SELECT *
    FROM (select LOCA_DIMEN1.*, DIMEN2.LOCALTION LOCATION_DIMEN2
            FROM LOCA_DIMEN1
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN2
              ON LOCA_DIMEN1.DIM_CODE2 = DIMEN2.DIM_CODE
             AND LOCA_DIMEN1.DIM_DETAIL_CODE2 = DIMEN2.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN2
      OR LOCATION_DIMEN2 IS NULL),
LOCA_DIMEN3 as
 (SELECT *
    FROM (select LOCA_DIMEN2.*, DIMEN3.LOCALTION LOCATION_DIMEN3
            FROM LOCA_DIMEN2
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN3
              ON LOCA_DIMEN2.DIM_CODE3 = DIMEN3.DIM_CODE
             AND LOCA_DIMEN2.DIM_DETAIL_CODE3 = DIMEN3.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN3
      OR LOCATION_DIMEN3 IS NULL)


     
SELECT DISTINCT LOCATION_INDEX,INDEX_VALUE FROM LOCA_DIMEN3

);
        
   BEGIN
   jsonStr := '[';
   FOR V_ENRGY IN return_cursor LOOP
  jsonStr := jsonStr || '{''location'':''' || V_ENRGY.LOCATION_INDEX ||
                 ''',''value'':''' || to_char(V_ENRGY.Index_Value) || '''},';

  END LOOP;
  jsonStr := jsonStr || ']';
  jsonStr := replace(jsonStr,'},]','}]');
  dbms_output.put_line(jsonStr);
  END;
  
  procedure getT0005Sum(P_RPTCODE IN VARCHAR2,
            	          P_RPTYEAR  IN VARCHAR2,
                       P_RPTMONTH IN VARCHAR2,
                       P_RPTORGID IN VARCHAR2,jsonStr OUT CLOB) IS
  Cursor return_cursor is
      SELECT *
        FROM (with datas as
 (select report_code,
         report_year,
         report_month,
         index_code,
         sum(index_value) as index_value,
         dim_code1,
         dim_detail_code1,
         dim_code2,
         dim_detail_code2,
         dim_code3,
         dim_detail_code3,
         dim_code4,
         dim_detail_code4
    from (SELECT P_RPTCODE REPORT_CODE,
                 T1.REPORT_YEAR,
                 T1.REPORT_MONTH,
                 T1.ORG_ID,
                 T3.INDEX_CODE,
                 T3.INDEX_VALUE,
                 T4.DIM_CODE AS DIM_CODE1,
                 T4.DIM_DETAIL_CODE AS DIM_DETAIL_CODE1,
                 T5.DIM_CODE AS DIM_CODE2,
                 T5.DIM_DETAIL_CODE AS DIM_DETAIL_CODE2,
                 T7.DIM_CODE AS DIM_CODE3,
                 T7.DIM_DETAIL_CODE AS DIM_DETAIL_CODE3,
                 T9.DIM_CODE AS DIM_CODE4,
                 T9.DIM_DETAIL_CODE AS DIM_DETAIL_CODE4
            FROM E7_STA_REPINST T1
            LEFT JOIN E7_STA_RPT_INDEX_INST T2
              ON T1.REPINST_ID = T2.REPINST_ID
            LEFT JOIN E7_STA_INDEX_INST T3
              ON T2.STA_INDEX_INST_ID = T3.STA_INDEX_INST_ID
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T4
              ON T2.STA_INDEX_INST_ID = T4.STA_INDEX_INST_ID
             AND T4.DIM_CODE = 'Assets_type'
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T5
              ON T2.STA_INDEX_INST_ID = T5.STA_INDEX_INST_ID
             AND T5.DIM_CODE = 'Industry_type'
          
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T7
              ON T2.STA_INDEX_INST_ID = T7.STA_INDEX_INST_ID
             AND T7.DIM_CODE = 'Energy_consu_depos_typ'
          
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T9
              ON T2.STA_INDEX_INST_ID = T9.STA_INDEX_INST_ID
             AND T9.DIM_CODE LIKE 'E_cons_classi%'
          
           WHERE T1.REPORT_CODE = 'C0121'
             AND T1.REPORT_YEAR = P_RPTYEAR
             AND T1.REPORT_MONTH = P_RPTMONTH
             AND T1.ORG_ID IN (SELECT ORG_ID
                                 FROM E7_STA_RPT_AUTH
                                WHERE V_ORG_ID = P_RPTORGID
                                  AND REPORT_CODE = 'C0121'))
  
   group by report_code,
            report_year,
            report_month,
            index_code,
            dim_code1,
            dim_detail_code1,
            dim_code2,
            dim_detail_code2,
            dim_code3,
            dim_detail_code3,
            dim_code4,
            dim_detail_code4),
LOCA_INDEX AS
 (SELECT *
    FROM E7_EXCEL_LOCATIONBYINDEX
   WHERE REPORT_CODE = 'T0005'
     AND IS_PY = 'N'),
LOCA_DIMEN AS
 (SELECT * FROM E7_EXCEL_LOCATIONBYDIMEN WHERE REPORT_CODE = 'T0005'),
LOC_INDEX AS
 (SELECT DATAS.*, LOCA_INDEX.LOCALTION LOCATION_INDEX
    FROM DATAS
    LEFT JOIN LOCA_INDEX
      ON DATAS.INDEX_CODE = LOCA_INDEX.INDEX_CODE),
LOCA_DIMEN1 AS
 (SELECT *
    FROM (SELECT LOC_INDEX.*, DIMEN1.LOCALTION LOCATION_DIMEN1
            FROM LOC_INDEX
            LEFT JOIN LOCA_DIMEN DIMEN1
              ON LOC_INDEX.DIM_DETAIL_CODE1 = DIMEN1.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN1
      OR LOCATION_DIMEN1 IS NULL),
LOCA_DIMEN2 as
 (SELECT *
    FROM (select LOCA_DIMEN1.*, DIMEN2.LOCALTION LOCATION_DIMEN2
            FROM LOCA_DIMEN1
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN2
              ON LOCA_DIMEN1.DIM_CODE2 = DIMEN2.DIM_CODE
             AND LOCA_DIMEN1.DIM_DETAIL_CODE2 = DIMEN2.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN2
      OR LOCATION_DIMEN2 IS NULL),
LOCA_DIMEN3 as
 (SELECT *
    FROM (select LOCA_DIMEN2.*, DIMEN3.LOCALTION LOCATION_DIMEN3
            FROM LOCA_DIMEN2
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN3
              ON LOCA_DIMEN2.DIM_CODE3 = DIMEN3.DIM_CODE
             AND LOCA_DIMEN2.DIM_DETAIL_CODE3 = DIMEN3.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN3
      OR LOCATION_DIMEN3 IS NULL),

LOCA_DIMEN4 as
 (SELECT *
    FROM (select LOCA_DIMEN3.*, DIMEN4.LOCALTION LOCATION_DIMEN4
            FROM LOCA_DIMEN3
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN4
              ON LOCA_DIMEN3.DIM_CODE4 = DIMEN4.DIM_CODE
             AND LOCA_DIMEN3.DIM_DETAIL_CODE4 = DIMEN4.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN4
      OR LOCATION_DIMEN4 IS NULL)
SELECT DISTINCT LOCATION_INDEX,INDEX_VALUE FROM LOCA_DIMEN4
);
        
   BEGIN
   jsonStr := '[';
   FOR V_ENRGY IN return_cursor LOOP
  jsonStr := jsonStr || '{''location'':''' || V_ENRGY.LOCATION_INDEX ||
                 ''',''value'':''' || to_char(V_ENRGY.Index_Value) || '''},';

  END LOOP;
  jsonStr := jsonStr || ']';
  jsonStr := replace(jsonStr,'},]','}]');
  dbms_output.put_line(jsonStr);
  END;  
  procedure getC0121Sum(P_RPTCODE IN VARCHAR2,
            	          P_RPTYEAR  IN VARCHAR2,
                       P_RPTMONTH IN VARCHAR2,
                       P_RPTORGID IN VARCHAR2,jsonStr OUT CLOB) IS
  Cursor return_cursor is
      SELECT *
        FROM (with datas as
 (select report_code,
         report_year,
         report_month,
         index_code,
         sum(index_value) as index_value,
         dim_code1,
         dim_detail_code1,
         dim_code2,
         dim_detail_code2,
         dim_code3,
         dim_detail_code3,
         dim_code4,
         dim_detail_code4
    from (SELECT P_RPTCODE REPORT_CODE,
                 T1.REPORT_YEAR,
                 T1.REPORT_MONTH,
                 T1.ORG_ID,
                 T3.INDEX_CODE,
                 T3.INDEX_VALUE,
                 T4.DIM_CODE AS DIM_CODE1,
                 T4.DIM_DETAIL_CODE AS DIM_DETAIL_CODE1,
                 T5.DIM_CODE AS DIM_CODE2,
                 T5.DIM_DETAIL_CODE AS DIM_DETAIL_CODE2,
                 T7.DIM_CODE AS DIM_CODE3,
                 T7.DIM_DETAIL_CODE AS DIM_DETAIL_CODE3,
                 T9.DIM_CODE AS DIM_CODE4,
                 T9.DIM_DETAIL_CODE AS DIM_DETAIL_CODE4
            FROM E7_STA_REPINST T1
            LEFT JOIN E7_STA_RPT_INDEX_INST T2
              ON T1.REPINST_ID = T2.REPINST_ID
            LEFT JOIN E7_STA_INDEX_INST T3
              ON T2.STA_INDEX_INST_ID = T3.STA_INDEX_INST_ID
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T4
              ON T2.STA_INDEX_INST_ID = T4.STA_INDEX_INST_ID
             AND T4.DIM_CODE = 'Assets_type'
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T5
              ON T2.STA_INDEX_INST_ID = T5.STA_INDEX_INST_ID
             AND T5.DIM_CODE = 'Industry_type'
          
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T7
              ON T2.STA_INDEX_INST_ID = T7.STA_INDEX_INST_ID
             AND T7.DIM_CODE = 'Energy_consu_depos_typ'
          
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T9
              ON T2.STA_INDEX_INST_ID = T9.STA_INDEX_INST_ID
             AND T9.DIM_CODE LIKE 'E_cons_classi%'
          
           WHERE T1.REPORT_CODE = 'C0121'
             AND T1.REPORT_YEAR = P_RPTYEAR
             AND T1.REPORT_MONTH = P_RPTMONTH
             AND T1.ORG_ID IN (SELECT ORG_ID
                                 FROM E7_STA_RPT_AUTH
                                WHERE V_ORG_ID = P_RPTORGID
                                  AND REPORT_CODE = 'C0121'))
  
   group by report_code,
            report_year,
            report_month,
            index_code,
            dim_code1,
            dim_detail_code1,
            dim_code2,
            dim_detail_code2,
            dim_code3,
            dim_detail_code3,
            dim_code4,
            dim_detail_code4),
LOCA_INDEX AS
 (SELECT *
    FROM E7_EXCEL_LOCATIONBYINDEX
   WHERE REPORT_CODE = 'C0121'
     AND IS_PY = 'N'),
LOCA_DIMEN AS
 (SELECT * FROM E7_EXCEL_LOCATIONBYDIMEN WHERE REPORT_CODE = 'C0121'),
LOC_INDEX AS
 (SELECT DATAS.*, LOCA_INDEX.LOCALTION LOCATION_INDEX
    FROM DATAS
    LEFT JOIN LOCA_INDEX
      ON DATAS.INDEX_CODE = LOCA_INDEX.INDEX_CODE),
LOCA_DIMEN1 AS
 (SELECT *
    FROM (SELECT LOC_INDEX.*, DIMEN1.LOCALTION LOCATION_DIMEN1
            FROM LOC_INDEX
            LEFT JOIN LOCA_DIMEN DIMEN1
              ON LOC_INDEX.DIM_DETAIL_CODE1 = DIMEN1.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN1
      OR LOCATION_DIMEN1 IS NULL),
LOCA_DIMEN2 as
 (SELECT *
    FROM (select LOCA_DIMEN1.*, DIMEN2.LOCALTION LOCATION_DIMEN2
            FROM LOCA_DIMEN1
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN2
              ON LOCA_DIMEN1.DIM_CODE2 = DIMEN2.DIM_CODE
             AND LOCA_DIMEN1.DIM_DETAIL_CODE2 = DIMEN2.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN2
      OR LOCATION_DIMEN2 IS NULL),
LOCA_DIMEN3 as
 (SELECT *
    FROM (select LOCA_DIMEN2.*, DIMEN3.LOCALTION LOCATION_DIMEN3
            FROM LOCA_DIMEN2
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN3
              ON LOCA_DIMEN2.DIM_CODE3 = DIMEN3.DIM_CODE
             AND LOCA_DIMEN2.DIM_DETAIL_CODE3 = DIMEN3.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN3
      OR LOCATION_DIMEN3 IS NULL),

LOCA_DIMEN4 as
 (SELECT *
    FROM (select LOCA_DIMEN3.*, DIMEN4.LOCALTION LOCATION_DIMEN4
            FROM LOCA_DIMEN3
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN4
              ON LOCA_DIMEN3.DIM_CODE4 = DIMEN4.DIM_CODE
             AND LOCA_DIMEN3.DIM_DETAIL_CODE4 = DIMEN4.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN4
      OR LOCATION_DIMEN4 IS NULL)
SELECT DISTINCT LOCATION_INDEX,INDEX_VALUE FROM LOCA_DIMEN4
);
        
   BEGIN
   jsonStr := '[';
   FOR V_ENRGY IN return_cursor LOOP
  jsonStr := jsonStr || '{''location'':''' || V_ENRGY.LOCATION_INDEX ||
                 ''',''value'':''' || to_char(V_ENRGY.Index_Value) || '''},';

  END LOOP;
  jsonStr := jsonStr || ']';
  jsonStr := replace(jsonStr,'},]','}]');
  dbms_output.put_line(jsonStr);
  END;     
  
  
  procedure getT0006Sum(P_RPTCODE IN VARCHAR2,
            	          P_RPTYEAR  IN VARCHAR2,
                       P_RPTMONTH IN VARCHAR2,
                       P_RPTORGID IN VARCHAR2,jsonStr OUT CLOB) IS
  Cursor return_cursor is
      SELECT *
        FROM (with datas as
 (select report_code,
         report_year,
         report_month,
         index_code,
         sum(index_value) as index_value,
         dim_code1,
         dim_detail_code1,
         dim_code2,
         dim_detail_code2,
         dim_code3,
         dim_detail_code3
    from (SELECT P_RPTCODE REPORT_CODE,
                 T1.REPORT_YEAR,
                 T1.REPORT_MONTH,
                 T1.ORG_ID,
                 T3.INDEX_CODE,
                 T3.INDEX_VALUE,
                 T4.DIM_CODE AS DIM_CODE1,
                 T4.DIM_DETAIL_CODE AS DIM_DETAIL_CODE1,
                 T5.DIM_CODE AS DIM_CODE2,
                 T5.DIM_DETAIL_CODE AS DIM_DETAIL_CODE2,
                 T7.DIM_CODE AS DIM_CODE3,
                 T7.DIM_DETAIL_CODE AS DIM_DETAIL_CODE3
            FROM E7_STA_REPINST T1
            LEFT JOIN E7_STA_RPT_INDEX_INST T2
              ON T1.REPINST_ID = T2.REPINST_ID
            LEFT JOIN E7_STA_INDEX_INST T3
              ON T2.STA_INDEX_INST_ID = T3.STA_INDEX_INST_ID
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T4
              ON T2.STA_INDEX_INST_ID = T4.STA_INDEX_INST_ID
             AND T4.DIM_CODE = 'Assets_type'
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T5
              ON T2.STA_INDEX_INST_ID = T5.STA_INDEX_INST_ID
             AND T5.DIM_CODE = 'E_convers_typ'
          
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T7
              ON T2.STA_INDEX_INST_ID = T7.STA_INDEX_INST_ID
             AND T7.DIM_CODE = 'Energy_consu_depos_typ'
         
           WHERE T1.REPORT_CODE = 'C0122'
             AND T1.REPORT_YEAR = P_RPTYEAR
             AND T1.REPORT_MONTH = P_RPTMONTH
             AND T1.ORG_ID IN (SELECT ORG_ID
                                 FROM E7_STA_RPT_AUTH
                                WHERE V_ORG_ID = P_RPTORGID
                                  AND REPORT_CODE = 'C0122'))
  
   group by report_code,
            report_year,
            report_month,
            index_code,
            dim_code1,
            dim_detail_code1,
            dim_code2,
            dim_detail_code2,
            dim_code3,
            dim_detail_code3),
LOCA_INDEX AS
 (SELECT *
    FROM E7_EXCEL_LOCATIONBYINDEX
   WHERE REPORT_CODE = 'T0006'
     AND IS_PY = 'N'),
LOCA_DIMEN AS
 (SELECT * FROM E7_EXCEL_LOCATIONBYDIMEN WHERE REPORT_CODE = 'T0006'),
LOC_INDEX AS
 (SELECT DATAS.*, LOCA_INDEX.LOCALTION LOCATION_INDEX
    FROM DATAS
    LEFT JOIN LOCA_INDEX
      ON DATAS.INDEX_CODE = LOCA_INDEX.INDEX_CODE),
LOCA_DIMEN1 AS
 (SELECT *
    FROM (SELECT LOC_INDEX.*, DIMEN1.LOCALTION LOCATION_DIMEN1
            FROM LOC_INDEX
            LEFT JOIN LOCA_DIMEN DIMEN1
              ON LOC_INDEX.DIM_DETAIL_CODE1 = DIMEN1.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN1
      OR LOCATION_DIMEN1 IS NULL),
LOCA_DIMEN2 as
 (SELECT *
    FROM (select LOCA_DIMEN1.*, DIMEN2.LOCALTION LOCATION_DIMEN2
            FROM LOCA_DIMEN1
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN2
              ON LOCA_DIMEN1.DIM_CODE2 = DIMEN2.DIM_CODE
             AND LOCA_DIMEN1.DIM_DETAIL_CODE2 = DIMEN2.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN2
      OR LOCATION_DIMEN2 IS NULL),
LOCA_DIMEN3 as
 (SELECT *
    FROM (select LOCA_DIMEN2.*, DIMEN3.LOCALTION LOCATION_DIMEN3
            FROM LOCA_DIMEN2
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN3
              ON LOCA_DIMEN2.DIM_CODE3 = DIMEN3.DIM_CODE
             AND LOCA_DIMEN2.DIM_DETAIL_CODE3 = DIMEN3.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN3
      OR LOCATION_DIMEN3 IS NULL)


     
SELECT DISTINCT LOCATION_INDEX,INDEX_VALUE FROM LOCA_DIMEN3

);
        
   BEGIN
   jsonStr := '[';
   FOR V_ENRGY IN return_cursor LOOP
  jsonStr := jsonStr || '{''location'':''' || V_ENRGY.LOCATION_INDEX ||
                 ''',''value'':''' || to_char(V_ENRGY.Index_Value) || '''},';

  END LOOP;
  jsonStr := jsonStr || ']';
  jsonStr := replace(jsonStr,'},]','}]');
  dbms_output.put_line(jsonStr);
  END;  
  procedure getC0122Sum(P_RPTCODE IN VARCHAR2,
            	          P_RPTYEAR  IN VARCHAR2,
                       P_RPTMONTH IN VARCHAR2,
                       P_RPTORGID IN VARCHAR2,jsonStr OUT CLOB) IS
  Cursor return_cursor is
      SELECT *
        FROM (with datas as
 (select report_code,
         report_year,
         report_month,
         index_code,
         sum(index_value) as index_value,
         dim_code1,
         dim_detail_code1,
         dim_code2,
         dim_detail_code2,
         dim_code3,
         dim_detail_code3
    from (SELECT P_RPTCODE REPORT_CODE,
                 T1.REPORT_YEAR,
                 T1.REPORT_MONTH,
                 T1.ORG_ID,
                 T3.INDEX_CODE,
                 T3.INDEX_VALUE,
                 T4.DIM_CODE AS DIM_CODE1,
                 T4.DIM_DETAIL_CODE AS DIM_DETAIL_CODE1,
                 T5.DIM_CODE AS DIM_CODE2,
                 T5.DIM_DETAIL_CODE AS DIM_DETAIL_CODE2,
                 T7.DIM_CODE AS DIM_CODE3,
                 T7.DIM_DETAIL_CODE AS DIM_DETAIL_CODE3
            FROM E7_STA_REPINST T1
            LEFT JOIN E7_STA_RPT_INDEX_INST T2
              ON T1.REPINST_ID = T2.REPINST_ID
            LEFT JOIN E7_STA_INDEX_INST T3
              ON T2.STA_INDEX_INST_ID = T3.STA_INDEX_INST_ID
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T4
              ON T2.STA_INDEX_INST_ID = T4.STA_INDEX_INST_ID
             AND T4.DIM_CODE = 'Assets_type'
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T5
              ON T2.STA_INDEX_INST_ID = T5.STA_INDEX_INST_ID
             AND T5.DIM_CODE = 'E_convers_typ'
          
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T7
              ON T2.STA_INDEX_INST_ID = T7.STA_INDEX_INST_ID
             AND T7.DIM_CODE = 'Energy_consu_depos_typ'
         
           WHERE T1.REPORT_CODE = 'C0122'
             AND T1.REPORT_YEAR = P_RPTYEAR
             AND T1.REPORT_MONTH = P_RPTMONTH
             AND T1.ORG_ID IN (SELECT ORG_ID
                                 FROM E7_STA_RPT_AUTH
                                WHERE V_ORG_ID = P_RPTORGID
                                  AND REPORT_CODE = 'C0122'))
  
   group by report_code,
            report_year,
            report_month,
            index_code,
            dim_code1,
            dim_detail_code1,
            dim_code2,
            dim_detail_code2,
            dim_code3,
            dim_detail_code3),
LOCA_INDEX AS
 (SELECT *
    FROM E7_EXCEL_LOCATIONBYINDEX
   WHERE REPORT_CODE = 'C0122'
     AND IS_PY = 'N'),
LOCA_DIMEN AS
 (SELECT * FROM E7_EXCEL_LOCATIONBYDIMEN WHERE REPORT_CODE = 'C0122'),
LOC_INDEX AS
 (SELECT DATAS.*, LOCA_INDEX.LOCALTION LOCATION_INDEX
    FROM DATAS
    LEFT JOIN LOCA_INDEX
      ON DATAS.INDEX_CODE = LOCA_INDEX.INDEX_CODE),
LOCA_DIMEN1 AS
 (SELECT *
    FROM (SELECT LOC_INDEX.*, DIMEN1.LOCALTION LOCATION_DIMEN1
            FROM LOC_INDEX
            LEFT JOIN LOCA_DIMEN DIMEN1
              ON LOC_INDEX.DIM_DETAIL_CODE1 = DIMEN1.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN1
      OR LOCATION_DIMEN1 IS NULL),
LOCA_DIMEN2 as
 (SELECT *
    FROM (select LOCA_DIMEN1.*, DIMEN2.LOCALTION LOCATION_DIMEN2
            FROM LOCA_DIMEN1
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN2
              ON LOCA_DIMEN1.DIM_CODE2 = DIMEN2.DIM_CODE
             AND LOCA_DIMEN1.DIM_DETAIL_CODE2 = DIMEN2.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN2
      OR LOCATION_DIMEN2 IS NULL),
LOCA_DIMEN3 as
 (SELECT *
    FROM (select LOCA_DIMEN2.*, DIMEN3.LOCALTION LOCATION_DIMEN3
            FROM LOCA_DIMEN2
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN3
              ON LOCA_DIMEN2.DIM_CODE3 = DIMEN3.DIM_CODE
             AND LOCA_DIMEN2.DIM_DETAIL_CODE3 = DIMEN3.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN3
      OR LOCATION_DIMEN3 IS NULL)


     
SELECT DISTINCT LOCATION_INDEX,INDEX_VALUE FROM LOCA_DIMEN3

);
        
   BEGIN
   jsonStr := '[';
   FOR V_ENRGY IN return_cursor LOOP
  jsonStr := jsonStr || '{''location'':''' || V_ENRGY.LOCATION_INDEX ||
                 ''',''value'':''' || to_char(V_ENRGY.Index_Value) || '''},';

  END LOOP;
  jsonStr := jsonStr || ']';
  jsonStr := replace(jsonStr,'},]','}]');
  dbms_output.put_line(jsonStr);
  END;  
  procedure getT0007Sum(P_RPTCODE IN VARCHAR2,
            	          P_RPTYEAR  IN VARCHAR2,
                       P_RPTMONTH IN VARCHAR2,
                       P_RPTORGID IN VARCHAR2,jsonStr OUT CLOB) IS
    
    Cursor return_cursor is
      SELECT *
        FROM (WITH DATAS AS
 (SELECT REPORT_CODE,
         REPORT_YEAR,
         REPORT_MONTH,
         INDEX_CODE,
         SUM(INDEX_VALUE) INDEX_VALUE,
         DIM_CODE1,
         DIM_DETAIL_CODE1,
         DIM_CODE2,
         DIM_DETAIL_CODE2,
         DIM_CODE4,
         DIM_DETAIL_CODE4,
         DIM_CODE5,
         DIM_DETAIL_CODE5,
         DIM_CODE6,
         DIM_DETAIL_CODE6
    FROM (SELECT P_RPTCODE REPORT_CODE,
                 T1.REPORT_YEAR,
                 T1.REPORT_MONTH,
                 T1.ORG_ID,
                 T3.INDEX_CODE,
                 T3.INDEX_VALUE,
                 NULL AS DIM_CODE1,
                 NULL AS DIM_DETAIL_CODE1,
                 T5.DIM_CODE AS DIM_CODE2,
                 T5.DIM_DETAIL_CODE AS DIM_DETAIL_CODE2,
                 
                 T7.DIM_CODE AS DIM_CODE4,
                 T7.DIM_DETAIL_CODE AS DIM_DETAIL_CODE4,
                 
                 DECODE(T3.INDEX_CODE,'Engy_csmp_amt_pratl',
                     DECODE(T7.DIM_DETAIL_CODE,
                     'Cru_oil',NVL(T8.DIM_CODE,'Cru_oil_E_cons_typ'),
                     'Natural_gas',NVL(T8.DIM_CODE,'Cru_oil_E_cons_typ'),
                     T8.DIM_CODE),
                     T8.DIM_CODE) AS DIM_CODE5,
                 DECODE(T3.INDEX_CODE,'Engy_csmp_amt_pratl',
                     DECODE(T7.DIM_DETAIL_CODE,
                     'Cru_oil',NVL(T8.DIM_DETAIL_CODE,'Since_the_amo_C'),
                     'Natural_gas',NVL(T8.DIM_DETAIL_CODE,'Since_the_amo_N'),
                     T8.DIM_DETAIL_CODE),
                     T8.DIM_DETAIL_CODE) AS DIM_DETAIL_CODE5,
                 
                 T9.DIM_CODE AS DIM_CODE6,
                 T9.DIM_DETAIL_CODE AS DIM_DETAIL_CODE6
            FROM E7_STA_REPINST T1
            LEFT JOIN E7_STA_RPT_INDEX_INST T2
              ON T1.REPINST_ID = T2.REPINST_ID
            LEFT JOIN E7_STA_INDEX_INST T3
              ON T2.STA_INDEX_INST_ID = T3.STA_INDEX_INST_ID
  
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T5
              ON T2.STA_INDEX_INST_ID = T5.STA_INDEX_INST_ID
             AND T5.DIM_CODE = 'Industry_type'
          
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T7
              ON T2.STA_INDEX_INST_ID = T7.STA_INDEX_INST_ID
             AND T7.DIM_CODE = 'Cru_oil_E_cons_typ'
             AND T7.DIM_DETAIL_CODE IN
                 (SELECT DIM_DETAIL_CODE
                    FROM E7_STA_DIM_DETAIL D
                   WHERE D.DIM_CODE = 'Cru_oil_E_cons_typ'
                     AND D.PARENT_DIM_DETAIL_CODE IS NULL)
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T8
              ON T2.STA_INDEX_INST_ID = T8.STA_INDEX_INST_ID
             AND T8.DIM_CODE = 'Cru_oil_E_cons_typ'
             AND T8.DIM_DETAIL_CODE <> T7.DIM_DETAIL_CODE
             
             LEFT JOIN E7_STA_INDEX_INST_DIMEN T9
             ON T2.STA_INDEX_INST_ID = T9.STA_INDEX_INST_ID
             AND T9.DIM_CODE = 'Crude_oil_alter_typ'
             
           WHERE T1.REPORT_CODE IN( 'T0008','T0009','T0010','T0011','T0012','T0013','T0014','T0015','T0016','T0017','T0018','T0019','T0020','T0021','T0022')
             AND T3.INDEX_CODE NOT IN ('Stadc_coef','Engy_csmp_unit_pric')
             AND T1.REPORT_YEAR = P_RPTYEAR
             AND T1.REPORT_MONTH = P_RPTMONTH
             AND T1.ORG_ID IN P_RPTORGID)
   GROUP BY REPORT_CODE,
            REPORT_YEAR,
            REPORT_MONTH,
            INDEX_CODE,
            DIM_CODE1,
            DIM_DETAIL_CODE1,
            DIM_CODE2,
            DIM_DETAIL_CODE2,
            DIM_CODE4,
            DIM_DETAIL_CODE4,
            DIM_CODE5,
            DIM_DETAIL_CODE5,
            DIM_CODE6,
            DIM_DETAIL_CODE6
            )      , 
DATA_AMT AS
 (SELECT 
  REPORT_CODE,
 REPORT_YEAR,
 REPORT_MONTH,
 INDEX_CODE,
 SUM(NVL(INDEX_VALUE,0)) INDEX_VALUE,
 NULL DIM_CODE1,
 NULL DIM_DETAIL_CODE1,
 NULL DIM_CODE2,
 NULL DIM_DETAIL_CODE2,
 DIM_CODE4,
 DIM_DETAIL_CODE4,
 NULL DIM_CODE5,
 NULL DIM_DETAIL_CODE5,
 DIM_CODE6,
 DIM_DETAIL_CODE6
  FROM DATAS WHERE INDEX_CODE = 'Engy_csmp_amt_pratl'
  GROUP BY 
  REPORT_CODE,
 REPORT_YEAR,
 REPORT_MONTH,
 INDEX_CODE,
 DIM_CODE2,
 DIM_DETAIL_CODE2,
 DIM_CODE4,
 DIM_DETAIL_CODE4,
 DIM_CODE5,
 DIM_DETAIL_CODE5,
 DIM_CODE6,
 DIM_DETAIL_CODE6),
DATA_COST AS
 (SELECT 

  REPORT_CODE,
 REPORT_YEAR,
 REPORT_MONTH,
 INDEX_CODE,
 SUM(NVL(INDEX_VALUE,0)) INDEX_VALUE,
 NULL DIM_CODE1,
 NULL DIM_DETAIL_CODE1,
 NULL DIM_CODE2,
 NULL DIM_DETAIL_CODE2,
 DIM_CODE4,
 DIM_DETAIL_CODE4,
 NULL DIM_CODE5,
 NULL DIM_DETAIL_CODE5,
 DIM_CODE6,
 DIM_DETAIL_CODE6
  FROM DATAS WHERE INDEX_CODE = 'Engy_csmp_cost'
 GROUP BY 
  REPORT_CODE,
 REPORT_YEAR,
 REPORT_MONTH,
 INDEX_CODE,
 DIM_CODE2,
 DIM_DETAIL_CODE2,
 DIM_CODE4,
 DIM_DETAIL_CODE4,
 DIM_CODE5,
 DIM_DETAIL_CODE5,
 DIM_CODE6,
 DIM_DETAIL_CODE6),
DATA_PRICE AS
 (SELECT DATA_AMT.REPORT_CODE,
         DATA_AMT.REPORT_YEAR,
         DATA_AMT.REPORT_MONTH,
         'Engy_csmp_unit_pric' INDEX_CODE,
        DECODE(SUM(DATA_AMT.INDEX_VALUE),0,0,  ROUND(sum(DATA_COST.INDEX_VALUE) * 10000 / sum(DATA_AMT.INDEX_VALUE), 4)) INDEX_VALUE,
         null DIM_CODE1,
         null DIM_DETAIL_CODE1,
         null DIM_CODE2,
         null DIM_DETAIL_CODE2,
         DATA_AMT.DIM_CODE4,
         DATA_AMT.DIM_DETAIL_CODE4,
         null DIM_CODE5,
         null DIM_DETAIL_CODE5,
         null DIM_CODE6,
         null DIM_DETAIL_CODE6
    FROM DATA_AMT
    LEFT JOIN DATA_COST
      ON DATA_AMT.REPORT_CODE = DATA_COST.REPORT_CODE
     AND DATA_AMT.REPORT_YEAR = DATA_COST.REPORT_YEAR
     AND DATA_AMT.REPORT_MONTH = DATA_COST.REPORT_MONTH
   
     AND DATA_AMT.DIM_DETAIL_CODE4 = DATA_COST.DIM_DETAIL_CODE4
      group by 
      DATA_AMT.REPORT_CODE,
         DATA_AMT.REPORT_YEAR,
         DATA_AMT.REPORT_MONTH,
         DATA_AMT.DIM_CODE1,
         DATA_AMT.DIM_DETAIL_CODE1,
         DATA_AMT.DIM_CODE4,
         DATA_AMT.DIM_DETAIL_CODE4),
RESULTS AS
 (SELECT * FROM DATAS),

LOCA_INDEX AS
 (SELECT *
    FROM E7_EXCEL_LOCATIONBYINDEX
   WHERE REPORT_CODE = 'T0007'
     AND IS_PY = 'N'),
LOCA_DIMEN AS
 (SELECT * FROM E7_EXCEL_LOCATIONBYDIMEN 
 WHERE REPORT_CODE = 'T0007' and LOCALTION IN (
       SELECT LOCALTION FROM LOCA_INDEX
 )),
LOC_INDEX AS
 (SELECT RESULTS.*, LOCA_INDEX.LOCALTION LOCATION_INDEX
    FROM RESULTS
    LEFT JOIN LOCA_INDEX
      ON RESULTS.INDEX_CODE = LOCA_INDEX.INDEX_CODE),
LOCA_DIMEN1 AS
 (SELECT *
    FROM (SELECT LOC_INDEX.*, DIMEN1.LOCALTION LOCATION_DIMEN1
            FROM LOC_INDEX
            LEFT JOIN LOCA_DIMEN DIMEN1
              ON LOC_INDEX.DIM_DETAIL_CODE1 = DIMEN1.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN1
      OR LOCATION_DIMEN1 IS NULL),
LOCA_DIMEN2 as
 (SELECT *
    FROM (select LOCA_DIMEN1.*, DIMEN2.LOCALTION LOCATION_DIMEN2
            FROM LOCA_DIMEN1
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN2
              ON LOCA_DIMEN1.DIM_CODE2 = DIMEN2.DIM_CODE
             AND LOCA_DIMEN1.DIM_DETAIL_CODE2 = DIMEN2.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN2
      OR LOCATION_DIMEN2 IS NULL),
LOCA_DIMEN3 as
 (SELECT *
    FROM (select LOCA_DIMEN2.*, DIMEN3.LOCALTION LOCATION_DIMEN3
            FROM LOCA_DIMEN2
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN3
              ON LOCA_DIMEN2.DIM_CODE4 = DIMEN3.DIM_CODE
             AND LOCA_DIMEN2.DIM_DETAIL_CODE4 = DIMEN3.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN3
      OR LOCATION_DIMEN3 IS NULL),
LOCA_DIMEN4 as
 (SELECT *
    FROM (select LOCA_DIMEN3.*, DIMEN4.LOCALTION LOCATION_DIMEN4
            FROM LOCA_DIMEN3
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN4
              ON LOCA_DIMEN3.DIM_CODE5 = DIMEN4.DIM_CODE
             AND LOCA_DIMEN3.DIM_DETAIL_CODE5 = DIMEN4.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN4
      OR LOCATION_DIMEN4 IS NULL), 
LOCA_DIMEN5 as
 (SELECT *
    FROM (select LOCA_DIMEN4.*, DIMEN5.LOCALTION LOCATION_DIMEN5
            FROM LOCA_DIMEN4
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN5
              ON LOCA_DIMEN4.DIM_CODE6 = DIMEN5.DIM_CODE
             AND LOCA_DIMEN4.DIM_DETAIL_CODE6 = DIMEN5.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN5
      OR LOCATION_DIMEN5 IS NULL),
loca_indexprice as
 (
  
  SELECT DATA_PRICE.*, LOCA_INDEX.LOCALTION LOCATION_INDEX
    FROM DATA_PRICE
    LEFT JOIN LOCA_INDEX
      ON DATA_PRICE.INDEX_CODE = LOCA_INDEX.INDEX_CODE),
loca_dimenprice as
 (
  
  SELECT *
    FROM (select loca_indexprice.*,
                  null LOCATION_DIMEN1,
                  null LOCATION_DIMEN2,
                  null LOCATION_DIMEN3,
                  null LOCATION_DIMEN4,
                  DIMEN3.LOCALTION LOCATION_DIMENPRICE
             FROM loca_indexprice
             LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN3
               ON loca_indexprice.DIM_CODE4 = DIMEN3.DIM_CODE
              AND loca_indexprice.DIM_DETAIL_CODE4 = DIMEN3.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMENPRICE
      OR LOCATION_DIMENPRICE IS NULL),
ALLRESULTS AS
 (SELECT * FROM LOCA_DIMEN5 
 UNION ALL SELECT * FROM LOCA_DIMENPRICE
 )
SELECT DISTINCT LOCATION_INDEX, sum(INDEX_VALUE) INDEX_VALUE FROM ALLRESULTS WHERE LOCATION_INDEX IS NOT NULL GROUP BY LOCATION_INDEX

);
BEGIN
jsonStr := '[';
FOR V_ENRGY IN return_cursor LOOP
  jsonStr := jsonStr || '{''location'':''' || V_ENRGY.LOCATION_INDEX ||
                 ''',''value'':''' || to_char(V_ENRGY.Index_Value) || '''},';

  END LOOP;
  jsonStr := jsonStr || ']';
  jsonStr := replace(jsonStr,'},]','}]');
  dbms_output.put_line(jsonStr);
  END;
  procedure getT0008Sum(P_RPTCODE IN VARCHAR2,
            	          P_RPTYEAR  IN VARCHAR2,
                       P_RPTMONTH IN VARCHAR2,
                       P_RPTORGID IN VARCHAR2,jsonStr OUT CLOB) IS
    
    Cursor return_cursor is
      SELECT *
        FROM (WITH DATAS AS
 (SELECT REPORT_CODE,
         REPORT_YEAR,
         REPORT_MONTH,
         INDEX_CODE,
         SUM(INDEX_VALUE) INDEX_VALUE,
         DIM_CODE1,
         DIM_DETAIL_CODE1,
         DIM_CODE2,
         DIM_DETAIL_CODE2,
         DIM_CODE4,
         DIM_DETAIL_CODE4,
         DIM_CODE5,
         DIM_DETAIL_CODE5,
         DIM_CODE6,
         DIM_DETAIL_CODE6
    FROM (SELECT P_RPTCODE REPORT_CODE,
                 T1.REPORT_YEAR,
                 T1.REPORT_MONTH,
                 T1.ORG_ID,
                 T3.INDEX_CODE,
                 T3.INDEX_VALUE,
                 T4.DIM_CODE AS DIM_CODE1,
                 DECODE(T4.DIM_DETAIL_CODE,
                        'Transportation',
                        'Other',
                        'Office',
                        'Other',
                        T4.DIM_DETAIL_CODE) AS DIM_DETAIL_CODE1,
                 DECODE(T3.INDEX_CODE,'Replace_oil_engy_amt','Industry_type',T5.DIM_CODE) AS DIM_CODE2,
                 DECODE(T3.INDEX_CODE,'Replace_oil_engy_amt','Industry',T3.T5.DIM_DETAIL_CODE) AS DIM_DETAIL_CODE2,
                 T7.DIM_CODE AS DIM_CODE4,
                 T7.DIM_DETAIL_CODE AS DIM_DETAIL_CODE4,
                 T8.DIM_CODE AS DIM_CODE5,
                 T8.DIM_DETAIL_CODE AS DIM_DETAIL_CODE5,
                 T9.DIM_CODE AS DIM_CODE6,
                 T9.DIM_DETAIL_CODE AS DIM_DETAIL_CODE6
            FROM E7_STA_REPINST T1
            LEFT JOIN E7_STA_RPT_INDEX_INST T2
              ON T1.REPINST_ID = T2.REPINST_ID
            LEFT JOIN E7_STA_INDEX_INST T3
              ON T2.STA_INDEX_INST_ID = T3.STA_INDEX_INST_ID
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T4
              ON T2.STA_INDEX_INST_ID = T4.STA_INDEX_INST_ID
             AND T4.DIM_CODE LIKE '%_link'
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T5
              ON T4.STA_INDEX_INST_ID = T5.STA_INDEX_INST_ID
             AND T5.DIM_CODE = 'Industry_type'
          
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T7
              ON T2.STA_INDEX_INST_ID = T7.STA_INDEX_INST_ID
             AND T7.DIM_CODE = 'Cru_oil_E_cons_typ'
             AND T7.DIM_DETAIL_CODE IN
                 (SELECT DIM_DETAIL_CODE
                    FROM E7_STA_DIM_DETAIL D
                   WHERE D.DIM_CODE = 'Cru_oil_E_cons_typ'
                     AND D.PARENT_DIM_DETAIL_CODE IS NULL)
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T8
              ON T2.STA_INDEX_INST_ID = T8.STA_INDEX_INST_ID
             AND T8.DIM_CODE = 'Cru_oil_E_cons_typ'
             AND T8.DIM_DETAIL_CODE <> T7.DIM_DETAIL_CODE
             
             LEFT JOIN E7_STA_INDEX_INST_DIMEN T9
             ON T2.STA_INDEX_INST_ID = T9.STA_INDEX_INST_ID
             AND T9.DIM_CODE = 'Crude_oil_alter_typ'
             
           WHERE T1.REPORT_CODE IN( 'C0007','C0010')
             AND T3.INDEX_CODE NOT IN ('Stadc_coef')
             AND (T5.DIM_DETAIL_CODE = 'Industry' 
             OR T5.DIM_DETAIL_CODE IS NULL)
             AND T1.REPORT_YEAR = P_RPTYEAR
             AND T1.REPORT_MONTH = P_RPTMONTH
             AND T1.ORG_ID IN (SELECT ORG_ID
                                 FROM E7_STA_RPT_AUTH
                                WHERE V_ORG_ID = P_RPTORGID
                                  AND REPORT_CODE = 'C0007'))
   GROUP BY REPORT_CODE,
            REPORT_YEAR,
            REPORT_MONTH,
            INDEX_CODE,
            DIM_CODE1,
            DIM_DETAIL_CODE1,
            DIM_CODE2,
            DIM_DETAIL_CODE2,
            DIM_CODE4,
            DIM_DETAIL_CODE4,
            DIM_CODE5,
            DIM_DETAIL_CODE5,
            DIM_CODE6,
            DIM_DETAIL_CODE6
            ),         
DATA_AMT AS
 (SELECT * FROM DATAS WHERE INDEX_CODE = 'Engy_csmp_amt_pratl'),
DATA_COST AS
 (SELECT * FROM DATAS WHERE INDEX_CODE = 'Engy_csmp_cost'),
DATA_PRICE AS
 (SELECT DATA_AMT.REPORT_CODE,
         DATA_AMT.REPORT_YEAR,
         DATA_AMT.REPORT_MONTH,
         'Engy_csmp_unit_pric' INDEX_CODE,
        DECODE(SUM(DATA_AMT.INDEX_VALUE),0,0,  ROUND(sum(DATA_COST.INDEX_VALUE) * 10000 / sum(DATA_AMT.INDEX_VALUE), 4)) INDEX_VALUE,
         DATA_AMT.DIM_CODE1,
         DATA_AMT.DIM_DETAIL_CODE1,
         null DIM_CODE2,
         null DIM_DETAIL_CODE2,
         DATA_AMT.DIM_CODE4,
         DATA_AMT.DIM_DETAIL_CODE4,
         null DIM_CODE5,
         null DIM_DETAIL_CODE5,
         null DIM_CODE6,
         null DIM_DETAIL_CODE6
    FROM DATA_AMT
    LEFT JOIN DATA_COST
      ON DATA_AMT.REPORT_CODE = DATA_COST.REPORT_CODE
     AND DATA_AMT.REPORT_YEAR = DATA_COST.REPORT_YEAR
     AND DATA_AMT.REPORT_MONTH = DATA_COST.REPORT_MONTH
     AND DATA_AMT.DIM_DETAIL_CODE1 = DATA_COST.DIM_DETAIL_CODE1
     AND DATA_AMT.DIM_DETAIL_CODE4 = DATA_COST.DIM_DETAIL_CODE4
      group by 
      DATA_AMT.REPORT_CODE,
         DATA_AMT.REPORT_YEAR,
         DATA_AMT.REPORT_MONTH,
         DATA_AMT.DIM_CODE1,
         DATA_AMT.DIM_DETAIL_CODE1,
         DATA_AMT.DIM_CODE4,
         DATA_AMT.DIM_DETAIL_CODE4),
RESULTS AS
 (SELECT * FROM DATAS),

LOCA_INDEX AS
 (SELECT *
    FROM E7_EXCEL_LOCATIONBYINDEX
   WHERE REPORT_CODE = P_RPTCODE
     AND IS_PY = 'N'),
LOCA_DIMEN AS
 (SELECT * FROM E7_EXCEL_LOCATIONBYDIMEN 
 WHERE REPORT_CODE = P_RPTCODE and LOCALTION IN (
       SELECT LOCALTION FROM LOCA_INDEX
 )),
LOC_INDEX AS
 (SELECT RESULTS.*, LOCA_INDEX.LOCALTION LOCATION_INDEX
    FROM RESULTS
    LEFT JOIN LOCA_INDEX
      ON RESULTS.INDEX_CODE = LOCA_INDEX.INDEX_CODE),
LOCA_DIMEN1 AS
 (SELECT *
    FROM (SELECT LOC_INDEX.*, DIMEN1.LOCALTION LOCATION_DIMEN1
            FROM LOC_INDEX
            LEFT JOIN LOCA_DIMEN DIMEN1
              ON LOC_INDEX.DIM_DETAIL_CODE1 = DIMEN1.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN1
      OR LOCATION_DIMEN1 IS NULL),
LOCA_DIMEN2 as
 (SELECT *
    FROM (select LOCA_DIMEN1.*, DIMEN2.LOCALTION LOCATION_DIMEN2
            FROM LOCA_DIMEN1
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN2
              ON LOCA_DIMEN1.DIM_CODE2 = DIMEN2.DIM_CODE
             AND LOCA_DIMEN1.DIM_DETAIL_CODE2 = DIMEN2.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN2
      OR LOCATION_DIMEN2 IS NULL),
LOCA_DIMEN3 as
 (SELECT *
    FROM (select LOCA_DIMEN2.*, DIMEN3.LOCALTION LOCATION_DIMEN3
            FROM LOCA_DIMEN2
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN3
              ON LOCA_DIMEN2.DIM_CODE4 = DIMEN3.DIM_CODE
             AND LOCA_DIMEN2.DIM_DETAIL_CODE4 = DIMEN3.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN3
      OR LOCATION_DIMEN3 IS NULL),
LOCA_DIMEN4 as
 (SELECT *
    FROM (select LOCA_DIMEN3.*, DIMEN4.LOCALTION LOCATION_DIMEN4
            FROM LOCA_DIMEN3
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN4
              ON LOCA_DIMEN3.DIM_CODE5 = DIMEN4.DIM_CODE
             AND LOCA_DIMEN3.DIM_DETAIL_CODE5 = DIMEN4.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN4
      OR LOCATION_DIMEN4 IS NULL), 
LOCA_DIMEN5 as
 (SELECT *
    FROM (select LOCA_DIMEN4.*, DIMEN5.LOCALTION LOCATION_DIMEN5
            FROM LOCA_DIMEN4
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN5
              ON LOCA_DIMEN4.DIM_CODE6 = DIMEN5.DIM_CODE
             AND LOCA_DIMEN4.DIM_DETAIL_CODE6 = DIMEN5.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN5
      OR LOCATION_DIMEN5 IS NULL),       
loca_indexprice as
 (
  
  SELECT DATA_PRICE.*, LOCA_INDEX.LOCALTION LOCATION_INDEX
    FROM DATA_PRICE
    LEFT JOIN LOCA_INDEX
      ON DATA_PRICE.INDEX_CODE = LOCA_INDEX.INDEX_CODE),
loca_dimenprice as
 (
  
  SELECT *
    FROM (select loca_indexprice.*,
                  null LOCATION_DIMEN1,
                  null LOCATION_DIMEN2,
                  null LOCATION_DIMEN3,
                  null LOCATION_DIMEN4,
                  DIMEN3.LOCALTION LOCATION_DIMENPRICE
             FROM loca_indexprice
             LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN3
               ON loca_indexprice.DIM_CODE4 = DIMEN3.DIM_CODE
              AND loca_indexprice.DIM_DETAIL_CODE4 = DIMEN3.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMENPRICE
      OR LOCATION_DIMENPRICE IS NULL),
ALLRESULTS AS
 (SELECT * FROM LOCA_DIMEN5 
 UNION ALL SELECT * FROM LOCA_DIMENPRICE
 )
SELECT DISTINCT LOCATION_INDEX, INDEX_VALUE FROM ALLRESULTS WHERE LOCATION_INDEX IS NOT NULL
);
BEGIN
jsonStr := '[';
FOR V_ENRGY IN return_cursor LOOP
  jsonStr := jsonStr || '{''location'':''' || V_ENRGY.LOCATION_INDEX ||
                 ''',''value'':''' || to_char(V_ENRGY.Index_Value) || '''},';

  END LOOP;
  jsonStr := jsonStr || ']';
  jsonStr := replace(jsonStr,'},]','}]');
  dbms_output.put_line(jsonStr);
  END;
  
  procedure getT0009Sum(P_RPTCODE IN VARCHAR2,
            	          P_RPTYEAR  IN VARCHAR2,
                       P_RPTMONTH IN VARCHAR2,
                       P_RPTORGID IN VARCHAR2,jsonStr OUT CLOB) IS
    
    Cursor return_cursor is
      SELECT *
        FROM (WITH DATAS AS
 (SELECT REPORT_CODE,
         REPORT_YEAR,
         REPORT_MONTH,
         INDEX_CODE,
         SUM(INDEX_VALUE) INDEX_VALUE,
         DIM_CODE1,
         DIM_DETAIL_CODE1,
         DIM_CODE2,
         DIM_DETAIL_CODE2,
         DIM_CODE4,
         DIM_DETAIL_CODE4,
         DIM_CODE5,
         DIM_DETAIL_CODE5,
         DIM_CODE6,
         DIM_DETAIL_CODE6
    FROM (SELECT P_RPTCODE REPORT_CODE,
                 T1.REPORT_YEAR,
                 T1.REPORT_MONTH,
                 T1.ORG_ID,
                 T3.INDEX_CODE,
                 T3.INDEX_VALUE,
                 T4.DIM_CODE AS DIM_CODE1,
                 DECODE(T4.DIM_DETAIL_CODE,
                        'Transportation',
                        'Other',
                        'Office',
                        'Other',
                        'Injection_polymer',
                        'Other',
                        T4.DIM_DETAIL_CODE) AS DIM_DETAIL_CODE1,
                 DECODE(T3.INDEX_CODE,'Replace_oil_engy_amt','Industry_type',T5.DIM_CODE) AS DIM_CODE2,
                 DECODE(T3.INDEX_CODE,'Replace_oil_engy_amt','Industry',T3.T5.DIM_DETAIL_CODE) AS DIM_DETAIL_CODE2,
                 T7.DIM_CODE AS DIM_CODE4,
                 T7.DIM_DETAIL_CODE AS DIM_DETAIL_CODE4,
                 T8.DIM_CODE AS DIM_CODE5,
                 T8.DIM_DETAIL_CODE AS DIM_DETAIL_CODE5,
                 T9.DIM_CODE AS DIM_CODE6,
                 T9.DIM_DETAIL_CODE AS DIM_DETAIL_CODE6
            FROM E7_STA_REPINST T1
            LEFT JOIN E7_STA_RPT_INDEX_INST T2
              ON T1.REPINST_ID = T2.REPINST_ID
            LEFT JOIN E7_STA_INDEX_INST T3
              ON T2.STA_INDEX_INST_ID = T3.STA_INDEX_INST_ID
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T4
              ON T2.STA_INDEX_INST_ID = T4.STA_INDEX_INST_ID
             AND T4.DIM_CODE LIKE '%_link'
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T5
              ON T4.STA_INDEX_INST_ID = T5.STA_INDEX_INST_ID
             AND T5.DIM_CODE = 'Industry_type'
          
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T7
              ON T2.STA_INDEX_INST_ID = T7.STA_INDEX_INST_ID
             AND T7.DIM_CODE = 'Cru_oil_E_cons_typ'
             AND T7.DIM_DETAIL_CODE IN
                 (SELECT DIM_DETAIL_CODE
                    FROM E7_STA_DIM_DETAIL D
                   WHERE D.DIM_CODE = 'Cru_oil_E_cons_typ'
                     AND D.PARENT_DIM_DETAIL_CODE IS NULL)
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T8
              ON T2.STA_INDEX_INST_ID = T8.STA_INDEX_INST_ID
             AND T8.DIM_CODE = 'Cru_oil_E_cons_typ'
             AND T8.DIM_DETAIL_CODE <> T7.DIM_DETAIL_CODE
             
             LEFT JOIN E7_STA_INDEX_INST_DIMEN T9
             ON T2.STA_INDEX_INST_ID = T9.STA_INDEX_INST_ID
             AND T9.DIM_CODE = 'Crude_oil_alter_typ'
             
           WHERE T1.REPORT_CODE IN( 'C0002','C0005')
             AND T3.INDEX_CODE NOT IN ('Stadc_coef')
             AND (T5.DIM_DETAIL_CODE = 'Industry' 
             OR T5.DIM_DETAIL_CODE IS NULL)
             AND T1.REPORT_YEAR = P_RPTYEAR
             AND T1.REPORT_MONTH = P_RPTMONTH
             AND T1.ORG_ID IN (SELECT ORG_ID
                                 FROM E7_STA_RPT_AUTH
                                WHERE V_ORG_ID = P_RPTORGID
                                  AND REPORT_CODE = 'C0002'))
   GROUP BY REPORT_CODE,
            REPORT_YEAR,
            REPORT_MONTH,
            INDEX_CODE,
            DIM_CODE1,
            DIM_DETAIL_CODE1,
            DIM_CODE2,
            DIM_DETAIL_CODE2,
            DIM_CODE4,
            DIM_DETAIL_CODE4,
            DIM_CODE5,
            DIM_DETAIL_CODE5,
            DIM_CODE6,
            DIM_DETAIL_CODE6
            ),         
DATA_AMT AS
 (SELECT * FROM DATAS WHERE INDEX_CODE = 'Engy_csmp_amt_pratl'),
DATA_COST AS
 (SELECT * FROM DATAS WHERE INDEX_CODE = 'Engy_csmp_cost'),
DATA_PRICE AS
 (SELECT DATA_AMT.REPORT_CODE,
         DATA_AMT.REPORT_YEAR,
         DATA_AMT.REPORT_MONTH,
         'Engy_csmp_unit_pric' INDEX_CODE,
        DECODE(SUM(DATA_AMT.INDEX_VALUE),0,0,  ROUND(sum(DATA_COST.INDEX_VALUE) * 10000 / sum(DATA_AMT.INDEX_VALUE), 4)) INDEX_VALUE,
         DATA_AMT.DIM_CODE1,
         DATA_AMT.DIM_DETAIL_CODE1,
         null DIM_CODE2,
         null DIM_DETAIL_CODE2,
         DATA_AMT.DIM_CODE4,
         DATA_AMT.DIM_DETAIL_CODE4,
         null DIM_CODE5,
         null DIM_DETAIL_CODE5,
         null DIM_CODE6,
         null DIM_DETAIL_CODE6
    FROM DATA_AMT
    LEFT JOIN DATA_COST
      ON DATA_AMT.REPORT_CODE = DATA_COST.REPORT_CODE
     AND DATA_AMT.REPORT_YEAR = DATA_COST.REPORT_YEAR
     AND DATA_AMT.REPORT_MONTH = DATA_COST.REPORT_MONTH
     AND DATA_AMT.DIM_DETAIL_CODE1 = DATA_COST.DIM_DETAIL_CODE1
     AND DATA_AMT.DIM_DETAIL_CODE4 = DATA_COST.DIM_DETAIL_CODE4
     group by 
      DATA_AMT.REPORT_CODE,
         DATA_AMT.REPORT_YEAR,
         DATA_AMT.REPORT_MONTH,
         DATA_AMT.DIM_CODE1,
         DATA_AMT.DIM_DETAIL_CODE1,
         DATA_AMT.DIM_CODE4,
         DATA_AMT.DIM_DETAIL_CODE4),
RESULTS AS
 (SELECT * FROM DATAS),

LOCA_INDEX AS
 (SELECT *
    FROM E7_EXCEL_LOCATIONBYINDEX
   WHERE REPORT_CODE = P_RPTCODE
     AND IS_PY = 'N'),
LOCA_DIMEN AS
 (SELECT * FROM E7_EXCEL_LOCATIONBYDIMEN 
 WHERE REPORT_CODE = P_RPTCODE and LOCALTION IN (
       SELECT LOCALTION FROM LOCA_INDEX
 )),
LOC_INDEX AS
 (SELECT RESULTS.*, LOCA_INDEX.LOCALTION LOCATION_INDEX
    FROM RESULTS
    LEFT JOIN LOCA_INDEX
      ON RESULTS.INDEX_CODE = LOCA_INDEX.INDEX_CODE),
LOCA_DIMEN1 AS
 (SELECT *
    FROM (SELECT LOC_INDEX.*, DIMEN1.LOCALTION LOCATION_DIMEN1
            FROM LOC_INDEX
            LEFT JOIN LOCA_DIMEN DIMEN1
              ON LOC_INDEX.DIM_DETAIL_CODE1 = DIMEN1.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN1
      OR LOCATION_DIMEN1 IS NULL),
LOCA_DIMEN2 as
 (SELECT *
    FROM (select LOCA_DIMEN1.*, DIMEN2.LOCALTION LOCATION_DIMEN2
            FROM LOCA_DIMEN1
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN2
              ON LOCA_DIMEN1.DIM_CODE2 = DIMEN2.DIM_CODE
             AND LOCA_DIMEN1.DIM_DETAIL_CODE2 = DIMEN2.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN2
      OR LOCATION_DIMEN2 IS NULL),
LOCA_DIMEN3 as
 (SELECT *
    FROM (select LOCA_DIMEN2.*, DIMEN3.LOCALTION LOCATION_DIMEN3
            FROM LOCA_DIMEN2
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN3
              ON LOCA_DIMEN2.DIM_CODE4 = DIMEN3.DIM_CODE
             AND LOCA_DIMEN2.DIM_DETAIL_CODE4 = DIMEN3.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN3
      OR LOCATION_DIMEN3 IS NULL),
LOCA_DIMEN4 as
 (SELECT *
    FROM (select LOCA_DIMEN3.*, DIMEN4.LOCALTION LOCATION_DIMEN4
            FROM LOCA_DIMEN3
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN4
              ON LOCA_DIMEN3.DIM_CODE5 = DIMEN4.DIM_CODE
             AND LOCA_DIMEN3.DIM_DETAIL_CODE5 = DIMEN4.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN4
      OR LOCATION_DIMEN4 IS NULL), 
LOCA_DIMEN5 as
 (SELECT *
    FROM (select LOCA_DIMEN4.*, DIMEN5.LOCALTION LOCATION_DIMEN5
            FROM LOCA_DIMEN4
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN5
              ON LOCA_DIMEN4.DIM_CODE6 = DIMEN5.DIM_CODE
             AND LOCA_DIMEN4.DIM_DETAIL_CODE6 = DIMEN5.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN5
      OR LOCATION_DIMEN5 IS NULL),       
loca_indexprice as
 (
  
  SELECT DATA_PRICE.*, LOCA_INDEX.LOCALTION LOCATION_INDEX
    FROM DATA_PRICE
    LEFT JOIN LOCA_INDEX
      ON DATA_PRICE.INDEX_CODE = LOCA_INDEX.INDEX_CODE),
loca_dimenprice as
 (
  
  SELECT *
    FROM (select loca_indexprice.*,
                  null LOCATION_DIMEN1,
                  null LOCATION_DIMEN2,
                  null LOCATION_DIMEN3,
                  null LOCATION_DIMEN4,
                  DIMEN3.LOCALTION LOCATION_DIMENPRICE
             FROM loca_indexprice
             LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN3
               ON loca_indexprice.DIM_CODE4 = DIMEN3.DIM_CODE
              AND loca_indexprice.DIM_DETAIL_CODE4 = DIMEN3.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMENPRICE
      OR LOCATION_DIMENPRICE IS NULL),
ALLRESULTS AS
 (SELECT * FROM LOCA_DIMEN5 
 UNION ALL SELECT * FROM LOCA_DIMENPRICE
 )
SELECT DISTINCT LOCATION_INDEX, INDEX_VALUE FROM ALLRESULTS WHERE LOCATION_INDEX IS NOT NULL
);
BEGIN
jsonStr := '[';
FOR V_ENRGY IN return_cursor LOOP
  jsonStr := jsonStr || '{''location'':''' || V_ENRGY.LOCATION_INDEX ||
                 ''',''value'':''' || to_char(V_ENRGY.Index_Value) || '''},';

  END LOOP;
  jsonStr := jsonStr || ']';
  jsonStr := replace(jsonStr,'},]','}]');
  dbms_output.put_line(jsonStr);
  END;
  
  procedure getT0010Sum(P_RPTCODE IN VARCHAR2,
            	          P_RPTYEAR  IN VARCHAR2,
                       P_RPTMONTH IN VARCHAR2,
                       P_RPTORGID IN VARCHAR2,jsonStr OUT CLOB) IS
    
    Cursor return_cursor is
      SELECT *
        FROM (WITH DATAS AS
 (SELECT REPORT_CODE,
         REPORT_YEAR,
         REPORT_MONTH,
         INDEX_CODE,
         SUM(INDEX_VALUE) INDEX_VALUE,
         DIM_CODE1,
         DIM_DETAIL_CODE1,
         DIM_CODE2,
         DIM_DETAIL_CODE2,
         DIM_CODE4,
         DIM_DETAIL_CODE4,
         DIM_CODE5,
         DIM_DETAIL_CODE5,
         DIM_CODE6,
         DIM_DETAIL_CODE6
    FROM (SELECT P_RPTCODE REPORT_CODE,
                 T1.REPORT_YEAR,
                 T1.REPORT_MONTH,
                 T1.ORG_ID,
                 T3.INDEX_CODE,
                 T3.INDEX_VALUE,
                 T4.DIM_CODE AS DIM_CODE1,
                 DECODE(T4.DIM_DETAIL_CODE,
                        'Transportation',
                        'Other',
                        'Office',
                        'Other',
                        T4.DIM_DETAIL_CODE) AS DIM_DETAIL_CODE1,
                 DECODE(T3.INDEX_CODE,'Replace_oil_engy_amt','Industry_type',T5.DIM_CODE) AS DIM_CODE2,
                 DECODE(T3.INDEX_CODE,'Replace_oil_engy_amt','Industry',T3.T5.DIM_DETAIL_CODE) AS DIM_DETAIL_CODE2,
                 T7.DIM_CODE AS DIM_CODE4,
                 T7.DIM_DETAIL_CODE AS DIM_DETAIL_CODE4,
                 T8.DIM_CODE AS DIM_CODE5,
                 T8.DIM_DETAIL_CODE AS DIM_DETAIL_CODE5,
                 T9.DIM_CODE AS DIM_CODE6,
                 T9.DIM_DETAIL_CODE AS DIM_DETAIL_CODE6
            FROM E7_STA_REPINST T1
            LEFT JOIN E7_STA_RPT_INDEX_INST T2
              ON T1.REPINST_ID = T2.REPINST_ID
            LEFT JOIN E7_STA_INDEX_INST T3
              ON T2.STA_INDEX_INST_ID = T3.STA_INDEX_INST_ID
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T4
              ON T2.STA_INDEX_INST_ID = T4.STA_INDEX_INST_ID
             AND T4.DIM_CODE LIKE '%_link'
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T5
              ON T4.STA_INDEX_INST_ID = T5.STA_INDEX_INST_ID
             AND T5.DIM_CODE = 'Industry_type'
          
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T7
              ON T2.STA_INDEX_INST_ID = T7.STA_INDEX_INST_ID
             AND T7.DIM_CODE = 'Cru_oil_E_cons_typ'
             AND T7.DIM_DETAIL_CODE IN
                 (SELECT DIM_DETAIL_CODE
                    FROM E7_STA_DIM_DETAIL D
                   WHERE D.DIM_CODE = 'Cru_oil_E_cons_typ'
                     AND D.PARENT_DIM_DETAIL_CODE IS NULL)
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T8
              ON T2.STA_INDEX_INST_ID = T8.STA_INDEX_INST_ID
             AND T8.DIM_CODE = 'Cru_oil_E_cons_typ'
             AND T8.DIM_DETAIL_CODE <> T7.DIM_DETAIL_CODE
             
             LEFT JOIN E7_STA_INDEX_INST_DIMEN T9
             ON T2.STA_INDEX_INST_ID = T9.STA_INDEX_INST_ID
             AND T9.DIM_CODE = 'Crude_oil_alter_typ'
             
           WHERE T1.REPORT_CODE IN( 'C0012','C0015')
             AND T3.INDEX_CODE NOT IN ('Stadc_coef')
             AND (T5.DIM_DETAIL_CODE = 'Industry' 
             OR T5.DIM_DETAIL_CODE IS NULL)
             AND T1.REPORT_YEAR = P_RPTYEAR
             AND T1.REPORT_MONTH = P_RPTMONTH
             AND T1.ORG_ID IN (SELECT ORG_ID
                                 FROM E7_STA_RPT_AUTH
                                WHERE V_ORG_ID = P_RPTORGID
                                  AND REPORT_CODE = 'C0012'))
   GROUP BY REPORT_CODE,
            REPORT_YEAR,
            REPORT_MONTH,
            INDEX_CODE,
            DIM_CODE1,
            DIM_DETAIL_CODE1,
            DIM_CODE2,
            DIM_DETAIL_CODE2,
            DIM_CODE4,
            DIM_DETAIL_CODE4,
            DIM_CODE5,
            DIM_DETAIL_CODE5,
            DIM_CODE6,
            DIM_DETAIL_CODE6
            ),         
DATA_AMT AS
 (SELECT * FROM DATAS WHERE INDEX_CODE = 'Engy_csmp_amt_pratl'),
DATA_COST AS
 (SELECT * FROM DATAS WHERE INDEX_CODE = 'Engy_csmp_cost'),
DATA_PRICE AS
 (SELECT DATA_AMT.REPORT_CODE,
         DATA_AMT.REPORT_YEAR,
         DATA_AMT.REPORT_MONTH,
         'Engy_csmp_unit_pric' INDEX_CODE,
        DECODE(SUM(DATA_AMT.INDEX_VALUE),0,0,  ROUND(sum(DATA_COST.INDEX_VALUE) * 10000 / sum(DATA_AMT.INDEX_VALUE), 4)) INDEX_VALUE,
         DATA_AMT.DIM_CODE1,
         DATA_AMT.DIM_DETAIL_CODE1,
         null DIM_CODE2,
         null DIM_DETAIL_CODE2,
         DATA_AMT.DIM_CODE4,
         DATA_AMT.DIM_DETAIL_CODE4,
         null DIM_CODE5,
         null DIM_DETAIL_CODE5,
         null DIM_CODE6,
         null DIM_DETAIL_CODE6
    FROM DATA_AMT
    LEFT JOIN DATA_COST
      ON DATA_AMT.REPORT_CODE = DATA_COST.REPORT_CODE
     AND DATA_AMT.REPORT_YEAR = DATA_COST.REPORT_YEAR
     AND DATA_AMT.REPORT_MONTH = DATA_COST.REPORT_MONTH
     AND DATA_AMT.DIM_DETAIL_CODE1 = DATA_COST.DIM_DETAIL_CODE1
     AND DATA_AMT.DIM_DETAIL_CODE4 = DATA_COST.DIM_DETAIL_CODE4
     group by 
      DATA_AMT.REPORT_CODE,
         DATA_AMT.REPORT_YEAR,
         DATA_AMT.REPORT_MONTH,
         DATA_AMT.DIM_CODE1,
         DATA_AMT.DIM_DETAIL_CODE1,
         DATA_AMT.DIM_CODE4,
         DATA_AMT.DIM_DETAIL_CODE4),
RESULTS AS
 (SELECT * FROM DATAS),

LOCA_INDEX AS
 (SELECT *
    FROM E7_EXCEL_LOCATIONBYINDEX
   WHERE REPORT_CODE = P_RPTCODE
     AND IS_PY = 'N'),
LOCA_DIMEN AS
 (SELECT * FROM E7_EXCEL_LOCATIONBYDIMEN 
 WHERE REPORT_CODE = P_RPTCODE and LOCALTION IN (
       SELECT LOCALTION FROM LOCA_INDEX
 )),
LOC_INDEX AS
 (SELECT RESULTS.*, LOCA_INDEX.LOCALTION LOCATION_INDEX
    FROM RESULTS
    LEFT JOIN LOCA_INDEX
      ON RESULTS.INDEX_CODE = LOCA_INDEX.INDEX_CODE),
LOCA_DIMEN1 AS
 (SELECT *
    FROM (SELECT LOC_INDEX.*, DIMEN1.LOCALTION LOCATION_DIMEN1
            FROM LOC_INDEX
            LEFT JOIN LOCA_DIMEN DIMEN1
              ON LOC_INDEX.DIM_DETAIL_CODE1 = DIMEN1.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN1
      OR LOCATION_DIMEN1 IS NULL),
LOCA_DIMEN2 as
 (SELECT *
    FROM (select LOCA_DIMEN1.*, DIMEN2.LOCALTION LOCATION_DIMEN2
            FROM LOCA_DIMEN1
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN2
              ON LOCA_DIMEN1.DIM_CODE2 = DIMEN2.DIM_CODE
             AND LOCA_DIMEN1.DIM_DETAIL_CODE2 = DIMEN2.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN2
      OR LOCATION_DIMEN2 IS NULL),
LOCA_DIMEN3 as
 (SELECT *
    FROM (select LOCA_DIMEN2.*, DIMEN3.LOCALTION LOCATION_DIMEN3
            FROM LOCA_DIMEN2
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN3
              ON LOCA_DIMEN2.DIM_CODE4 = DIMEN3.DIM_CODE
             AND LOCA_DIMEN2.DIM_DETAIL_CODE4 = DIMEN3.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN3
      OR LOCATION_DIMEN3 IS NULL),
LOCA_DIMEN4 as
 (SELECT *
    FROM (select LOCA_DIMEN3.*, DIMEN4.LOCALTION LOCATION_DIMEN4
            FROM LOCA_DIMEN3
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN4
              ON LOCA_DIMEN3.DIM_CODE5 = DIMEN4.DIM_CODE
             AND LOCA_DIMEN3.DIM_DETAIL_CODE5 = DIMEN4.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN4
      OR LOCATION_DIMEN4 IS NULL), 
LOCA_DIMEN5 as
 (SELECT *
    FROM (select LOCA_DIMEN4.*, DIMEN5.LOCALTION LOCATION_DIMEN5
            FROM LOCA_DIMEN4
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN5
              ON LOCA_DIMEN4.DIM_CODE6 = DIMEN5.DIM_CODE
             AND LOCA_DIMEN4.DIM_DETAIL_CODE6 = DIMEN5.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN5
      OR LOCATION_DIMEN5 IS NULL),       
loca_indexprice as
 (
  
  SELECT DATA_PRICE.*, LOCA_INDEX.LOCALTION LOCATION_INDEX
    FROM DATA_PRICE
    LEFT JOIN LOCA_INDEX
      ON DATA_PRICE.INDEX_CODE = LOCA_INDEX.INDEX_CODE),
loca_dimenprice as
 (
  
  SELECT *
    FROM (select loca_indexprice.*,
                  null LOCATION_DIMEN1,
                  null LOCATION_DIMEN2,
                  null LOCATION_DIMEN3,
                  null LOCATION_DIMEN4,
                  DIMEN3.LOCALTION LOCATION_DIMENPRICE
             FROM loca_indexprice
             LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN3
               ON loca_indexprice.DIM_CODE4 = DIMEN3.DIM_CODE
              AND loca_indexprice.DIM_DETAIL_CODE4 = DIMEN3.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMENPRICE
      OR LOCATION_DIMENPRICE IS NULL),
ALLRESULTS AS
 (SELECT * FROM LOCA_DIMEN5 
 UNION ALL SELECT * FROM LOCA_DIMENPRICE
 )
SELECT DISTINCT LOCATION_INDEX, INDEX_VALUE FROM ALLRESULTS WHERE LOCATION_INDEX IS NOT NULL
);
BEGIN
jsonStr := '[';
FOR V_ENRGY IN return_cursor LOOP
  jsonStr := jsonStr || '{''location'':''' || V_ENRGY.LOCATION_INDEX ||
                 ''',''value'':''' || to_char(V_ENRGY.Index_Value) || '''},';

  END LOOP;
  jsonStr := jsonStr || ']';
  jsonStr := replace(jsonStr,'},]','}]');
  dbms_output.put_line(jsonStr);
  END;
  
  procedure getT0011Sum(P_RPTCODE IN VARCHAR2,
            	          P_RPTYEAR  IN VARCHAR2,
                       P_RPTMONTH IN VARCHAR2,
                       P_RPTORGID IN VARCHAR2,jsonStr OUT CLOB) IS
    
    Cursor return_cursor is
      SELECT *
        FROM (WITH DATAS AS
 (SELECT REPORT_CODE,
         REPORT_YEAR,
         REPORT_MONTH,
         INDEX_CODE,
         SUM(INDEX_VALUE) INDEX_VALUE,
         DIM_CODE1,
         DIM_DETAIL_CODE1,
         DIM_CODE2,
         DIM_DETAIL_CODE2,
         DIM_CODE4,
         DIM_DETAIL_CODE4,
         DIM_CODE5,
         DIM_DETAIL_CODE5,
         DIM_CODE6,
         DIM_DETAIL_CODE6
    FROM (SELECT P_RPTCODE REPORT_CODE,
                 T1.REPORT_YEAR,
                 T1.REPORT_MONTH,
                 T1.ORG_ID,
                 T3.INDEX_CODE,
                 T3.INDEX_VALUE,
                 T4.DIM_CODE AS DIM_CODE1,
                 DECODE(T4.DIM_DETAIL_CODE,
                        'Transportation',
                        'Other',
                        'Office',
                        'Other',
                        T4.DIM_DETAIL_CODE) AS DIM_DETAIL_CODE1,
                 DECODE(T3.INDEX_CODE,'Replace_oil_engy_amt','Industry_type',T5.DIM_CODE) AS DIM_CODE2,
                 DECODE(T3.INDEX_CODE,'Replace_oil_engy_amt','Industry',T3.T5.DIM_DETAIL_CODE) AS DIM_DETAIL_CODE2,
                 T7.DIM_CODE AS DIM_CODE4,
                 T7.DIM_DETAIL_CODE AS DIM_DETAIL_CODE4,
                 T8.DIM_CODE AS DIM_CODE5,
                 T8.DIM_DETAIL_CODE AS DIM_DETAIL_CODE5,
                 T9.DIM_CODE AS DIM_CODE6,
                 T9.DIM_DETAIL_CODE AS DIM_DETAIL_CODE6
            FROM E7_STA_REPINST T1
            LEFT JOIN E7_STA_RPT_INDEX_INST T2
              ON T1.REPINST_ID = T2.REPINST_ID
            LEFT JOIN E7_STA_INDEX_INST T3
              ON T2.STA_INDEX_INST_ID = T3.STA_INDEX_INST_ID
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T4
              ON T2.STA_INDEX_INST_ID = T4.STA_INDEX_INST_ID
             AND T4.DIM_CODE LIKE '%_link'
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T5
              ON T4.STA_INDEX_INST_ID = T5.STA_INDEX_INST_ID
             AND T5.DIM_CODE = 'Industry_type'
          
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T7
              ON T2.STA_INDEX_INST_ID = T7.STA_INDEX_INST_ID
             AND T7.DIM_CODE = 'Cru_oil_E_cons_typ'
             AND T7.DIM_DETAIL_CODE IN
                 (SELECT DIM_DETAIL_CODE
                    FROM E7_STA_DIM_DETAIL D
                   WHERE D.DIM_CODE = 'Cru_oil_E_cons_typ'
                     AND D.PARENT_DIM_DETAIL_CODE IS NULL)
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T8
              ON T2.STA_INDEX_INST_ID = T8.STA_INDEX_INST_ID
             AND T8.DIM_CODE = 'Cru_oil_E_cons_typ'
             AND T8.DIM_DETAIL_CODE <> T7.DIM_DETAIL_CODE
             
             LEFT JOIN E7_STA_INDEX_INST_DIMEN T9
             ON T2.STA_INDEX_INST_ID = T9.STA_INDEX_INST_ID
             AND T9.DIM_CODE = 'Crude_oil_alter_typ'
             
           WHERE T1.REPORT_CODE IN( 'C0035','C0039')
             AND T3.INDEX_CODE NOT IN ('Stadc_coef')
             AND (T5.DIM_DETAIL_CODE = 'Industry' 
             OR T5.DIM_DETAIL_CODE IS NULL)
             AND T1.REPORT_YEAR = P_RPTYEAR
             AND T1.REPORT_MONTH = P_RPTMONTH
             AND T1.ORG_ID IN (SELECT ORG_ID
                                 FROM E7_STA_RPT_AUTH
                                WHERE V_ORG_ID = P_RPTORGID
                                  AND REPORT_CODE = 'C0035'))
   GROUP BY REPORT_CODE,
            REPORT_YEAR,
            REPORT_MONTH,
            INDEX_CODE,
            DIM_CODE1,
            DIM_DETAIL_CODE1,
            DIM_CODE2,
            DIM_DETAIL_CODE2,
            DIM_CODE4,
            DIM_DETAIL_CODE4,
            DIM_CODE5,
            DIM_DETAIL_CODE5,
            DIM_CODE6,
            DIM_DETAIL_CODE6
            ),         
DATA_AMT AS
 (SELECT * FROM DATAS WHERE INDEX_CODE = 'Engy_csmp_amt_pratl'),
DATA_COST AS
 (SELECT * FROM DATAS WHERE INDEX_CODE = 'Engy_csmp_cost'),
DATA_PRICE AS
 (SELECT DATA_AMT.REPORT_CODE,
         DATA_AMT.REPORT_YEAR,
         DATA_AMT.REPORT_MONTH,
         'Engy_csmp_unit_pric' INDEX_CODE,
        DECODE(SUM(DATA_AMT.INDEX_VALUE),0,0,  ROUND(sum(DATA_COST.INDEX_VALUE) * 10000 / sum(DATA_AMT.INDEX_VALUE), 4)) INDEX_VALUE,
         DATA_AMT.DIM_CODE1,
         DATA_AMT.DIM_DETAIL_CODE1,
         null DIM_CODE2,
         null DIM_DETAIL_CODE2,
         DATA_AMT.DIM_CODE4,
         DATA_AMT.DIM_DETAIL_CODE4,
         null DIM_CODE5,
         null DIM_DETAIL_CODE5,
         null DIM_CODE6,
         null DIM_DETAIL_CODE6
    FROM DATA_AMT
    LEFT JOIN DATA_COST
      ON DATA_AMT.REPORT_CODE = DATA_COST.REPORT_CODE
     AND DATA_AMT.REPORT_YEAR = DATA_COST.REPORT_YEAR
     AND DATA_AMT.REPORT_MONTH = DATA_COST.REPORT_MONTH
     AND DATA_AMT.DIM_DETAIL_CODE1 = DATA_COST.DIM_DETAIL_CODE1
     AND DATA_AMT.DIM_DETAIL_CODE4 = DATA_COST.DIM_DETAIL_CODE4
     group by 
      DATA_AMT.REPORT_CODE,
         DATA_AMT.REPORT_YEAR,
         DATA_AMT.REPORT_MONTH,
         DATA_AMT.DIM_CODE1,
         DATA_AMT.DIM_DETAIL_CODE1,
         DATA_AMT.DIM_CODE4,
         DATA_AMT.DIM_DETAIL_CODE4),
RESULTS AS
 (SELECT * FROM DATAS),

LOCA_INDEX AS
 (SELECT *
    FROM E7_EXCEL_LOCATIONBYINDEX
   WHERE REPORT_CODE = P_RPTCODE
     AND IS_PY = 'N'),
LOCA_DIMEN AS
 (SELECT * FROM E7_EXCEL_LOCATIONBYDIMEN 
 WHERE REPORT_CODE = P_RPTCODE and LOCALTION IN (
       SELECT LOCALTION FROM LOCA_INDEX
 )),
LOC_INDEX AS
 (SELECT RESULTS.*, LOCA_INDEX.LOCALTION LOCATION_INDEX
    FROM RESULTS
    LEFT JOIN LOCA_INDEX
      ON RESULTS.INDEX_CODE = LOCA_INDEX.INDEX_CODE),
LOCA_DIMEN1 AS
 (SELECT *
    FROM (SELECT LOC_INDEX.*, DIMEN1.LOCALTION LOCATION_DIMEN1
            FROM LOC_INDEX
            LEFT JOIN LOCA_DIMEN DIMEN1
              ON LOC_INDEX.DIM_DETAIL_CODE1 = DIMEN1.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN1
      OR LOCATION_DIMEN1 IS NULL),
LOCA_DIMEN2 as
 (SELECT *
    FROM (select LOCA_DIMEN1.*, DIMEN2.LOCALTION LOCATION_DIMEN2
            FROM LOCA_DIMEN1
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN2
              ON LOCA_DIMEN1.DIM_CODE2 = DIMEN2.DIM_CODE
             AND LOCA_DIMEN1.DIM_DETAIL_CODE2 = DIMEN2.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN2
      OR LOCATION_DIMEN2 IS NULL),
LOCA_DIMEN3 as
 (SELECT *
    FROM (select LOCA_DIMEN2.*, DIMEN3.LOCALTION LOCATION_DIMEN3
            FROM LOCA_DIMEN2
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN3
              ON LOCA_DIMEN2.DIM_CODE4 = DIMEN3.DIM_CODE
             AND LOCA_DIMEN2.DIM_DETAIL_CODE4 = DIMEN3.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN3
      OR LOCATION_DIMEN3 IS NULL),
LOCA_DIMEN4 as
 (SELECT *
    FROM (select LOCA_DIMEN3.*, DIMEN4.LOCALTION LOCATION_DIMEN4
            FROM LOCA_DIMEN3
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN4
              ON LOCA_DIMEN3.DIM_CODE5 = DIMEN4.DIM_CODE
             AND LOCA_DIMEN3.DIM_DETAIL_CODE5 = DIMEN4.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN4
      OR LOCATION_DIMEN4 IS NULL), 
LOCA_DIMEN5 as
 (SELECT *
    FROM (select LOCA_DIMEN4.*, DIMEN5.LOCALTION LOCATION_DIMEN5
            FROM LOCA_DIMEN4
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN5
              ON LOCA_DIMEN4.DIM_CODE6 = DIMEN5.DIM_CODE
             AND LOCA_DIMEN4.DIM_DETAIL_CODE6 = DIMEN5.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN5
      OR LOCATION_DIMEN5 IS NULL),       
loca_indexprice as
 (
  
  SELECT DATA_PRICE.*, LOCA_INDEX.LOCALTION LOCATION_INDEX
    FROM DATA_PRICE
    LEFT JOIN LOCA_INDEX
      ON DATA_PRICE.INDEX_CODE = LOCA_INDEX.INDEX_CODE),
loca_dimenprice as
 (
  
  SELECT *
    FROM (select loca_indexprice.*,
                  null LOCATION_DIMEN1,
                  null LOCATION_DIMEN2,
                  null LOCATION_DIMEN3,
                  null LOCATION_DIMEN4,
                  DIMEN3.LOCALTION LOCATION_DIMENPRICE
             FROM loca_indexprice
             LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN3
               ON loca_indexprice.DIM_CODE4 = DIMEN3.DIM_CODE
              AND loca_indexprice.DIM_DETAIL_CODE4 = DIMEN3.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMENPRICE
      OR LOCATION_DIMENPRICE IS NULL),
ALLRESULTS AS
 (SELECT * FROM LOCA_DIMEN5 
 UNION ALL SELECT * FROM LOCA_DIMENPRICE
 )
SELECT DISTINCT LOCATION_INDEX, INDEX_VALUE FROM ALLRESULTS WHERE LOCATION_INDEX IS NOT NULL
);
BEGIN
jsonStr := '[';
FOR V_ENRGY IN return_cursor LOOP
  jsonStr := jsonStr || '{''location'':''' || V_ENRGY.LOCATION_INDEX ||
                 ''',''value'':''' || to_char(V_ENRGY.Index_Value) || '''},';

  END LOOP;
  jsonStr := jsonStr || ']';
  jsonStr := replace(jsonStr,'},]','}]');
  dbms_output.put_line(jsonStr);
  END;
  PROCEDURE getT0001Sum (REPORTCODE IN VARCHAR2,

                    P_RPTYEAR  IN VARCHAR2,
                    P_RPTMONTH IN VARCHAR2,
                    P_RPTORGID IN VARCHAR2,
                    jsonStr OUT CLOB) IS
     cursor location(REPORTCODE varchar2)
                 is
                 SELECT ind.index_code,ind.localtion,
                 nvl(dim.dim_code,'*') dim_code,nvl(dim.dim_detail_code,'*')  dim_detail_code
                 FROM e7_excel_locationbyindex ind left join e7_excel_locationbydimen  dim
                 on ind.report_code=dim.report_code and ind.localtion=dim.localtion
                 where ind.report_code=REPORTCODE
                 and ind.is_py='N';
    location_info location%rowtype;
    location_code VARCHAR2(10);
    location_value number; 
    location_value2 number; 
  begin
    jsonStr:= '[';
    for location_info in location(REPORTCODE) LOOP
    location_code :=location_info.localtion;
      begin
          IF location_info.index_code='Pipe_Og_transpt_amt'
          THEN 
          WITH TEMP AS(SELECT 
            SUM(T3.INDEX_VALUE) AS SUMVALUE,
            T3.INDEX_CODE,
            decode(LINE.LINE_TYPE_CODE,'01','Crud_oil_lon_dist_pip','02','Refi_oil_lon_dist_pip','03','Gas_long_dist_pip') as LINE_TYPE_CODE
            FROM E7_STA_REPINST T1
            LEFT JOIN E7_STA_RPT_INDEX_INST T2 
            ON T1.REPINST_ID = T2.REPINST_ID
            LEFT JOIN E7_STA_INDEX_INST T3 
            ON T2.STA_INDEX_INST_ID = T3.STA_INDEX_INST_ID
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T4 
            ON T2.STA_INDEX_INST_ID = T4.STA_INDEX_INST_ID
            LEFT JOIN E7_SYS_LINE LINE 
            ON T4.DIM_DETEAIL_ID = LINE.LINE_ID
            LEFT JOIN E7_SYS_LINEORG LINEORG
            ON LINE.LINE_ID = LINEORG.LINE_ID
            AND  T1.ORG_ID = LINEORG.ORG_ID
            WHERE T1.REPORT_CODE = 'C0061'
            AND T1.REPORT_YEAR =P_RPTYEAR
            AND T1.REPORT_MONTH =P_RPTMONTH
            AND T1.ORG_ID in (select t.org_id from E7_STA_RPT_AUTH t where t.v_org_id = P_RPTORGID and t.report_code = 'C0061')
            GROUP BY T3.INDEX_CODE,LINE.LINE_TYPE_CODE)
            SELECT sum(SUMVALUE) into location_value FROM TEMP WHERE INDEX_CODE=location_info.index_code
            AND LINE_TYPE_CODE =location_info.dim_detail_code;
          ELSIF  location_info.index_code='Wd_ftg'
            then
              with temp as(SELECT 
                INDEXINST.INDEX_CODE,
                INDEXINSTDIMEN.DIM_DETAIL_CODE,
                sum(INDEXINST.INDEX_VALUE) as sumvalue 
                FROM E7_STA_REPINST REPINST
                LEFT JOIN E7_STA_RPT_INDEX_INST RPTINDEXINST 
                ON REPINST.REPINST_ID = RPTINDEXINST.REPINST_ID
                LEFT JOIN E7_STA_INDEX_INST INDEXINST 
                ON RPTINDEXINST.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
                LEFT JOIN E7_STA_INDEX_INST_DIMEN INDEXINSTDIMEN 
                ON RPTINDEXINST.STA_INDEX_INST_ID = INDEXINSTDIMEN.STA_INDEX_INST_ID
                WHERE REPINST.REPORT_CODE ='C0016'
                AND REPINST.REPORT_YEAR =P_RPTYEAR
                AND REPINST.REPORT_MONTH =P_RPTMONTH
                AND INDEXINST.INDEX_CODE = 'Wd_ftg'
                AND REPINST.ORG_ID in (select t.org_id from E7_STA_RPT_AUTH t where t.v_org_id =P_RPTORGID and t.report_code = 'C0016')
                GROUP BY INDEXINST.INDEX_CODE,INDEXINSTDIMEN.DIM_DETAIL_CODE)
                SELECT sum(SUMVALUE)/10000 into location_value FROM TEMP
                where (temp.DIM_DETAIL_CODE='Dies_oil' or temp.DIM_DETAIL_CODE='Elec_netw')
                and temp.INDEX_CODE=location_info.index_code;
            ELSIF  location_info.index_code='Comph_engy_csmp_amt_1'
              then
                with temp as(SELECT 
                  indexinst.index_code 
                  ,indexinstdimen.dim_code
                  ,indexinstdimen.dim_detail_code 
                  ,indexinstdimen1.dim_code as dim_code1
                  ,indexinstdimen1.dim_detail_code as dim_detail_code1  
                  ,indexinstdimen2.dim_code as dim_code2
                  ,indexinstdimen2.dim_detail_code as dim_detail_code2  
                  ,sum(indexinst.index_value) as sumvalue
                  FROM e7_sta_repinst r
                  LEFT JOIN e7_sta_rpt_index_inst rptindex
                  ON r.repinst_id = rptindex.repinst_id
                  LEFT JOIN e7_sta_index_inst indexinst
                  ON rptindex.sta_index_inst_id = indexinst.sta_index_inst_id
                  LEFT JOIN e7_sta_index_inst_dimen indexinstdimen
                  ON indexinstdimen.sta_index_inst_id = indexinst.sta_index_inst_id
                  LEFT JOIN e7_sta_index_inst_dimen indexinstdimen1
                  ON indexinstdimen.sta_index_inst_id = indexinstdimen1.sta_index_inst_id
                  AND indexinstdimen.dim_code <> indexinstdimen1.dim_code
                  AND indexinstdimen.dim_detail_code <> indexinstdimen1.dim_detail_code
                  LEFT JOIN e7_sta_index_inst_dimen indexinstdimen2
                  ON indexinstdimen.sta_index_inst_id = indexinstdimen2.sta_index_inst_id
                  AND indexinstdimen.dim_code <> indexinstdimen2.dim_code
                  AND indexinstdimen.dim_detail_code <> indexinstdimen2.dim_detail_code
                  AND indexinstdimen1.dim_code <> indexinstdimen2.dim_code
                  AND indexinstdimen1.dim_detail_code <> indexinstdimen2.dim_detail_code
                  WHERE r.report_code in ('T0003','T0005') 
                  AND r.org_id in (select t.org_id from E7_STA_RPT_AUTH t where t.org_id =P_RPTORGID   and t.report_code in ('T0003','T0005') )
                  AND r.report_year =P_RPTYEAR
                  AND r.report_month =P_RPTMONTH
                  GROUP BY indexinst.index_code,indexinstdimen.dim_code,indexinstdimen.dim_detail_code,indexinstdimen1.dim_code,indexinstdimen1.dim_detail_code,indexinstdimen2.dim_code,indexinstdimen2.dim_detail_code)
                  select sum(sumvalue) into location_value from temp where
                  temp.INDEX_CODE='Comph_engy_csmp_amt'
                  and temp.dim_detail_code=location_info.dim_detail_code;
              else
                with temp as(SELECT
                    tt.INDEX_CODE,
                    nvl(tt.DIM_CODE,'*') DIM_CODE,
                    nvl(tt.DIM_DETAIL_CODE,'*') DIM_DETAIL_CODE,
                    sum(tt.sumvalue) as sumvalue 
                    from
                    (SELECT 
                    INDEXINST.INDEX_CODE,
                    INDEXINSTDIMEN.DIM_CODE,
                    INDEXINSTDIMEN.DIM_DETAIL_CODE,
                    case when INDEXINST.INDEX_CODE IN ('Oil_first_procs_ability','Procs_Co_amt')   then  (sum(INDEXINST.INDEX_VALUE))/10000 else  sum(INDEXINST.INDEX_VALUE) end as sumvalue 
                    FROM E7_STA_REPINST REPINST
                    LEFT JOIN E7_STA_RPT_INDEX_INST RPTINDEXINST 
                    ON REPINST.REPINST_ID = RPTINDEXINST.REPINST_ID
                    LEFT JOIN E7_STA_INDEX_INST INDEXINST 
                    ON RPTINDEXINST.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
                    LEFT JOIN E7_STA_INDEX_INST_DIMEN INDEXINSTDIMEN 
                    ON RPTINDEXINST.STA_INDEX_INST_ID = INDEXINSTDIMEN.STA_INDEX_INST_ID
                    WHERE REPINST.REPORT_CODE in ('C0001','C0006','C0011','C0016','C0021','C0026','C0034','C0051','C0056','C0061','C0071','C0076','C0094','C0099','C0104','C0114','C0168')
                    AND REPINST.REPORT_YEAR =P_RPTYEAR
                    AND REPINST.REPORT_MONTH =P_RPTMONTH
                    AND REPINST.ORG_ID in (select t.org_id from E7_STA_RPT_AUTH t where t.v_org_id = P_RPTORGID and t.report_code in ('C0001','C0006','C0011','C0016','C0021','C0026','C0034','C0051','C0056','C0061','C0071','C0076','C0094','C0099','C0104','C0114','C0168') )
                    GROUP BY INDEXINST.INDEX_CODE,INDEXINSTDIMEN.DIM_CODE,INDEXINSTDIMEN.DIM_DETAIL_CODE
                    union all
                    SELECT 
                    INDEXINST.INDEX_CODE,
                    INDEXINSTDIMEN.DIM_CODE,
                    INDEXINSTDIMEN.DIM_DETAIL_CODE,
                    case when INDEXINST.INDEX_CODE IN ('Ind_outp','Entrp_added_value')   then  (sum(INDEXINST.INDEX_VALUE)) else  sum(INDEXINST.INDEX_VALUE)/10000 end as sumvalue
                    FROM E7_STA_REPINST REPINST
                    LEFT JOIN E7_STA_RPT_INDEX_INST RPTINDEXINST 
                    ON REPINST.REPINST_ID = RPTINDEXINST.REPINST_ID
                    LEFT JOIN E7_STA_INDEX_INST INDEXINST 
                    ON RPTINDEXINST.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
                    LEFT JOIN E7_STA_INDEX_INST_DIMEN INDEXINSTDIMEN 
                    ON RPTINDEXINST.STA_INDEX_INST_ID = INDEXINSTDIMEN.STA_INDEX_INST_ID
                    WHERE REPINST.REPORT_CODE in ('C0044')
                    AND REPINST.REPORT_YEAR =P_RPTYEAR
                    AND REPINST.REPORT_MONTH =P_RPTMONTH
                    AND REPINST.ORG_ID in (select t.org_id from E7_STA_RPT_AUTH t where t.v_org_id =P_RPTORGID  and t.report_code in ('C0044') )
                    GROUP BY INDEXINST.INDEX_CODE,INDEXINSTDIMEN.DIM_CODE,INDEXINSTDIMEN.DIM_DETAIL_CODE) tt
                    GROUP BY tt.INDEX_CODE,tt.DIM_CODE,tt.DIM_DETAIL_CODE)
                    select sum(sumvalue)  into location_value from temp where
                    temp.INDEX_CODE=location_info.index_code and
                    temp.DIM_DETAIL_CODE=location_info.dim_detail_code;
                    if location_info.index_code='Ng_bargain_amt'
                      then
                        SELECT sum(INDEXINST.INDEX_VALUE) as sumvalue  into location_value2
                          FROM E7_STA_REPINST REPINST
                          LEFT JOIN E7_STA_RPT_INDEX_INST RPTINDEXINST 
                          ON REPINST.REPINST_ID = RPTINDEXINST.REPINST_ID
                          LEFT JOIN E7_STA_INDEX_INST INDEXINST 
                          ON RPTINDEXINST.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
                          LEFT JOIN E7_STA_INDEX_INST_DIMEN INDEXINSTDIMEN 
                          ON RPTINDEXINST.STA_INDEX_INST_ID = INDEXINSTDIMEN.STA_INDEX_INST_ID
                         WHERE REPINST.REPORT_CODE ='C0076'
                           AND REPINST.REPORT_YEAR =P_RPTYEAR
                           AND REPINST.REPORT_MONTH =P_RPTMONTH
                           AND INDEXINST.INDEX_CODE in ('pipe_gas_sls_vol','CNG_sls_vol','LNG_sls_vol')
                           AND REPINST.ORG_ID in (select t.org_id from E7_STA_RPT_AUTH t where t.v_org_id = P_RPTORGID and t.report_code = 'C0076');
                           location_value:=location_value+location_value2;
                     end if; 

        end if;          
        exception when no_data_found then
            location_value:=0; 
      end;  
      jsonStr := jsonStr || '{''location'':''' || location_code ||
                     ''',''value'':''' || to_char(location_value) || '''},';
    END LOOP;
   jsonStr:=jsonStr || ']';
   jsonStr:= replace(jsonStr,'},]','}]');
  end;
   PROCEDURE getT0002Sum (REPORTCODE IN VARCHAR2,

                    P_RPTYEAR  IN VARCHAR2,
                    P_RPTMONTH IN VARCHAR2,
                    P_RPTORGID IN VARCHAR2,
                    jsonStr OUT CLOB) IS
     cursor location(REPORTCODE varchar2)
                 is
                 SELECT ind.index_code,ind.localtion,
                     nvl(dim1.dim_code,'*') dim_code1,nvl(dim1.dim_detail_code,'*')  dim_detail_code1,
                     nvl(dim2.dim_code，'*') dim_code2,nvl(dim2.dim_detail_code,'*')  dim_detail_code2,
                     nvl(dim3.dim_code,'*' )dim_code3,nvl(dim3.dim_detail_code  ,'*')dim_detail_code3
                       FROM e7_excel_locationbyindex ind
                       left join e7_excel_locationbydimen  dim1
                       on ind.report_code=dim1.report_code and ind.localtion=dim1.localtion
                       and (dim1.dim_code in
                        ('Product_steam_mod',
                        'Or_Comph_engy_lost_typ',
                        'LNG_outp_vol_typ',
                        'Orig_energy_type',
                        'Long_line_type',
                        'Industry_type',
                        'Gas_stat_typ',
                        'Professional_type',
                        'Sal_pro_hl_type',
                        'Gas_stat_typ') or (dim1.dim_code='Sal_pro_amt_type' and dim1.dim_detail_code in ('Wholesale','Retail','Fuel_gas')))
                        left join e7_excel_locationbydimen  dim2
                        on ind.report_code=dim2.report_code and ind.localtion=dim2.localtion
                        and dim2.dim_code='Sal_pro_amt_type'and dim2.dim_detail_code <> dim1.dim_detail_code
                        left join e7_excel_locationbydimen  dim3
                        on ind.report_code=dim3.report_code and ind.localtion=dim3.localtion
                        and dim3.dim_code in('Sal_form1'，'Sal_form2')
                        where ind.report_code='T0002'
                        and ind.is_py='N';
    location_info location%rowtype;
    location_code VARCHAR2(10);
    location_value number; 
  begin
    jsonStr:= '[';
    for location_info in location(REPORTCODE) LOOP
    location_code :=location_info.localtion;
      begin
        WITH TEMP AS(SELECT C.INDEX_CODE,
                 SUM(C.INDEX_VALUE) INDEX_VALUE,
                   nvl(D.DIM_CODE,'*') AS DIM_CODE1,
                   nvl(D.DIM_DETAIL_CODE,'*' ) AS DIM_DETAIL_CODE1,
                   nvl(E.DIM_CODE，'*'  )            AS DIM_CODE2,
                   nvl(E.DIM_DETAIL_CODE ,'*')      AS DIM_DETAIL_CODE2,
                   nvl(F.DIM_CODE，'*' )             AS DIM_CODE3,
                   nvl(F.DIM_DETAIL_CODE,'*')       AS DIM_DETAIL_CODE3
                   FROM E7_STA_REPINST A
                   JOIN E7_STA_RPT_INDEX_INST B ON A.REPINST_ID = B.REPINST_ID
                   JOIN E7_STA_INDEX_INST C ON B.STA_INDEX_INST_ID = C.STA_INDEX_INST_ID
                   LEFT JOIN E7_STA_INDEX_INST_DIMEN D ON C.STA_INDEX_INST_ID = D.STA_INDEX_INST_ID
                   LEFT JOIN E7_STA_INDEX_INST_DIMEN E ON C.STA_INDEX_INST_ID = E.STA_INDEX_INST_ID AND D.DIM_DETAIL_CODE <> E.DIM_DETAIL_CODE
                   LEFT JOIN e7_STA_INDEX_INST_DIMEN F ON C.STA_INDEX_INST_ID =F.STA_INDEX_INST_ID AND D.DIM_DETAIL_CODE<> F.DIM_DETAIL_CODE AND E.DIM_DETAIL_CODE<>F.DIM_DETAIL_CODE AND D.DIM_DETAIL_CODE <> E.DIM_DETAIL_CODE WHERE A.REPORT_CODE ='C0083'
                   AND A.ORG_ID IN(SELECT DISTINCT A.ORG_ID FROM E7_STA_RPT_AUTH A WHERE A.V_ORG_ID =P_RPTORGID AND A.REPORT_CODE = 'C0083')
                   AND A.REPORT_YEAR = P_RPTYEAR
                   AND A.REPORT_MONTH =P_RPTMONTH
                   GROUP BY C.INDEX_CODE,D.DIM_CODE,D.DIM_DETAIL_CODE,E.DIM_CODE,E.DIM_DETAIL_CODE,F.DIM_CODE,F.DIM_DETAIL_CODE
                   union all
                   SELECT 
                   'Sls_sls_vol' as INDEX_CODE,
                   sum(REPINDEXINST.INDEX_VALUE) as INDEX_VALUE, 
                   'Sal_pro_amt_type' as DIM_CODE,
                   'Fuel_gas' as DIM_DETAIL_CODE,
                   'Sal_pro_amt_type' as DIM_CODE2,
                   decode(REPINDEXINST.INDEX_CODE,'CNG_sls_vol','CNG','LNG_sls_vol','LNG','LPG_sls_vol','LPG',REPINDEXINST.INDEX_CODE)  as DIM_DETAIL_CODE2,
                    '*'        AS DIM_CODE3,
                    '*'       AS DIM_DETAIL_CODE3
                    FROM E7_STA_REPINST REPINST
                    LEFT JOIN E7_STA_RPT_INDEX_INST INDEXINST
                   ON REPINST.REPINST_ID = INDEXINST.REPINST_ID
                   LEFT JOIN E7_STA_INDEX_INST REPINDEXINST
                   ON INDEXINST.STA_INDEX_INST_ID = REPINDEXINST.STA_INDEX_INST_ID
                   WHERE REPINST.REPORT_CODE ='C0076'
                   AND REPINST.ORG_ID IN(SELECT DISTINCT A.ORG_ID FROM E7_STA_RPT_AUTH A WHERE A.V_ORG_ID =P_RPTORGID AND A.REPORT_CODE = 'C0076')
                   AND REPINST.REPORT_YEAR =P_RPTYEAR
                   AND REPINST.REPORT_MONTH =P_RPTMONTH
                   group by REPINDEXINST.INDEX_CODE)
                  SELECT SUM(INDEX_VALUE) INTO location_value FROM TEMP 
                  WHERE INDEX_CODE=location_info.index_code
                  AND   DIM_CODE1=location_info.Dim_Code1
                  AND   DIM_DETAIL_CODE1=location_info.Dim_Detail_Code1
                  AND   DIM_CODE2=location_info.Dim_Code2
                  AND   DIM_DETAIL_CODE2=location_info.Dim_Detail_Code2
                  AND   DIM_CODE3=location_info.Dim_Code3
                  AND   DIM_DETAIL_CODE3=location_info.Dim_Detail_Code3; 
            exception when no_data_found then
            location_value:=0;         
      end;
      jsonStr := jsonStr || '{''location'':''' || location_code ||
                     ''',''value'':''' || to_char(location_value) || '''},';           
    end loop;  
   jsonStr:=jsonStr || ']';
   jsonStr:= replace(jsonStr,'},]','}]');
  end;
  PROCEDURE getT0035Sum (REPORTCODE IN VARCHAR2,

                    P_RPTYEAR  IN VARCHAR2,
                    P_RPTMONTH IN VARCHAR2,
                    P_RPTORGID IN VARCHAR2,
                    jsonStr OUT CLOB) IS
     cursor location(REPORTCODE varchar2)
                 is
                 SELECT ind.report_code,ind.index_code,ind.localtion,
                          dim.dim_code dim_code,dim.dim_detail_code  dim_detail_code
                          FROM e7_excel_locationbyindex ind
                          left join e7_excel_locationbydimen  dim
                          on ind.report_code=dim.report_code and ind.localtion=dim.localtion
                          where ind.report_code='T0035'
                          and ind.is_py='N'
                          and ind.index_code<> 'Stadc_coef';
    location_info location%rowtype;
    location_code VARCHAR2(10);
    location_value number; 
  begin
    jsonStr:= '[';
    for location_info in location(REPORTCODE) LOOP
    location_code :=location_info.localtion;
      begin
        IF location_info.index_code='dev_efficiency_tested'
          then WITH TEMP AS(select 
                  dim_code,
                  dim_detail_code,
                  case when sum(value2)=0 then 0 else sum(value1)/sum(value2) end value1
                  from
                  (
                  select 
                  aa.report_code,
                  aa.org_id,
                  aa.dim_detail_code,
                  aa.dim_code,
                  case when aa.index_value=0 then 0 else (dd.index_value * (bb.index_value / aa.index_value * 100) * cc.index_value ) end as value1, 
                  case when aa.index_value=0 then 0 else (bb.index_value / aa.index_value * 100) * cc.index_value end as value2
                  from 
                  (
                  select 
                         repinst.report_code,
                         repinst.org_id,
                         indexinst.index_code,
                         indexinst_dim.dim_detail_code,
                         indexinst_dim.dim_code,
                         indexinst.index_value
                    from e7_sta_repinst repinst
                    left join e7_sta_rpt_index_inst repinst_indexinst
                      on repinst.repinst_id = repinst_indexinst.repinst_id
                    left join e7_sta_index_inst indexinst
                      on indexinst.sta_index_inst_id = repinst_indexinst.sta_index_inst_id and indexinst.index_code = 'dev_amt_in_use'
                    left join e7_sta_index_inst_dimen indexinst_dim
                      on indexinst_dim.sta_index_inst_id = indexinst.sta_index_inst_id
                   where repinst.report_code in ('T0036','T0037','T0038','T0039')
                     and repinst.org_id =P_RPTORGID 
                     and repinst.report_year = P_RPTYEAR 
                     and repinst.report_month =P_RPTMONTH 
                     and index_code is not null 
                   ) aa 
                  left join 
                  (
                  select 
                         repinst.report_code,
                         repinst.org_id,
                         indexinst.index_code,
                         indexinst_dim.dim_detail_code,
                         indexinst_dim.dim_code,
                         indexinst.index_value
                    from e7_sta_repinst repinst
                    left join e7_sta_rpt_index_inst repinst_indexinst
                      on repinst.repinst_id = repinst_indexinst.repinst_id
                    left join e7_sta_index_inst indexinst
                      on indexinst.sta_index_inst_id = repinst_indexinst.sta_index_inst_id and indexinst.index_code = 'dev_amt_tested'
                    left join e7_sta_index_inst_dimen indexinst_dim
                      on indexinst_dim.sta_index_inst_id = indexinst.sta_index_inst_id
                   where repinst.report_code in ('T0036','T0037','T0038','T0039')
                     and repinst.org_id =P_RPTORGID 
                     and repinst.report_year = P_RPTYEAR 
                     and repinst.report_month =P_RPTMONTH 
                     and index_code is not null 
                  )bb
                  on  aa.report_code = bb.report_code 
                  and aa.org_id = bb.org_id
                  and aa.dim_detail_code = bb.dim_detail_code
                  and aa.dim_code = bb.dim_code

                  left join 
                  (
                  select 
                         repinst.report_code,
                         repinst.org_id,
                         indexinst.index_code,
                         indexinst_dim.dim_detail_code,
                         indexinst_dim.dim_code,
                         indexinst.index_value
                    from e7_sta_repinst repinst
                    left join e7_sta_rpt_index_inst repinst_indexinst
                      on repinst.repinst_id = repinst_indexinst.repinst_id
                    left join e7_sta_index_inst indexinst
                      on indexinst.sta_index_inst_id = repinst_indexinst.sta_index_inst_id and indexinst.index_code = 'dev_capacity'
                    left join e7_sta_index_inst_dimen indexinst_dim
                      on indexinst_dim.sta_index_inst_id = indexinst.sta_index_inst_id
                   where repinst.report_code in ('T0036','T0037','T0038','T0039')
                     and repinst.org_id =P_RPTORGID 
                     and repinst.report_year = P_RPTYEAR 
                     and repinst.report_month =P_RPTMONTH 
                     and index_code is not null  
                  )cc
                  on  aa.report_code = cc.report_code 
                  and aa.org_id = cc.org_id
                  and aa.dim_detail_code = cc.dim_detail_code
                  and aa.dim_code = cc.dim_code
                  left join 
                  (
                  select 
                         repinst.report_code,
                         repinst.org_id,
                         indexinst.index_code,
                         indexinst_dim.dim_detail_code,
                         indexinst_dim.dim_code,
                         indexinst.index_value
                    from e7_sta_repinst repinst
                    left join e7_sta_rpt_index_inst repinst_indexinst
                      on repinst.repinst_id = repinst_indexinst.repinst_id
                    left join e7_sta_index_inst indexinst
                      on indexinst.sta_index_inst_id = repinst_indexinst.sta_index_inst_id and indexinst.index_code = 'dev_efficiency_tested'
                    left join e7_sta_index_inst_dimen indexinst_dim
                      on indexinst_dim.sta_index_inst_id = indexinst.sta_index_inst_id
                   where repinst.report_code in ('T0036','T0037','T0038','T0039')
                     and repinst.org_id =P_RPTORGID 
                     and repinst.report_year = P_RPTYEAR 
                     and repinst.report_month =P_RPTMONTH 
                     and index_code is not null 
                  )dd
                  on  aa.report_code = dd.report_code 
                  and aa.org_id = dd.org_id
                  and aa.dim_detail_code = dd.dim_detail_code
                  and aa.dim_code = dd.dim_code 

                  )

                  group by dim_code,dim_detail_code
                  )
                  SELECT VALUE1 into location_value FROM TEMP WHERE dim_detail_code=location_info.dim_detail_code;
          elsif location_info.index_code='dev_sys_efficiency_tested'--系统测试效率     
              then
               WITH TEMP AS( select 
                    dim_code,
                    dim_detail_code,
                    case when sum(value2)=0 then 0 else sum(value1)/sum(value2) end value1,
                    case when sum(value2)=0 then 0 else sum(value3)/sum(value2) end value2
                    from
                    (
                    select 
                    aa.report_code,
                    aa.org_id,
                    aa.dim_detail_code,
                    aa.dim_code,
                    case when aa.index_value=0 then 0 else (dd.index_value * (bb.index_value / aa.index_value * 100) * cc.index_value ) end as value1, 
                    case when aa.index_value=0 then 0 else (bb.index_value / aa.index_value * 100) * cc.index_value end as value2, 
                    case when aa.index_value=0 then 0 else (ee.index_value * (bb.index_value / aa.index_value * 100) * cc.index_value ) end as value3
                    from 
                    (
                    select 
                           repinst.report_code,
                           repinst.org_id,
                           indexinst.index_code,
                           indexinst_dim.dim_detail_code,
                           indexinst_dim.dim_code,
                           indexinst.index_value
                      from e7_sta_repinst repinst
                      left join e7_sta_rpt_index_inst repinst_indexinst
                        on repinst.repinst_id = repinst_indexinst.repinst_id
                      left join e7_sta_index_inst indexinst
                        on indexinst.sta_index_inst_id = repinst_indexinst.sta_index_inst_id and indexinst.index_code = 'dev_amt_in_use'
                      left join e7_sta_index_inst_dimen indexinst_dim
                        on indexinst_dim.sta_index_inst_id = indexinst.sta_index_inst_id
                     where repinst.report_code in ('T0036','T0037','T0038','T0039')
                     and repinst.org_id =P_RPTORGID 
                     and repinst.report_year = P_RPTYEAR 
                     and repinst.report_month =P_RPTMONTH 
                       and index_code is not null 
                     ) aa 
                    left join 
                    (
                    select 
                           repinst.report_code,
                           repinst.org_id,
                           indexinst.index_code,
                           indexinst_dim.dim_detail_code,
                           indexinst_dim.dim_code,
                           indexinst.index_value
                      from e7_sta_repinst repinst
                      left join e7_sta_rpt_index_inst repinst_indexinst
                        on repinst.repinst_id = repinst_indexinst.repinst_id
                      left join e7_sta_index_inst indexinst
                        on indexinst.sta_index_inst_id = repinst_indexinst.sta_index_inst_id and indexinst.index_code = 'dev_amt_tested'
                      left join e7_sta_index_inst_dimen indexinst_dim
                        on indexinst_dim.sta_index_inst_id = indexinst.sta_index_inst_id
                     where repinst.report_code in ('T0036','T0037','T0038','T0039')
                     and repinst.org_id =P_RPTORGID 
                     and repinst.report_year = P_RPTYEAR 
                     and repinst.report_month =P_RPTMONTH 
                       and index_code is not null 
                    )bb
                    on  aa.report_code = bb.report_code 
                    and aa.org_id = bb.org_id
                    and aa.dim_detail_code = bb.dim_detail_code
                    and aa.dim_code = bb.dim_code

                    left join 
                    (
                    select 
                           repinst.report_code,
                           repinst.org_id,
                           indexinst.index_code,
                           indexinst_dim.dim_detail_code,
                           indexinst_dim.dim_code,
                           indexinst.index_value
                      from e7_sta_repinst repinst
                      left join e7_sta_rpt_index_inst repinst_indexinst
                        on repinst.repinst_id = repinst_indexinst.repinst_id
                      left join e7_sta_index_inst indexinst
                        on indexinst.sta_index_inst_id = repinst_indexinst.sta_index_inst_id and indexinst.index_code = 'dev_capacity'
                      left join e7_sta_index_inst_dimen indexinst_dim
                        on indexinst_dim.sta_index_inst_id = indexinst.sta_index_inst_id
                     where repinst.report_code in ('T0036','T0037','T0038','T0039')
                     and repinst.org_id =P_RPTORGID 
                     and repinst.report_year = P_RPTYEAR 
                     and repinst.report_month =P_RPTMONTH 
                       and index_code is not null  
                    )cc
                    on  aa.report_code = cc.report_code 
                    and aa.org_id = cc.org_id
                    and aa.dim_detail_code = cc.dim_detail_code
                    and aa.dim_code = cc.dim_code
                    left join 
                    (
                    select 
                           repinst.report_code,
                           repinst.org_id,
                           indexinst.index_code,
                           indexinst_dim.dim_detail_code,
                           indexinst_dim.dim_code,
                           indexinst.index_value
                      from e7_sta_repinst repinst
                      left join e7_sta_rpt_index_inst repinst_indexinst
                        on repinst.repinst_id = repinst_indexinst.repinst_id
                      left join e7_sta_index_inst indexinst
                        on indexinst.sta_index_inst_id = repinst_indexinst.sta_index_inst_id and indexinst.index_code = 'dev_efficiency_tested'
                      left join e7_sta_index_inst_dimen indexinst_dim
                        on indexinst_dim.sta_index_inst_id = indexinst.sta_index_inst_id
                     where repinst.report_code in ('T0036','T0037','T0038','T0039')
                     and repinst.org_id =P_RPTORGID 
                     and repinst.report_year = P_RPTYEAR 
                     and repinst.report_month =P_RPTMONTH 
                       and index_code is not null 
                    )dd
                    on  aa.report_code = dd.report_code 
                    and aa.org_id = dd.org_id
                    and aa.dim_detail_code = dd.dim_detail_code
                    and aa.dim_code = dd.dim_code 
                    left join 
                    (
                    select 
                           repinst.report_code,
                           repinst.org_id,
                           indexinst.index_code,
                           indexinst_dim.dim_detail_code,
                           indexinst_dim.dim_code,
                           indexinst.index_value
                      from e7_sta_repinst repinst
                      left join e7_sta_rpt_index_inst repinst_indexinst
                        on repinst.repinst_id = repinst_indexinst.repinst_id
                      left join e7_sta_index_inst indexinst
                        on indexinst.sta_index_inst_id = repinst_indexinst.sta_index_inst_id and indexinst.index_code = 'dev_sys_efficiency_tested'
                      left join e7_sta_index_inst_dimen indexinst_dim
                        on indexinst_dim.sta_index_inst_id = indexinst.sta_index_inst_id
                     where repinst.report_code in ('T0036','T0037','T0038','T0039')
                     and repinst.org_id =P_RPTORGID 
                     and repinst.report_year = P_RPTYEAR 
                     and repinst.report_month =P_RPTMONTH 
                       and index_code is not null  
                    )ee
                    on  aa.report_code = ee.report_code 
                    and aa.org_id = ee.org_id
                    and aa.dim_detail_code = ee.dim_detail_code
                    and aa.dim_code = ee.dim_code

                    )
                    group by dim_code,dim_detail_code)
                    SELECT VALUE2 into location_value FROM TEMP WHERE dim_detail_code=location_info.dim_detail_code;
               elsif location_info.index_code='dev_sys_efficiency_tested' and location_info.dim_detail_code not in('Oil_fir_Het_fu','Oil_pup','Oil_pup_mach','Elec_subme_pup','Air_blower','Mach_pup')--数量子项
                    then
                      with t_temp as (
                            select repinst.report_code,
                                   indexinst.sta_index_inst_id,
                                   indexinst.index_inst_orderno,
                                   indexinst.index_code,
                                   indexinst_dim.dim_deteail_id,
                                   indexinst_dim.dim_detail_code,
                                   indexinst_dim.dim_code,
                                   indexinst.index_value,
                                   indexinst.unit_code index_unit_code,
                                   indexinst_dim.repinst_dtl_dimen,
                                   indexinst.remark,
                                   indexinst.composited_index_code,
                                   indexinst_dim.composite_dim_code

                              from e7_sta_repinst repinst
                              left join e7_sta_rpt_index_inst repinst_indexinst
                                on repinst.repinst_id = repinst_indexinst.repinst_id
                              left join e7_sta_index_inst indexinst
                                on indexinst.sta_index_inst_id = repinst_indexinst.sta_index_inst_id
                              left join e7_sta_index_inst_dimen indexinst_dim
                                on indexinst_dim.sta_index_inst_id = indexinst.sta_index_inst_id
                             where repinst.report_code in ('T0036','T0037','T0038','T0039')
                                 and repinst.org_id =P_RPTORGID 
                                 and repinst.report_year = P_RPTYEAR 
                                 and repinst.report_month =P_RPTMONTH 
                               ),
                               t_amt as 
                               (select report_code,index_code,dim_detail_code,index_value from t_temp where index_code = 'Engy_csmp_amt_pratl'),
                               t_sta
                               as
                               (select report_code,index_code,dim_detail_code,index_value from t_temp where index_code = 'Stadc_coef'),
                               t_result
                               as(
                               select a.report_Code,c.parent_dim_detail_code,a.dim_detail_code,a.index_value as amt,
                               b.index_value as stadc_coef,
                               a.index_value * b.index_value as stadc_amt
                               from t_amt a 
                               left join t_sta b 
                               on a.dim_detail_code = b.dim_detail_code
                              and a.report_Code = b.report_Code
                               left join e7_sta_dim_detail c
                               on a.dim_Detail_code = c.dim_detail_code)
                              select amt into location_value from t_result 
                               where dim_detail_code  not in (
                               select parent_dim_detail_code from t_result where parent_dim_detail_code is not null)
                               and dim_detail_code=location_info.dim_detail_code;
                       else WITH TEMP AS(select
                             indexinst.index_code,
                             indexinst_dim.dim_detail_code,
                             sum(indexinst.index_value) index_value
                        from e7_sta_repinst repinst
                        left join e7_sta_rpt_index_inst repinst_indexinst
                          on repinst.repinst_id = repinst_indexinst.repinst_id
                        left join e7_sta_index_inst indexinst
                          on indexinst.sta_index_inst_id = repinst_indexinst.sta_index_inst_id
                        left join e7_sta_index_inst_dimen indexinst_dim
                          on indexinst_dim.sta_index_inst_id = indexinst.sta_index_inst_id
                       where repinst.report_code in ('T0036','T0037','T0038','T0039')
                         and repinst.org_id =P_RPTORGID 
                         and repinst.report_year = P_RPTYEAR 
                         and repinst.report_month =P_RPTMONTH 
                         and indexinst.index_code != 'Stadc_coef' 
                       group by index_code,dim_detail_code)
                       SELECT index_value into location_value FROM TEMP WHERE dim_detail_code=location_info.dim_detail_code
                        And index_code=location_info.index_code
                       ;
            end if;
            exception when no_data_found then
            location_value:=0;   
      end;
      jsonStr := jsonStr || '{''location'':''' || location_code ||
                     ''',''value'':''' || to_char(location_value) || '''},';    
    end loop;  
   jsonStr:=jsonStr || ']';
   jsonStr:= replace(jsonStr,'},]','}]');
  end;
  PROCEDURE getSBZBSum (REPORTCODE IN VARCHAR2,

                    P_RPTYEAR  IN VARCHAR2,
                    P_RPTMONTH IN VARCHAR2,
                    P_RPTORGID IN VARCHAR2,
                    jsonStr OUT CLOB) IS
     cursor location(REPORTCODE varchar2)
                 is
                 SELECT ind.index_code,ind.localtion,
                 dim.dim_code dim_code,dim.dim_detail_code  dim_detail_code
                 FROM e7_excel_locationbyindex ind left join e7_excel_locationbydimen  dim
                 on ind.report_code=dim.report_code and ind.localtion=dim.localtion
                 where ind.report_code=REPORTCODE
                 and ind.is_py='N'
                 and ind.index_code<> 'Stadc_coef';
    location_info location%rowtype;
    location_code VARCHAR2(10);
    location_value number; 
    CODESQL varchar2(100);
    temp_sql varchar2(30000);
  begin
    jsonStr:= '[';
    if REPORTCODE='T0036'  THEN CODESQL:='''C0004'',''C0009'',''C0014'',''C0069'',''C0074'',''C0079''';END IF; 
    if REPORTCODE='T0037'  THEN CODESQL:='''C0037''';END IF; 
    if REPORTCODE='T0038'  THEN CODESQL:='''C0047''';END IF; 
    if REPORTCODE='T0039'  THEN CODESQL:='''C0019'',''C0024'',''C0054'',''C0059'',''C0029'',''C0097'',''C0102'',''C0107'',''C0117'' ,''C0171''';END IF; 
    for location_info in location(REPORTCODE) LOOP
    location_code :=location_info.localtion;
      begin
        IF location_info.index_code='dev_efficiency_tested'
          then temp_sql:=' WITH TEMP AS(select 
                  dim_code,
                  dim_detail_code,
                  case when sum(value2)=0 then 0 else sum(value1)/sum(value2) end value1,
                  case when sum(value2)=0 then 0 else sum(value3)/sum(value2) end value2
                  from
                  (
                  select 
                  aa.report_code,
                  aa.org_id,
                  aa.dim_detail_code,
                  aa.dim_code,
                  case when aa.index_value=0 then 0 else (dd.index_value * (bb.index_value / aa.index_value * 100) * cc.index_value ) end as value1, 
                  case when aa.index_value=0 then 0 else (bb.index_value / aa.index_value * 100) * cc.index_value end as value2, 
                  case when aa.index_value=0 then 0 else (ee.index_value * (bb.index_value / aa.index_value * 100) * cc.index_value ) end as value3
                  from 
                  (
                  select 
                         repinst.report_code,
                         repinst.org_id,
                         indexinst.index_code,
                         indexinst_dim.dim_detail_code,
                         indexinst_dim.dim_code,
                         indexinst.index_value
                    from e7_sta_repinst repinst
                    left join e7_sta_rpt_index_inst repinst_indexinst
                      on repinst.repinst_id = repinst_indexinst.repinst_id
                    left join e7_sta_index_inst indexinst
                      on indexinst.sta_index_inst_id = repinst_indexinst.sta_index_inst_id and indexinst.index_code = ''dev_amt_in_use''
                    left join e7_sta_index_inst_dimen indexinst_dim
                      on indexinst_dim.sta_index_inst_id = indexinst.sta_index_inst_id
                   where repinst.report_code in ('||CODESQL||')
                     and repinst.org_id in (select org_id from e7_sta_rpt_auth where v_org_id = '||P_RPTORGID||' and report_code in ('||CODESQL||'))
                     and repinst.report_year ='|| P_RPTYEAR ||'
                     and repinst.report_month ='||P_RPTMONTH|| '
                     and index_code is not null 
                   ) aa 
                  left join 
                  (
                  select 
                         repinst.report_code,
                         repinst.org_id,
                         indexinst.index_code,
                         indexinst_dim.dim_detail_code,
                         indexinst_dim.dim_code,
                         indexinst.index_value
                    from e7_sta_repinst repinst
                    left join e7_sta_rpt_index_inst repinst_indexinst
                      on repinst.repinst_id = repinst_indexinst.repinst_id
                    left join e7_sta_index_inst indexinst
                      on indexinst.sta_index_inst_id = repinst_indexinst.sta_index_inst_id and indexinst.index_code = ''dev_amt_tested''
                    left join e7_sta_index_inst_dimen indexinst_dim
                      on indexinst_dim.sta_index_inst_id = indexinst.sta_index_inst_id
                      where repinst.report_code in ('||CODESQL||')
                     and repinst.org_id in (select org_id from e7_sta_rpt_auth where v_org_id = '||P_RPTORGID||' and report_code in ('||CODESQL||'))
                     and repinst.report_year ='|| P_RPTYEAR ||'
                     and repinst.report_month ='||P_RPTMONTH|| '
                     and index_code is not null 
                  )bb
                  on  aa.report_code = bb.report_code 
                  and aa.org_id = bb.org_id
                  and aa.dim_detail_code = bb.dim_detail_code
                  and aa.dim_code = bb.dim_code

                  left join 
                  (
                  select 
                         repinst.report_code,
                         repinst.org_id,
                         indexinst.index_code,
                         indexinst_dim.dim_detail_code,
                         indexinst_dim.dim_code,
                         indexinst.index_value
                    from e7_sta_repinst repinst
                    left join e7_sta_rpt_index_inst repinst_indexinst
                      on repinst.repinst_id = repinst_indexinst.repinst_id
                    left join e7_sta_index_inst indexinst
                      on indexinst.sta_index_inst_id = repinst_indexinst.sta_index_inst_id and indexinst.index_code = ''dev_capacity''
                    left join e7_sta_index_inst_dimen indexinst_dim
                      on indexinst_dim.sta_index_inst_id = indexinst.sta_index_inst_id
                   where repinst.report_code in ('||CODESQL||')
                     and repinst.org_id in (select org_id from e7_sta_rpt_auth where v_org_id = '||P_RPTORGID||' and report_code in ('||CODESQL||'))
                     and repinst.report_year ='|| P_RPTYEAR ||'
                     and repinst.report_month ='||P_RPTMONTH|| '
                     and index_code is not null  
                  )cc
                  on  aa.report_code = cc.report_code 
                  and aa.org_id = cc.org_id
                  and aa.dim_detail_code = cc.dim_detail_code
                  and aa.dim_code = cc.dim_code
                  left join 
                  (
                  select 
                         repinst.report_code,
                         repinst.org_id,
                         indexinst.index_code,
                         indexinst_dim.dim_detail_code,
                         indexinst_dim.dim_code,
                         indexinst.index_value
                    from e7_sta_repinst repinst
                    left join e7_sta_rpt_index_inst repinst_indexinst
                      on repinst.repinst_id = repinst_indexinst.repinst_id
                    left join e7_sta_index_inst indexinst
                      on indexinst.sta_index_inst_id = repinst_indexinst.sta_index_inst_id and indexinst.index_code = ''dev_efficiency_tested''
                    left join e7_sta_index_inst_dimen indexinst_dim
                      on indexinst_dim.sta_index_inst_id = indexinst.sta_index_inst_id
                   where repinst.report_code in ('||CODESQL||')
                     and repinst.org_id in (select org_id from e7_sta_rpt_auth where v_org_id = '||P_RPTORGID||' and report_code in ('||CODESQL||'))
                     and repinst.report_year ='|| P_RPTYEAR ||'
                     and repinst.report_month ='||P_RPTMONTH|| '
                     and index_code is not null 
                  )dd
                  on  aa.report_code = dd.report_code 
                  and aa.org_id = dd.org_id
                  and aa.dim_detail_code = dd.dim_detail_code
                  and aa.dim_code = dd.dim_code 
                  left join 
                  (
                  select 
                         repinst.report_code,
                         repinst.org_id,
                         indexinst.index_code,
                         indexinst_dim.dim_detail_code,
                         indexinst_dim.dim_code,
                         indexinst.index_value
                    from e7_sta_repinst repinst
                    left join e7_sta_rpt_index_inst repinst_indexinst
                      on repinst.repinst_id = repinst_indexinst.repinst_id
                    left join e7_sta_index_inst indexinst
                      on indexinst.sta_index_inst_id = repinst_indexinst.sta_index_inst_id and indexinst.index_code = ''dev_sys_efficiency_tested''
                    left join e7_sta_index_inst_dimen indexinst_dim
                      on indexinst_dim.sta_index_inst_id = indexinst.sta_index_inst_id
                  where repinst.report_code in ('||CODESQL||')
                     and repinst.org_id in (select org_id from e7_sta_rpt_auth where v_org_id = '||P_RPTORGID||' and report_code in ('||CODESQL||'))
                     and repinst.report_year ='|| P_RPTYEAR ||'
                     and repinst.report_month ='||P_RPTMONTH|| '
                     and index_code is not null  
                  )ee
                  on  aa.report_code = ee.report_code 
                  and aa.org_id = ee.org_id
                  and aa.dim_detail_code = ee.dim_detail_code
                  and aa.dim_code = ee.dim_code

                  )

                  group by dim_code,dim_detail_code)
                  SELECT VALUE1  FROM TEMP WHERE dim_detail_code='''||location_info.dim_detail_code||'''';
            elsif location_info.index_code='dev_sys_efficiency_tested'
              then temp_sql:=' WITH TEMP AS(select 
                  dim_code,
                  dim_detail_code,
                  case when sum(value2)=0 then 0 else sum(value1)/sum(value2) end value1,
                  case when sum(value2)=0 then 0 else sum(value3)/sum(value2) end value2
                  from
                  (
                  select 
                  aa.report_code,
                  aa.org_id,
                  aa.dim_detail_code,
                  aa.dim_code,
                  case when aa.index_value=0 then 0 else (dd.index_value * (bb.index_value / aa.index_value * 100) * cc.index_value ) end as value1, 
                  case when aa.index_value=0 then 0 else (bb.index_value / aa.index_value * 100) * cc.index_value end as value2, 
                  case when aa.index_value=0 then 0 else (ee.index_value * (bb.index_value / aa.index_value * 100) * cc.index_value ) end as value3
                  from 
                  (
                  select 
                         repinst.report_code,
                         repinst.org_id,
                         indexinst.index_code,
                         indexinst_dim.dim_detail_code,
                         indexinst_dim.dim_code,
                         indexinst.index_value
                    from e7_sta_repinst repinst
                    left join e7_sta_rpt_index_inst repinst_indexinst
                      on repinst.repinst_id = repinst_indexinst.repinst_id
                    left join e7_sta_index_inst indexinst
                      on indexinst.sta_index_inst_id = repinst_indexinst.sta_index_inst_id and indexinst.index_code = ''dev_amt_in_use''
                    left join e7_sta_index_inst_dimen indexinst_dim
                      on indexinst_dim.sta_index_inst_id = indexinst.sta_index_inst_id
                   where repinst.report_code in ('||CODESQL||')
                     and repinst.org_id in (select org_id from e7_sta_rpt_auth where v_org_id = '||P_RPTORGID||' and report_code in ('||CODESQL||'))
                     and repinst.report_year ='|| P_RPTYEAR ||'
                     and repinst.report_month ='||P_RPTMONTH|| '
                     and index_code is not null 
                   ) aa 
                  left join 
                  (
                  select 
                         repinst.report_code,
                         repinst.org_id,
                         indexinst.index_code,
                         indexinst_dim.dim_detail_code,
                         indexinst_dim.dim_code,
                         indexinst.index_value
                    from e7_sta_repinst repinst
                    left join e7_sta_rpt_index_inst repinst_indexinst
                      on repinst.repinst_id = repinst_indexinst.repinst_id
                    left join e7_sta_index_inst indexinst
                      on indexinst.sta_index_inst_id = repinst_indexinst.sta_index_inst_id and indexinst.index_code = ''dev_amt_tested''
                    left join e7_sta_index_inst_dimen indexinst_dim
                      on indexinst_dim.sta_index_inst_id = indexinst.sta_index_inst_id
                   where repinst.report_code in ('||CODESQL||')
                     and repinst.org_id in (select org_id from e7_sta_rpt_auth where v_org_id = '||P_RPTORGID||' and report_code in ('||CODESQL||'))
                     and repinst.report_year ='|| P_RPTYEAR ||'
                     and repinst.report_month ='||P_RPTMONTH|| '
                     and index_code is not null 
                  )bb
                  on  aa.report_code = bb.report_code 
                  and aa.org_id = bb.org_id
                  and aa.dim_detail_code = bb.dim_detail_code
                  and aa.dim_code = bb.dim_code

                  left join 
                  (
                  select 
                         repinst.report_code,
                         repinst.org_id,
                         indexinst.index_code,
                         indexinst_dim.dim_detail_code,
                         indexinst_dim.dim_code,
                         indexinst.index_value
                    from e7_sta_repinst repinst
                    left join e7_sta_rpt_index_inst repinst_indexinst
                      on repinst.repinst_id = repinst_indexinst.repinst_id
                    left join e7_sta_index_inst indexinst
                      on indexinst.sta_index_inst_id = repinst_indexinst.sta_index_inst_id and indexinst.index_code = ''dev_capacity''
                    left join e7_sta_index_inst_dimen indexinst_dim
                      on indexinst_dim.sta_index_inst_id = indexinst.sta_index_inst_id
                    where repinst.report_code in ('||CODESQL||')
                     and repinst.org_id in (select org_id from e7_sta_rpt_auth where v_org_id = '||P_RPTORGID||' and report_code in ('||CODESQL||'))
                     and repinst.report_year ='|| P_RPTYEAR ||'
                     and repinst.report_month ='||P_RPTMONTH|| '
                     and index_code is not null  
                  )cc
                  on  aa.report_code = cc.report_code 
                  and aa.org_id = cc.org_id
                  and aa.dim_detail_code = cc.dim_detail_code
                  and aa.dim_code = cc.dim_code
                  left join 
                  (
                  select 
                         repinst.report_code,
                         repinst.org_id,
                         indexinst.index_code,
                         indexinst_dim.dim_detail_code,
                         indexinst_dim.dim_code,
                         indexinst.index_value
                    from e7_sta_repinst repinst
                    left join e7_sta_rpt_index_inst repinst_indexinst
                      on repinst.repinst_id = repinst_indexinst.repinst_id
                    left join e7_sta_index_inst indexinst
                      on indexinst.sta_index_inst_id = repinst_indexinst.sta_index_inst_id and indexinst.index_code = ''dev_efficiency_tested''
                    left join e7_sta_index_inst_dimen indexinst_dim
                      on indexinst_dim.sta_index_inst_id = indexinst.sta_index_inst_id
                    where repinst.report_code in ('||CODESQL||')
                     and repinst.org_id in (select org_id from e7_sta_rpt_auth where v_org_id = '||P_RPTORGID||' and report_code in ('||CODESQL||'))
                     and repinst.report_year ='|| P_RPTYEAR ||'
                     and repinst.report_month ='||P_RPTMONTH|| '
                     and index_code is not null 
                  )dd
                  on  aa.report_code = dd.report_code 
                  and aa.org_id = dd.org_id
                  and aa.dim_detail_code = dd.dim_detail_code
                  and aa.dim_code = dd.dim_code 
                  left join 
                  (
                  select 
                         repinst.report_code,
                         repinst.org_id,
                         indexinst.index_code,
                         indexinst_dim.dim_detail_code,
                         indexinst_dim.dim_code,
                         indexinst.index_value
                    from e7_sta_repinst repinst
                    left join e7_sta_rpt_index_inst repinst_indexinst
                      on repinst.repinst_id = repinst_indexinst.repinst_id
                    left join e7_sta_index_inst indexinst
                      on indexinst.sta_index_inst_id = repinst_indexinst.sta_index_inst_id and indexinst.index_code = ''dev_sys_efficiency_tested''
                    left join e7_sta_index_inst_dimen indexinst_dim
                      on indexinst_dim.sta_index_inst_id = indexinst.sta_index_inst_id
                   where repinst.report_code in ('||CODESQL||')
                     and repinst.org_id in (select org_id from e7_sta_rpt_auth where v_org_id = '||P_RPTORGID||' and report_code in ('||CODESQL||'))
                     and repinst.report_year ='|| P_RPTYEAR ||'
                     and repinst.report_month ='||P_RPTMONTH|| '
                     and index_code is not null  
                  )ee
                  on  aa.report_code = ee.report_code 
                  and aa.org_id = ee.org_id
                  and aa.dim_detail_code = ee.dim_detail_code
                  and aa.dim_code = ee.dim_code

                  )

                  group by dim_code,dim_detail_code)
                  SELECT VALUE2  FROM TEMP WHERE dim_detail_code='''||location_info.dim_detail_code||'''';
                 
               elsif  location_info.index_code='Engy_csmp_amt_pratl' and location_info.dim_detail_code not in('Inject_pup','Oil_fir_Het_fu','Oil_pup','Oil_pup_mach','Elec_subme_pup','Air_blower','Mach_pup')--数量子项
                 then temp_sql:=' with t_temp 
                        as
                        (select 
                        repinst.org_id,
                        indexinst.sta_index_inst_id,
                               indexinst.index_inst_orderno,
                               indexinst.index_code,
                               indexinst_dim.dim_deteail_id,
                               indexinst_dim.dim_detail_code,
                               indexinst_dim.dim_code,
                               indexinst.index_value,
                               indexinst.unit_code index_unit_code,
                               indexinst_dim.repinst_dtl_dimen,
                               indexinst.remark,
                               indexinst.composited_index_code,
                               indexinst_dim.composite_dim_code
                          from e7_sta_repinst repinst
                          left join e7_sta_rpt_index_inst repinst_indexinst
                            on repinst.repinst_id = repinst_indexinst.repinst_id
                          left join e7_sta_index_inst indexinst
                            on indexinst.sta_index_inst_id = repinst_indexinst.sta_index_inst_id
                          left join e7_sta_index_inst_dimen indexinst_dim
                            on indexinst_dim.sta_index_inst_id = indexinst.sta_index_inst_id
                          where repinst.report_code in ('||CODESQL||')
                             and repinst.org_id in (select org_id from e7_sta_rpt_auth where v_org_id = '||P_RPTORGID||' and report_code in ('||CODESQL||'))
                             and repinst.report_year ='|| P_RPTYEAR ||'
                             and repinst.report_month ='||P_RPTMONTH|| '
                           ),
                           t_amt 
                           as 
                           (select index_code,dim_detail_code,index_value,org_id from t_temp where index_code = ''Engy_csmp_amt_pratl''),
                           t_sta
                           as
                           (select distinct index_code,dim_detail_code,index_value,org_id from t_temp where index_code = ''Stadc_coef'')
                           select  sum(a.index_value) 
                           from t_amt a 
                           left join t_sta b 
                           on a.dim_detail_code = b.dim_detail_code
                           and a.org_id = b.org_id
                           left join e7_sta_dim_detail c
                           on a.dim_Detail_code = c.dim_detail_code
                           WHERE  a.dim_detail_code='''
                           ||location_info.dim_detail_code||'''';
                       else temp_sql:=' WITH TEMP AS( select 
                              num1.index_code,
                              num1.dim_detail_code,
                              sum(num1.index_value) index_value,
                              sum(num1.index_value2)index_value2
                          from 
                          (
                          select
                                 indexinst.index_code,
                                 indexinst_dim.dim_detail_code,
                                 indexinst.index_value,
                                 indexinst.index_value *
                                 (
                                 select
                                  MAX(decode(indexinst.index_code,''Engy_csmp_amt_pratl'',indexinst_.index_value,null ))
                                  
                            from e7_sta_repinst repinst_
                            left join e7_sta_rpt_index_inst repinst_indexinst_
                              on repinst_.repinst_id = repinst_indexinst_.repinst_id
                            left join e7_sta_index_inst indexinst_
                              on indexinst_.sta_index_inst_id = repinst_indexinst_.sta_index_inst_id 
                            left join e7_sta_index_inst_dimen indexinst_dim_
                              on indexinst_dim_.sta_index_inst_id = indexinst_.sta_index_inst_id
                           where repinst_.report_code =   repinst.report_code
                             and repinst_.org_id = repinst.org_id
                             and repinst_.report_year =  repinst.report_year
                             and repinst_.report_month = repinst.report_month
                             and indexinst_.index_code = ''Stadc_coef''
                             and indexinst_dim_.dim_detail_code = indexinst_dim.dim_detail_code   
                                 ) index_value2

                            from e7_sta_repinst repinst
                            left join e7_sta_rpt_index_inst repinst_indexinst
                              on repinst.repinst_id = repinst_indexinst.repinst_id
                            left join e7_sta_index_inst indexinst
                              on indexinst.sta_index_inst_id = repinst_indexinst.sta_index_inst_id 
                                left join e7_sta_index_inst_dimen indexinst_dim
                              on indexinst_dim.sta_index_inst_id = indexinst.sta_index_inst_id
                           where repinst.report_code in ('||CODESQL||')
                             and repinst.org_id in (select org_id from e7_sta_rpt_auth where v_org_id = '||P_RPTORGID||' and report_code in ('||CODESQL||'))
                             and repinst.report_year ='|| P_RPTYEAR ||'
                             and repinst.report_month ='||P_RPTMONTH|| '
                             and indexinst.index_code != ''Stadc_coef'' 
                          )num1

                          group by index_code,dim_detail_code)
                          SELECT index_value  FROM TEMP WHERE dim_detail_code='''||location_info.dim_detail_code||''' 
								                And index_code='''||location_info.index_code||''''; 
                          
        end if;     
        execute immediate temp_sql into location_value;   
        exception when no_data_found then
            location_value:=0;       
      end;
      jsonStr := jsonStr || '{''location'':''' || location_code ||
                     ''',''value'':''' || to_char(location_value) || '''},';   
    end loop;  
   jsonStr:=jsonStr || ']';
   jsonStr:= replace(jsonStr,'},]','}]');
  end;
  PROCEDURE getSCSum (REPORTCODE IN VARCHAR2,

                    P_RPTYEAR  IN VARCHAR2,
                    P_RPTMONTH IN VARCHAR2,
                    P_RPTORGID IN VARCHAR2,
                    jsonStr OUT CLOB) IS
     cursor location(REPORTCODE varchar2)
                 is
                 SELECT ind.report_code,ind.index_code,ind.localtion,
                         dim1.dim_code dim_code1,dim1.dim_detail_code  dim_detail_code1,
                         dim2.dim_code dim_code2,dim2.dim_detail_code  dim_detail_code2,
                         dim3.dim_code dim_code3,dim3.dim_detail_code  dim_detail_code3
                  FROM e7_excel_locationbyindex ind
                  left join e7_excel_locationbydimen  dim1
                  on ind.report_code=dim1.report_code and ind.localtion=dim1.localtion
                  and (dim1.dim_code in
                  ('Product_steam_mod','Drill_E_dissip_type',
                  'Or_Comph_engy_lost_typ',
                  'LNG_outp_vol_typ',
                  'Orig_energy_type',
                  'Long_line_type',
                  'Industry_type',
                  'Gas_stat_typ',
                  'Professional_type',
                  'Sal_pro_hl_type',
                  'Gas_stat_typ') or (dim1.dim_code='Sal_pro_amt_type' and dim1.dim_detail_code in ('Wholesale','Retail','Fuel_gas')))
                  left join e7_excel_locationbydimen  dim2
                  on ind.report_code=dim2.report_code and ind.localtion=dim2.localtion
                  and dim2.dim_code='Sal_pro_amt_type'and dim2.dim_detail_code <> dim1.dim_detail_code
                  left join e7_excel_locationbydimen  dim3
                  on ind.report_code=dim3.report_code and ind.localtion=dim3.localtion
                  and dim3.dim_code in('Sal_form1'，'Sal_form2')
                  where ind.report_code=REPORTCODE
                 and ind.is_py='N';
    location_info location%rowtype;
    location_code VARCHAR2(10);
    location_value number; 
  begin
    jsonStr:= '[';
    for location_info in location(REPORTCODE) LOOP
    location_code :=location_info.localtion;
      begin
        with VALTEMP as(
             SELECT T3.INDEX_CODE,
                 SUM(T3.INDEX_VALUE) AS INDEX_VALUE,
                 nvl(T4.DIM_CODE，'*') AS DIM_CODE1,
                 nvl(T4.DIM_DETAIL_CODE,'*') AS DIM_DETAIL_CODE1,
                 nvl(T5.DIM_CODE,'*') AS DIM_CODE2,
                 nvl(T5.DIM_DETAIL_CODE,'*') AS DIM_DETAIL_CODE2,
                 nvl(T6.DIM_CODE,'*') AS DIM_CODE3,
                 nvl(T6.DIM_DETAIL_CODE,'*') AS DIM_DETAIL_CODE3
            FROM E7_STA_REPINST T1
            LEFT JOIN E7_STA_RPT_INDEX_INST T2 ON T1.REPINST_ID = T2.REPINST_ID
            LEFT JOIN E7_STA_INDEX_INST T3 ON T2.STA_INDEX_INST_ID = T3.STA_INDEX_INST_ID
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T4 ON T2.STA_INDEX_INST_ID = T4.STA_INDEX_INST_ID
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T5 ON T2.STA_INDEX_INST_ID = T5.STA_INDEX_INST_ID
             AND T4.DIM_DETAIL_CODE <> T5.DIM_DETAIL_CODE
           LEFT JOIN E7_STA_INDEX_INST_DIMEN T6 ON T2.STA_INDEX_INST_ID = T6.STA_INDEX_INST_ID 
           AND T4.DIM_DETAIL_CODE <> T5.DIM_DETAIL_CODE 
           AND T4.DIM_DETAIL_CODE <> T6.DIM_DETAIL_CODE 
           AND T5.DIM_DETAIL_CODE<>T6.DIM_DETAIL_CODE
           WHERE T1.REPORT_CODE =REPORTCODE
             AND T1.REPORT_YEAR =P_RPTYEAR
             AND T1.REPORT_MONTH =P_RPTMONTH
             AND T1.ORG_ID IN(SELECT DISTINCT A.ORG_ID FROM E7_STA_RPT_AUTH A WHERE A.V_ORG_ID = P_RPTORGID AND A.REPORT_CODE = REPORTCODE)
             GROUP BY T3.INDEX_CODE,
                 T4.DIM_CODE,T4.DIM_DETAIL_CODE,
                 T5.DIM_CODE,T5.DIM_DETAIL_CODE,
                 T6.DIM_CODE,T6.DIM_DETAIL_CODE
        )   
        select  INDEX_VALUE into location_value from VALTEMP  
         WHERE VALTEMP.INDEX_CODE=location_info.index_code AND
                              VALTEMP.DIM_CODE1= nvl(location_info.DIM_CODE1,'*') AND
                              VALTEMP.DIM_DETAIL_CODE1= nvl(location_info.DIM_DETAIL_CODE1,'*')AND
                              VALTEMP.DIM_CODE2= nvl(location_info.DIM_CODE2,'*') AND
                              VALTEMP.DIM_DETAIL_CODE2= nvl(location_info.DIM_DETAIL_CODE2,'*') AND
                              VALTEMP.DIM_CODE3= nvl(location_info.DIM_CODE3 ,'*' ) AND
                              VALTEMP.DIM_DETAIL_CODE3= nvl(location_info.DIM_DETAIL_CODE3 ,'*' );
        exception when no_data_found then
        location_value:=0; 
      end;
      jsonStr := jsonStr || '{''location'':''' || location_code ||
                     ''',''value'':''' || to_char(location_value) || '''},';
         dbms_output.put_line(jsonStr);  
    END LOOP;
   jsonStr:=jsonStr || ']';
   jsonStr:= replace(jsonStr,'},]','}]');
  end;
   PROCEDURE getSBSum (REPORTCODE IN VARCHAR2,
                    P_RPTYEAR  IN VARCHAR2,
                    P_RPTMONTH IN VARCHAR2,
                    P_RPTORGID IN VARCHAR2,
                    jsonStr OUT CLOB) IS
   cursor location(REPORTCODE varchar2)
                 is
                 SELECT ind.report_code,ind.index_code,ind.localtion,
                          dim.dim_code dim_code,dim.dim_detail_code  dim_detail_code
                          FROM e7_excel_locationbyindex ind
                          left join e7_excel_locationbydimen  dim
                          on ind.report_code=dim.report_code and ind.localtion=dim.localtion
                          where ind.report_code=REPORTCODE
                          and ind.is_py='N'
                          and ind.index_code<> 'Stadc_coef';
    location_info location%rowtype;
    location_code VARCHAR2(10);
    location_value number; 
  begin
    jsonStr:= '[';
    for location_info in location(REPORTCODE) LOOP
    location_code :=location_info.localtion;
      begin
        IF location_info.index_code='dev_efficiency_tested' --'设备测试效率 collect value1
          then with temp as(
            select 
                dim_code,
                dim_detail_code,
                case when sum(value2)=0 then 0 else sum(value1)/sum(value2) end value1,
                case when sum(value2)=0 then 0 else sum(value3)/sum(value2) end value2
                from
                (
                select 
                aa.report_code,
                aa.org_id,
                aa.dim_detail_code,
                aa.dim_code,
                case when aa.index_value=0 then 0 else (dd.index_value * (bb.index_value / aa.index_value * 100) * cc.index_value ) end as value1, 
                case when aa.index_value=0 then 0 else (bb.index_value / aa.index_value * 100) * cc.index_value end as value2, 
                case when aa.index_value=0 then 0 else (ee.index_value * (bb.index_value / aa.index_value * 100) * cc.index_value ) end as value3
                from 
                (
                select 
                       repinst.report_code,
                       repinst.org_id,
                       indexinst.index_code,
                       indexinst_dim.dim_detail_code,
                       indexinst_dim.dim_code,
                       indexinst.index_value
                  from e7_sta_repinst repinst
                  left join e7_sta_rpt_index_inst repinst_indexinst
                    on repinst.repinst_id = repinst_indexinst.repinst_id
                  left join e7_sta_index_inst indexinst
                    on indexinst.sta_index_inst_id = repinst_indexinst.sta_index_inst_id and indexinst.index_code = 'dev_amt_in_use'
                  left join e7_sta_index_inst_dimen indexinst_dim
                    on indexinst_dim.sta_index_inst_id = indexinst.sta_index_inst_id
                 where repinst.report_code = REPORTCODE
                   and repinst.org_id in (select org_id from e7_sta_rpt_auth where v_org_id =P_RPTORGID and report_code =REPORTCODE)
                   and repinst.report_year =P_RPTYEAR 
                   and repinst.report_month =P_RPTMONTH
                   and index_code is not null 
                 ) aa 
                left join 
                (
                select 
                       repinst.report_code,
                       repinst.org_id,
                       indexinst.index_code,
                       indexinst_dim.dim_detail_code,
                       indexinst_dim.dim_code,
                       indexinst.index_value
                  from e7_sta_repinst repinst
                  left join e7_sta_rpt_index_inst repinst_indexinst
                    on repinst.repinst_id = repinst_indexinst.repinst_id
                  left join e7_sta_index_inst indexinst
                    on indexinst.sta_index_inst_id = repinst_indexinst.sta_index_inst_id and indexinst.index_code = 'dev_amt_tested'
                  left join e7_sta_index_inst_dimen indexinst_dim
                    on indexinst_dim.sta_index_inst_id = indexinst.sta_index_inst_id
                where repinst.report_code = REPORTCODE
                   and repinst.org_id in (select org_id from e7_sta_rpt_auth where v_org_id =P_RPTORGID and report_code =REPORTCODE)
                   and repinst.report_year =P_RPTYEAR 
                   and repinst.report_month =P_RPTMONTH
                   and index_code is not null 
                )bb
                on  aa.report_code = bb.report_code 
                and aa.org_id = bb.org_id
                and aa.dim_detail_code = bb.dim_detail_code
                and aa.dim_code = bb.dim_code

                left join 
                (
                select 
                       repinst.report_code,
                       repinst.org_id,
                       indexinst.index_code,
                       indexinst_dim.dim_detail_code,
                       indexinst_dim.dim_code,
                       indexinst.index_value
                  from e7_sta_repinst repinst
                  left join e7_sta_rpt_index_inst repinst_indexinst
                    on repinst.repinst_id = repinst_indexinst.repinst_id
                  left join e7_sta_index_inst indexinst
                    on indexinst.sta_index_inst_id = repinst_indexinst.sta_index_inst_id and indexinst.index_code = 'dev_capacity'
                  left join e7_sta_index_inst_dimen indexinst_dim
                    on indexinst_dim.sta_index_inst_id = indexinst.sta_index_inst_id
                where repinst.report_code = REPORTCODE
                   and repinst.org_id in (select org_id from e7_sta_rpt_auth where v_org_id =P_RPTORGID and report_code =REPORTCODE)
                   and repinst.report_year =P_RPTYEAR 
                   and repinst.report_month =P_RPTMONTH
                   and index_code is not null  
                )cc
                on  aa.report_code = cc.report_code 
                and aa.org_id = cc.org_id
                and aa.dim_detail_code = cc.dim_detail_code
                and aa.dim_code = cc.dim_code
                left join 
                (
                select 
                       repinst.report_code,
                       repinst.org_id,
                       indexinst.index_code,
                       indexinst_dim.dim_detail_code,
                       indexinst_dim.dim_code,
                       indexinst.index_value
                  from e7_sta_repinst repinst
                  left join e7_sta_rpt_index_inst repinst_indexinst
                    on repinst.repinst_id = repinst_indexinst.repinst_id
                  left join e7_sta_index_inst indexinst
                    on indexinst.sta_index_inst_id = repinst_indexinst.sta_index_inst_id and indexinst.index_code = 'dev_efficiency_tested'
                  left join e7_sta_index_inst_dimen indexinst_dim
                    on indexinst_dim.sta_index_inst_id = indexinst.sta_index_inst_id
                where repinst.report_code = REPORTCODE
                   and repinst.org_id in (select org_id from e7_sta_rpt_auth where v_org_id =P_RPTORGID and report_code =REPORTCODE)
                   and repinst.report_year =P_RPTYEAR 
                   and repinst.report_month =P_RPTMONTH
                   and index_code is not null 
                )dd
                on  aa.report_code = dd.report_code 
                and aa.org_id = dd.org_id
                and aa.dim_detail_code = dd.dim_detail_code
                and aa.dim_code = dd.dim_code 
                left join 
                (
                select 
                       repinst.report_code,
                       repinst.org_id,
                       indexinst.index_code,
                       indexinst_dim.dim_detail_code,
                       indexinst_dim.dim_code,
                       indexinst.index_value
                  from e7_sta_repinst repinst
                  left join e7_sta_rpt_index_inst repinst_indexinst
                    on repinst.repinst_id = repinst_indexinst.repinst_id
                  left join e7_sta_index_inst indexinst
                    on indexinst.sta_index_inst_id = repinst_indexinst.sta_index_inst_id and indexinst.index_code = 'dev_sys_efficiency_tested'
                  left join e7_sta_index_inst_dimen indexinst_dim
                    on indexinst_dim.sta_index_inst_id = indexinst.sta_index_inst_id
                 where repinst.report_code = REPORTCODE
                   and repinst.org_id in (select org_id from e7_sta_rpt_auth where v_org_id =P_RPTORGID and report_code =REPORTCODE)
                   and repinst.report_year =P_RPTYEAR 
                   and repinst.report_month =P_RPTMONTH
                   and index_code is not null  
                )ee
                on  aa.report_code = ee.report_code 
                and aa.org_id = ee.org_id
                and aa.dim_detail_code = ee.dim_detail_code
                and aa.dim_code = ee.dim_code

                )

                group by dim_code,dim_detail_code,value1,value2
            )
            select max(temp.value1) into location_value from temp where temp.dim_code=location_info.dim_code and temp.dim_detail_code=location_info.dim_detail_code;
          elsif location_info.index_code='dev_sys_efficiency_tested'--系统测试效率      collect value2
              then with temp as(
            select 
                dim_code,
                dim_detail_code,
                case when sum(value2)=0 then 0 else sum(value1)/sum(value2) end value1,
                case when sum(value2)=0 then 0 else sum(value3)/sum(value2) end value2
                from
                (
                select 
                aa.report_code,
                aa.org_id,
                aa.dim_detail_code,
                aa.dim_code,
                case when aa.index_value=0 then 0 else (dd.index_value * (bb.index_value / aa.index_value * 100) * cc.index_value ) end as value1, 
                case when aa.index_value=0 then 0 else (bb.index_value / aa.index_value * 100) * cc.index_value end as value2, 
                case when aa.index_value=0 then 0 else (ee.index_value * (bb.index_value / aa.index_value * 100) * cc.index_value ) end as value3
                from 
                (
                select 
                       repinst.report_code,
                       repinst.org_id,
                       indexinst.index_code,
                       indexinst_dim.dim_detail_code,
                       indexinst_dim.dim_code,
                       indexinst.index_value
                  from e7_sta_repinst repinst
                  left join e7_sta_rpt_index_inst repinst_indexinst
                    on repinst.repinst_id = repinst_indexinst.repinst_id
                  left join e7_sta_index_inst indexinst
                    on indexinst.sta_index_inst_id = repinst_indexinst.sta_index_inst_id and indexinst.index_code = 'dev_amt_in_use'
                  left join e7_sta_index_inst_dimen indexinst_dim
                    on indexinst_dim.sta_index_inst_id = indexinst.sta_index_inst_id
                 where repinst.report_code = REPORTCODE
                   and repinst.org_id in (select org_id from e7_sta_rpt_auth where v_org_id =P_RPTORGID and report_code =REPORTCODE)
                   and repinst.report_year =P_RPTYEAR 
                   and repinst.report_month =P_RPTMONTH
                   and index_code is not null 
                 ) aa 
                left join 
                (
                select 
                       repinst.report_code,
                       repinst.org_id,
                       indexinst.index_code,
                       indexinst_dim.dim_detail_code,
                       indexinst_dim.dim_code,
                       indexinst.index_value
                  from e7_sta_repinst repinst
                  left join e7_sta_rpt_index_inst repinst_indexinst
                    on repinst.repinst_id = repinst_indexinst.repinst_id
                  left join e7_sta_index_inst indexinst
                    on indexinst.sta_index_inst_id = repinst_indexinst.sta_index_inst_id and indexinst.index_code = 'dev_amt_tested'
                  left join e7_sta_index_inst_dimen indexinst_dim
                    on indexinst_dim.sta_index_inst_id = indexinst.sta_index_inst_id
                where repinst.report_code = REPORTCODE
                   and repinst.org_id in (select org_id from e7_sta_rpt_auth where v_org_id =P_RPTORGID and report_code =REPORTCODE)
                   and repinst.report_year =P_RPTYEAR 
                   and repinst.report_month =P_RPTMONTH
                   and index_code is not null 
                )bb
                on  aa.report_code = bb.report_code 
                and aa.org_id = bb.org_id
                and aa.dim_detail_code = bb.dim_detail_code
                and aa.dim_code = bb.dim_code

                left join 
                (
                select 
                       repinst.report_code,
                       repinst.org_id,
                       indexinst.index_code,
                       indexinst_dim.dim_detail_code,
                       indexinst_dim.dim_code,
                       indexinst.index_value
                  from e7_sta_repinst repinst
                  left join e7_sta_rpt_index_inst repinst_indexinst
                    on repinst.repinst_id = repinst_indexinst.repinst_id
                  left join e7_sta_index_inst indexinst
                    on indexinst.sta_index_inst_id = repinst_indexinst.sta_index_inst_id and indexinst.index_code = 'dev_capacity'
                  left join e7_sta_index_inst_dimen indexinst_dim
                    on indexinst_dim.sta_index_inst_id = indexinst.sta_index_inst_id
                where repinst.report_code = REPORTCODE
                   and repinst.org_id in (select org_id from e7_sta_rpt_auth where v_org_id =P_RPTORGID and report_code =REPORTCODE)
                   and repinst.report_year =P_RPTYEAR 
                   and repinst.report_month =P_RPTMONTH
                   and index_code is not null  
                )cc
                on  aa.report_code = cc.report_code 
                and aa.org_id = cc.org_id
                and aa.dim_detail_code = cc.dim_detail_code
                and aa.dim_code = cc.dim_code
                left join 
                (
                select 
                       repinst.report_code,
                       repinst.org_id,
                       indexinst.index_code,
                       indexinst_dim.dim_detail_code,
                       indexinst_dim.dim_code,
                       indexinst.index_value
                  from e7_sta_repinst repinst
                  left join e7_sta_rpt_index_inst repinst_indexinst
                    on repinst.repinst_id = repinst_indexinst.repinst_id
                  left join e7_sta_index_inst indexinst
                    on indexinst.sta_index_inst_id = repinst_indexinst.sta_index_inst_id and indexinst.index_code = 'dev_efficiency_tested'
                  left join e7_sta_index_inst_dimen indexinst_dim
                    on indexinst_dim.sta_index_inst_id = indexinst.sta_index_inst_id
                where repinst.report_code = REPORTCODE
                   and repinst.org_id in (select org_id from e7_sta_rpt_auth where v_org_id =P_RPTORGID and report_code =REPORTCODE)
                   and repinst.report_year =P_RPTYEAR 
                   and repinst.report_month =P_RPTMONTH
                   and index_code is not null 
                )dd
                on  aa.report_code = dd.report_code 
                and aa.org_id = dd.org_id
                and aa.dim_detail_code = dd.dim_detail_code
                and aa.dim_code = dd.dim_code 
                left join 
                (
                select 
                       repinst.report_code,
                       repinst.org_id,
                       indexinst.index_code,
                       indexinst_dim.dim_detail_code,
                       indexinst_dim.dim_code,
                       indexinst.index_value
                  from e7_sta_repinst repinst
                  left join e7_sta_rpt_index_inst repinst_indexinst
                    on repinst.repinst_id = repinst_indexinst.repinst_id
                  left join e7_sta_index_inst indexinst
                    on indexinst.sta_index_inst_id = repinst_indexinst.sta_index_inst_id and indexinst.index_code = 'dev_sys_efficiency_tested'
                  left join e7_sta_index_inst_dimen indexinst_dim
                    on indexinst_dim.sta_index_inst_id = indexinst.sta_index_inst_id
                 where repinst.report_code = REPORTCODE
                   and repinst.org_id in (select org_id from e7_sta_rpt_auth where v_org_id =P_RPTORGID and report_code =REPORTCODE)
                   and repinst.report_year =P_RPTYEAR 
                   and repinst.report_month =P_RPTMONTH
                   and index_code is not null  
                )ee
                on  aa.report_code = ee.report_code 
                and aa.org_id = ee.org_id
                and aa.dim_detail_code = ee.dim_detail_code
                and aa.dim_code = ee.dim_code

                )

                group by dim_code,dim_detail_code,value1,value2
            )
            select max(temp.value2) into location_value from temp where temp.dim_code=location_info.dim_code and temp.dim_detail_code=location_info.dim_detail_code;
               else --'设备测试效率 collect2 
                 with temp as (select
                             indexinst.index_code,
                             indexinst_dim.dim_detail_code,
                             sum(indexinst.index_value) index_value
                        from e7_sta_repinst repinst
                        left join e7_sta_rpt_index_inst repinst_indexinst
                          on repinst.repinst_id = repinst_indexinst.repinst_id
                        left join e7_sta_index_inst indexinst
                          on indexinst.sta_index_inst_id = repinst_indexinst.sta_index_inst_id
                        left join e7_sta_index_inst_dimen indexinst_dim
                          on indexinst_dim.sta_index_inst_id = indexinst.sta_index_inst_id
                       where repinst.report_code = REPORTCODE
                           and repinst.org_id in (select org_id from e7_sta_rpt_auth where v_org_id =P_RPTORGID and report_code =REPORTCODE)
                           and repinst.report_year =P_RPTYEAR 
                           and repinst.report_month =P_RPTMONTH
                         and indexinst.index_code != 'Stadc_coef' 
                       group by index_code,dim_detail_code )  
                select sum(temp.index_value) into location_value from temp 
                where temp.dim_detail_code=location_info.dim_detail_code
                and temp.index_code=location_info.index_code ;
        end if;
        exception when no_data_found then
        location_value:=0;   
      end;
      jsonStr := jsonStr || '{''location'':''' || location_code ||
                     ''',''value'':''' || to_char(location_value) || '''},';    
    end loop;  
   jsonStr:=jsonStr || ']';
   jsonStr:= replace(jsonStr,'},]','}]');
  end;
  PROCEDURE getCJSum (REPORTCODE IN VARCHAR2,

                    P_RPTYEAR  IN VARCHAR2,
                    P_RPTMONTH IN VARCHAR2,
                    P_RPTORGID IN VARCHAR2,
                    jsonStr OUT CLOB) IS
     cursor location(REPORTCODE varchar2)
                 is
                 SELECT ind.report_code,ind.index_code,ind.localtion,
                         dim1.dim_code dim_code1,dim1.dim_detail_code  dim_detail_code1
                  FROM e7_excel_locationbyindex ind
                  left join e7_excel_locationbydimen  dim1
                  on ind.report_code=dim1.report_code and ind.localtion=dim1.localtion
                  and (dim1.dim_code in
                  ('Crude_oil_alter_typ','Chemi_prod_type','Professional_type') 
                  or (dim1.dim_code='Crude_oil_alter_typ1' and dim1.dim_detail_code in ('Industry_C','Non_industrial_C','Industry_G','Non_industrial_G','Industry_O','Non_industrial_O'))
                  or(dim1.dim_code='Crude_oil_alter_typ2' and dim1.dim_detail_code in ('Coal_repl_oil_amo_C','Gas_repl_oil_amo_C','Other_repl_oil_amo_C','Coal_repl_oil_amo_G','Gas_repl_oil_amo_G','Other_repl_oil_amo_G','Coal_repl_oil_amo_R','Gas_repl_oil_amo_R','Other_repl_oil_amo_R'))
                  or(ind.index_code in('Saved_engy_amt','Saved_engy_value_amt','Saved_watr_amt','Saved_watr_value_amt') and dim1.dim_code='Industry_type')
                  )
                  where ind.report_code=REPORTCODE
                 and ind.is_py='N';
    location_info location%rowtype;
    location_code VARCHAR2(10);
    location_value number; 
  begin
    jsonStr:= '[';
    for location_info in location(REPORTCODE) LOOP
    location_code :=location_info.localtion;
      begin
        with VALTEMP as(SELECT INDEXINST.INDEX_CODE,nvl(INDEXINSTDIMEN.DIM_CODE,'*') DIM_CODE1,nvl(INDEXINSTDIMEN.DIM_DETAIL_CODE,'*') DIM_DETAIL_CODE1,
             SUM(INDEXINST.INDEX_VALUE) INDEX_VALUE
        FROM E7_STA_REPINST REPINST
        LEFT JOIN E7_STA_RPT_INDEX_INST RPTINDEXINST ON REPINST.REPINST_ID = RPTINDEXINST.REPINST_ID
        LEFT JOIN E7_STA_INDEX_INST INDEXINST ON RPTINDEXINST.STA_INDEX_INST_ID = INDEXINST.STA_INDEX_INST_ID
        LEFT JOIN E7_STA_INDEX_INST_DIMEN INDEXINSTDIMEN ON RPTINDEXINST.STA_INDEX_INST_ID = INDEXINSTDIMEN.STA_INDEX_INST_ID
       WHERE REPINST.REPORT_CODE =REPORTCODE
         AND REPINST.REPORT_YEAR =P_RPTYEAR
         AND REPINST.REPORT_MONTH =P_RPTMONTH
         AND REPINST.ORG_ID IN (select org_id from e7_sta_rpt_auth where v_org_id = P_RPTORGID and report_code =REPORTCODE)

   GROUP BY INDEXINST.INDEX_CODE,INDEXINSTDIMEN.DIM_CODE,INDEXINSTDIMEN.DIM_DETAIL_CODE
        )   
        select  INDEX_VALUE into location_value from VALTEMP  
         WHERE VALTEMP.INDEX_CODE=location_info.index_code AND
                              VALTEMP.DIM_CODE1= nvl(location_info.DIM_CODE1,'*') AND
                              VALTEMP.DIM_DETAIL_CODE1= nvl(location_info.DIM_DETAIL_CODE1,'*');
        exception when no_data_found then
        location_value:=0; 
      end;
      jsonStr := jsonStr || '{''location'':''' || location_code ||
                     ''',''value'':''' || to_char(location_value) || '''},';
         dbms_output.put_line(jsonStr);  
    END LOOP;
   jsonStr:=jsonStr || ']';
   jsonStr:= replace(jsonStr,'},]','}]');
  end;
  
  procedure getT0012Sum(P_RPTCODE IN VARCHAR2,
            	          P_RPTYEAR  IN VARCHAR2,
                       P_RPTMONTH IN VARCHAR2,
                       P_RPTORGID IN VARCHAR2,jsonStr OUT CLOB) IS
    
    Cursor return_cursor is
      SELECT *
        FROM (WITH DATAS AS
 (SELECT REPORT_CODE,
         REPORT_YEAR,
         REPORT_MONTH,
         INDEX_CODE,
         SUM(INDEX_VALUE) INDEX_VALUE,
         DIM_CODE1,
         DIM_DETAIL_CODE1,
         DIM_CODE2,
         DIM_DETAIL_CODE2,
         DIM_CODE4,
         DIM_DETAIL_CODE4,
         DIM_CODE5,
         DIM_DETAIL_CODE5,
         DIM_CODE6,
         DIM_DETAIL_CODE6
    FROM (SELECT P_RPTCODE REPORT_CODE,
                 T1.REPORT_YEAR,
                 T1.REPORT_MONTH,
                 T1.ORG_ID,
                 T3.INDEX_CODE,
                 T3.INDEX_VALUE,
                 T4.DIM_CODE AS DIM_CODE1,
                 DECODE(T4.DIM_DETAIL_CODE,
                        'Transportation',
                        'Other',
                        'Office',
                        'Other',
                        T4.DIM_DETAIL_CODE) AS DIM_DETAIL_CODE1,
                 DECODE(T3.INDEX_CODE,'Replace_oil_engy_amt','Industry_type',T5.DIM_CODE) AS DIM_CODE2,
                 DECODE(T3.INDEX_CODE,'Replace_oil_engy_amt','Industry',T3.T5.DIM_DETAIL_CODE) AS DIM_DETAIL_CODE2,
                 T7.DIM_CODE AS DIM_CODE4,
                 T7.DIM_DETAIL_CODE AS DIM_DETAIL_CODE4,
                 T8.DIM_CODE AS DIM_CODE5,
                 T8.DIM_DETAIL_CODE AS DIM_DETAIL_CODE5,
                 T9.DIM_CODE AS DIM_CODE6,
                 T9.DIM_DETAIL_CODE AS DIM_DETAIL_CODE6
            FROM E7_STA_REPINST T1
            LEFT JOIN E7_STA_RPT_INDEX_INST T2
              ON T1.REPINST_ID = T2.REPINST_ID
            LEFT JOIN E7_STA_INDEX_INST T3
              ON T2.STA_INDEX_INST_ID = T3.STA_INDEX_INST_ID
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T4
              ON T2.STA_INDEX_INST_ID = T4.STA_INDEX_INST_ID
             AND T4.DIM_CODE LIKE '%_link'
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T5
              ON T4.STA_INDEX_INST_ID = T5.STA_INDEX_INST_ID
             AND T5.DIM_CODE = 'Industry_type'
          
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T7
              ON T2.STA_INDEX_INST_ID = T7.STA_INDEX_INST_ID
             AND T7.DIM_CODE = 'Cru_oil_E_cons_typ'
             AND T7.DIM_DETAIL_CODE IN
                 (SELECT DIM_DETAIL_CODE
                    FROM E7_STA_DIM_DETAIL D
                   WHERE D.DIM_CODE = 'Cru_oil_E_cons_typ'
                     AND D.PARENT_DIM_DETAIL_CODE IS NULL)
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T8
              ON T2.STA_INDEX_INST_ID = T8.STA_INDEX_INST_ID
             AND T8.DIM_CODE = 'Cru_oil_E_cons_typ'
             AND T8.DIM_DETAIL_CODE <> T7.DIM_DETAIL_CODE
             
             LEFT JOIN E7_STA_INDEX_INST_DIMEN T9
             ON T2.STA_INDEX_INST_ID = T9.STA_INDEX_INST_ID
             AND T9.DIM_CODE = 'Crude_oil_alter_typ'
             
           WHERE T1.REPORT_CODE IN( 'C0049','C0045')
             AND T3.INDEX_CODE NOT IN ('Stadc_coef')
             AND (T5.DIM_DETAIL_CODE = 'Industry' 
             OR T5.DIM_DETAIL_CODE IS NULL)
             AND T1.REPORT_YEAR = P_RPTYEAR
             AND T1.REPORT_MONTH = P_RPTMONTH
             AND T1.ORG_ID IN (SELECT ORG_ID
                                 FROM E7_STA_RPT_AUTH
                                WHERE V_ORG_ID = P_RPTORGID
                                  AND REPORT_CODE = 'C0045'))
   GROUP BY REPORT_CODE,
            REPORT_YEAR,
            REPORT_MONTH,
            INDEX_CODE,
            DIM_CODE1,
            DIM_DETAIL_CODE1,
            DIM_CODE2,
            DIM_DETAIL_CODE2,
            DIM_CODE4,
            DIM_DETAIL_CODE4,
            DIM_CODE5,
            DIM_DETAIL_CODE5,
            DIM_CODE6,
            DIM_DETAIL_CODE6
            ),         
DATA_AMT AS
 (SELECT * FROM DATAS WHERE INDEX_CODE = 'Engy_csmp_amt_pratl'),
DATA_COST AS
 (SELECT * FROM DATAS WHERE INDEX_CODE = 'Engy_csmp_cost'),
DATA_PRICE AS
 (SELECT DATA_AMT.REPORT_CODE,
         DATA_AMT.REPORT_YEAR,
         DATA_AMT.REPORT_MONTH,
         'Engy_csmp_unit_pric' INDEX_CODE,
        DECODE(SUM(DATA_AMT.INDEX_VALUE),0,0,  ROUND(sum(DATA_COST.INDEX_VALUE) * 10000 / sum(DATA_AMT.INDEX_VALUE), 4)) INDEX_VALUE,
         DATA_AMT.DIM_CODE1,
         DATA_AMT.DIM_DETAIL_CODE1,
         null DIM_CODE2,
         null DIM_DETAIL_CODE2,
         DATA_AMT.DIM_CODE4,
         DATA_AMT.DIM_DETAIL_CODE4,
         null DIM_CODE5,
         null DIM_DETAIL_CODE5,
         null DIM_CODE6,
         null DIM_DETAIL_CODE6
    FROM DATA_AMT
    LEFT JOIN DATA_COST
      ON DATA_AMT.REPORT_CODE = DATA_COST.REPORT_CODE
     AND DATA_AMT.REPORT_YEAR = DATA_COST.REPORT_YEAR
     AND DATA_AMT.REPORT_MONTH = DATA_COST.REPORT_MONTH
     AND DATA_AMT.DIM_DETAIL_CODE1 = DATA_COST.DIM_DETAIL_CODE1
     AND DATA_AMT.DIM_DETAIL_CODE4 = DATA_COST.DIM_DETAIL_CODE4
     group by 
      DATA_AMT.REPORT_CODE,
         DATA_AMT.REPORT_YEAR,
         DATA_AMT.REPORT_MONTH,
         DATA_AMT.DIM_CODE1,
         DATA_AMT.DIM_DETAIL_CODE1,
         DATA_AMT.DIM_CODE4,
         DATA_AMT.DIM_DETAIL_CODE4),
RESULTS AS
 (SELECT * FROM DATAS),

LOCA_INDEX AS
 (SELECT *
    FROM E7_EXCEL_LOCATIONBYINDEX
   WHERE REPORT_CODE = P_RPTCODE
     AND IS_PY = 'N'),
LOCA_DIMEN AS
 (SELECT * FROM E7_EXCEL_LOCATIONBYDIMEN 
 WHERE REPORT_CODE = P_RPTCODE and LOCALTION IN (
       SELECT LOCALTION FROM LOCA_INDEX
 )),
LOC_INDEX AS
 (SELECT RESULTS.*, LOCA_INDEX.LOCALTION LOCATION_INDEX
    FROM RESULTS
    LEFT JOIN LOCA_INDEX
      ON RESULTS.INDEX_CODE = LOCA_INDEX.INDEX_CODE),
LOCA_DIMEN1 AS
 (SELECT *
    FROM (SELECT LOC_INDEX.*, DIMEN1.LOCALTION LOCATION_DIMEN1
            FROM LOC_INDEX
            LEFT JOIN LOCA_DIMEN DIMEN1
              ON LOC_INDEX.DIM_DETAIL_CODE1 = DIMEN1.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN1
      OR LOCATION_DIMEN1 IS NULL),
LOCA_DIMEN2 as
 (SELECT *
    FROM (select LOCA_DIMEN1.*, DIMEN2.LOCALTION LOCATION_DIMEN2
            FROM LOCA_DIMEN1
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN2
              ON LOCA_DIMEN1.DIM_CODE2 = DIMEN2.DIM_CODE
             AND LOCA_DIMEN1.DIM_DETAIL_CODE2 = DIMEN2.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN2
      OR LOCATION_DIMEN2 IS NULL),
LOCA_DIMEN3 as
 (SELECT *
    FROM (select LOCA_DIMEN2.*, DIMEN3.LOCALTION LOCATION_DIMEN3
            FROM LOCA_DIMEN2
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN3
              ON LOCA_DIMEN2.DIM_CODE4 = DIMEN3.DIM_CODE
             AND LOCA_DIMEN2.DIM_DETAIL_CODE4 = DIMEN3.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN3
      OR LOCATION_DIMEN3 IS NULL),
LOCA_DIMEN4 as
 (SELECT *
    FROM (select LOCA_DIMEN3.*, DIMEN4.LOCALTION LOCATION_DIMEN4
            FROM LOCA_DIMEN3
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN4
              ON LOCA_DIMEN3.DIM_CODE5 = DIMEN4.DIM_CODE
             AND LOCA_DIMEN3.DIM_DETAIL_CODE5 = DIMEN4.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN4
      OR LOCATION_DIMEN4 IS NULL), 
LOCA_DIMEN5 as
 (SELECT *
    FROM (select LOCA_DIMEN4.*, DIMEN5.LOCALTION LOCATION_DIMEN5
            FROM LOCA_DIMEN4
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN5
              ON LOCA_DIMEN4.DIM_CODE6 = DIMEN5.DIM_CODE
             AND LOCA_DIMEN4.DIM_DETAIL_CODE6 = DIMEN5.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN5
      OR LOCATION_DIMEN5 IS NULL),       
loca_indexprice as
 (
  
  SELECT DATA_PRICE.*, LOCA_INDEX.LOCALTION LOCATION_INDEX
    FROM DATA_PRICE
    LEFT JOIN LOCA_INDEX
      ON DATA_PRICE.INDEX_CODE = LOCA_INDEX.INDEX_CODE),
loca_dimenprice as
 (
  
  SELECT *
    FROM (select loca_indexprice.*,
                  null LOCATION_DIMEN1,
                  null LOCATION_DIMEN2,
                  null LOCATION_DIMEN3,
                  null LOCATION_DIMEN4,
                  DIMEN3.LOCALTION LOCATION_DIMENPRICE
             FROM loca_indexprice
             LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN3
               ON loca_indexprice.DIM_CODE4 = DIMEN3.DIM_CODE
              AND loca_indexprice.DIM_DETAIL_CODE4 = DIMEN3.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMENPRICE
      OR LOCATION_DIMENPRICE IS NULL),
ALLRESULTS AS
 (SELECT * FROM LOCA_DIMEN5 
 UNION ALL SELECT * FROM LOCA_DIMENPRICE
 )
SELECT DISTINCT LOCATION_INDEX, INDEX_VALUE FROM ALLRESULTS WHERE LOCATION_INDEX IS NOT NULL
);
BEGIN
jsonStr := '[';
FOR V_ENRGY IN return_cursor LOOP
  jsonStr := jsonStr || '{''location'':''' || V_ENRGY.LOCATION_INDEX ||
                 ''',''value'':''' || to_char(V_ENRGY.Index_Value) || '''},';

  END LOOP;
  jsonStr := jsonStr || ']';
  jsonStr := replace(jsonStr,'},]','}]');
  dbms_output.put_line(jsonStr);
  END;
  
  
  procedure getT0013Sum(P_RPTCODE IN VARCHAR2,
            	          P_RPTYEAR  IN VARCHAR2,
                       P_RPTMONTH IN VARCHAR2,
                       P_RPTORGID IN VARCHAR2,jsonStr OUT CLOB) IS
    
    Cursor return_cursor is
      SELECT *
        FROM (WITH DATAS AS
 (SELECT REPORT_CODE,
         REPORT_YEAR,
         REPORT_MONTH,
         INDEX_CODE,
         SUM(INDEX_VALUE) INDEX_VALUE,
         DIM_CODE1,
         DIM_DETAIL_CODE1,
         DIM_CODE2,
         DIM_DETAIL_CODE2,
         DIM_CODE4,
         DIM_DETAIL_CODE4,
         decode(DIM_DETAIL_CODE5,NULL,NULL,'Cru_oil_E_cons_typ' ) AS DIM_CODE5,
         DIM_DETAIL_CODE5,
         DIM_CODE6,
         DIM_DETAIL_CODE6,
         DIM_CODE7,
         DIM_DETAIL_CODE7
    FROM (SELECT P_RPTCODE REPORT_CODE,
                 T1.REPORT_YEAR,
                 T1.REPORT_MONTH,
                 T1.ORG_ID,
                 T3.INDEX_CODE,
                 T3.INDEX_VALUE,
                 DECODE(T4.DIM_CODE,'Engine_tech_ind_type','Engine_tech_ind_type','Engine_tech_ind_type') AS DIM_CODE1,
                 DECODE(T4.DIM_DETAIL_CODE,
                        'Well_drilling',
                        'Drilling','Other'
                        ) AS DIM_DETAIL_CODE1,
                 DECODE(T3.INDEX_CODE,'Replace_oil_engy_amt','Engine_tech_ind_type','Engine_tech_ind_type') AS DIM_CODE2,
                 DECODE(T3.INDEX_CODE,'Replace_oil_engy_amt',
                 DECODE(T5.DIM_DETAIL_CODE,
                 'Industry_C','Industry',
                 'Industry_G','Industry',
                 'Industry_O','Industry',
                 'Non_industrial_C','Non_industrial',
                 'Non_industrial_G','Non_industrial',
                 'Non_industrial_O','Non_industrial'),
                 T5.DIM_DETAIL_CODE) AS DIM_DETAIL_CODE2,
                 T7.DIM_CODE AS DIM_CODE4,
                 T7.DIM_DETAIL_CODE AS DIM_DETAIL_CODE4,
                 T8.DIM_CODE AS DIM_CODE5,
                 decode(T7.DIM_DETAIL_CODE,'Dies','Drilling_consumption',T8.DIM_DETAIL_CODE ) AS DIM_DETAIL_CODE5,
                 T9.DIM_CODE AS DIM_CODE6,
                 T9.DIM_DETAIL_CODE AS DIM_DETAIL_CODE6,
                 decode(T10.DIM_CODE,'Crude_oil_alter_typ1','Crude_oil_alter_typ',T10.DIM_CODE) AS DIM_CODE7,
                 T10.DIM_DETAIL_CODE AS DIM_DETAIL_CODE7
            FROM E7_STA_REPINST T1
            LEFT JOIN E7_STA_RPT_INDEX_INST T2
              ON T1.REPINST_ID = T2.REPINST_ID
            LEFT JOIN E7_STA_INDEX_INST T3
              ON T2.STA_INDEX_INST_ID = T3.STA_INDEX_INST_ID
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T4
              ON T2.STA_INDEX_INST_ID = T4.STA_INDEX_INST_ID
             AND T4.DIM_CODE LIKE '%_link'
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T5
              ON T2.STA_INDEX_INST_ID = T5.STA_INDEX_INST_ID
             AND T5.DIM_CODE IN( 'Industry_type' ,'Crude_oil_alter_typ1')
             AND T5.DIM_DETAIL_CODE IN('Industry_C','Industry_G','Industry_O','Non_industrial_C','Non_industrial_G','Non_industrial_O','Industry','Non_industrial')
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T7
              ON T2.STA_INDEX_INST_ID = T7.STA_INDEX_INST_ID
             AND T7.DIM_CODE = 'Cru_oil_E_cons_typ'
             AND T7.DIM_DETAIL_CODE IN
                 (SELECT DIM_DETAIL_CODE
                    FROM E7_STA_DIM_DETAIL D
                   WHERE D.DIM_CODE = 'Cru_oil_E_cons_typ'
                     AND D.PARENT_DIM_DETAIL_CODE IS NULL)
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T8
              ON T2.STA_INDEX_INST_ID = T8.STA_INDEX_INST_ID
             AND T8.DIM_CODE = 'Cru_oil_E_cons_typ'
             AND T8.DIM_DETAIL_CODE <> T7.DIM_DETAIL_CODE
             
             LEFT JOIN E7_STA_INDEX_INST_DIMEN T9
             ON T2.STA_INDEX_INST_ID = T9.STA_INDEX_INST_ID
             AND T9.DIM_CODE = 'Crude_oil_alter_typ'
             -- AND T5.DIM_DETAIL_CODE IN ('Industry_C','Industry_G','Industry_D','Non_industrial_C','Non_industrial_G','Non_industrial_D'))
             LEFT JOIN E7_STA_INDEX_INST_DIMEN T10
             ON T2.STA_INDEX_INST_ID = T10.STA_INDEX_INST_ID
             AND T10.DIM_CODE = 'Crude_oil_alter_typ1' 
             AND T10.DIM_DETAIL_CODE IN ('Other_repl_oil_amo','Gas_repl_oil_amo','Coal_repl_oil_amo')
             
           WHERE T1.REPORT_CODE IN( 'C0017','C0020','C0022','C0025','C0169','C0172')
             AND T3.INDEX_CODE NOT IN ('Stadc_coef')
             AND T1.REPORT_YEAR = P_RPTYEAR
             AND T1.REPORT_MONTH = P_RPTMONTH
             AND T1.ORG_ID IN (SELECT ORG_ID
                                 FROM E7_STA_RPT_AUTH
                                WHERE V_ORG_ID = P_RPTORGID
                                  AND REPORT_CODE IN ('C0017','C0020','C0022','C0025','C0169','C0172')))
   WHERE DIM_DETAIL_CODE5 <>'Lighter_hyd_los' OR DIM_DETAIL_CODE5 IS NULL
   GROUP BY REPORT_CODE,
            REPORT_YEAR,
            REPORT_MONTH,
            INDEX_CODE,
            DIM_CODE1,
            DIM_DETAIL_CODE1,
            DIM_CODE2,
            DIM_DETAIL_CODE2,
            DIM_CODE4,
            DIM_DETAIL_CODE4,
            DIM_CODE5,
            DIM_DETAIL_CODE5,
            DIM_CODE6,
            DIM_DETAIL_CODE6,
            DIM_CODE7,
            DIM_DETAIL_CODE7
            ),         
DATA_AMT AS
 (SELECT 
  REPORT_CODE,
 REPORT_YEAR,
 REPORT_MONTH,
 INDEX_CODE,
 SUM(NVL(INDEX_VALUE,0)) INDEX_VALUE,
 NULL DIM_CODE1,
 NULL DIM_DETAIL_CODE1,
 DIM_CODE2,
 DIM_DETAIL_CODE2,
 DIM_CODE4,
 DIM_DETAIL_CODE4,
 DIM_CODE5,
 DIM_DETAIL_CODE5,
 DIM_CODE6,
 DIM_DETAIL_CODE6,
 DIM_CODE7,
 DIM_DETAIL_CODE7
  FROM DATAS WHERE INDEX_CODE = 'Engy_csmp_amt_pratl'
  GROUP BY 
  REPORT_CODE,
 REPORT_YEAR,
 REPORT_MONTH,
 INDEX_CODE,
 DIM_CODE2,
 DIM_DETAIL_CODE2,
 DIM_CODE4,
 DIM_DETAIL_CODE4,
 DIM_CODE5,
 DIM_DETAIL_CODE5,
 DIM_CODE6,
 DIM_DETAIL_CODE6,
 DIM_CODE7,
 DIM_DETAIL_CODE7),
DATA_COST AS
 (SELECT 
  REPORT_CODE,
 REPORT_YEAR,
 REPORT_MONTH,
 INDEX_CODE,
 SUM(NVL(INDEX_VALUE,0)) INDEX_VALUE,
 NULL DIM_CODE1,
 NULL DIM_DETAIL_CODE1,
 DIM_CODE2,
 DIM_DETAIL_CODE2,
 DIM_CODE4,
 DIM_DETAIL_CODE4,
 DIM_CODE5,
 DIM_DETAIL_CODE5,
 DIM_CODE6,
 DIM_DETAIL_CODE6,
 DIM_CODE7,
 DIM_DETAIL_CODE7
  FROM DATAS WHERE INDEX_CODE = 'Engy_csmp_cost'
  GROUP BY 
  REPORT_CODE,
 REPORT_YEAR,
 REPORT_MONTH,
 INDEX_CODE,
 DIM_CODE2,
 DIM_DETAIL_CODE2,
 DIM_CODE4,
 DIM_DETAIL_CODE4,
 DIM_CODE5,
 DIM_DETAIL_CODE5,
 DIM_CODE6,
 DIM_DETAIL_CODE6,
 DIM_CODE7,
 DIM_DETAIL_CODE7),
DATA_PRICE AS
 (SELECT DATA_AMT.REPORT_CODE,
         DATA_AMT.REPORT_YEAR,
         DATA_AMT.REPORT_MONTH,
         'Engy_csmp_unit_pric' INDEX_CODE,
        DECODE(SUM(DATA_AMT.INDEX_VALUE),0,0,  ROUND(sum(DATA_COST.INDEX_VALUE) * 10000 / sum(DATA_AMT.INDEX_VALUE), 4)) INDEX_VALUE,
         NULL DIM_CODE1,
         NULL DIM_DETAIL_CODE1,
         null DIM_CODE2,
         null DIM_DETAIL_CODE2,
         DATA_AMT.DIM_CODE4,
         DATA_AMT.DIM_DETAIL_CODE4,
         null DIM_CODE5,
         null DIM_DETAIL_CODE5,
         null DIM_CODE6,
         null DIM_DETAIL_CODE6,
         null DIM_CODE7,
         null DIM_DETAIL_CODE7
    FROM DATA_AMT
    LEFT JOIN DATA_COST
      ON DATA_AMT.REPORT_CODE = DATA_COST.REPORT_CODE
     AND DATA_AMT.REPORT_YEAR = DATA_COST.REPORT_YEAR
     AND DATA_AMT.REPORT_MONTH = DATA_COST.REPORT_MONTH
     AND DATA_AMT.DIM_DETAIL_CODE4 = DATA_COST.DIM_DETAIL_CODE4
     group by 
      DATA_AMT.REPORT_CODE,
         DATA_AMT.REPORT_YEAR,
         DATA_AMT.REPORT_MONTH,
         DATA_AMT.DIM_CODE4,
         DATA_AMT.DIM_DETAIL_CODE4),
RESULTS AS
 (SELECT * FROM DATAS),

LOCA_INDEX AS
 (SELECT *
    FROM E7_EXCEL_LOCATIONBYINDEX
   WHERE REPORT_CODE = P_RPTCODE
     AND IS_PY = 'N'),
LOCA_DIMEN AS
 (SELECT * FROM E7_EXCEL_LOCATIONBYDIMEN 
 WHERE REPORT_CODE = P_RPTCODE and LOCALTION IN (
       SELECT LOCALTION FROM LOCA_INDEX
 )),
LOC_INDEX AS
 (SELECT RESULTS.*, LOCA_INDEX.LOCALTION LOCATION_INDEX
    FROM RESULTS
    LEFT JOIN LOCA_INDEX
      ON RESULTS.INDEX_CODE = LOCA_INDEX.INDEX_CODE),
LOCA_DIMEN1 AS
 (SELECT *
    FROM (SELECT LOC_INDEX.*, DIMEN1.LOCALTION LOCATION_DIMEN1
            FROM LOC_INDEX
            LEFT JOIN LOCA_DIMEN DIMEN1
              ON LOC_INDEX.DIM_DETAIL_CODE1 = DIMEN1.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN1
      OR LOCATION_DIMEN1 IS NULL),
LOCA_DIMEN2 as
 (SELECT *
    FROM (select LOCA_DIMEN1.*, DIMEN2.LOCALTION LOCATION_DIMEN2
            FROM LOCA_DIMEN1
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN2
              ON LOCA_DIMEN1.DIM_CODE2 = DIMEN2.DIM_CODE
             AND LOCA_DIMEN1.DIM_DETAIL_CODE2 = DIMEN2.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN2
      OR LOCATION_DIMEN2 IS NULL),
LOCA_DIMEN3 as
 (SELECT *
    FROM (select LOCA_DIMEN2.*, DIMEN3.LOCALTION LOCATION_DIMEN3
            FROM LOCA_DIMEN2
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN3
              ON LOCA_DIMEN2.DIM_CODE4 = DIMEN3.DIM_CODE
             AND LOCA_DIMEN2.DIM_DETAIL_CODE4 = DIMEN3.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN3
      OR LOCATION_DIMEN3 IS NULL),
LOCA_DIMEN4 as
 (SELECT *
    FROM (select LOCA_DIMEN3.*, DIMEN4.LOCALTION LOCATION_DIMEN4
            FROM LOCA_DIMEN3
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN4
              ON LOCA_DIMEN3.DIM_CODE5 = DIMEN4.DIM_CODE
             AND LOCA_DIMEN3.DIM_DETAIL_CODE5 = DIMEN4.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN4
      OR LOCATION_DIMEN4 IS NULL), 
LOCA_DIMEN5 as
 (SELECT *
    FROM (select LOCA_DIMEN4.*, DIMEN5.LOCALTION LOCATION_DIMEN5
            FROM LOCA_DIMEN4
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN5
              ON LOCA_DIMEN4.DIM_CODE6 = DIMEN5.DIM_CODE
             AND LOCA_DIMEN4.DIM_DETAIL_CODE6 = DIMEN5.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN5
      OR LOCATION_DIMEN5 IS NULL),
LOCA_DIMEN6 as
 (SELECT *
    FROM (select LOCA_DIMEN5.*, DIMEN6.LOCALTION LOCATION_DIMEN6
            FROM LOCA_DIMEN5
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN6
              ON LOCA_DIMEN5.DIM_CODE7 = DIMEN6.DIM_CODE
             AND LOCA_DIMEN5.DIM_DETAIL_CODE7 = DIMEN6.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN6
      OR LOCATION_DIMEN6 IS NULL),
loca_indexprice as
 (
  
  SELECT DATA_PRICE.*, LOCA_INDEX.LOCALTION LOCATION_INDEX
    FROM DATA_PRICE
    LEFT JOIN LOCA_INDEX
      ON DATA_PRICE.INDEX_CODE = LOCA_INDEX.INDEX_CODE),
loca_dimenprice as
 (
  
  SELECT *
    FROM (select loca_indexprice.*,
    null dimen1,
    null dimen2,
    null dimen3,
    null dimen4,
    null dimen5,
                  DIMEN3.LOCALTION LOCATION_DIMENPRICE
             FROM loca_indexprice
             LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN3
               ON loca_indexprice.DIM_CODE4 = DIMEN3.DIM_CODE
              AND loca_indexprice.DIM_DETAIL_CODE4 = DIMEN3.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMENPRICE
      OR LOCATION_DIMENPRICE IS NULL),
      
ALLRESULTS AS
 (SELECT * FROM LOCA_DIMEN6 
 UNION ALL SELECT * FROM LOCA_DIMENPRICE
 )
SELECT DISTINCT LOCATION_INDEX, sum(INDEX_VALUE) INDEX_VALUE FROM ALLRESULTS WHERE LOCATION_INDEX IS NOT NULL GROUP BY LOCATION_INDEX);
BEGIN
jsonStr := '[';
FOR V_ENRGY IN return_cursor LOOP
  jsonStr := jsonStr || '{''location'':''' || V_ENRGY.LOCATION_INDEX ||
                 ''',''value'':''' || to_char(V_ENRGY.Index_Value) || '''},';

  END LOOP;
  jsonStr := jsonStr || ']';
  jsonStr := replace(jsonStr,'},]','}]');
  dbms_output.put_line(jsonStr);
  END;
  
  procedure getT0014Sum(P_RPTCODE IN VARCHAR2,
            	          P_RPTYEAR  IN VARCHAR2,
                       P_RPTMONTH IN VARCHAR2,
                       P_RPTORGID IN VARCHAR2,jsonStr OUT CLOB) IS
    
    Cursor return_cursor is
      SELECT *
        FROM (WITH DATAS AS
 (SELECT REPORT_CODE,
         REPORT_YEAR,
         REPORT_MONTH,
         INDEX_CODE,
         SUM(INDEX_VALUE) INDEX_VALUE,
         DIM_CODE1,
         DIM_DETAIL_CODE1,
         DIM_CODE2,
         DIM_DETAIL_CODE2,
         DIM_CODE4,
         DIM_DETAIL_CODE4,
         decode(DIM_DETAIL_CODE5,NULL,NULL,'Cru_oil_E_cons_typ' ) AS DIM_CODE5,
         DIM_DETAIL_CODE5,
         DIM_CODE6,
         DIM_DETAIL_CODE6,
         DIM_CODE7,
         DIM_DETAIL_CODE7
    FROM (SELECT P_RPTCODE REPORT_CODE,
                 T1.REPORT_YEAR,
                 T1.REPORT_MONTH,
                 T1.ORG_ID,
                 T3.INDEX_CODE,
                 T3.INDEX_VALUE,
                 T4.DIM_CODE AS DIM_CODE1,
                 T4.DIM_DETAIL_CODE AS DIM_DETAIL_CODE1,
                 DECODE(T3.INDEX_CODE,'Replace_oil_engy_amt','Industry_type',T5.DIM_CODE) AS DIM_CODE2,
                 DECODE(T3.INDEX_CODE,'Replace_oil_engy_amt',
                 DECODE(T5.DIM_DETAIL_CODE,
                 'Industry_C','Industry',
                 'Industry_G','Industry',
                 'Industry_O','Industry',
                 'Non_industrial_C','Non_industrial',
                 'Non_industrial_G','Non_industrial',
                 'Non_industrial_O','Non_industrial'),
                 T5.DIM_DETAIL_CODE) AS DIM_DETAIL_CODE2,
                 T7.DIM_CODE AS DIM_CODE4,
                 T7.DIM_DETAIL_CODE AS DIM_DETAIL_CODE4,
                 DECODE(T7.DIM_DETAIL_CODE,'Cru_oil',NULL,T8.DIM_CODE) AS DIM_CODE5,
                 decode(T7.DIM_DETAIL_CODE,'Cru_oil',NULL,T8.DIM_DETAIL_CODE ) AS DIM_DETAIL_CODE5,
                 T9.DIM_CODE AS DIM_CODE6,
                 T9.DIM_DETAIL_CODE AS DIM_DETAIL_CODE6,
                 decode(T10.DIM_CODE,'Crude_oil_alter_typ1','Crude_oil_alter_typ',T10.DIM_CODE) AS DIM_CODE7,
                 T10.DIM_DETAIL_CODE AS DIM_DETAIL_CODE7
            FROM E7_STA_REPINST T1
            LEFT JOIN E7_STA_RPT_INDEX_INST T2
              ON T1.REPINST_ID = T2.REPINST_ID
            LEFT JOIN E7_STA_INDEX_INST T3
              ON T2.STA_INDEX_INST_ID = T3.STA_INDEX_INST_ID
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T4
              ON T2.STA_INDEX_INST_ID = T4.STA_INDEX_INST_ID
             AND T4.DIM_CODE LIKE '%_link'
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T5
              ON T2.STA_INDEX_INST_ID = T5.STA_INDEX_INST_ID
             AND T5.DIM_CODE IN( 'Industry_type' ,'Crude_oil_alter_typ1')
             AND T5.DIM_DETAIL_CODE IN('Industry_C','Industry_G','Industry_O','Non_industrial_C','Non_industrial_G','Non_industrial_O','Industry','Non_industrial')
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T7
              ON T2.STA_INDEX_INST_ID = T7.STA_INDEX_INST_ID
             AND T7.DIM_CODE = 'Cru_oil_E_cons_typ'
             AND T7.DIM_DETAIL_CODE IN
                 (SELECT DIM_DETAIL_CODE
                    FROM E7_STA_DIM_DETAIL D
                   WHERE D.DIM_CODE = 'Cru_oil_E_cons_typ'
                     AND D.PARENT_DIM_DETAIL_CODE IS NULL)
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T8
              ON T2.STA_INDEX_INST_ID = T8.STA_INDEX_INST_ID
             AND T8.DIM_CODE = 'Cru_oil_E_cons_typ'
             AND T8.DIM_DETAIL_CODE <> T7.DIM_DETAIL_CODE
             
             LEFT JOIN E7_STA_INDEX_INST_DIMEN T9
             ON T2.STA_INDEX_INST_ID = T9.STA_INDEX_INST_ID
             AND T9.DIM_CODE = 'Crude_oil_alter_typ'
             -- AND T5.DIM_DETAIL_CODE IN ('Industry_C','Industry_G','Industry_D','Non_industrial_C','Non_industrial_G','Non_industrial_D'))
             LEFT JOIN E7_STA_INDEX_INST_DIMEN T10
             ON T2.STA_INDEX_INST_ID = T10.STA_INDEX_INST_ID
             AND T10.DIM_CODE = 'Crude_oil_alter_typ1' 
             AND T10.DIM_DETAIL_CODE IN ('Other_repl_oil_amo','Gas_repl_oil_amo','Coal_repl_oil_amo')
             
           WHERE T1.REPORT_CODE IN( 'C0052','C0055')
             AND T3.INDEX_CODE NOT IN ('Stadc_coef')
             AND T1.REPORT_YEAR = P_RPTYEAR
             AND T1.REPORT_MONTH = P_RPTMONTH
             AND T1.ORG_ID IN (SELECT ORG_ID
                                 FROM E7_STA_RPT_AUTH
                                WHERE V_ORG_ID = P_RPTORGID
                                  AND REPORT_CODE IN ('C0052')))
   WHERE DIM_DETAIL_CODE5 <>'Lighter_hyd_los' OR DIM_DETAIL_CODE5 IS NULL
   GROUP BY REPORT_CODE,
            REPORT_YEAR,
            REPORT_MONTH,
            INDEX_CODE,
            DIM_CODE1,
            DIM_DETAIL_CODE1,
            DIM_CODE2,
            DIM_DETAIL_CODE2,
            DIM_CODE4,
            DIM_DETAIL_CODE4,
            DIM_CODE5,
            DIM_DETAIL_CODE5,
            DIM_CODE6,
            DIM_DETAIL_CODE6,
            DIM_CODE7,
            DIM_DETAIL_CODE7
            ),         
DATA_AMT AS
 (SELECT 
  REPORT_CODE,
 REPORT_YEAR,
 REPORT_MONTH,
 INDEX_CODE,
 SUM(NVL(INDEX_VALUE,0)) INDEX_VALUE,
 NULL DIM_CODE1,
 NULL DIM_DETAIL_CODE1,
 DIM_CODE2,
 DIM_DETAIL_CODE2,
 DIM_CODE4,
 DIM_DETAIL_CODE4,
 DIM_CODE5,
 DIM_DETAIL_CODE5,
 DIM_CODE6,
 DIM_DETAIL_CODE6,
 DIM_CODE7,
 DIM_DETAIL_CODE7
  FROM DATAS WHERE INDEX_CODE = 'Engy_csmp_amt_pratl'
  GROUP BY 
  REPORT_CODE,
 REPORT_YEAR,
 REPORT_MONTH,
 INDEX_CODE,
 DIM_CODE2,
 DIM_DETAIL_CODE2,
 DIM_CODE4,
 DIM_DETAIL_CODE4,
 DIM_CODE5,
 DIM_DETAIL_CODE5,
 DIM_CODE6,
 DIM_DETAIL_CODE6,
 DIM_CODE7,
 DIM_DETAIL_CODE7),
DATA_COST AS
 (SELECT 
  REPORT_CODE,
 REPORT_YEAR,
 REPORT_MONTH,
 INDEX_CODE,
 SUM(NVL(INDEX_VALUE,0)) INDEX_VALUE,
 NULL DIM_CODE1,
 NULL DIM_DETAIL_CODE1,
 DIM_CODE2,
 DIM_DETAIL_CODE2,
 DIM_CODE4,
 DIM_DETAIL_CODE4,
 DIM_CODE5,
 DIM_DETAIL_CODE5,
 DIM_CODE6,
 DIM_DETAIL_CODE6,
 DIM_CODE7,
 DIM_DETAIL_CODE7
  FROM DATAS WHERE INDEX_CODE = 'Engy_csmp_cost'
  GROUP BY 
  REPORT_CODE,
 REPORT_YEAR,
 REPORT_MONTH,
 INDEX_CODE,
 DIM_CODE2,
 DIM_DETAIL_CODE2,
 DIM_CODE4,
 DIM_DETAIL_CODE4,
 DIM_CODE5,
 DIM_DETAIL_CODE5,
 DIM_CODE6,
 DIM_DETAIL_CODE6,
 DIM_CODE7,
 DIM_DETAIL_CODE7),
DATA_PRICE AS
 (SELECT DATA_AMT.REPORT_CODE,
         DATA_AMT.REPORT_YEAR,
         DATA_AMT.REPORT_MONTH,
         'Engy_csmp_unit_pric' INDEX_CODE,
        DECODE(SUM(DATA_AMT.INDEX_VALUE),0,0,  ROUND(sum(DATA_COST.INDEX_VALUE) * 10000 / sum(DATA_AMT.INDEX_VALUE), 4)) INDEX_VALUE,
         NULL DIM_CODE1,
         NULL DIM_DETAIL_CODE1,
         null DIM_CODE2,
         null DIM_DETAIL_CODE2,
         DATA_AMT.DIM_CODE4,
         DATA_AMT.DIM_DETAIL_CODE4,
         null DIM_CODE5,
         null DIM_DETAIL_CODE5,
         null DIM_CODE6,
         null DIM_DETAIL_CODE6,
         null DIM_CODE7,
         null DIM_DETAIL_CODE7
    FROM DATA_AMT
    LEFT JOIN DATA_COST
      ON DATA_AMT.REPORT_CODE = DATA_COST.REPORT_CODE
     AND DATA_AMT.REPORT_YEAR = DATA_COST.REPORT_YEAR
     AND DATA_AMT.REPORT_MONTH = DATA_COST.REPORT_MONTH
     AND DATA_AMT.DIM_DETAIL_CODE4 = DATA_COST.DIM_DETAIL_CODE4
     group by 
      DATA_AMT.REPORT_CODE,
         DATA_AMT.REPORT_YEAR,
         DATA_AMT.REPORT_MONTH,
         DATA_AMT.DIM_CODE4,
         DATA_AMT.DIM_DETAIL_CODE4),
RESULTS AS
 (SELECT * FROM DATAS),

LOCA_INDEX AS
 (SELECT *
    FROM E7_EXCEL_LOCATIONBYINDEX
   WHERE REPORT_CODE = 'T0014'
     AND IS_PY = 'N'),
LOCA_DIMEN AS
 (SELECT * FROM E7_EXCEL_LOCATIONBYDIMEN 
 WHERE REPORT_CODE = 'T0014' and LOCALTION IN (
       SELECT LOCALTION FROM LOCA_INDEX
 )),
LOC_INDEX AS
 (SELECT RESULTS.*, LOCA_INDEX.LOCALTION LOCATION_INDEX
    FROM RESULTS
    LEFT JOIN LOCA_INDEX
      ON RESULTS.INDEX_CODE = LOCA_INDEX.INDEX_CODE),
LOCA_DIMEN1 AS
 (SELECT *
    FROM (SELECT LOC_INDEX.*, DIMEN1.LOCALTION LOCATION_DIMEN1
            FROM LOC_INDEX
            LEFT JOIN LOCA_DIMEN DIMEN1
              ON LOC_INDEX.DIM_DETAIL_CODE1 = DIMEN1.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN1
      OR LOCATION_DIMEN1 IS NULL),
LOCA_DIMEN2 as
 (SELECT *
    FROM (select LOCA_DIMEN1.*, DIMEN2.LOCALTION LOCATION_DIMEN2
            FROM LOCA_DIMEN1
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN2
              ON LOCA_DIMEN1.DIM_CODE2 = DIMEN2.DIM_CODE
             AND LOCA_DIMEN1.DIM_DETAIL_CODE2 = DIMEN2.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN2
      OR LOCATION_DIMEN2 IS NULL),
LOCA_DIMEN3 as
 (SELECT *
    FROM (select LOCA_DIMEN2.*, DIMEN3.LOCALTION LOCATION_DIMEN3
            FROM LOCA_DIMEN2
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN3
              ON LOCA_DIMEN2.DIM_CODE4 = DIMEN3.DIM_CODE
             AND LOCA_DIMEN2.DIM_DETAIL_CODE4 = DIMEN3.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN3
      OR LOCATION_DIMEN3 IS NULL),
LOCA_DIMEN4 as
 (SELECT *
    FROM (select LOCA_DIMEN3.*, DIMEN4.LOCALTION LOCATION_DIMEN4
            FROM LOCA_DIMEN3
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN4
              ON LOCA_DIMEN3.DIM_CODE5 = DIMEN4.DIM_CODE
             AND LOCA_DIMEN3.DIM_DETAIL_CODE5 = DIMEN4.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN4
      OR LOCATION_DIMEN4 IS NULL), 
LOCA_DIMEN5 as
 (SELECT *
    FROM (select LOCA_DIMEN4.*, DIMEN5.LOCALTION LOCATION_DIMEN5
            FROM LOCA_DIMEN4
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN5
              ON LOCA_DIMEN4.DIM_CODE6 = DIMEN5.DIM_CODE
             AND LOCA_DIMEN4.DIM_DETAIL_CODE6 = DIMEN5.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN5
      OR LOCATION_DIMEN5 IS NULL),
LOCA_DIMEN6 as
 (SELECT *
    FROM (select LOCA_DIMEN5.*, DIMEN6.LOCALTION LOCATION_DIMEN6
            FROM LOCA_DIMEN5
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN6
              ON LOCA_DIMEN5.DIM_CODE7 = DIMEN6.DIM_CODE
             AND LOCA_DIMEN5.DIM_DETAIL_CODE7 = DIMEN6.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN6
      OR LOCATION_DIMEN6 IS NULL),
loca_indexprice as
 (
  
  SELECT DATA_PRICE.*, LOCA_INDEX.LOCALTION LOCATION_INDEX
    FROM DATA_PRICE
    LEFT JOIN LOCA_INDEX
      ON DATA_PRICE.INDEX_CODE = LOCA_INDEX.INDEX_CODE),
loca_dimenprice as
 (
  
  SELECT *
    FROM (select loca_indexprice.*,
    null dimen1,
    null dimen2,
    null dimen3,
    null dimen4,
    null dimen5,
                  DIMEN3.LOCALTION LOCATION_DIMENPRICE
             FROM loca_indexprice
             LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN3
               ON loca_indexprice.DIM_CODE4 = DIMEN3.DIM_CODE
              AND loca_indexprice.DIM_DETAIL_CODE4 = DIMEN3.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMENPRICE
      OR LOCATION_DIMENPRICE IS NULL),
      
ALLRESULTS AS
 (SELECT * FROM LOCA_DIMEN6 
 UNION ALL SELECT * FROM LOCA_DIMENPRICE
 )
SELECT DISTINCT LOCATION_INDEX, sum(INDEX_VALUE) INDEX_VALUE FROM ALLRESULTS WHERE LOCATION_INDEX IS NOT NULL GROUP BY LOCATION_INDEX
);
BEGIN
jsonStr := '[';
FOR V_ENRGY IN return_cursor LOOP
  jsonStr := jsonStr || '{''location'':''' || V_ENRGY.LOCATION_INDEX ||
                 ''',''value'':''' || to_char(V_ENRGY.Index_Value) || '''},';

  END LOOP;
  jsonStr := jsonStr || ']';
  jsonStr := replace(jsonStr,'},]','}]');
  dbms_output.put_line(jsonStr);
  END;
  
  procedure getT0015Sum(P_RPTCODE IN VARCHAR2,
            	          P_RPTYEAR  IN VARCHAR2,
                       P_RPTMONTH IN VARCHAR2,
                       P_RPTORGID IN VARCHAR2,jsonStr OUT CLOB) IS
    
    Cursor return_cursor is
      SELECT *
        FROM (WITH DATAS AS
 (SELECT REPORT_CODE,
         REPORT_YEAR,
         REPORT_MONTH,
         INDEX_CODE,
         SUM(INDEX_VALUE) INDEX_VALUE,
         DIM_CODE1,
         DIM_DETAIL_CODE1,
         DIM_CODE2,
         DIM_DETAIL_CODE2,
         DIM_CODE4,
         DIM_DETAIL_CODE4,
         decode(DIM_DETAIL_CODE5,NULL,NULL,'Cru_oil_E_cons_typ' ) AS DIM_CODE5,
         DIM_DETAIL_CODE5,
         DIM_CODE6,
         DIM_DETAIL_CODE6,
         DIM_CODE7,
         DIM_DETAIL_CODE7
    FROM (SELECT P_RPTCODE REPORT_CODE,
                 T1.REPORT_YEAR,
                 T1.REPORT_MONTH,
                 T1.ORG_ID,
                 T3.INDEX_CODE,
                 T3.INDEX_VALUE,
                 T4.DIM_CODE AS DIM_CODE1,
                 T4.DIM_DETAIL_CODE AS DIM_DETAIL_CODE1,
                 DECODE(T3.INDEX_CODE,'Replace_oil_engy_amt','Industry_type',T5.DIM_CODE) AS DIM_CODE2,
                 DECODE(T3.INDEX_CODE,'Replace_oil_engy_amt',
                 DECODE(T5.DIM_DETAIL_CODE,
                 'Industry_C','Industry',
                 'Industry_G','Industry',
                 'Industry_O','Industry',
                 'Non_industrial_C','Non_industrial',
                 'Non_industrial_G','Non_industrial',
                 'Non_industrial_O','Non_industrial'),
                 T5.DIM_DETAIL_CODE) AS DIM_DETAIL_CODE2,
                 T7.DIM_CODE AS DIM_CODE4,
                 T7.DIM_DETAIL_CODE AS DIM_DETAIL_CODE4,
                 DECODE(T7.DIM_DETAIL_CODE,'Cru_oil',NULL,T8.DIM_CODE) AS DIM_CODE5,
                 decode(T7.DIM_DETAIL_CODE,'Cru_oil',NULL,T8.DIM_DETAIL_CODE ) AS DIM_DETAIL_CODE5,
                 T9.DIM_CODE AS DIM_CODE6,
                 T9.DIM_DETAIL_CODE AS DIM_DETAIL_CODE6,
                 decode(T10.DIM_CODE,'Crude_oil_alter_typ1','Crude_oil_alter_typ',T10.DIM_CODE) AS DIM_CODE7,
                 T10.DIM_DETAIL_CODE AS DIM_DETAIL_CODE7
            FROM E7_STA_REPINST T1
            LEFT JOIN E7_STA_RPT_INDEX_INST T2
              ON T1.REPINST_ID = T2.REPINST_ID
            LEFT JOIN E7_STA_INDEX_INST T3
              ON T2.STA_INDEX_INST_ID = T3.STA_INDEX_INST_ID
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T4
              ON T2.STA_INDEX_INST_ID = T4.STA_INDEX_INST_ID
             AND T4.DIM_CODE LIKE '%_link'
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T5
              ON T2.STA_INDEX_INST_ID = T5.STA_INDEX_INST_ID
             AND T5.DIM_CODE IN( 'Industry_type' ,'Crude_oil_alter_typ1')
             AND T5.DIM_DETAIL_CODE IN('Industry_C','Industry_G','Industry_O','Non_industrial_C','Non_industrial_G','Non_industrial_O','Industry','Non_industrial')
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T7
              ON T2.STA_INDEX_INST_ID = T7.STA_INDEX_INST_ID
             AND T7.DIM_CODE = 'Cru_oil_E_cons_typ'
             AND T7.DIM_DETAIL_CODE IN
                 (SELECT DIM_DETAIL_CODE
                    FROM E7_STA_DIM_DETAIL D
                   WHERE D.DIM_CODE = 'Cru_oil_E_cons_typ'
                     AND D.PARENT_DIM_DETAIL_CODE IS NULL)
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T8
              ON T2.STA_INDEX_INST_ID = T8.STA_INDEX_INST_ID
             AND T8.DIM_CODE = 'Cru_oil_E_cons_typ'
             AND T8.DIM_DETAIL_CODE <> T7.DIM_DETAIL_CODE
             
             LEFT JOIN E7_STA_INDEX_INST_DIMEN T9
             ON T2.STA_INDEX_INST_ID = T9.STA_INDEX_INST_ID
             AND T9.DIM_CODE = 'Crude_oil_alter_typ'
             -- AND T5.DIM_DETAIL_CODE IN ('Industry_C','Industry_G','Industry_D','Non_industrial_C','Non_industrial_G','Non_industrial_D'))
             LEFT JOIN E7_STA_INDEX_INST_DIMEN T10
             ON T2.STA_INDEX_INST_ID = T10.STA_INDEX_INST_ID
             AND T10.DIM_CODE = 'Crude_oil_alter_typ1' 
             AND T10.DIM_DETAIL_CODE IN ('Other_repl_oil_amo','Gas_repl_oil_amo','Coal_repl_oil_amo')
             
           WHERE T1.REPORT_CODE IN( 'C0057','C0060')
             AND T3.INDEX_CODE NOT IN ('Stadc_coef')
             AND T1.REPORT_YEAR = P_RPTYEAR
             AND T1.REPORT_MONTH = P_RPTMONTH
             AND T1.ORG_ID IN (SELECT ORG_ID
                                 FROM E7_STA_RPT_AUTH
                                WHERE V_ORG_ID = P_RPTORGID
                                  AND REPORT_CODE IN ('C0057')))
   WHERE DIM_DETAIL_CODE5 <>'Lighter_hyd_los' OR DIM_DETAIL_CODE5 IS NULL
   GROUP BY REPORT_CODE,
            REPORT_YEAR,
            REPORT_MONTH,
            INDEX_CODE,
            DIM_CODE1,
            DIM_DETAIL_CODE1,
            DIM_CODE2,
            DIM_DETAIL_CODE2,
            DIM_CODE4,
            DIM_DETAIL_CODE4,
            DIM_CODE5,
            DIM_DETAIL_CODE5,
            DIM_CODE6,
            DIM_DETAIL_CODE6,
            DIM_CODE7,
            DIM_DETAIL_CODE7
            ),         
DATA_AMT AS
 (SELECT 
  REPORT_CODE,
 REPORT_YEAR,
 REPORT_MONTH,
 INDEX_CODE,
 SUM(NVL(INDEX_VALUE,0)) INDEX_VALUE,
 NULL DIM_CODE1,
 NULL DIM_DETAIL_CODE1,
 DIM_CODE2,
 DIM_DETAIL_CODE2,
 DIM_CODE4,
 DIM_DETAIL_CODE4,
 DIM_CODE5,
 DIM_DETAIL_CODE5,
 DIM_CODE6,
 DIM_DETAIL_CODE6,
 DIM_CODE7,
 DIM_DETAIL_CODE7
  FROM DATAS WHERE INDEX_CODE = 'Engy_csmp_amt_pratl'
  GROUP BY 
  REPORT_CODE,
 REPORT_YEAR,
 REPORT_MONTH,
 INDEX_CODE,
 DIM_CODE2,
 DIM_DETAIL_CODE2,
 DIM_CODE4,
 DIM_DETAIL_CODE4,
 DIM_CODE5,
 DIM_DETAIL_CODE5,
 DIM_CODE6,
 DIM_DETAIL_CODE6,
 DIM_CODE7,
 DIM_DETAIL_CODE7),
DATA_COST AS
 (SELECT 
  REPORT_CODE,
 REPORT_YEAR,
 REPORT_MONTH,
 INDEX_CODE,
 SUM(NVL(INDEX_VALUE,0)) INDEX_VALUE,
 NULL DIM_CODE1,
 NULL DIM_DETAIL_CODE1,
 DIM_CODE2,
 DIM_DETAIL_CODE2,
 DIM_CODE4,
 DIM_DETAIL_CODE4,
 DIM_CODE5,
 DIM_DETAIL_CODE5,
 DIM_CODE6,
 DIM_DETAIL_CODE6,
 DIM_CODE7,
 DIM_DETAIL_CODE7
  FROM DATAS WHERE INDEX_CODE = 'Engy_csmp_cost'
  GROUP BY 
  REPORT_CODE,
 REPORT_YEAR,
 REPORT_MONTH,
 INDEX_CODE,
 DIM_CODE2,
 DIM_DETAIL_CODE2,
 DIM_CODE4,
 DIM_DETAIL_CODE4,
 DIM_CODE5,
 DIM_DETAIL_CODE5,
 DIM_CODE6,
 DIM_DETAIL_CODE6,
 DIM_CODE7,
 DIM_DETAIL_CODE7),
DATA_PRICE AS
 (SELECT DATA_AMT.REPORT_CODE,
         DATA_AMT.REPORT_YEAR,
         DATA_AMT.REPORT_MONTH,
         'Engy_csmp_unit_pric' INDEX_CODE,
        DECODE(SUM(DATA_AMT.INDEX_VALUE),0,0,  ROUND(sum(DATA_COST.INDEX_VALUE) * 10000 / sum(DATA_AMT.INDEX_VALUE), 4)) INDEX_VALUE,
         NULL DIM_CODE1,
         NULL DIM_DETAIL_CODE1,
         null DIM_CODE2,
         null DIM_DETAIL_CODE2,
         DATA_AMT.DIM_CODE4,
         DATA_AMT.DIM_DETAIL_CODE4,
         null DIM_CODE5,
         null DIM_DETAIL_CODE5,
         null DIM_CODE6,
         null DIM_DETAIL_CODE6,
         null DIM_CODE7,
         null DIM_DETAIL_CODE7
    FROM DATA_AMT
    LEFT JOIN DATA_COST
      ON DATA_AMT.REPORT_CODE = DATA_COST.REPORT_CODE
     AND DATA_AMT.REPORT_YEAR = DATA_COST.REPORT_YEAR
     AND DATA_AMT.REPORT_MONTH = DATA_COST.REPORT_MONTH
     AND DATA_AMT.DIM_DETAIL_CODE4 = DATA_COST.DIM_DETAIL_CODE4
     group by 
      DATA_AMT.REPORT_CODE,
         DATA_AMT.REPORT_YEAR,
         DATA_AMT.REPORT_MONTH,
         DATA_AMT.DIM_CODE4,
         DATA_AMT.DIM_DETAIL_CODE4),
RESULTS AS
 (SELECT * FROM DATAS),

LOCA_INDEX AS
 (SELECT *
    FROM E7_EXCEL_LOCATIONBYINDEX
   WHERE REPORT_CODE = 'T0015'
     AND IS_PY = 'N'),
LOCA_DIMEN AS
 (SELECT * FROM E7_EXCEL_LOCATIONBYDIMEN 
 WHERE REPORT_CODE = 'T0015' and LOCALTION IN (
       SELECT LOCALTION FROM LOCA_INDEX
 )),
LOC_INDEX AS
 (SELECT RESULTS.*, LOCA_INDEX.LOCALTION LOCATION_INDEX
    FROM RESULTS
    LEFT JOIN LOCA_INDEX
      ON RESULTS.INDEX_CODE = LOCA_INDEX.INDEX_CODE),
LOCA_DIMEN1 AS
 (SELECT *
    FROM (SELECT LOC_INDEX.*, DIMEN1.LOCALTION LOCATION_DIMEN1
            FROM LOC_INDEX
            LEFT JOIN LOCA_DIMEN DIMEN1
              ON LOC_INDEX.DIM_DETAIL_CODE1 = DIMEN1.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN1
      OR LOCATION_DIMEN1 IS NULL),
LOCA_DIMEN2 as
 (SELECT *
    FROM (select LOCA_DIMEN1.*, DIMEN2.LOCALTION LOCATION_DIMEN2
            FROM LOCA_DIMEN1
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN2
              ON LOCA_DIMEN1.DIM_CODE2 = DIMEN2.DIM_CODE
             AND LOCA_DIMEN1.DIM_DETAIL_CODE2 = DIMEN2.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN2
      OR LOCATION_DIMEN2 IS NULL),
LOCA_DIMEN3 as
 (SELECT *
    FROM (select LOCA_DIMEN2.*, DIMEN3.LOCALTION LOCATION_DIMEN3
            FROM LOCA_DIMEN2
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN3
              ON LOCA_DIMEN2.DIM_CODE4 = DIMEN3.DIM_CODE
             AND LOCA_DIMEN2.DIM_DETAIL_CODE4 = DIMEN3.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN3
      OR LOCATION_DIMEN3 IS NULL),
LOCA_DIMEN4 as
 (SELECT *
    FROM (select LOCA_DIMEN3.*, DIMEN4.LOCALTION LOCATION_DIMEN4
            FROM LOCA_DIMEN3
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN4
              ON LOCA_DIMEN3.DIM_CODE5 = DIMEN4.DIM_CODE
             AND LOCA_DIMEN3.DIM_DETAIL_CODE5 = DIMEN4.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN4
      OR LOCATION_DIMEN4 IS NULL), 
LOCA_DIMEN5 as
 (SELECT *
    FROM (select LOCA_DIMEN4.*, DIMEN5.LOCALTION LOCATION_DIMEN5
            FROM LOCA_DIMEN4
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN5
              ON LOCA_DIMEN4.DIM_CODE6 = DIMEN5.DIM_CODE
             AND LOCA_DIMEN4.DIM_DETAIL_CODE6 = DIMEN5.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN5
      OR LOCATION_DIMEN5 IS NULL),
LOCA_DIMEN6 as
 (SELECT *
    FROM (select LOCA_DIMEN5.*, DIMEN6.LOCALTION LOCATION_DIMEN6
            FROM LOCA_DIMEN5
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN6
              ON LOCA_DIMEN5.DIM_CODE7 = DIMEN6.DIM_CODE
             AND LOCA_DIMEN5.DIM_DETAIL_CODE7 = DIMEN6.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN6
      OR LOCATION_DIMEN6 IS NULL),
loca_indexprice as
 (
  
  SELECT DATA_PRICE.*, LOCA_INDEX.LOCALTION LOCATION_INDEX
    FROM DATA_PRICE
    LEFT JOIN LOCA_INDEX
      ON DATA_PRICE.INDEX_CODE = LOCA_INDEX.INDEX_CODE),
loca_dimenprice as
 (
  
  SELECT *
    FROM (select loca_indexprice.*,
    null dimen1,
    null dimen2,
    null dimen3,
    null dimen4,
    null dimen5,
                  DIMEN3.LOCALTION LOCATION_DIMENPRICE
             FROM loca_indexprice
             LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN3
               ON loca_indexprice.DIM_CODE4 = DIMEN3.DIM_CODE
              AND loca_indexprice.DIM_DETAIL_CODE4 = DIMEN3.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMENPRICE
      OR LOCATION_DIMENPRICE IS NULL),
      
ALLRESULTS AS
 (SELECT * FROM LOCA_DIMEN6 
 UNION ALL SELECT * FROM LOCA_DIMENPRICE
 )
SELECT DISTINCT LOCATION_INDEX, sum(INDEX_VALUE) INDEX_VALUE FROM ALLRESULTS WHERE LOCATION_INDEX IS NOT NULL GROUP BY LOCATION_INDEX
);
BEGIN
jsonStr := '[';
FOR V_ENRGY IN return_cursor LOOP
  jsonStr := jsonStr || '{''location'':''' || V_ENRGY.LOCATION_INDEX ||
                 ''',''value'':''' || to_char(V_ENRGY.Index_Value) || '''},';

  END LOOP;
  jsonStr := jsonStr || ']';
  jsonStr := replace(jsonStr,'},]','}]');
  dbms_output.put_line(jsonStr);
  END;
  
  procedure getT0016Sum(P_RPTCODE IN VARCHAR2,
            	          P_RPTYEAR  IN VARCHAR2,
                       P_RPTMONTH IN VARCHAR2,
                       P_RPTORGID IN VARCHAR2,jsonStr OUT CLOB) IS
    
    Cursor return_cursor is
      SELECT *
        FROM (WITH DATAS AS
 (SELECT REPORT_CODE,
         REPORT_YEAR,
         REPORT_MONTH,
         INDEX_CODE,
         SUM(INDEX_VALUE) INDEX_VALUE,
         DIM_CODE1,
         DIM_DETAIL_CODE1,
         DIM_CODE2,
         DIM_DETAIL_CODE2,
         DIM_CODE4,
         DIM_DETAIL_CODE4,
         decode(DIM_DETAIL_CODE5,NULL,NULL,'Cru_oil_E_cons_typ' ) AS DIM_CODE5,
         DIM_DETAIL_CODE5,
         DIM_CODE6,
         DIM_DETAIL_CODE6,
         DIM_CODE7,
         DIM_DETAIL_CODE7
    FROM (SELECT P_RPTCODE REPORT_CODE,
                 T1.REPORT_YEAR,
                 T1.REPORT_MONTH,
                 T1.ORG_ID,
                 T3.INDEX_CODE,
                 T3.INDEX_VALUE,
                 T4.DIM_CODE AS DIM_CODE1,
                 T4.DIM_DETAIL_CODE AS DIM_DETAIL_CODE1,
                 DECODE(T3.INDEX_CODE,'Replace_oil_engy_amt','Industry_type',T5.DIM_CODE) AS DIM_CODE2,
                 DECODE(T3.INDEX_CODE,'Replace_oil_engy_amt',
                 DECODE(T5.DIM_DETAIL_CODE,
                 'Industry_C','Industry',
                 'Industry_G','Industry',
                 'Industry_O','Industry',
                 'Non_industrial_C','Non_industrial',
                 'Non_industrial_G','Non_industrial',
                 'Non_industrial_O','Non_industrial'),
                 T5.DIM_DETAIL_CODE) AS DIM_DETAIL_CODE2,
                 T7.DIM_CODE AS DIM_CODE4,
                 T7.DIM_DETAIL_CODE AS DIM_DETAIL_CODE4,
                 DECODE(T7.DIM_DETAIL_CODE,'Cru_oil',NULL,'Natural_gas','Since_the_amo_N',T8.DIM_CODE) AS DIM_CODE5,
                 decode(T7.DIM_DETAIL_CODE,'Cru_oil',NULL,'Natural_gas','Since_the_amo_N',T8.DIM_DETAIL_CODE ) AS DIM_DETAIL_CODE5,
                 T9.DIM_CODE AS DIM_CODE6,
                 T9.DIM_DETAIL_CODE AS DIM_DETAIL_CODE6,
                 decode(T10.DIM_CODE,'Crude_oil_alter_typ1','Crude_oil_alter_typ',T10.DIM_CODE) AS DIM_CODE7,
                 T10.DIM_DETAIL_CODE AS DIM_DETAIL_CODE7
            FROM E7_STA_REPINST T1
            LEFT JOIN E7_STA_RPT_INDEX_INST T2
              ON T1.REPINST_ID = T2.REPINST_ID
            LEFT JOIN E7_STA_INDEX_INST T3
              ON T2.STA_INDEX_INST_ID = T3.STA_INDEX_INST_ID
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T4
              ON T2.STA_INDEX_INST_ID = T4.STA_INDEX_INST_ID
             AND T4.DIM_CODE LIKE '%_link'
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T5
              ON T2.STA_INDEX_INST_ID = T5.STA_INDEX_INST_ID
             AND T5.DIM_CODE IN( 'Industry_type' ,'Crude_oil_alter_typ1')
             AND T5.DIM_DETAIL_CODE IN('Industry_C','Industry_G','Industry_O','Non_industrial_C','Non_industrial_G','Non_industrial_O','Industry','Non_industrial')
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T7
              ON T2.STA_INDEX_INST_ID = T7.STA_INDEX_INST_ID
             AND T7.DIM_CODE = 'Cru_oil_E_cons_typ'
             AND T7.DIM_DETAIL_CODE IN
                 (SELECT DIM_DETAIL_CODE
                    FROM E7_STA_DIM_DETAIL D
                   WHERE D.DIM_CODE = 'Cru_oil_E_cons_typ'
                     AND D.PARENT_DIM_DETAIL_CODE IS NULL)
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T8
              ON T2.STA_INDEX_INST_ID = T8.STA_INDEX_INST_ID
             AND T8.DIM_CODE = 'Cru_oil_E_cons_typ'
             AND T8.DIM_DETAIL_CODE <> T7.DIM_DETAIL_CODE
             
             LEFT JOIN E7_STA_INDEX_INST_DIMEN T9
             ON T2.STA_INDEX_INST_ID = T9.STA_INDEX_INST_ID
             AND T9.DIM_CODE = 'Crude_oil_alter_typ'
             -- AND T5.DIM_DETAIL_CODE IN ('Industry_C','Industry_G','Industry_D','Non_industrial_C','Non_industrial_G','Non_industrial_D'))
             LEFT JOIN E7_STA_INDEX_INST_DIMEN T10
             ON T2.STA_INDEX_INST_ID = T10.STA_INDEX_INST_ID
             AND T10.DIM_CODE = 'Crude_oil_alter_typ1' 
             AND T10.DIM_DETAIL_CODE IN ('Other_repl_oil_amo','Gas_repl_oil_amo','Coal_repl_oil_amo')
             
           WHERE T1.REPORT_CODE IN( 'C0105','C0108')
             AND T3.INDEX_CODE NOT IN ('Stadc_coef')
             AND T1.REPORT_YEAR = P_RPTYEAR
             AND T1.REPORT_MONTH = P_RPTMONTH
             AND T1.ORG_ID IN (SELECT ORG_ID
                                 FROM E7_STA_RPT_AUTH
                                WHERE V_ORG_ID = P_RPTORGID
                                  AND REPORT_CODE IN ('C0105')))
   WHERE DIM_DETAIL_CODE5 <>'Lighter_hyd_los' OR DIM_DETAIL_CODE5 IS NULL
   GROUP BY REPORT_CODE,
            REPORT_YEAR,
            REPORT_MONTH,
            INDEX_CODE,
            DIM_CODE1,
            DIM_DETAIL_CODE1,
            DIM_CODE2,
            DIM_DETAIL_CODE2,
            DIM_CODE4,
            DIM_DETAIL_CODE4,
            DIM_CODE5,
            DIM_DETAIL_CODE5,
            DIM_CODE6,
            DIM_DETAIL_CODE6,
            DIM_CODE7,
            DIM_DETAIL_CODE7
            ),         
DATA_AMT AS
 (SELECT 
  REPORT_CODE,
 REPORT_YEAR,
 REPORT_MONTH,
 INDEX_CODE,
 SUM(NVL(INDEX_VALUE,0)) INDEX_VALUE,
 NULL DIM_CODE1,
 NULL DIM_DETAIL_CODE1,
 DIM_CODE2,
 DIM_DETAIL_CODE2,
 DIM_CODE4,
 DIM_DETAIL_CODE4,
 DIM_CODE5,
 DIM_DETAIL_CODE5,
 DIM_CODE6,
 DIM_DETAIL_CODE6,
 DIM_CODE7,
 DIM_DETAIL_CODE7
  FROM DATAS WHERE INDEX_CODE = 'Engy_csmp_amt_pratl'
  GROUP BY 
  REPORT_CODE,
 REPORT_YEAR,
 REPORT_MONTH,
 INDEX_CODE,
 DIM_CODE2,
 DIM_DETAIL_CODE2,
 DIM_CODE4,
 DIM_DETAIL_CODE4,
 DIM_CODE5,
 DIM_DETAIL_CODE5,
 DIM_CODE6,
 DIM_DETAIL_CODE6,
 DIM_CODE7,
 DIM_DETAIL_CODE7),
DATA_COST AS
 (SELECT 
  REPORT_CODE,
 REPORT_YEAR,
 REPORT_MONTH,
 INDEX_CODE,
 SUM(NVL(INDEX_VALUE,0)) INDEX_VALUE,
 NULL DIM_CODE1,
 NULL DIM_DETAIL_CODE1,
 DIM_CODE2,
 DIM_DETAIL_CODE2,
 DIM_CODE4,
 DIM_DETAIL_CODE4,
 DIM_CODE5,
 DIM_DETAIL_CODE5,
 DIM_CODE6,
 DIM_DETAIL_CODE6,
 DIM_CODE7,
 DIM_DETAIL_CODE7
  FROM DATAS WHERE INDEX_CODE = 'Engy_csmp_cost'
  GROUP BY 
  REPORT_CODE,
 REPORT_YEAR,
 REPORT_MONTH,
 INDEX_CODE,
 DIM_CODE2,
 DIM_DETAIL_CODE2,
 DIM_CODE4,
 DIM_DETAIL_CODE4,
 DIM_CODE5,
 DIM_DETAIL_CODE5,
 DIM_CODE6,
 DIM_DETAIL_CODE6,
 DIM_CODE7,
 DIM_DETAIL_CODE7),
DATA_PRICE AS
 (SELECT DATA_AMT.REPORT_CODE,
         DATA_AMT.REPORT_YEAR,
         DATA_AMT.REPORT_MONTH,
         'Engy_csmp_unit_pric' INDEX_CODE,
        DECODE(SUM(DATA_AMT.INDEX_VALUE),0,0,  ROUND(sum(DATA_COST.INDEX_VALUE) * 10000 / sum(DATA_AMT.INDEX_VALUE), 4)) INDEX_VALUE,
         NULL DIM_CODE1,
         NULL DIM_DETAIL_CODE1,
         null DIM_CODE2,
         null DIM_DETAIL_CODE2,
         DATA_AMT.DIM_CODE4,
         DATA_AMT.DIM_DETAIL_CODE4,
         null DIM_CODE5,
         null DIM_DETAIL_CODE5,
         null DIM_CODE6,
         null DIM_DETAIL_CODE6,
         null DIM_CODE7,
         null DIM_DETAIL_CODE7
    FROM DATA_AMT
    LEFT JOIN DATA_COST
      ON DATA_AMT.REPORT_CODE = DATA_COST.REPORT_CODE
     AND DATA_AMT.REPORT_YEAR = DATA_COST.REPORT_YEAR
     AND DATA_AMT.REPORT_MONTH = DATA_COST.REPORT_MONTH
     AND DATA_AMT.DIM_DETAIL_CODE4 = DATA_COST.DIM_DETAIL_CODE4
     group by 
      DATA_AMT.REPORT_CODE,
         DATA_AMT.REPORT_YEAR,
         DATA_AMT.REPORT_MONTH,
         DATA_AMT.DIM_CODE4,
         DATA_AMT.DIM_DETAIL_CODE4),
RESULTS AS
 (SELECT * FROM DATAS),

LOCA_INDEX AS
 (SELECT *
    FROM E7_EXCEL_LOCATIONBYINDEX
   WHERE REPORT_CODE = 'T0016'
     AND IS_PY = 'N'),
LOCA_DIMEN AS
 (SELECT * FROM E7_EXCEL_LOCATIONBYDIMEN 
 WHERE REPORT_CODE = 'T0016' and LOCALTION IN (
       SELECT LOCALTION FROM LOCA_INDEX
 )),
LOC_INDEX AS
 (SELECT RESULTS.*, LOCA_INDEX.LOCALTION LOCATION_INDEX
    FROM RESULTS
    LEFT JOIN LOCA_INDEX
      ON RESULTS.INDEX_CODE = LOCA_INDEX.INDEX_CODE),
LOCA_DIMEN1 AS
 (SELECT *
    FROM (SELECT LOC_INDEX.*, DIMEN1.LOCALTION LOCATION_DIMEN1
            FROM LOC_INDEX
            LEFT JOIN LOCA_DIMEN DIMEN1
              ON LOC_INDEX.DIM_DETAIL_CODE1 = DIMEN1.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN1
      OR LOCATION_DIMEN1 IS NULL),
LOCA_DIMEN2 as
 (SELECT *
    FROM (select LOCA_DIMEN1.*, DIMEN2.LOCALTION LOCATION_DIMEN2
            FROM LOCA_DIMEN1
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN2
              ON LOCA_DIMEN1.DIM_CODE2 = DIMEN2.DIM_CODE
             AND LOCA_DIMEN1.DIM_DETAIL_CODE2 = DIMEN2.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN2
      OR LOCATION_DIMEN2 IS NULL),
LOCA_DIMEN3 as
 (SELECT *
    FROM (select LOCA_DIMEN2.*, DIMEN3.LOCALTION LOCATION_DIMEN3
            FROM LOCA_DIMEN2
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN3
              ON LOCA_DIMEN2.DIM_CODE4 = DIMEN3.DIM_CODE
             AND LOCA_DIMEN2.DIM_DETAIL_CODE4 = DIMEN3.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN3
      OR LOCATION_DIMEN3 IS NULL),
LOCA_DIMEN4 as
 (SELECT *
    FROM (select LOCA_DIMEN3.*, DIMEN4.LOCALTION LOCATION_DIMEN4
            FROM LOCA_DIMEN3
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN4
              ON LOCA_DIMEN3.DIM_CODE5 = DIMEN4.DIM_CODE
             AND LOCA_DIMEN3.DIM_DETAIL_CODE5 = DIMEN4.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN4
      OR LOCATION_DIMEN4 IS NULL), 
LOCA_DIMEN5 as
 (SELECT *
    FROM (select LOCA_DIMEN4.*, DIMEN5.LOCALTION LOCATION_DIMEN5
            FROM LOCA_DIMEN4
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN5
              ON LOCA_DIMEN4.DIM_CODE6 = DIMEN5.DIM_CODE
             AND LOCA_DIMEN4.DIM_DETAIL_CODE6 = DIMEN5.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN5
      OR LOCATION_DIMEN5 IS NULL),
LOCA_DIMEN6 as
 (SELECT *
    FROM (select LOCA_DIMEN5.*, DIMEN6.LOCALTION LOCATION_DIMEN6
            FROM LOCA_DIMEN5
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN6
              ON LOCA_DIMEN5.DIM_CODE7 = DIMEN6.DIM_CODE
             AND LOCA_DIMEN5.DIM_DETAIL_CODE7 = DIMEN6.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN6
      OR LOCATION_DIMEN6 IS NULL),
loca_indexprice as
 (
  
  SELECT DATA_PRICE.*, LOCA_INDEX.LOCALTION LOCATION_INDEX
    FROM DATA_PRICE
    LEFT JOIN LOCA_INDEX
      ON DATA_PRICE.INDEX_CODE = LOCA_INDEX.INDEX_CODE),
loca_dimenprice as
 (
  
  SELECT *
    FROM (select loca_indexprice.*,
    null dimen1,
    null dimen2,
    null dimen3,
    null dimen4,
    null dimen5,
                  DIMEN3.LOCALTION LOCATION_DIMENPRICE
             FROM loca_indexprice
             LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN3
               ON loca_indexprice.DIM_CODE4 = DIMEN3.DIM_CODE
              AND loca_indexprice.DIM_DETAIL_CODE4 = DIMEN3.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMENPRICE
      OR LOCATION_DIMENPRICE IS NULL),
      
ALLRESULTS AS
 (SELECT * FROM LOCA_DIMEN6 
 UNION ALL SELECT * FROM LOCA_DIMENPRICE
 )
SELECT DISTINCT LOCATION_INDEX, sum(INDEX_VALUE) INDEX_VALUE FROM ALLRESULTS WHERE LOCATION_INDEX IS NOT NULL GROUP BY LOCATION_INDEX

);
BEGIN
jsonStr := '[';
FOR V_ENRGY IN return_cursor LOOP
  jsonStr := jsonStr || '{''location'':''' || V_ENRGY.LOCATION_INDEX ||
                 ''',''value'':''' || to_char(V_ENRGY.Index_Value) || '''},';

  END LOOP;
  jsonStr := jsonStr || ']';
  jsonStr := replace(jsonStr,'},]','}]');
  dbms_output.put_line(jsonStr);
  END;
  
  
  
  
  
  
  
  
  procedure getT0020Sum(P_RPTCODE IN VARCHAR2,
            	          P_RPTYEAR  IN VARCHAR2,
                       P_RPTMONTH IN VARCHAR2,
                       P_RPTORGID IN VARCHAR2,jsonStr OUT CLOB) IS
    
    Cursor return_cursor is
      SELECT *
        FROM (WITH DATAS AS
 (SELECT REPORT_CODE,
         REPORT_YEAR,
         REPORT_MONTH,
         INDEX_CODE,
         SUM(INDEX_VALUE) INDEX_VALUE,
         DIM_CODE1,
         DIM_DETAIL_CODE1,
         DIM_CODE2,
         DIM_DETAIL_CODE2,
         DIM_CODE4,
         DIM_DETAIL_CODE4,
         decode(DIM_DETAIL_CODE5,NULL,NULL,'Cru_oil_E_cons_typ' ) AS DIM_CODE5,
         DIM_DETAIL_CODE5,
         DIM_CODE6,
         DIM_DETAIL_CODE6,
         DIM_CODE7,
         DIM_DETAIL_CODE7
    FROM (SELECT P_RPTCODE REPORT_CODE,
                 T1.REPORT_YEAR,
                 T1.REPORT_MONTH,
                 T1.ORG_ID,
                 T3.INDEX_CODE,
                 T3.INDEX_VALUE,
                 T4.DIM_CODE AS DIM_CODE1,
                 T4.DIM_DETAIL_CODE AS DIM_DETAIL_CODE1,
                 DECODE(T3.INDEX_CODE,'Replace_oil_engy_amt','Industry_type',T5.DIM_CODE) AS DIM_CODE2,
                 DECODE(T3.INDEX_CODE,'Replace_oil_engy_amt',
                 DECODE(T5.DIM_DETAIL_CODE,
                 'Industry_C','Industry',
                 'Industry_G','Industry',
                 'Industry_O','Industry',
                 'Non_industrial_C','Non_industrial',
                 'Non_industrial_G','Non_industrial',
                 'Non_industrial_O','Non_industrial'),
                 T5.DIM_DETAIL_CODE) AS DIM_DETAIL_CODE2,
                 T7.DIM_CODE AS DIM_CODE4,
                 T7.DIM_DETAIL_CODE AS DIM_DETAIL_CODE4,
                 DECODE(T7.DIM_DETAIL_CODE,'Cru_oil',NULL,'Natural_gas',NULL,T8.DIM_CODE) AS DIM_CODE5,
                 decode(T7.DIM_DETAIL_CODE,'Cru_oil',NULL,'Natural_gas',NULL,T8.DIM_DETAIL_CODE ) AS DIM_DETAIL_CODE5,
                 T9.DIM_CODE AS DIM_CODE6,
                 T9.DIM_DETAIL_CODE AS DIM_DETAIL_CODE6,
                 decode(T10.DIM_CODE,'Crude_oil_alter_typ1','Crude_oil_alter_typ',T10.DIM_CODE) AS DIM_CODE7,
                 T10.DIM_DETAIL_CODE AS DIM_DETAIL_CODE7
            FROM E7_STA_REPINST T1
            LEFT JOIN E7_STA_RPT_INDEX_INST T2
              ON T1.REPINST_ID = T2.REPINST_ID
            LEFT JOIN E7_STA_INDEX_INST T3
              ON T2.STA_INDEX_INST_ID = T3.STA_INDEX_INST_ID
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T4
              ON T2.STA_INDEX_INST_ID = T4.STA_INDEX_INST_ID
             AND T4.DIM_CODE LIKE '%_link'
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T5
              ON T2.STA_INDEX_INST_ID = T5.STA_INDEX_INST_ID
             AND T5.DIM_CODE IN( 'Industry_type' ,'Crude_oil_alter_typ1')
             AND T5.DIM_DETAIL_CODE IN('Industry_C','Industry_G','Industry_O','Non_industrial_C','Non_industrial_G','Non_industrial_O','Industry','Non_industrial')
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T7
              ON T2.STA_INDEX_INST_ID = T7.STA_INDEX_INST_ID
             AND T7.DIM_CODE = 'Cru_oil_E_cons_typ'
             AND T7.DIM_DETAIL_CODE IN
                 (SELECT DIM_DETAIL_CODE
                    FROM E7_STA_DIM_DETAIL D
                   WHERE D.DIM_CODE = 'Cru_oil_E_cons_typ'
                     AND D.PARENT_DIM_DETAIL_CODE IS NULL)
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T8
              ON T2.STA_INDEX_INST_ID = T8.STA_INDEX_INST_ID
             AND T8.DIM_CODE = 'Cru_oil_E_cons_typ'
             AND T8.DIM_DETAIL_CODE <> T7.DIM_DETAIL_CODE
             
             LEFT JOIN E7_STA_INDEX_INST_DIMEN T9
             ON T2.STA_INDEX_INST_ID = T9.STA_INDEX_INST_ID
             AND T9.DIM_CODE = 'Crude_oil_alter_typ'
             -- AND T5.DIM_DETAIL_CODE IN ('Industry_C','Industry_G','Industry_D','Non_industrial_C','Non_industrial_G','Non_industrial_D'))
             LEFT JOIN E7_STA_INDEX_INST_DIMEN T10
             ON T2.STA_INDEX_INST_ID = T10.STA_INDEX_INST_ID
             AND T10.DIM_CODE = 'Crude_oil_alter_typ1' 
             AND T10.DIM_DETAIL_CODE IN ('Other_repl_oil_amo','Gas_repl_oil_amo','Coal_repl_oil_amo')
             
           WHERE 
           (T1.REPORT_CODE IN('C0100','C0115','C0072','C0077','C0075','C0080','C0103','C0118','C0091')
           OR (T1.REPORT_CODE IN( 'C0002','C0007','C0012','C0035','C0045') AND T5.DIM_DETAIL_CODE <> 'Industry' ))
           
             AND T3.INDEX_CODE NOT IN ('Stadc_coef')
             AND T1.REPORT_YEAR = P_RPTYEAR
             AND T1.REPORT_MONTH = P_RPTMONTH
             AND T1.ORG_ID IN (SELECT ORG_ID
                                 FROM E7_STA_RPT_AUTH
                                WHERE V_ORG_ID = P_RPTORGID
                                  AND REPORT_CODE IN ('C0100','C0115','C0072','C0077','C0075','C0080','C0103','C0118','C0091')))
   WHERE DIM_DETAIL_CODE5 <>'Lighter_hyd_los' OR DIM_DETAIL_CODE5 IS NULL
   GROUP BY REPORT_CODE,
            REPORT_YEAR,
            REPORT_MONTH,
            INDEX_CODE,
            DIM_CODE1,
            DIM_DETAIL_CODE1,
            DIM_CODE2,
            DIM_DETAIL_CODE2,
            DIM_CODE4,
            DIM_DETAIL_CODE4,
            DIM_CODE5,
            DIM_DETAIL_CODE5,
            DIM_CODE6,
            DIM_DETAIL_CODE6,
            DIM_CODE7,
            DIM_DETAIL_CODE7
            ),         
DATA_AMT AS
 (SELECT 
  REPORT_CODE,
 REPORT_YEAR,
 REPORT_MONTH,
 INDEX_CODE,
 SUM(NVL(INDEX_VALUE,0)) INDEX_VALUE,
 NULL DIM_CODE1,
 NULL DIM_DETAIL_CODE1,
 DIM_CODE2,
 DIM_DETAIL_CODE2,
 DIM_CODE4,
 DIM_DETAIL_CODE4,
 DIM_CODE5,
 DIM_DETAIL_CODE5,
 DIM_CODE6,
 DIM_DETAIL_CODE6,
 DIM_CODE7,
 DIM_DETAIL_CODE7
  FROM DATAS WHERE INDEX_CODE = 'Engy_csmp_amt_pratl'
  GROUP BY 
  REPORT_CODE,
 REPORT_YEAR,
 REPORT_MONTH,
 INDEX_CODE,
 DIM_CODE2,
 DIM_DETAIL_CODE2,
 DIM_CODE4,
 DIM_DETAIL_CODE4,
 DIM_CODE5,
 DIM_DETAIL_CODE5,
 DIM_CODE6,
 DIM_DETAIL_CODE6,
 DIM_CODE7,
 DIM_DETAIL_CODE7),
DATA_COST AS
 (SELECT 
  REPORT_CODE,
 REPORT_YEAR,
 REPORT_MONTH,
 INDEX_CODE,
 SUM(NVL(INDEX_VALUE,0)) INDEX_VALUE,
 NULL DIM_CODE1,
 NULL DIM_DETAIL_CODE1,
 DIM_CODE2,
 DIM_DETAIL_CODE2,
 DIM_CODE4,
 DIM_DETAIL_CODE4,
 DIM_CODE5,
 DIM_DETAIL_CODE5,
 DIM_CODE6,
 DIM_DETAIL_CODE6,
 DIM_CODE7,
 DIM_DETAIL_CODE7
  FROM DATAS WHERE INDEX_CODE = 'Engy_csmp_cost'
  GROUP BY 
  REPORT_CODE,
 REPORT_YEAR,
 REPORT_MONTH,
 INDEX_CODE,
 DIM_CODE2,
 DIM_DETAIL_CODE2,
 DIM_CODE4,
 DIM_DETAIL_CODE4,
 DIM_CODE5,
 DIM_DETAIL_CODE5,
 DIM_CODE6,
 DIM_DETAIL_CODE6,
 DIM_CODE7,
 DIM_DETAIL_CODE7),
DATA_PRICE AS
 (SELECT DATA_AMT.REPORT_CODE,
         DATA_AMT.REPORT_YEAR,
         DATA_AMT.REPORT_MONTH,
         'Engy_csmp_unit_pric' INDEX_CODE,
        DECODE(SUM(DATA_AMT.INDEX_VALUE),0,0,  ROUND(sum(DATA_COST.INDEX_VALUE) * 10000 / sum(DATA_AMT.INDEX_VALUE), 4)) INDEX_VALUE,
         NULL DIM_CODE1,
         NULL DIM_DETAIL_CODE1,
         null DIM_CODE2,
         null DIM_DETAIL_CODE2,
         DATA_AMT.DIM_CODE4,
         DATA_AMT.DIM_DETAIL_CODE4,
         null DIM_CODE5,
         null DIM_DETAIL_CODE5,
         null DIM_CODE6,
         null DIM_DETAIL_CODE6,
         null DIM_CODE7,
         null DIM_DETAIL_CODE7
    FROM DATA_AMT
    LEFT JOIN DATA_COST
      ON DATA_AMT.REPORT_CODE = DATA_COST.REPORT_CODE
     AND DATA_AMT.REPORT_YEAR = DATA_COST.REPORT_YEAR
     AND DATA_AMT.REPORT_MONTH = DATA_COST.REPORT_MONTH
     AND DATA_AMT.DIM_DETAIL_CODE4 = DATA_COST.DIM_DETAIL_CODE4
     group by 
      DATA_AMT.REPORT_CODE,
         DATA_AMT.REPORT_YEAR,
         DATA_AMT.REPORT_MONTH,
         DATA_AMT.DIM_CODE4,
         DATA_AMT.DIM_DETAIL_CODE4),
RESULTS AS
 (SELECT * FROM DATAS),

LOCA_INDEX AS
 (SELECT *
    FROM E7_EXCEL_LOCATIONBYINDEX
   WHERE REPORT_CODE = 'T0020'
     AND IS_PY = 'N'),
LOCA_DIMEN AS
 (SELECT * FROM E7_EXCEL_LOCATIONBYDIMEN 
 WHERE REPORT_CODE = 'T0020' and LOCALTION IN (
       SELECT LOCALTION FROM LOCA_INDEX
 )),
LOC_INDEX AS
 (SELECT RESULTS.*, LOCA_INDEX.LOCALTION LOCATION_INDEX
    FROM RESULTS
    LEFT JOIN LOCA_INDEX
      ON RESULTS.INDEX_CODE = LOCA_INDEX.INDEX_CODE),
LOCA_DIMEN1 AS
 (SELECT *
    FROM (SELECT LOC_INDEX.*, DIMEN1.LOCALTION LOCATION_DIMEN1
            FROM LOC_INDEX
            LEFT JOIN LOCA_DIMEN DIMEN1
              ON LOC_INDEX.DIM_DETAIL_CODE1 = DIMEN1.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN1
      OR LOCATION_DIMEN1 IS NULL),
LOCA_DIMEN2 as
 (SELECT *
    FROM (select LOCA_DIMEN1.*, DIMEN2.LOCALTION LOCATION_DIMEN2
            FROM LOCA_DIMEN1
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN2
              ON LOCA_DIMEN1.DIM_CODE2 = DIMEN2.DIM_CODE
             AND LOCA_DIMEN1.DIM_DETAIL_CODE2 = DIMEN2.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN2
      OR LOCATION_DIMEN2 IS NULL),
LOCA_DIMEN3 as
 (SELECT *
    FROM (select LOCA_DIMEN2.*, DIMEN3.LOCALTION LOCATION_DIMEN3
            FROM LOCA_DIMEN2
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN3
              ON LOCA_DIMEN2.DIM_CODE4 = DIMEN3.DIM_CODE
             AND LOCA_DIMEN2.DIM_DETAIL_CODE4 = DIMEN3.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN3
      OR LOCATION_DIMEN3 IS NULL),
LOCA_DIMEN4 as
 (SELECT *
    FROM (select LOCA_DIMEN3.*, DIMEN4.LOCALTION LOCATION_DIMEN4
            FROM LOCA_DIMEN3
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN4
              ON LOCA_DIMEN3.DIM_CODE5 = DIMEN4.DIM_CODE
             AND LOCA_DIMEN3.DIM_DETAIL_CODE5 = DIMEN4.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN4
      OR LOCATION_DIMEN4 IS NULL), 
LOCA_DIMEN5 as
 (SELECT *
    FROM (select LOCA_DIMEN4.*, DIMEN5.LOCALTION LOCATION_DIMEN5
            FROM LOCA_DIMEN4
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN5
              ON LOCA_DIMEN4.DIM_CODE6 = DIMEN5.DIM_CODE
             AND LOCA_DIMEN4.DIM_DETAIL_CODE6 = DIMEN5.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN5
      OR LOCATION_DIMEN5 IS NULL),
LOCA_DIMEN6 as
 (SELECT *
    FROM (select LOCA_DIMEN5.*, DIMEN6.LOCALTION LOCATION_DIMEN6
            FROM LOCA_DIMEN5
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN6
              ON LOCA_DIMEN5.DIM_CODE7 = DIMEN6.DIM_CODE
             AND LOCA_DIMEN5.DIM_DETAIL_CODE7 = DIMEN6.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN6
      OR LOCATION_DIMEN6 IS NULL),
loca_indexprice as
 (
  
  SELECT DATA_PRICE.*, LOCA_INDEX.LOCALTION LOCATION_INDEX
    FROM DATA_PRICE
    LEFT JOIN LOCA_INDEX
      ON DATA_PRICE.INDEX_CODE = LOCA_INDEX.INDEX_CODE),
loca_dimenprice as
 (
  
  SELECT *
    FROM (select loca_indexprice.*,
    null dimen1,
    null dimen2,
    null dimen3,
    null dimen4,
    null dimen5,
                  DIMEN3.LOCALTION LOCATION_DIMENPRICE
             FROM loca_indexprice
             LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN3
               ON loca_indexprice.DIM_CODE4 = DIMEN3.DIM_CODE
              AND loca_indexprice.DIM_DETAIL_CODE4 = DIMEN3.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMENPRICE
      OR LOCATION_DIMENPRICE IS NULL),
      
ALLRESULTS AS
 (SELECT * FROM LOCA_DIMEN6 
 UNION ALL SELECT * FROM LOCA_DIMENPRICE
 )
SELECT DISTINCT LOCATION_INDEX, sum(INDEX_VALUE) INDEX_VALUE FROM ALLRESULTS WHERE LOCATION_INDEX IS NOT NULL GROUP BY LOCATION_INDEX
);
BEGIN
jsonStr := '[';
FOR V_ENRGY IN return_cursor LOOP
  jsonStr := jsonStr || '{''location'':''' || V_ENRGY.LOCATION_INDEX ||
                 ''',''value'':''' || to_char(V_ENRGY.Index_Value) || '''},';

  END LOOP;
  jsonStr := jsonStr || ']';
  jsonStr := replace(jsonStr,'},]','}]');
  dbms_output.put_line(jsonStr);
  END;
  
  procedure getT0021Sum(P_RPTCODE IN VARCHAR2,
            	          P_RPTYEAR  IN VARCHAR2,
                       P_RPTMONTH IN VARCHAR2,
                       P_RPTORGID IN VARCHAR2,jsonStr OUT CLOB) IS
    
    Cursor return_cursor is
      SELECT *
        FROM (WITH DATAS AS
 (SELECT REPORT_CODE,
         REPORT_YEAR,
         REPORT_MONTH,
         INDEX_CODE,
         SUM(INDEX_VALUE) INDEX_VALUE,
         DIM_CODE1,
         DIM_DETAIL_CODE1,
         DIM_CODE2,
         DIM_DETAIL_CODE2,
         DIM_CODE4,
         DIM_DETAIL_CODE4,
         decode(DIM_DETAIL_CODE5,NULL,NULL,'Cru_oil_E_cons_typ' ) AS DIM_CODE5,
         DIM_DETAIL_CODE5,
         DIM_CODE6,
         DIM_DETAIL_CODE6,
         DIM_CODE7,
         DIM_DETAIL_CODE7
    FROM (SELECT P_RPTCODE REPORT_CODE,
                 T1.REPORT_YEAR,
                 T1.REPORT_MONTH,
                 T1.ORG_ID,
                 T3.INDEX_CODE,
                 T3.INDEX_VALUE,
                 T4.DIM_CODE AS DIM_CODE1,
                 T4.DIM_DETAIL_CODE AS DIM_DETAIL_CODE1,
                 DECODE(T3.INDEX_CODE,'Replace_oil_engy_amt','Industry_type',T5.DIM_CODE) AS DIM_CODE2,
                 DECODE(T3.INDEX_CODE,'Replace_oil_engy_amt',
                 DECODE(T5.DIM_DETAIL_CODE,
                 'Industry_C','Industry',
                 'Industry_G','Industry',
                 'Industry_O','Industry',
                 'Non_industrial_C','Non_industrial',
                 'Non_industrial_G','Non_industrial',
                 'Non_industrial_O','Non_industrial'),
                 T5.DIM_DETAIL_CODE) AS DIM_DETAIL_CODE2,
                 T7.DIM_CODE AS DIM_CODE4,
                 T7.DIM_DETAIL_CODE AS DIM_DETAIL_CODE4,
                 DECODE(T7.DIM_DETAIL_CODE,'Cru_oil',NULL,'Natural_gas',NULL,T8.DIM_CODE) AS DIM_CODE5,
                 decode(T7.DIM_DETAIL_CODE,'Cru_oil',NULL,'Natural_gas',NULL,T8.DIM_DETAIL_CODE ) AS DIM_DETAIL_CODE5,
                 T9.DIM_CODE AS DIM_CODE6,
                 T9.DIM_DETAIL_CODE AS DIM_DETAIL_CODE6,
                 decode(T10.DIM_CODE,'Crude_oil_alter_typ1','Crude_oil_alter_typ',T10.DIM_CODE) AS DIM_CODE7,
                 T10.DIM_DETAIL_CODE AS DIM_DETAIL_CODE7
            FROM E7_STA_REPINST T1
            LEFT JOIN E7_STA_RPT_INDEX_INST T2
              ON T1.REPINST_ID = T2.REPINST_ID
            LEFT JOIN E7_STA_INDEX_INST T3
              ON T2.STA_INDEX_INST_ID = T3.STA_INDEX_INST_ID
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T4
              ON T2.STA_INDEX_INST_ID = T4.STA_INDEX_INST_ID
             AND T4.DIM_CODE LIKE '%_link'
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T5
              ON T2.STA_INDEX_INST_ID = T5.STA_INDEX_INST_ID
             AND T5.DIM_CODE IN( 'Industry_type' ,'Crude_oil_alter_typ1')
             AND T5.DIM_DETAIL_CODE IN('Industry_C','Industry_G','Industry_O','Non_industrial_C','Non_industrial_G','Non_industrial_O','Industry','Non_industrial')
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T7
              ON T2.STA_INDEX_INST_ID = T7.STA_INDEX_INST_ID
             AND T7.DIM_CODE = 'Cru_oil_E_cons_typ'
             AND T7.DIM_DETAIL_CODE IN
                 (SELECT DIM_DETAIL_CODE
                    FROM E7_STA_DIM_DETAIL D
                   WHERE D.DIM_CODE = 'Cru_oil_E_cons_typ'
                     AND D.PARENT_DIM_DETAIL_CODE IS NULL)
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T8
              ON T2.STA_INDEX_INST_ID = T8.STA_INDEX_INST_ID
             AND T8.DIM_CODE = 'Cru_oil_E_cons_typ'
             AND T8.DIM_DETAIL_CODE <> T7.DIM_DETAIL_CODE
             
             LEFT JOIN E7_STA_INDEX_INST_DIMEN T9
             ON T2.STA_INDEX_INST_ID = T9.STA_INDEX_INST_ID
             AND T9.DIM_CODE = 'Crude_oil_alter_typ'
             -- AND T5.DIM_DETAIL_CODE IN ('Industry_C','Industry_G','Industry_D','Non_industrial_C','Non_industrial_G','Non_industrial_D'))
             LEFT JOIN E7_STA_INDEX_INST_DIMEN T10
             ON T2.STA_INDEX_INST_ID = T10.STA_INDEX_INST_ID
             AND T10.DIM_CODE = 'Crude_oil_alter_typ1' 
             AND T10.DIM_DETAIL_CODE IN ('Other_repl_oil_amo','Gas_repl_oil_amo','Coal_repl_oil_amo')
             
           WHERE  T1.REPORT_CODE IN('C0095','C0098')
             AND T3.INDEX_CODE NOT IN ('Stadc_coef')
             AND T1.REPORT_YEAR = P_RPTYEAR
             AND T1.REPORT_MONTH = P_RPTMONTH
             AND T1.ORG_ID IN (SELECT ORG_ID
                                 FROM E7_STA_RPT_AUTH
                                WHERE V_ORG_ID = P_RPTORGID
                                  AND REPORT_CODE IN ('C0095','C0098')))
   WHERE DIM_DETAIL_CODE5 <>'Lighter_hyd_los' OR DIM_DETAIL_CODE5 IS NULL
   GROUP BY REPORT_CODE,
            REPORT_YEAR,
            REPORT_MONTH,
            INDEX_CODE,
            DIM_CODE1,
            DIM_DETAIL_CODE1,
            DIM_CODE2,
            DIM_DETAIL_CODE2,
            DIM_CODE4,
            DIM_DETAIL_CODE4,
            DIM_CODE5,
            DIM_DETAIL_CODE5,
            DIM_CODE6,
            DIM_DETAIL_CODE6,
            DIM_CODE7,
            DIM_DETAIL_CODE7
            ),         
DATA_AMT AS
 (SELECT 
  REPORT_CODE,
 REPORT_YEAR,
 REPORT_MONTH,
 INDEX_CODE,
 SUM(NVL(INDEX_VALUE,0)) INDEX_VALUE,
 NULL DIM_CODE1,
 NULL DIM_DETAIL_CODE1,
 DIM_CODE2,
 DIM_DETAIL_CODE2,
 DIM_CODE4,
 DIM_DETAIL_CODE4,
 DIM_CODE5,
 DIM_DETAIL_CODE5,
 DIM_CODE6,
 DIM_DETAIL_CODE6,
 DIM_CODE7,
 DIM_DETAIL_CODE7
  FROM DATAS WHERE INDEX_CODE = 'Engy_csmp_amt_pratl'
  GROUP BY 
  REPORT_CODE,
 REPORT_YEAR,
 REPORT_MONTH,
 INDEX_CODE,
 DIM_CODE2,
 DIM_DETAIL_CODE2,
 DIM_CODE4,
 DIM_DETAIL_CODE4,
 DIM_CODE5,
 DIM_DETAIL_CODE5,
 DIM_CODE6,
 DIM_DETAIL_CODE6,
 DIM_CODE7,
 DIM_DETAIL_CODE7),
DATA_COST AS
 (SELECT 
  REPORT_CODE,
 REPORT_YEAR,
 REPORT_MONTH,
 INDEX_CODE,
 SUM(NVL(INDEX_VALUE,0)) INDEX_VALUE,
 NULL DIM_CODE1,
 NULL DIM_DETAIL_CODE1,
 DIM_CODE2,
 DIM_DETAIL_CODE2,
 DIM_CODE4,
 DIM_DETAIL_CODE4,
 DIM_CODE5,
 DIM_DETAIL_CODE5,
 DIM_CODE6,
 DIM_DETAIL_CODE6,
 DIM_CODE7,
 DIM_DETAIL_CODE7
  FROM DATAS WHERE INDEX_CODE = 'Engy_csmp_cost'
  GROUP BY 
  REPORT_CODE,
 REPORT_YEAR,
 REPORT_MONTH,
 INDEX_CODE,
 DIM_CODE2,
 DIM_DETAIL_CODE2,
 DIM_CODE4,
 DIM_DETAIL_CODE4,
 DIM_CODE5,
 DIM_DETAIL_CODE5,
 DIM_CODE6,
 DIM_DETAIL_CODE6,
 DIM_CODE7,
 DIM_DETAIL_CODE7),
DATA_PRICE AS
 (SELECT DATA_AMT.REPORT_CODE,
         DATA_AMT.REPORT_YEAR,
         DATA_AMT.REPORT_MONTH,
         'Engy_csmp_unit_pric' INDEX_CODE,
        DECODE(SUM(DATA_AMT.INDEX_VALUE),0,0,  ROUND(sum(DATA_COST.INDEX_VALUE) * 10000 / sum(DATA_AMT.INDEX_VALUE), 4)) INDEX_VALUE,
         NULL DIM_CODE1,
         NULL DIM_DETAIL_CODE1,
         null DIM_CODE2,
         null DIM_DETAIL_CODE2,
         DATA_AMT.DIM_CODE4,
         DATA_AMT.DIM_DETAIL_CODE4,
         null DIM_CODE5,
         null DIM_DETAIL_CODE5,
         null DIM_CODE6,
         null DIM_DETAIL_CODE6,
         null DIM_CODE7,
         null DIM_DETAIL_CODE7
    FROM DATA_AMT
    LEFT JOIN DATA_COST
      ON DATA_AMT.REPORT_CODE = DATA_COST.REPORT_CODE
     AND DATA_AMT.REPORT_YEAR = DATA_COST.REPORT_YEAR
     AND DATA_AMT.REPORT_MONTH = DATA_COST.REPORT_MONTH
     AND DATA_AMT.DIM_DETAIL_CODE4 = DATA_COST.DIM_DETAIL_CODE4
     group by 
      DATA_AMT.REPORT_CODE,
         DATA_AMT.REPORT_YEAR,
         DATA_AMT.REPORT_MONTH,
         DATA_AMT.DIM_CODE4,
         DATA_AMT.DIM_DETAIL_CODE4),
RESULTS AS
 (SELECT * FROM DATAS),

LOCA_INDEX AS
 (SELECT *
    FROM E7_EXCEL_LOCATIONBYINDEX
   WHERE REPORT_CODE = 'T0021'
     AND IS_PY = 'N'),
LOCA_DIMEN AS
 (SELECT * FROM E7_EXCEL_LOCATIONBYDIMEN 
 WHERE REPORT_CODE = 'T0021' and LOCALTION IN (
       SELECT LOCALTION FROM LOCA_INDEX
 )),
LOC_INDEX AS
 (SELECT RESULTS.*, LOCA_INDEX.LOCALTION LOCATION_INDEX
    FROM RESULTS
    LEFT JOIN LOCA_INDEX
      ON RESULTS.INDEX_CODE = LOCA_INDEX.INDEX_CODE),
LOCA_DIMEN1 AS
 (SELECT *
    FROM (SELECT LOC_INDEX.*, DIMEN1.LOCALTION LOCATION_DIMEN1
            FROM LOC_INDEX
            LEFT JOIN LOCA_DIMEN DIMEN1
              ON LOC_INDEX.DIM_DETAIL_CODE1 = DIMEN1.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN1
      OR LOCATION_DIMEN1 IS NULL),
LOCA_DIMEN2 as
 (SELECT *
    FROM (select LOCA_DIMEN1.*, DIMEN2.LOCALTION LOCATION_DIMEN2
            FROM LOCA_DIMEN1
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN2
              ON LOCA_DIMEN1.DIM_CODE2 = DIMEN2.DIM_CODE
             AND LOCA_DIMEN1.DIM_DETAIL_CODE2 = DIMEN2.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN2
      OR LOCATION_DIMEN2 IS NULL),
LOCA_DIMEN3 as
 (SELECT *
    FROM (select LOCA_DIMEN2.*, DIMEN3.LOCALTION LOCATION_DIMEN3
            FROM LOCA_DIMEN2
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN3
              ON LOCA_DIMEN2.DIM_CODE4 = DIMEN3.DIM_CODE
             AND LOCA_DIMEN2.DIM_DETAIL_CODE4 = DIMEN3.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN3
      OR LOCATION_DIMEN3 IS NULL),
LOCA_DIMEN4 as
 (SELECT *
    FROM (select LOCA_DIMEN3.*, DIMEN4.LOCALTION LOCATION_DIMEN4
            FROM LOCA_DIMEN3
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN4
              ON LOCA_DIMEN3.DIM_CODE5 = DIMEN4.DIM_CODE
             AND LOCA_DIMEN3.DIM_DETAIL_CODE5 = DIMEN4.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN4
      OR LOCATION_DIMEN4 IS NULL), 
LOCA_DIMEN5 as
 (SELECT *
    FROM (select LOCA_DIMEN4.*, DIMEN5.LOCALTION LOCATION_DIMEN5
            FROM LOCA_DIMEN4
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN5
              ON LOCA_DIMEN4.DIM_CODE6 = DIMEN5.DIM_CODE
             AND LOCA_DIMEN4.DIM_DETAIL_CODE6 = DIMEN5.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN5
      OR LOCATION_DIMEN5 IS NULL),
LOCA_DIMEN6 as
 (SELECT *
    FROM (select LOCA_DIMEN5.*, DIMEN6.LOCALTION LOCATION_DIMEN6
            FROM LOCA_DIMEN5
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN6
              ON LOCA_DIMEN5.DIM_CODE7 = DIMEN6.DIM_CODE
             AND LOCA_DIMEN5.DIM_DETAIL_CODE7 = DIMEN6.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN6
      OR LOCATION_DIMEN6 IS NULL),
loca_indexprice as
 (
  
  SELECT DATA_PRICE.*, LOCA_INDEX.LOCALTION LOCATION_INDEX
    FROM DATA_PRICE
    LEFT JOIN LOCA_INDEX
      ON DATA_PRICE.INDEX_CODE = LOCA_INDEX.INDEX_CODE),
loca_dimenprice as
 (
  
  SELECT *
    FROM (select loca_indexprice.*,
    null dimen1,
    null dimen2,
    null dimen3,
    null dimen4,
    null dimen5,
                  DIMEN3.LOCALTION LOCATION_DIMENPRICE
             FROM loca_indexprice
             LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN3
               ON loca_indexprice.DIM_CODE4 = DIMEN3.DIM_CODE
              AND loca_indexprice.DIM_DETAIL_CODE4 = DIMEN3.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMENPRICE
      OR LOCATION_DIMENPRICE IS NULL),
      
ALLRESULTS AS
 (SELECT * FROM LOCA_DIMEN6 
 UNION ALL SELECT * FROM LOCA_DIMENPRICE
 )
SELECT DISTINCT LOCATION_INDEX, sum(INDEX_VALUE) INDEX_VALUE FROM ALLRESULTS WHERE LOCATION_INDEX IS NOT NULL GROUP BY LOCATION_INDEX
);
BEGIN
jsonStr := '[';
FOR V_ENRGY IN return_cursor LOOP
  jsonStr := jsonStr || '{''location'':''' || V_ENRGY.LOCATION_INDEX ||
                 ''',''value'':''' || to_char(V_ENRGY.Index_Value) || '''},';

  END LOOP;
  jsonStr := jsonStr || ']';
  jsonStr := replace(jsonStr,'},]','}]');
  dbms_output.put_line(jsonStr);
  END;
  
  
  procedure getT0022Sum(P_RPTCODE IN VARCHAR2,
            	          P_RPTYEAR  IN VARCHAR2,
                       P_RPTMONTH IN VARCHAR2,
                       P_RPTORGID IN VARCHAR2,jsonStr OUT CLOB) IS
    
    Cursor return_cursor is
      SELECT *
        FROM (WITH DATAS AS
 (SELECT REPORT_CODE,
         REPORT_YEAR,
         REPORT_MONTH,
         INDEX_CODE,
         SUM(INDEX_VALUE) INDEX_VALUE,
         DIM_CODE1,
         DIM_DETAIL_CODE1,
         DIM_CODE2,
         DIM_DETAIL_CODE2,
         DIM_CODE4,
         DIM_DETAIL_CODE4,
         decode(DIM_DETAIL_CODE5,NULL,NULL,'Cru_oil_E_cons_typ' ) AS DIM_CODE5,
         DIM_DETAIL_CODE5,
         DIM_CODE6,
         DIM_DETAIL_CODE6,
         DIM_CODE7,
         DIM_DETAIL_CODE7
    FROM (SELECT P_RPTCODE REPORT_CODE,
                 T1.REPORT_YEAR,
                 T1.REPORT_MONTH,
                 T1.ORG_ID,
                 T3.INDEX_CODE,
                 T3.INDEX_VALUE,
                 T4.DIM_CODE AS DIM_CODE1,
                 T4.DIM_DETAIL_CODE AS DIM_DETAIL_CODE1,
                 DECODE(T3.INDEX_CODE,'Replace_oil_engy_amt','Industry_type',T5.DIM_CODE) AS DIM_CODE2,
                 DECODE(T3.INDEX_CODE,'Replace_oil_engy_amt','Industry',T5.DIM_DETAIL_CODE) AS DIM_DETAIL_CODE2,
                 T7.DIM_CODE AS DIM_CODE4,
                 T7.DIM_DETAIL_CODE AS DIM_DETAIL_CODE4,
                 DECODE(T7.DIM_DETAIL_CODE,'Cru_oil',NULL,'Natural_gas',NULL,T8.DIM_CODE) AS DIM_CODE5,
                 decode(T7.DIM_DETAIL_CODE,'Cru_oil',NULL,'Natural_gas',NULL,T8.DIM_DETAIL_CODE ) AS DIM_DETAIL_CODE5,
                 T9.DIM_CODE AS DIM_CODE6,
                 T9.DIM_DETAIL_CODE AS DIM_DETAIL_CODE6,
                 decode(T10.DIM_CODE,'Crude_oil_alter_typ1','Crude_oil_alter_typ',T10.DIM_CODE) AS DIM_CODE7,
                 T10.DIM_DETAIL_CODE AS DIM_DETAIL_CODE7
            FROM E7_STA_REPINST T1
            LEFT JOIN E7_STA_RPT_INDEX_INST T2
              ON T1.REPINST_ID = T2.REPINST_ID
            LEFT JOIN E7_STA_INDEX_INST T3
              ON T2.STA_INDEX_INST_ID = T3.STA_INDEX_INST_ID
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T4
              ON T2.STA_INDEX_INST_ID = T4.STA_INDEX_INST_ID
             AND T4.DIM_CODE LIKE '%_link'
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T5
              ON T2.STA_INDEX_INST_ID = T5.STA_INDEX_INST_ID
             AND T5.DIM_CODE IN( 'Industry_type' ,'Crude_oil_alter_typ1')
             AND T5.DIM_DETAIL_CODE IN('Industry_C','Industry_G','Industry_O','Non_industrial_C','Non_industrial_G','Non_industrial_O','Industry','Non_industrial')
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T7
              ON T2.STA_INDEX_INST_ID = T7.STA_INDEX_INST_ID
             AND T7.DIM_CODE = 'Cru_oil_E_cons_typ'
             AND T7.DIM_DETAIL_CODE IN
                 (SELECT DIM_DETAIL_CODE
                    FROM E7_STA_DIM_DETAIL D
                   WHERE D.DIM_CODE = 'Cru_oil_E_cons_typ'
                     AND D.PARENT_DIM_DETAIL_CODE IS NULL)
            LEFT JOIN E7_STA_INDEX_INST_DIMEN T8
              ON T2.STA_INDEX_INST_ID = T8.STA_INDEX_INST_ID
             AND T8.DIM_CODE = 'Cru_oil_E_cons_typ'
             AND T8.DIM_DETAIL_CODE <> T7.DIM_DETAIL_CODE
             
             LEFT JOIN E7_STA_INDEX_INST_DIMEN T9
             ON T2.STA_INDEX_INST_ID = T9.STA_INDEX_INST_ID
             AND T9.DIM_CODE = 'Crude_oil_alter_typ'
             -- AND T5.DIM_DETAIL_CODE IN ('Industry_C','Industry_G','Industry_D','Non_industrial_C','Non_industrial_G','Non_industrial_D'))
             LEFT JOIN E7_STA_INDEX_INST_DIMEN T10
             ON T2.STA_INDEX_INST_ID = T10.STA_INDEX_INST_ID
             AND T10.DIM_CODE = 'Crude_oil_alter_typ1' 
             AND T10.DIM_DETAIL_CODE IN ('Other_repl_oil_amo','Gas_repl_oil_amo','Coal_repl_oil_amo')
             
           WHERE  T1.REPORT_CODE IN('C0027','C0030')
             AND T3.INDEX_CODE NOT IN ('Stadc_coef')
             AND T1.REPORT_YEAR = P_RPTYEAR
             AND T1.REPORT_MONTH = P_RPTMONTH
             AND T1.ORG_ID IN (SELECT ORG_ID
                                 FROM E7_STA_RPT_AUTH
                                WHERE V_ORG_ID = P_RPTORGID
                                  AND REPORT_CODE IN ('C0027','C0030'))
             AND (T8.DIM_DETAIL_CODE <> 'Lighter_hyd_los' OR T8.DIM_DETAIL_CODE IS NULL))
   WHERE DIM_DETAIL_CODE5 <>'Lighter_hyd_los' OR DIM_DETAIL_CODE5 IS NULL
   GROUP BY REPORT_CODE,
            REPORT_YEAR,
            REPORT_MONTH,
            INDEX_CODE,
            DIM_CODE1,
            DIM_DETAIL_CODE1,
            DIM_CODE2,
            DIM_DETAIL_CODE2,
            DIM_CODE4,
            DIM_DETAIL_CODE4,
            DIM_CODE5,
            DIM_DETAIL_CODE5,
            DIM_CODE6,
            DIM_DETAIL_CODE6,
            DIM_CODE7,
            DIM_DETAIL_CODE7
            ),         
DATA_AMT AS
 (SELECT 
  REPORT_CODE,
 REPORT_YEAR,
 REPORT_MONTH,
 INDEX_CODE,
 SUM(NVL(INDEX_VALUE,0)) INDEX_VALUE,
 NULL DIM_CODE1,
 NULL DIM_DETAIL_CODE1,
 DIM_CODE2,
 DIM_DETAIL_CODE2,
 DIM_CODE4,
 DIM_DETAIL_CODE4,
 DIM_CODE5,
 DIM_DETAIL_CODE5,
 DIM_CODE6,
 DIM_DETAIL_CODE6,
 DIM_CODE7,
 DIM_DETAIL_CODE7
  FROM DATAS WHERE INDEX_CODE = 'Engy_csmp_amt_pratl'
  GROUP BY 
  REPORT_CODE,
 REPORT_YEAR,
 REPORT_MONTH,
 INDEX_CODE,
 DIM_CODE2,
 DIM_DETAIL_CODE2,
 DIM_CODE4,
 DIM_DETAIL_CODE4,
 DIM_CODE5,
 DIM_DETAIL_CODE5,
 DIM_CODE6,
 DIM_DETAIL_CODE6,
 DIM_CODE7,
 DIM_DETAIL_CODE7),
DATA_COST AS
 (SELECT 
  REPORT_CODE,
 REPORT_YEAR,
 REPORT_MONTH,
 INDEX_CODE,
 SUM(NVL(INDEX_VALUE,0)) INDEX_VALUE,
 NULL DIM_CODE1,
 NULL DIM_DETAIL_CODE1,
 DIM_CODE2,
 DIM_DETAIL_CODE2,
 DIM_CODE4,
 DIM_DETAIL_CODE4,
 DIM_CODE5,
 DIM_DETAIL_CODE5,
 DIM_CODE6,
 DIM_DETAIL_CODE6,
 DIM_CODE7,
 DIM_DETAIL_CODE7
  FROM DATAS WHERE INDEX_CODE = 'Engy_csmp_cost'
  GROUP BY 
  REPORT_CODE,
 REPORT_YEAR,
 REPORT_MONTH,
 INDEX_CODE,
 DIM_CODE2,
 DIM_DETAIL_CODE2,
 DIM_CODE4,
 DIM_DETAIL_CODE4,
 DIM_CODE5,
 DIM_DETAIL_CODE5,
 DIM_CODE6,
 DIM_DETAIL_CODE6,
 DIM_CODE7,
 DIM_DETAIL_CODE7),
DATA_PRICE AS
 (SELECT DATA_AMT.REPORT_CODE,
         DATA_AMT.REPORT_YEAR,
         DATA_AMT.REPORT_MONTH,
         'Engy_csmp_unit_pric' INDEX_CODE,
        DECODE(SUM(DATA_AMT.INDEX_VALUE),0,0,  ROUND(sum(DATA_COST.INDEX_VALUE) * 10000 / sum(DATA_AMT.INDEX_VALUE), 4)) INDEX_VALUE,
         NULL DIM_CODE1,
         NULL DIM_DETAIL_CODE1,
         null DIM_CODE2,
         null DIM_DETAIL_CODE2,
         DATA_AMT.DIM_CODE4,
         DATA_AMT.DIM_DETAIL_CODE4,
         null DIM_CODE5,
         null DIM_DETAIL_CODE5,
         null DIM_CODE6,
         null DIM_DETAIL_CODE6,
         null DIM_CODE7,
         null DIM_DETAIL_CODE7
    FROM DATA_AMT
    LEFT JOIN DATA_COST
      ON DATA_AMT.REPORT_CODE = DATA_COST.REPORT_CODE
     AND DATA_AMT.REPORT_YEAR = DATA_COST.REPORT_YEAR
     AND DATA_AMT.REPORT_MONTH = DATA_COST.REPORT_MONTH
     AND DATA_AMT.DIM_DETAIL_CODE4 = DATA_COST.DIM_DETAIL_CODE4
     group by 
      DATA_AMT.REPORT_CODE,
         DATA_AMT.REPORT_YEAR,
         DATA_AMT.REPORT_MONTH,
         DATA_AMT.DIM_CODE4,
         DATA_AMT.DIM_DETAIL_CODE4),
RESULTS AS
 (SELECT * FROM DATAS),

LOCA_INDEX AS
 (SELECT *
    FROM E7_EXCEL_LOCATIONBYINDEX
   WHERE REPORT_CODE = 'T0022'
     AND IS_PY = 'N'),
LOCA_DIMEN AS
 (SELECT * FROM E7_EXCEL_LOCATIONBYDIMEN 
 WHERE REPORT_CODE = 'T0022' and LOCALTION IN (
       SELECT LOCALTION FROM LOCA_INDEX
 )),
LOC_INDEX AS
 (SELECT RESULTS.*, LOCA_INDEX.LOCALTION LOCATION_INDEX
    FROM RESULTS
    LEFT JOIN LOCA_INDEX
      ON RESULTS.INDEX_CODE = LOCA_INDEX.INDEX_CODE),
LOCA_DIMEN1 AS
 (SELECT *
    FROM (SELECT LOC_INDEX.*, DIMEN1.LOCALTION LOCATION_DIMEN1
            FROM LOC_INDEX
            LEFT JOIN LOCA_DIMEN DIMEN1
              ON LOC_INDEX.DIM_DETAIL_CODE1 = DIMEN1.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN1
      OR LOCATION_DIMEN1 IS NULL),
LOCA_DIMEN2 as
 (SELECT *
    FROM (select LOCA_DIMEN1.*, DIMEN2.LOCALTION LOCATION_DIMEN2
            FROM LOCA_DIMEN1
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN2
              ON LOCA_DIMEN1.DIM_CODE2 = DIMEN2.DIM_CODE
             AND LOCA_DIMEN1.DIM_DETAIL_CODE2 = DIMEN2.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN2
      OR LOCATION_DIMEN2 IS NULL),
LOCA_DIMEN3 as
 (SELECT *
    FROM (select LOCA_DIMEN2.*, DIMEN3.LOCALTION LOCATION_DIMEN3
            FROM LOCA_DIMEN2
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN3
              ON LOCA_DIMEN2.DIM_CODE4 = DIMEN3.DIM_CODE
             AND LOCA_DIMEN2.DIM_DETAIL_CODE4 = DIMEN3.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN3
      OR LOCATION_DIMEN3 IS NULL),
LOCA_DIMEN4 as
 (SELECT *
    FROM (select LOCA_DIMEN3.*, DIMEN4.LOCALTION LOCATION_DIMEN4
            FROM LOCA_DIMEN3
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN4
              ON LOCA_DIMEN3.DIM_CODE5 = DIMEN4.DIM_CODE
             AND LOCA_DIMEN3.DIM_DETAIL_CODE5 = DIMEN4.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN4
      OR LOCATION_DIMEN4 IS NULL), 
LOCA_DIMEN5 as
 (SELECT *
    FROM (select LOCA_DIMEN4.*, DIMEN5.LOCALTION LOCATION_DIMEN5
            FROM LOCA_DIMEN4
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN5
              ON LOCA_DIMEN4.DIM_CODE6 = DIMEN5.DIM_CODE
             AND LOCA_DIMEN4.DIM_DETAIL_CODE6 = DIMEN5.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN5
      OR LOCATION_DIMEN5 IS NULL),
LOCA_DIMEN6 as
 (SELECT *
    FROM (select LOCA_DIMEN5.*, DIMEN6.LOCALTION LOCATION_DIMEN6
            FROM LOCA_DIMEN5
            LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN6
              ON LOCA_DIMEN5.DIM_CODE7 = DIMEN6.DIM_CODE
             AND LOCA_DIMEN5.DIM_DETAIL_CODE7 = DIMEN6.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMEN6
      OR LOCATION_DIMEN6 IS NULL),
loca_indexprice as
 (
  
  SELECT DATA_PRICE.*, LOCA_INDEX.LOCALTION LOCATION_INDEX
    FROM DATA_PRICE
    LEFT JOIN LOCA_INDEX
      ON DATA_PRICE.INDEX_CODE = LOCA_INDEX.INDEX_CODE),
loca_dimenprice as
 (
  
  SELECT *
    FROM (select loca_indexprice.*,
    null dimen1,
    null dimen2,
    null dimen3,
    null dimen4,
    null dimen5,
                  DIMEN3.LOCALTION LOCATION_DIMENPRICE
             FROM loca_indexprice
             LEFT JOIN (SELECT * FROM LOCA_DIMEN) DIMEN3
               ON loca_indexprice.DIM_CODE4 = DIMEN3.DIM_CODE
              AND loca_indexprice.DIM_DETAIL_CODE4 = DIMEN3.DIM_DETAIL_CODE)
   WHERE LOCATION_INDEX = LOCATION_DIMENPRICE
      OR LOCATION_DIMENPRICE IS NULL),
      
ALLRESULTS AS
 (SELECT * FROM LOCA_DIMEN6 
 UNION ALL SELECT * FROM LOCA_DIMENPRICE
 )
SELECT DISTINCT LOCATION_INDEX, sum(INDEX_VALUE) INDEX_VALUE FROM ALLRESULTS WHERE LOCATION_INDEX IS NOT NULL GROUP BY LOCATION_INDEX
);
BEGIN
jsonStr := '[';
FOR V_ENRGY IN return_cursor LOOP
  jsonStr := jsonStr || '{''location'':''' || V_ENRGY.LOCATION_INDEX ||
                 ''',''value'':''' || to_char(V_ENRGY.Index_Value) || '''},';

  END LOOP;
  jsonStr := jsonStr || ']';
  jsonStr := replace(jsonStr,'},]','}]');
  dbms_output.put_line(jsonStr);
  END;
  
  
  
end getSumValues;
/

