CREATE type REPORTCODELIST  as table of  varchar2(20)
/

