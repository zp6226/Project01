CREATE package getSumValues is
 procedure getSourceReportCode(
   P_RPTCODE IN VARCHAR2,
   P_RPTYEAR  IN VARCHAR2,
   P_RPTMONTH IN VARCHAR2,
   P_RPTORGID IN VARCHAR2,
   jsonValue OUT VARCHAR2);
   

    
   procedure getT0030Sum(
    P_RPTCODE IN VARCHAR2,
    P_RPTYEAR  IN VARCHAR2,
    P_RPTMONTH IN VARCHAR2,
    P_RPTORGID IN VARCHAR2,
    jsonStr OUT CLOB);
   
  procedure getT0031Sum(
    P_RPTCODE IN VARCHAR2,
    P_RPTYEAR  IN VARCHAR2,
    P_RPTMONTH IN VARCHAR2,
    P_RPTORGID IN VARCHAR2,
    jsonStr OUT CLOB);

   
       procedure getT0033Sum(
    P_RPTCODE IN VARCHAR2,
    P_RPTYEAR  IN VARCHAR2,
    P_RPTMONTH IN VARCHAR2,
    P_RPTORGID IN VARCHAR2,
    jsonStr OUT CLOB);
   
    procedure getT0053Sum(
    P_RPTCODE IN VARCHAR2,
    P_RPTYEAR  IN VARCHAR2,
    P_RPTMONTH IN VARCHAR2,
    P_RPTORGID IN VARCHAR2,
    jsonStr OUT CLOB);
    
    procedure getT0054Sum(
    P_RPTCODE IN VARCHAR2,
    P_RPTYEAR  IN VARCHAR2,
    P_RPTMONTH IN VARCHAR2,
    P_RPTORGID IN VARCHAR2,
    jsonStr OUT CLOB);
    
   procedure getT0085Sum(
    P_RPTCODE IN VARCHAR2,
    P_RPTYEAR  IN VARCHAR2,
    P_RPTMONTH IN VARCHAR2,
    P_RPTORGID IN VARCHAR2,
    jsonStr OUT CLOB);
    
    procedure getT0003Sum(
    P_RPTCODE IN VARCHAR2,
    P_RPTYEAR  IN VARCHAR2,
    P_RPTMONTH IN VARCHAR2,
    P_RPTORGID IN VARCHAR2,
    jsonStr OUT CLOB);
    
     procedure getC0119Sum(
    P_RPTCODE IN VARCHAR2,
    P_RPTYEAR  IN VARCHAR2,
    P_RPTMONTH IN VARCHAR2,
    P_RPTORGID IN VARCHAR2,
    jsonStr OUT CLOB);
    
     procedure getT0004Sum(
    P_RPTCODE IN VARCHAR2,
    P_RPTYEAR  IN VARCHAR2,
    P_RPTMONTH IN VARCHAR2,
    P_RPTORGID IN VARCHAR2,
    jsonStr OUT CLOB);
    
     procedure getC0120Sum(
    P_RPTCODE IN VARCHAR2,
    P_RPTYEAR  IN VARCHAR2,
    P_RPTMONTH IN VARCHAR2,
    P_RPTORGID IN VARCHAR2,
    jsonStr OUT CLOB);
    
     procedure getT0005Sum(
    P_RPTCODE IN VARCHAR2,
    P_RPTYEAR  IN VARCHAR2,
    P_RPTMONTH IN VARCHAR2,
    P_RPTORGID IN VARCHAR2,
    jsonStr OUT CLOB);
    
     procedure getC0121Sum(
    P_RPTCODE IN VARCHAR2,
    P_RPTYEAR  IN VARCHAR2,
    P_RPTMONTH IN VARCHAR2,
    P_RPTORGID IN VARCHAR2,
    jsonStr OUT CLOB);
    
     procedure getT0006Sum(
    P_RPTCODE IN VARCHAR2,
    P_RPTYEAR  IN VARCHAR2,
    P_RPTMONTH IN VARCHAR2,
    P_RPTORGID IN VARCHAR2,
    jsonStr OUT CLOB);
    
     procedure getC0122Sum(
    P_RPTCODE IN VARCHAR2,
    P_RPTYEAR  IN VARCHAR2,
    P_RPTMONTH IN VARCHAR2,
    P_RPTORGID IN VARCHAR2,
    jsonStr OUT CLOB);
    
     procedure getT0007Sum(
    P_RPTCODE IN VARCHAR2,
    P_RPTYEAR  IN VARCHAR2,
    P_RPTMONTH IN VARCHAR2,
    P_RPTORGID IN VARCHAR2,
    jsonStr OUT CLOB);
  procedure getT0008Sum(
    P_RPTCODE IN VARCHAR2,
    P_RPTYEAR  IN VARCHAR2,
    P_RPTMONTH IN VARCHAR2,
    P_RPTORGID IN VARCHAR2,
    jsonStr OUT CLOB);
    
     procedure getT0009Sum(
    P_RPTCODE IN VARCHAR2,
    P_RPTYEAR  IN VARCHAR2,
    P_RPTMONTH IN VARCHAR2,
    P_RPTORGID IN VARCHAR2,
    jsonStr OUT CLOB);
    
    
     procedure getT0010Sum(
    P_RPTCODE IN VARCHAR2,
    P_RPTYEAR  IN VARCHAR2,
    P_RPTMONTH IN VARCHAR2,
    P_RPTORGID IN VARCHAR2,
    jsonStr OUT CLOB);
    
    procedure getT0011Sum(
    P_RPTCODE IN VARCHAR2,
    P_RPTYEAR  IN VARCHAR2,
    P_RPTMONTH IN VARCHAR2,
    P_RPTORGID IN VARCHAR2,
    jsonStr OUT CLOB);
    
    procedure getT0012Sum(
    P_RPTCODE IN VARCHAR2,
    P_RPTYEAR  IN VARCHAR2,
    P_RPTMONTH IN VARCHAR2,
    P_RPTORGID IN VARCHAR2,
    jsonStr OUT CLOB);
    
    procedure getT0013Sum(
    P_RPTCODE IN VARCHAR2,
    P_RPTYEAR  IN VARCHAR2,
    P_RPTMONTH IN VARCHAR2,
    P_RPTORGID IN VARCHAR2,
    jsonStr OUT CLOB);
    
    procedure getT0014Sum(
    P_RPTCODE IN VARCHAR2,
    P_RPTYEAR  IN VARCHAR2,
    P_RPTMONTH IN VARCHAR2,
    P_RPTORGID IN VARCHAR2,
    jsonStr OUT CLOB);
    
    procedure getT0015Sum(
    P_RPTCODE IN VARCHAR2,
    P_RPTYEAR  IN VARCHAR2,
    P_RPTMONTH IN VARCHAR2,
    P_RPTORGID IN VARCHAR2,
    jsonStr OUT CLOB);
    
    procedure getT0016Sum(
    P_RPTCODE IN VARCHAR2,
    P_RPTYEAR  IN VARCHAR2,
    P_RPTMONTH IN VARCHAR2,
    P_RPTORGID IN VARCHAR2,
    jsonStr OUT CLOB);
    
    
    
    
    
    
    
    procedure getT0020Sum(
    P_RPTCODE IN VARCHAR2,
    P_RPTYEAR  IN VARCHAR2,
    P_RPTMONTH IN VARCHAR2,
    P_RPTORGID IN VARCHAR2,
    jsonStr OUT CLOB);
    
    procedure getT0021Sum(
    P_RPTCODE IN VARCHAR2,
    P_RPTYEAR  IN VARCHAR2,
    P_RPTMONTH IN VARCHAR2,
    P_RPTORGID IN VARCHAR2,
    jsonStr OUT CLOB);
    
    procedure getT0022Sum(
    P_RPTCODE IN VARCHAR2,
    P_RPTYEAR  IN VARCHAR2,
    P_RPTMONTH IN VARCHAR2,
    P_RPTORGID IN VARCHAR2,
    jsonStr OUT CLOB);
    
    PROCEDURE getT0001Sum (REPORTCODE IN VARCHAR2,
                    P_RPTYEAR  IN VARCHAR2,
                    P_RPTMONTH IN VARCHAR2,
                    P_RPTORGID IN VARCHAR2,
                    jsonStr OUT CLOB);  
    PROCEDURE getT0002Sum (REPORTCODE IN VARCHAR2,
                        P_RPTYEAR  IN VARCHAR2,
                        P_RPTMONTH IN VARCHAR2,
                        P_RPTORGID IN VARCHAR2,
                        jsonStr OUT CLOB);  
    PROCEDURE getT0035Sum (REPORTCODE IN VARCHAR2,
                        P_RPTYEAR  IN VARCHAR2,
                        P_RPTMONTH IN VARCHAR2,
                        P_RPTORGID IN VARCHAR2,
                        jsonStr OUT CLOB);  
    PROCEDURE getSBZBSum (REPORTCODE IN VARCHAR2,
                        P_RPTYEAR  IN VARCHAR2,
                        P_RPTMONTH IN VARCHAR2,
                        P_RPTORGID IN VARCHAR2,
                        jsonStr OUT CLOB);   
   PROCEDURE getSCSum (REPORTCODE IN VARCHAR2,
                        P_RPTYEAR  IN VARCHAR2,
                        P_RPTMONTH IN VARCHAR2,
                        P_RPTORGID IN VARCHAR2,
                        jsonStr OUT CLOB);   
   PROCEDURE getSBSum (REPORTCODE IN VARCHAR2,
                        P_RPTYEAR  IN VARCHAR2,
                        P_RPTMONTH IN VARCHAR2,
                        P_RPTORGID IN VARCHAR2,
                        jsonStr OUT CLOB);
   PROCEDURE getCJSum (REPORTCODE IN VARCHAR2,
                        P_RPTYEAR  IN VARCHAR2,
                        P_RPTMONTH IN VARCHAR2,
                        P_RPTORGID IN VARCHAR2,
                        jsonStr OUT CLOB);                                           
                                                                                                                                                                                                                                       
end getSumValues;
/

