CREATE package getSumValues2 is
 PROCEDURE getT0001 (REPORTCODE IN VARCHAR2,
                    P_RPTYEAR  IN VARCHAR2,
                    P_RPTMONTH IN VARCHAR2,
                    P_RPTORGID IN VARCHAR2,
                    jsonStr OUT VARCHAR2);  
PROCEDURE getT0002 (REPORTCODE IN VARCHAR2,
                    P_RPTYEAR  IN VARCHAR2,
                    P_RPTMONTH IN VARCHAR2,
                    P_RPTORGID IN VARCHAR2,
                    jsonStr OUT VARCHAR2);  
PROCEDURE getT0035 (REPORTCODE IN VARCHAR2,
                    P_RPTYEAR  IN VARCHAR2,
                    P_RPTMONTH IN VARCHAR2,
                    P_RPTORGID IN VARCHAR2,
                    jsonStr OUT VARCHAR2);  
PROCEDURE getSBZB (REPORTCODE IN VARCHAR2,
                    P_RPTYEAR  IN VARCHAR2,
                    P_RPTMONTH IN VARCHAR2,
                    P_RPTORGID IN VARCHAR2,
                    jsonStr OUT VARCHAR2);                                      
end getSumValues2;
/

