CREATE PROCEDURE DATA_Statistics
(
     statistic_year IN VARCHAR2,
     statistic_month IN VARCHAR2,
     tongji out number,
     jienengteam out number,
     jienengjishu out number,
     kaohe out number,
     jiance out number,
     xingmu out number,
     shebei out number,
     duibiao out number,
     nengping out number,
     shenji out number,
     usernum out number,
     org out number
) is
LS_SQL0           VARCHAR2(20000);
LS_SQL1            VARCHAR2(20000);
LS_SQL2           VARCHAR2(20000);
LS_SQL3            VARCHAR2(20000);
LS_SQL4           VARCHAR2(20000);
LS_SQL5            VARCHAR2(20000);
LS_SQL6           VARCHAR2(20000);
LS_SQL7            VARCHAR2(20000);
LS_SQL8           VARCHAR2(20000);
LS_SQL9            VARCHAR2(20000);
LS_SQL10           VARCHAR2(20000);
LS_SQL11           VARCHAR2(20000);
BEGIN
LS_SQL0 :='with a as (
select count(1) "统计" from  e7.e7_sys_org aa, e7.e7_sta_repinst bb
where aa.org_id = bb.org_id
and ( bb.create_time is null or bb.report_year <'||statistic_year||' or ( bb.report_year='||statistic_year||' and bb.report_month <'||statistic_month||'))
union all
select count(1) from e7.e7_sys_org aa, e7.e7_sta_repinst bb
where aa.org_id = bb.org_id
and (bb.create_time is null or  bb.report_year <'||statistic_year||' or ( bb.report_year='||statistic_year||' and bb.report_month <'||statistic_month||'))
)
select SUM (a.统计) from a  ';
EXECUTE IMMEDIATE LS_SQL0 into tongji ;
COMMIT;
LS_SQL1:='--指标库
with a as (
select count(1) "考核" from  e7.e7_sys_org aa, e7.e7_exa_norm bb
where aa.org_id = bb.org_id
and(bb.create_time is null or to_char(bb.create_time,''YYYY'') <'||statistic_year||' or (to_char(bb.create_time,''YYYY'')='||statistic_year||' and  to_char(bb.create_time,''MM'') <'||statistic_month||'))
union all
--考核计划
select  count(1) "考核计划" from e7.e7_sys_org aa, e7.e7_exa_plan_main bb
where aa.org_id = bb.CHECK_ORG_ID
and(bb.create_time is null or to_char(bb.create_time,''YYYY'') <'||statistic_year||' or (to_char(bb.create_time,''YYYY'')='||statistic_year||' and  to_char(bb.create_time,''MM'') <'||statistic_month||'))
union all
--考核过程数据维护
select  count(1) "考核过程数据维护" from  e7.e7_sys_org aa, e7.e7_exta_data bb
where aa.org_id = bb.REPORT_CORP_ID
and(bb.create_time is null or to_char(bb.create_time,''YYYY'') <'||statistic_year||' or (to_char(bb.create_time,''YYYY'')='||statistic_year||' and  to_char(bb.create_time,''MM'') <'||statistic_month||'))
union all
--评分模板
select count(1) "评分模板" from e7.e7_sys_org aa, e7.E7_EXA_SCORE_TEMPLATE bb
where aa.org_id = bb.org_id
and(bb.create_time is null or to_char(bb.create_time,''YYYY'') <'||statistic_year||' or (to_char(bb.create_time,''YYYY'')='||statistic_year||' and  to_char(bb.create_time,''MM'') <'||statistic_month||'))
union all
--节能节水型企业自评
select  count(1) "节能节水型企业自评" from  e7.e7_sys_org aa, e7.E7_EXA_SELF_ASSESSMENT bb
where aa.org_id = bb.org_id
and(bb.create_time is null or to_char(bb.create_time,''YYYY'') <'||statistic_year||' or (to_char(bb.create_time,''YYYY'')='||statistic_year||' and  to_char(bb.create_time,''MM'') <'||statistic_month||'))
union all
--单位自评
select  count(1) "单位自评" from e7.e7_sys_org aa, e7.E7_EXA_SCORE_MAIN bb
where aa.org_id = bb.SCORED_ORG_ID
and(bb.create_time is null or to_char(bb.create_time,''YYYY'') <'||statistic_year||' or (to_char(bb.create_time,''YYYY'')='||statistic_year||' and  to_char(bb.create_time,''MM'') <'||statistic_month||'))
union all
--先进个人
select count(1) "先进个人" from e7.e7_sys_org aa, e7.E7_EXA_ADVANCED_PERSONAL_APPLY bb
where aa.org_id = bb.org_id
and(bb.create_time is null or to_char(bb.create_time,''YYYY'') <'||statistic_year||' or (to_char(bb.create_time,''YYYY'')='||statistic_year||' and  to_char(bb.create_time,''MM'') <'||statistic_month||'))
union all

--先进基层单位
select  count(1) "先进基层单位" from  e7.e7_sys_org aa, e7.E7_EXA_ADVANCED_UNIT_APPLY bb
where aa.org_id = bb.org_id
and(bb.create_time is null or to_char(bb.create_time,''YYYY'') <'||statistic_year||' or (to_char(bb.create_time,''YYYY'')='||statistic_year||' and  to_char(bb.create_time,''MM'') <'||statistic_month||'))
union all
select  count(1) "万家企业" from  e7.e7_sys_org aa, e7.E7_EXA_NORM_SPLIT_DETAIL bb,E7_EXA_NORM_SPLIT_MAIN cc
where aa.org_id = bb.SPLITED_ORG and (bb.save_energy is not null or bb.save_water is not null)
and bb.Norm_Split_Id=cc.norm_split_id
and(cc.create_time is null or to_char(cc.create_time,''YYYY'') <'||statistic_year||' or (to_char(cc.create_time,''YYYY'')='||statistic_year||' and  to_char(cc.create_time,''MM'') <'||statistic_month||'))
)
--查询
select sum(a.考核) from a ';
EXECUTE IMMEDIATE LS_SQL1 into kaohe ;
COMMIT;
LS_SQL2 :='--节能模块
--节能机构
with a as (
select  count(1) "节能队伍" from  e7.e7_sys_org aa, e7.E7_TEAM_AGENCY bb
where aa.org_id = bb.org_id
and(bb.create_time is null or to_char(bb.create_time,''YYYY'') <'||statistic_year||' or (to_char(bb.create_time,''YYYY'')='||statistic_year||' and  to_char(bb.create_time,''MM'') <'||statistic_month||'))
union all
--节能专家
select  count(1) "节能专家" from  e7.e7_sys_org aa, e7.E7_TEAM_EXPERT bb
where aa.org_id = bb.org_id
and(bb.create_time is null or to_char(bb.create_time,''YYYY'') <'||statistic_year||' or (to_char(bb.create_time,''YYYY'')='||statistic_year||' and  to_char(bb.create_time,''MM'') <'||statistic_month||'))
union all
--节能培训资料
select count(1) "节能培训资料" from e7.e7_sys_org aa, e7.E7_TEAM_INFORMATION bb
where aa.org_id = bb.org_id
and(bb.create_time is null or to_char(bb.create_time,''YYYY'') <'||statistic_year||' or (to_char(bb.create_time,''YYYY'')='||statistic_year||' and  to_char(bb.create_time,''MM'') <'||statistic_month||'))
union all
--节能组织（节能部门）
select count(1) "节能组织（节能部门）" from e7.e7_sys_org aa, e7.E7_TEAM_ORG bb
where aa.org_id = bb.org_id
and(bb.create_time is null or to_char(bb.create_time,''YYYY'') <'||statistic_year||' or (to_char(bb.create_time,''YYYY'')='||statistic_year||' and  to_char(bb.create_time,''MM'') <'||statistic_month||'))
union all
--节能人员
select count(1) "节能人员" from e7.e7_sys_org aa, e7.E7_TEAM_PERSON bb
where aa.org_id = bb.org_id
and(bb.create_time is null or to_char(bb.create_time,''YYYY'') <'||statistic_year||' or (to_char(bb.create_time,''YYYY'')='||statistic_year||' and  to_char(bb.create_time,''MM'') <'||statistic_month||'))
)
--查询
select sum(a.节能队伍) from a ';
EXECUTE IMMEDIATE LS_SQL2 into jienengteam ;
COMMIT;
LS_SQL3:='--节能技术

with a as (
--节能准入证
select  count(1) "节能技术" from  e7.e7_sys_org aa, e7.E7_TEC_PROD bb
where aa.org_id = bb.ORG_ID
and(bb.create_time is null or to_char(bb.create_time,''YYYY'') <'||statistic_year||' or (to_char(bb.create_time,''YYYY'')='||statistic_year||' and  to_char(bb.create_time,''MM'') <'||statistic_month||'))
union all
--节能技术库  ，只是集团公司
select  count(1)  from  e7.e7_sys_org aa, e7.e7_tec_share bb
where aa.org_id = bb.org_id
and(bb.create_time is null or to_char(bb.create_time,''YYYY'') <'||statistic_year||' or (to_char(bb.create_time,''YYYY'')='||statistic_year||' and  to_char(bb.create_time,''MM'') <'||statistic_month||'))
union all
--节水技术库  ，只是集团公司
select  count(1)  from  e7.e7_sys_org aa, e7.E7_TEC_W_SHARE bb
where aa.org_id = bb.org_id
and(bb.create_time is null or to_char(bb.create_time,''YYYY'') <'||statistic_year||' or (to_char(bb.create_time,''YYYY'')='||statistic_year||' and  to_char(bb.create_time,''MM'') <'||statistic_month||'))
union all
--节能技术库案例  ，只是集团公司
select  count(1)  from  e7.e7_sys_org aa, e7.E7_TEC_SHARE_CASE bb
where aa.org_id = bb.org_id
and(bb.create_time is null or to_char(bb.create_time,''YYYY'') <'||statistic_year||' or (to_char(bb.create_time,''YYYY'')='||statistic_year||' and  to_char(bb.create_time,''MM'') <'||statistic_month||'))
union all
--国家推广目录，只是集团公司
select  count(1)  from  e7.e7_sys_org aa, e7.E7_TEC_LIST_MAIN bb
where aa.org_id = bb.org_id
and(bb.create_time is null or to_char(bb.create_time,''YYYY'') <'||statistic_year||' or (to_char(bb.create_time,''YYYY'')='||statistic_year||' and  to_char(bb.create_time,''MM'') <'||statistic_month||'))
union all
--集团推广目录，只是集团公司
select  count(1)  from  e7.e7_sys_org aa, e7.E7_TEC_GROUP_LIST_MAIN bb
where aa.org_id = bb.org_id
and(bb.create_time is null or to_char(bb.create_time,''YYYY'') <'||statistic_year||' or (to_char(bb.create_time,''YYYY'')='||statistic_year||' and  to_char(bb.create_time,''MM'') <'||statistic_month||'))
union all
--节能技术淘汰目录(国家),只是集团公司
select  count(1)  from  e7.e7_sys_org aa, e7.E7_TEC_OUT_LIST_MAIN bb
where aa.org_id = bb.org_id
and(bb.create_time is null or to_char(bb.create_time,''YYYY'') <'||statistic_year||' or (to_char(bb.create_time,''YYYY'')='||statistic_year||' and  to_char(bb.create_time,''MM'') <'||statistic_month||'))
union all
--节能技术淘汰目录(国家),只是集团公司
select  count(1)  from  e7.e7_sys_org aa, e7.E7_TEC_GROUP_OUT_LIST_MAIN bb
where aa.org_id = bb.org_id
and(bb.create_time is null or to_char(bb.create_time,''YYYY'') <'||statistic_year||' or (to_char(bb.create_time,''YYYY'')='||statistic_year||' and  to_char(bb.create_time,''MM'') <'||statistic_month||'))
)
select sum(a.节能技术) from a  ';
EXECUTE IMMEDIATE LS_SQL3 into jienengjishu ;
COMMIT;
LS_SQL4:='--监控
with a as (
--监测计划
select count(1) "监测" from e7.e7_sys_org aa, e7.e7_mnt_plan_main bb
where aa.org_id = bb.RECORD_ORG_ID
and(bb.create_time is null or to_char(bb.create_time,''YYYY'') <'||statistic_year||' or (to_char(bb.create_time,''YYYY'')='||statistic_year||' and  to_char(bb.create_time,''MM'') <'||statistic_month||'))
union all
--监测需求
select count(1) "监测需求" from e7.e7_sys_org aa, e7.E7_MNT_PLANREQ_MAIN bb
where aa.org_id = bb.DECLARE_ORG_ID
and(bb.create_time is null or to_char(bb.create_time,''YYYY'') <'||statistic_year||' or (to_char(bb.create_time,''YYYY'')='||statistic_year||' and  to_char(bb.create_time,''MM'') <'||statistic_month||'))
union all
--委托测试
select  count(1) "委托测试" from  e7.e7_sys_org aa, e7.E7_MNT_PLAN_CONSIGN bb
where aa.org_id = bb.TESTING_ORG_ID
and(bb.create_time is null or to_char(bb.create_time,''YYYY'') <'||statistic_year||' or (to_char(bb.create_time,''YYYY'')='||statistic_year||' and  to_char(bb.create_time,''MM'') <'||statistic_month||'))
union all
--监测方案
select  count(1) "监测方案" from e7.e7_sys_org aa, e7.E7_MNT_PROP bb
where aa.org_id = bb.RECODE_ORG_ID
and(bb.create_time is null or to_char(bb.create_time,''YYYY'') <'||statistic_year||' or (to_char(bb.create_time,''YYYY'')='||statistic_year||' and  to_char(bb.create_time,''MM'') <'||statistic_month||'))
union all
--监测数据
select count(1) "监测数据" from  e7.e7_sys_org aa, e7.E7_MNT_DATA_MAIN bb
where aa.org_id = bb.MNTED_ORG_ID
and(bb.create_time is null or to_char(bb.create_time,''YYYY'') <'||statistic_year||' or (to_char(bb.create_time,''YYYY'')='||statistic_year||' and  to_char(bb.create_time,''MM'') <'||statistic_month||'))
union all
--监测报告
select  count(1) "监测报告" from e7.e7_sys_org aa, e7.E7_MNT_REPORT bb
where aa.org_id = bb.MONITOR_ORG_ID
and(bb.create_time is null or to_char(bb.create_time,''YYYY'') <'||statistic_year||' or (to_char(bb.create_time,''YYYY'')='||statistic_year||' and  to_char(bb.create_time,''MM'') <'||statistic_month||'))
union all
--监测整改
select  count(1) "监测整改" from  e7.e7_sys_org aa, e7.E7_MNT_CHG_REPORT bb
where aa.org_id = bb.ORG_ID
and(bb.create_time is null or to_char(bb.create_time,''YYYY'') <'||statistic_year||' or (to_char(bb.create_time,''YYYY'')='||statistic_year||' and  to_char(bb.create_time,''MM'') <'||statistic_month||'))
union all
--国家资质
select  count(1) "国家资质" from e7.e7_sys_org aa, e7.E7_MNT_ORG_QUALIFY bb
where aa.org_id = bb.ORG_ID
and(bb.create_time is null or to_char(bb.create_time,''YYYY'') <'||statistic_year||' or (to_char(bb.create_time,''YYYY'')='||statistic_year||' and  to_char(bb.create_time,''MM'') <'||statistic_month||'))
union all
--国家计量认证
select  count(1) "国家计量认证" from e7.e7_sys_org aa, e7.E7_MNT_ORG_CERT bb
where aa.org_id = bb.ORG_ID
and(bb.create_time is null or to_char(bb.create_time,''YYYY'') <'||statistic_year||' or (to_char(bb.create_time,''YYYY'')='||statistic_year||' and  to_char(bb.create_time,''MM'') <'||statistic_month||'))
union all
--节能人员认证
select  count(1) "节能人员认证" from  e7.e7_sys_org aa, e7.E7_MNT_MNTR_CERT bb
where aa.org_id = bb.ORG_ID
and(bb.create_time is null or to_char(bb.create_time,''YYYY'') <'||statistic_year||' or (to_char(bb.create_time,''YYYY'')='||statistic_year||' and  to_char(bb.create_time,''MM'') <'||statistic_month||'))
union all
--监测仪器
select  count(1) "监测仪器" from  e7.e7_sys_org aa, e7.E7_MNT_DEV_BOOK bb
where aa.org_id = bb.ORG_ID
and(bb.create_time is null or to_char(bb.create_time,''YYYY'') <'||statistic_year||' or (to_char(bb.create_time,''YYYY'')='||statistic_year||' and  to_char(bb.create_time,''MM'') <'||statistic_month||'))
union all
--监测人员
select  count(1) "监测人员" from e7.e7_sys_org aa, e7.E7_MNT_STAFF bb
where aa.org_id = bb.ORG_ID
and(bb.create_time is null or to_char(bb.create_time,''YYYY'') <'||statistic_year||' or (to_char(bb.create_time,''YYYY'')='||statistic_year||' and  to_char(bb.create_time,''MM'') <'||statistic_month||'))
）
--查询
select sum(a.监测) from a  ';
EXECUTE IMMEDIATE LS_SQL4 into jiance ;
COMMIT;
LS_SQL5:='--项目
select  count(1) "项目" from e7.e7_sys_org aa, e7.E7_PRJ_LIB bb
where aa.org_id = bb.ORG_ID
and(bb.create_time is null or to_char(bb.create_time,''YYYY'') <'||statistic_year||' or (to_char(bb.create_time,''YYYY'')='||statistic_year||' and  to_char(bb.create_time,''MM'') <'||statistic_month||'))
' ;
EXECUTE IMMEDIATE LS_SQL5 into xingmu ;
COMMIT;
LS_SQL6:='select count(1) "设备" from  e7.e7_sys_org aa, e7.e7_eqp_equip bb
where aa.org_id = bb.org_id
and(bb.create_time is null or to_char(bb.create_time,''YYYY'') <'||statistic_year||' or (to_char(bb.create_time,''YYYY'')='||statistic_year||' and  to_char(bb.create_time,''MM'') <'||statistic_month||'))
';

EXECUTE IMMEDIATE LS_SQL6 into shebei ;
COMMIT;
LS_SQL7:='select count(1) "对标" from  e7.e7_sys_org aa, e7.e7_aim_target bb
where aa.org_id = bb.org_id
and(bb.create_time is null or to_char(bb.create_time,''YYYY'') <'||statistic_year||' or (to_char(bb.create_time,''YYYY'')='||statistic_year||' and  to_char(bb.create_time,''MM'') <'||statistic_month||'))
';
EXECUTE IMMEDIATE LS_SQL7 into duibiao ;
COMMIT;
LS_SQL8:='select count(1) "能评" from  e7.e7_sys_org aa, e7.E7_ASS_PROC_INFO bb
where aa.org_id = bb.org_id
and(bb.create_time is null or to_char(bb.create_time,''YYYY'') <'||statistic_year||' or (to_char(bb.create_time,''YYYY'')='||statistic_year||' and  to_char(bb.create_time,''MM'') <'||statistic_month||'))
 ';

EXECUTE IMMEDIATE LS_SQL8 into nengping ;
COMMIT;
LS_SQL9:='--审计
with a as (

select count(1) "审计" from e7.e7_sys_org aa, e7.E7_AUD_PLAN bb
where aa.org_id = bb.org_id
and(bb.create_time is null or to_char(bb.create_time,''YYYY'') <'||statistic_year||' or (to_char(bb.create_time,''YYYY'')='||statistic_year||' and  to_char(bb.create_time,''MM'') <'||statistic_month||'))
union all

select count(1) "审计" from  e7.E7_AUD_CONTRACT bb
left join e7.E7_AUD_PLAN cc on bb.aud_plan_id=cc.aud_plan_id
left join e7.e7_sys_org aa on aa.org_id = cc.org_id
where(cc.create_time is null or to_char(cc.create_time,''YYYY'') <'||statistic_year||' or (to_char(cc.create_time,''YYYY'')='||statistic_year||' and  to_char(cc.create_time,''MM'') <'||statistic_month||'))
union all
select count(1) "审计" from  e7.E7_AUD_PLAN bb
left join e7.E7_AUD_PLAN cc on bb.aud_plan_id=cc.aud_plan_id
left join e7.e7_sys_org aa on aa.org_id = cc.org_id
where(cc.create_time is null or to_char(cc.create_time,''YYYY'') <'||statistic_year||' or (to_char(cc.create_time,''YYYY'')='||statistic_year||' and  to_char(cc.create_time,''MM'') <'||statistic_month||'))
union all
select  count(1) "审计" from   e7.E7_AUD_DOC bb
left join e7.e7_sys_org aa on aa.org_id = bb.org_id
where (bb.create_time is null or to_char(bb.create_time,''YYYY'') <'||statistic_year||' or (to_char(bb.create_time,''YYYY'')='||statistic_year||' and  to_char(bb.create_time,''MM'') <'||statistic_month||'))
union all
select  count(1) "审计" from  e7.E7_AUD_CHG bb
left join e7.e7_sys_org aa on aa.org_id = bb.org_id
where (bb.create_time is null or to_char(bb.create_time,''YYYY'') <'||statistic_year||' or (to_char(bb.create_time,''YYYY'')='||statistic_year||' and  to_char(bb.create_time,''MM'') <'||statistic_month||'))
 )

--查询
select sum(a.审计) from a  ';

EXECUTE IMMEDIATE LS_SQL9 into shenji ;
COMMIT;
LS_SQL10:='select count(1) from  e7.e7_sys_user aa left join e7.e7_sys_org bb on aa.org_id=bb.org_id
where(aa.create_time is null or to_char(aa.create_time,''YYYY'') <'||statistic_year||' or (to_char(aa.create_time,''YYYY'')='||statistic_year||' and  to_char(aa.create_time,''MM'') <'||statistic_month||'))
and aa.status_code=''02''
and bb.status_code=''02''
 ';
EXECUTE IMMEDIATE LS_SQL10 into usernum ;
COMMIT;
LS_SQL11:='select count(1) from  e7.e7_sys_org aa
where(aa.create_time is null or to_char(aa.create_time,''YYYY'') <'||statistic_year||' or (to_char(aa.create_time,''YYYY'')='||statistic_year||' and  to_char(aa.create_time,''MM'') <'||statistic_month||'))
and aa.status_code=''02''
 ';
EXECUTE IMMEDIATE LS_SQL11 into org ;
COMMIT;
END ;
/

