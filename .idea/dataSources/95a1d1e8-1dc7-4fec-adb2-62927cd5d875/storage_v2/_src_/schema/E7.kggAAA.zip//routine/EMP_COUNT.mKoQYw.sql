CREATE procedure emp_count
  is
 v_total number(10);               --声明变量,但这里不能写declare来定义
begin
  select count(*) into v_total from emp;
    dbms_output.put_line('雇员人数为:'||v_total);
  end;
--执行存储过程
execute emp_count
/

