CREATE VIEW T_PRDCTN_V AS
  WITH T_DIM_STAGE
        AS (  SELECT a.repinst_id,
                     a.org_id,
                     a.report_code,
                     a.report_year,
                     a.report_quarter,
                     a.report_month,
                     c.sta_index_inst_id,
                     c.index_code,
                     MAX (
                        DECODE (TRIM (E.ORIG_DIM_CODE),
                                'Drilling_typ', TRIM (E.ORIG_DIM_DETAIL_CODE),
                                NULL))
                        AS D_WELL_DRILL_TYPE,                           --钻井种类
                     MAX (
                        DECODE (
                           TRIM (E.ORIG_DIM_CODE),
                           'Drill_E_dissip_type', TRIM (E.ORIG_DIM_DETAIL_CODE),
                           NULL))
                        AS D_DRILL_ENRGY_TYPE,                        --钻机耗能种类
                     MAX (
                        DECODE (d.DIM_CODE,
                                'Long_line_type', d.dim_detail_code,
                                NULL))
                        AS D_LONG_LINE_TYPE,                         -- 长输管道类型
                     MAX (
                        DECODE (d.DIM_CODE,
                                'Orig_energy_type', d.dim_detail_code,
                                NULL))
                        AS D_ORGNL_ENRGY_TYPE,                        --基础能源种类
                     MAX (
                        DECODE (d.DIM_CODE,
                                'Industry_type', d.dim_detail_code,
                                NULL))
                        AS D_INDSTRY_TYPE,                              --产业类型
                     MAX (
                        CASE
                           WHEN a.report_code = 'C0001'           --稀油1-3表 1-5
                                                       THEN '4'
                           WHEN a.report_code = 'C0006'         --稠油1-3表  6-10
                                                       THEN '3'
                           WHEN a.report_code = 'C0011'        --气田1-3表  11-15
                                                       THEN '5'
                           WHEN a.report_code = 'C0016'        --钻探1-3表  16-20
                                                       THEN '6'
                           WHEN a.report_code = 'C0021'   --井下1-3表       21-25
                                                       THEN '7'
                           WHEN a.report_code = 'C0026'     --储运1-3表     26-30
                                                       THEN '8'
                           WHEN a.report_code = 'C0034'       --炼油1-6表   31-40
                                                       THEN '1'
                           WHEN a.report_code = 'C0044'   --化工1-6表       41-50
                                                       THEN '2'
                           WHEN a.report_code = 'C0051'        --工建1-3表  51-55
                                                       THEN '9'
                           WHEN a.report_code = 'C0056'        --装备1-3表  56-60
                                                       THEN '10'
                           WHEN a.report_code = 'C0061'       --长输1-8表   61-70
                                                       THEN '25'
                           WHEN a.report_code = 'C0071'       --LNG1-3表  71-75
                                                       THEN '21'
                           WHEN a.report_code = 'C0076'   --城燃1-3表       76-80
                                                       THEN '22'
                           WHEN a.report_code = 'C0094'       --供发电1-3表  94-98
                                                       THEN '19'
                           WHEN a.report_code = 'C0099'    --供水1-3表   99 - 103
                                                       THEN '23'
                           WHEN a.report_code = 'C0104'      --矿服1-3表  104-113
                                                       THEN '20'
                           WHEN a.report_code = 'C0114'   --其他1-3表     114-118
                                                       THEN '24'
                           ELSE '-1'
                        END)
                        AS D_PRFSNL_TYPE,                               --专业类型
                     MAX (
                        DECODE (d.DIM_CODE,
                                'Product_steam_mod', d.dim_detail_code,
                                NULL))
                        AS D_GAS_YIELD_TYPE,                           --产汽量方式
                     MAX (
                        DECODE (d.DIM_CODE,
                                'Dhole_operation_typ', d.dim_detail_code,
                                NULL))
                        AS D_DOWN_HOLE_OPRTN_TYPE,                    --井下作业类型
                     MAX (
                        DECODE (d.DIM_CODE,
                                'Or_Comph_engy_lost_typ', d.dim_detail_code,
                                NULL))
                        AS D_RFNRY_ENRGY_LOST_TYPE,                 --炼油综合损失类型
                     MAX (
                        DECODE (TRIM (D.DIM_SOURCE),
                                '05', TRIM (D.DIM_DETEAIL_ID),
                                NULL))
                        AS D_LONG_LINE,                                 --管线信息
                     MAX (
                        DECODE (d.DIM_CODE,
                                'LNG_outp_vol_typ', d.dim_detail_code,
                                NULL))
                        AS D_LNG_EXPORT_TYPE,                       --LNG外输量类型
                     MAX (c.index_value) AS index_value
                FROM STG.e7_sta_repinst a
                     JOIN STG.e7_sta_rpt_index_inst b
                        ON a.repinst_id = b.repinst_id
                     JOIN STG.e7_sta_index_inst c
                        ON b.sta_index_inst_id = c.sta_index_inst_id
                     LEFT JOIN STG.e7_sta_index_inst_dimen d
                        ON c.sta_index_inst_id = d.sta_index_inst_id
                     LEFT JOIN STG.e7_sta_dim_detail e
                        ON     d.dim_code = e.dim_code
                           AND d.dim_detail_code = e.dim_detail_code
               WHERE a.report_code IN
                        ('C0001',
                         'C0006',
                         'C0011',
                         'C0016',
                         'C0021',
                         'C0026',
                         'C0034',
                         'C0044',
                         'C0051',
                         'C0056',
                         'C0061',
                         'C0071',
                         'C0076',
                         'C0094',
                         'C0099',
                         'C0104',
                         'C0114')
            GROUP BY a.repinst_id,
                     a.org_id,
                     a.report_code,
                     a.report_year,
                     a.report_quarter,
                     a.report_month,
                     c.sta_index_inst_id,
                     c.index_code),
        T_SEMI_FACT_STAGE
        AS (  SELECT t.repinst_id AS REPINST_ID,
                     t.org_id AS ORG_ID,
                     t.report_code AS REPORT_CODE,
                     t.report_year AS RPT_YEAR,
                     t.report_quarter AS RPT_QTR,
                     t.report_month AS RPT_MTH,
                     NVL (t.D_WELL_DRILL_TYPE, 'N/A') AS D_WELL_DRILL_TYPE,
                     NVL (t.D_DRILL_ENRGY_TYPE, 'N/A') AS D_DRILL_ENRGY_TYPE,
                     NVL (t.D_ORGNL_ENRGY_TYPE, 'N/A') AS D_ORGNL_ENRGY_TYPE,
                     NVL (t.D_LONG_LINE_TYPE, 'N/A') AS D_LONG_LINE_TYPE,
                     NVL (t.D_INDSTRY_TYPE, 'N/A') AS D_INDSTRY_TYPE,
                     NVL (t.D_PRFSNL_TYPE, 'N/A') AS D_PRFSNL_TYPE,
                     NVL (t.D_GAS_YIELD_TYPE, 'N/A') AS D_GAS_YIELD_TYPE,
                     NVL (t.D_DOWN_HOLE_OPRTN_TYPE, 'N/A')
                        AS D_DOWN_HOLE_OPRTN_TYPE,
                     NVL (t.D_RFNRY_ENRGY_LOST_TYPE, 'N/A')
                        AS D_RFNRY_ENRGY_LOST_TYPE,
                     DECODE (t.D_LONG_LINE, NULL, -1, t.D_LONG_LINE)
                        AS D_LONG_LINE,
                     DECODE (t.D_LNG_EXPORT_TYPE,
                             NULL, 'N/A',
                             t.D_LNG_EXPORT_TYPE)
                        AS D_LNG_EXPORT_TYPE,
                     MAX (
                        DECODE (t.index_code, 'Co_prod', t.index_value, NULL))
                        AS CRUDE_OIL_YIELD_QTY,
                     MAX (
                        DECODE (t.index_code, 'Ng_prod', t.index_value, NULL))
                        AS NATUAL_GAS_YIELD_QTY,
                     MAX (
                        DECODE (t.index_code,
                                'Co_bargain_amt', t.index_value,
                                NULL))
                        AS CRUDE_OIL_TRADE_QTY,
                     MAX (
                        DECODE (t.index_code,
                                'Ng_bargain_amt', t.index_value,
                                NULL))
                        AS NATUAL_GAS_TRADE_QTY,
                     MAX (
                        DECODE (t.index_code, 'Watr_prod', t.index_value, NULL))
                        AS WATER_YIELD_QTY,
                     MAX (
                        DECODE (t.index_code, 'Liqd_prod', t.index_value, NULL))
                        AS LIQUID_YIELD_QTY,
                     MAX (
                        DECODE (t.index_code,
                                'Oil_first_procs_ability', t.index_value,
                                NULL))
                        AS CRUDE_OIL_PRCS_QTY_RATE,
                     MAX (
                        DECODE (t.index_code,
                                'Procs_Co_amt', t.index_value,
                                NULL))
                        AS CRUDE_OIL_PRCS_QTY,
                     MAX (
                        DECODE (t.index_code,
                                'Eth_procs_ability', t.index_value,
                                NULL))
                        AS ETHY_PRCS_QTY,
                     MAX (
                        DECODE (t.index_code, 'Eth_prod', t.index_value, NULL))
                        AS ETHY_YIELD_QTY,
                     MAX (
                        DECODE (t.index_code,
                                'Synth_amm_prod', t.index_value,
                                NULL))
                        AS SYNTHTC_AMMONIA_YIELD_QTY,
                     MAX (
                        DECODE (t.index_code,
                                'Pipe_Og_transpt_amt', t.index_value,
                                NULL))
                        AS PIPE_OIL_GAS_TRNSPRTN_QTY,
                     MAX (DECODE (t.index_code, 'Wd_ftg', t.index_value, NULL))
                        AS WELL_DRILL_FEET_QTY,
                     MAX (
                        DECODE (t.index_code, 'Ind_outp', t.index_value, NULL))
                        AS INDSTRY_YIELD_AMT,
                     MAX (
                        DECODE (t.index_code,
                                'Comph_engy_csmp_amt_1', t.index_value,
                                NULL))
                        AS ENRGY_CMPRHNSV_CNSMPTN_QTY,
                     MAX (
                        DECODE (t.index_code,
                                'Entrp_added_value', t.index_value,
                                NULL))
                        AS CMPNY_ADD_AMT,
                     MAX (
                        DECODE (t.index_code,
                                'Oil_well_amt', t.index_value,
                                NULL))
                        AS OIL_WELL_CNT,
                     MAX (
                        DECODE (t.index_code,
                                'liqd_transpt', t.index_value,
                                NULL))
                        AS LIQUID_TRNSPRTN_QTY,
                     MAX (
                        DECODE (t.index_code,
                                'watr_well_amt', t.index_value,
                                NULL))
                        AS WATER_WELL_CNT,
                     MAX (
                        DECODE (t.index_code,
                                'watr_injc_amt', t.index_value,
                                NULL))
                        AS INJCTN_WATER_QTY,
                     MAX (
                        DECODE (t.index_code,
                                'Polymer_injc_amt', t.index_value,
                                NULL))
                        AS PLYMR_INJCTN_QTY,
                     MAX (
                        DECODE (t.index_code,
                                'Ind_wastew_treat_amt', t.index_value,
                                NULL))
                        AS INDSTRY_SWG_TREAT_QTY,
                     MAX (
                        DECODE (t.index_code, 'Gas_prod', t.index_value, NULL))
                        AS GAS_YIELD_QTY,
                     MAX (
                        DECODE (t.index_code,
                                'Gas_well_amt', t.index_value,
                                NULL))
                        AS GAS_WELL_CNT,
                     MAX (
                        DECODE (t.index_code,
                                'Condensate_oil_prod', t.index_value,
                                NULL))
                        AS CNDNST_OIL_YIELD_QTY,
                     MAX (
                        DECODE (t.index_code,
                                'Gas_transpt_amt', t.index_value,
                                NULL))
                        AS GAS_TRNSPRTN_QTY,
                     MAX (
                        DECODE (t.index_code,
                                'Ng_procs_amt', t.index_value,
                                NULL))
                        AS GAS_PRCS_QTY,
                     MAX (
                        DECODE (t.index_code,
                                'Light_hydrocarbon_prod', t.index_value,
                                NULL))
                        AS LIGHT_HYDRCRBN_YIELD_QTY,
                     MAX (
                        DECODE (t.index_code,
                                'undergrd_work_times', t.index_value,
                                NULL))
                        AS DOWN_HOLE_OPRTN_CNT,
                     MAX (
                        DECODE (t.index_code, 'Co_stor', t.index_value, NULL))
                        AS OIL_STORE_CPCTY_QTY,
                     MAX (
                        DECODE (t.index_code,
                                'Co_transpt_amt', t.index_value,
                                NULL))
                        AS OIL_TRNSPRTN_QTY,
                     MAX (
                        DECODE (t.index_code, 'Ng_stor', t.index_value, NULL))
                        AS NTRL_GAS_STORE_CPCTY_QTY,
                     MAX (
                        DECODE (t.index_code,
                                'Ng_transpt_amt', t.index_value,
                                NULL))
                        AS NTRL_GAS_TRNSPRTN_QTY,
                     MAX (
                        DECODE (t.index_code, 'Og_prod', t.index_value, NULL))
                        AS CRUDE_OIL_GAS_PRCS_QTY,
                     MAX (
                        DECODE (t.index_code,
                                'Or_Comph_engy_lost_amt', t.index_value,
                                NULL))
                        AS RFNRY_GNRL_ENRGY_LOST_QTY,
                     MAX (
                        DECODE (t.index_code,
                                'Co_inco_amt', t.index_value,
                                NULL))
                        AS CRUDE_OIL_GAS_PRCHSE_QTY,
                     MAX (
                        DECODE (t.index_code,
                                'Metha_pro_amt', t.index_value,
                                NULL))
                        AS MTHNL_YIELD_QTY,
                     MAX (
                        DECODE (t.index_code,
                                'Acetic_acid_pro_amt', t.index_value,
                                NULL))
                        AS ACETIC_ACID_YIELD_QTY,
                     MAX (
                        DECODE (t.index_code,
                                'Urea_pro_amt', t.index_value,
                                NULL))
                        AS UREA_YIELD_QTY,
                     MAX (
                        DECODE (t.index_code,
                                'LowEth_pro_amt', t.index_value,
                                NULL))
                        AS LOW_PLYTHN_YIELD_QTY,
                     MAX (
                        DECODE (t.index_code,
                                'HighEth_pro_amt', t.index_value,
                                NULL))
                        AS HIGH_PLYTHN_YIELD_QTY,
                     MAX (
                        DECODE (t.index_code,
                                'LinehEth_pro_amt', t.index_value,
                                NULL))
                        AS LINE_PLYTHN_YIELD_QTY,
                     MAX (
                        DECODE (t.index_code,
                                'CohEth_pro_amt', t.index_value,
                                NULL))
                        AS PLYPRPYLN_YIELD_QTY,
                     MAX (
                        DECODE (t.index_code,
                                'Polyp_pro_amt', t.index_value,
                                NULL))
                        AS PLYSTR_YIELD_QTY,
                     MAX (
                        DECODE (t.index_code,
                                'Acr_pro_amt', t.index_value,
                                NULL))
                        AS NTRLN_YIELD_QTY,
                     MAX (
                        DECODE (t.index_code,
                                'Acryl_pro_amt', t.index_value,
                                NULL))
                        AS TRYLN_YIELD_QTY,
                     MAX (
                        DECODE (t.index_code,
                                'Purenitro_pro_amt', t.index_value,
                                NULL))
                        AS NTRGN_YIELD_QTY,
                     MAX (
                        DECODE (t.index_code,
                                'Long_pipe_tnov', t.index_value,
                                NULL))
                        AS PIPE_TURN_OVER_QTY,
                     MAX (
                        DECODE (t.index_code,
                                'LNG_import_vol', t.index_value,
                                NULL))
                        AS LNG_IMPORT_QTY,
                     MAX (
                        DECODE (t.index_code,
                                'LNG_outp_vol', t.index_value,
                                NULL))
                        AS LNG_EXPORT_QTY,
                     MAX (
                        DECODE (t.index_code,
                                'LNG_pot_stor_vol', t.index_value,
                                NULL))
                        AS LNG_TANK_INVNTRY_QTY,
                     MAX (
                        DECODE (t.index_code,
                                'pipe_gas_sls_vol', t.index_value,
                                NULL))
                        AS PIPE_GAS_SALE_QTY,
                     MAX (
                        DECODE (t.index_code,
                                'CNG_sls_vol', t.index_value,
                                NULL))
                        AS CNG_SALE_QTY,
                     MAX (
                        DECODE (t.index_code,
                                'LNG_sls_vol', t.index_value,
                                NULL))
                        AS LNG_SALE_QTY,
                     MAX (
                        DECODE (t.index_code,
                                'LPG_sls_vol', t.index_value,
                                NULL))
                        AS LPG_SALE_QTY,
                     MAX (
                        DECODE (t.index_code,
                                'Coal_gas_sls_vol', t.index_value,
                                NULL))
                        AS COAL_GAS_SALE_QTY,
                     MAX (
                        DECODE (t.index_code,
                                'watr_unit_elec_deno', t.index_value,
                                NULL))
                        AS POWER_YIELD_QTY,
                     MAX (
                        DECODE (t.index_code,
                                'elec_supl_unit_engy_csmp_deno', t.index_value,
                                NULL))
                        AS POWER_SPLY_QTY,
                     MAX (
                        DECODE (t.index_code,
                                'entrp_supl_elec_amt', t.index_value,
                                NULL))
                        AS CMPNY_OUT_POWER_SPLY_QTY,
                     MAX (
                        DECODE (t.index_code,
                                'ht_gener_amt', t.index_value,
                                NULL))
                        AS HEAT_STN_HEAT_YIELD_QTY,
                     MAX (
                        DECODE (t.index_code,
                                'watr_unit_htg_deno', t.index_value,
                                NULL))
                        AS HEAT_STN_HEAT_GNRTN_QTY,
                     MAX (
                        DECODE (t.index_code,
                                'htg_ht_supl_amt', t.index_value,
                                NULL))
                        AS HEAT_SPLY_QTY,
                     MAX (
                        DECODE (t.index_code,
                                'entrp_ht_supl_amt', t.index_value,
                                NULL))
                        AS CMPNY_OUT_HEAT_SPLY_QTY,
                     MAX (
                        DECODE (
                           t.index_code,
                           'htg_ht_supl_unit_engy_csmp_deno', t.index_value,
                           NULL))
                        AS HEAT_SPLY_AREA_QTY,
                     MAX (
                        DECODE (t.index_code,
                                'watr_supl_unit_elec_csmp_deno', t.index_value,
                                NULL))
                        AS WATER_SPLY_QTY
                FROM T_DIM_STAGE t
            GROUP BY t.repinst_id,
                     t.org_id,
                     t.report_code,
                     t.report_year,
                     t.report_quarter,
                     t.report_month,
                     t.D_WELL_DRILL_TYPE,
                     t.D_DRILL_ENRGY_TYPE,
                     t.D_ORGNL_ENRGY_TYPE,
                     t.D_LONG_LINE_TYPE,
                     t.D_INDSTRY_TYPE,
                     t.D_PRFSNL_TYPE,
                     t.D_GAS_YIELD_TYPE,
                     t.D_DOWN_HOLE_OPRTN_TYPE,
                     t.D_RFNRY_ENRGY_LOST_TYPE,
                     t.D_LONG_LINE,
                     t.D_LNG_EXPORT_TYPE
            ORDER BY report_code)
     SELECT ROW_NUMBER () OVER (ORDER BY m.REPORT_CODE) AS T_PRDCTN_KEY,
            NVL (do.ORG_ID, -2) AS ORG_ID,
            TO_NUMBER (m.RPT_YEAR) * 100 + TO_NUMBER (m.RPT_MTH) AS RPT_MNTH_ID,
            m.REPINST_ID AS SRC_RPT_INSTNC_ID,
            m.REPORT_CODE AS SRC_RPT_CD,
            NVL (dim11.INDSTRY_TYPE_CD, -2) AS INDSTRY_TYPE_CD,
            NVL (dim9.orgnl_enrgy_type_cd, -2) AS ORGNL_ENRGY_TYPE_CD,
            NVL (dim10.LONG_LINE_TYPE_CD, -2) AS LONG_LINE_TYPE_CD,
            NVL (dim1.PRFSNL_TYPE_CD, -2) AS PRFSNL_TYPE_CD,
            NVL (dim2.GAS_YIELD_TYPE_CD, -2) AS GAS_YIELD_TYPE_CD,
            NVL (dim3.WELL_DRILL_TYPE_CD, -2) AS WELL_DRILL_TYPE_CD,
            NVL (dim4.DRILL_ENRGY_TYPE_CD, -2) AS DRILL_ENRGY_TYPE_CD,
            NVL (dim5.DOWN_HOLE_OPRTN_TYPE_CD, -2) AS DOWN_HOLE_OPRTN_TYPE_CD,
            NVL (dim6.RFNRY_ENRGY_LOST_TYPE_CD, -2) AS RFNRY_ENRGY_LOST_TYPE_CD,
            DECODE (dim7.LONG_LINE_ID, NULL, -2, dim7.LONG_LINE_ID)
               AS LONG_LINE_ID,
            DECODE (dim8.LNG_EXPORT_TYPE_CD, NULL, -2, dim8.LNG_EXPORT_TYPE_CD)
               AS LNG_EXPORT_TYPE_CD,
            m.CRUDE_OIL_YIELD_QTY,
            m.NATUAL_GAS_YIELD_QTY,
            m.CRUDE_OIL_TRADE_QTY,
            m.NATUAL_GAS_TRADE_QTY,
            m.WATER_YIELD_QTY,
            m.LIQUID_YIELD_QTY,
            m.CRUDE_OIL_PRCS_QTY_RATE,
            m.CRUDE_OIL_PRCS_QTY,
            m.ETHY_PRCS_QTY,
            m.ETHY_YIELD_QTY,
            m.SYNTHTC_AMMONIA_YIELD_QTY,
            m.PIPE_OIL_GAS_TRNSPRTN_QTY,
            m.WELL_DRILL_FEET_QTY,
            m.ENRGY_CMPRHNSV_CNSMPTN_QTY,
            m.INDSTRY_YIELD_AMT,
            m.CMPNY_ADD_AMT,
            m.OIL_WELL_CNT,
            m.LIQUID_TRNSPRTN_QTY,
            m.WATER_WELL_CNT,
            m.INJCTN_WATER_QTY,
            m.PLYMR_INJCTN_QTY,
            m.INDSTRY_SWG_TREAT_QTY,
            m.GAS_YIELD_QTY,
            m.GAS_WELL_CNT,
            m.CNDNST_OIL_YIELD_QTY,
            m.GAS_TRNSPRTN_QTY,
            m.GAS_PRCS_QTY,
            m.LIGHT_HYDRCRBN_YIELD_QTY,
            m.DOWN_HOLE_OPRTN_CNT,
            m.OIL_STORE_CPCTY_QTY,
            m.OIL_TRNSPRTN_QTY,
            m.NTRL_GAS_STORE_CPCTY_QTY,
            m.NTRL_GAS_TRNSPRTN_QTY,
            m.CRUDE_OIL_GAS_PRCS_QTY,
            m.RFNRY_GNRL_ENRGY_LOST_QTY,
            m.CRUDE_OIL_GAS_PRCHSE_QTY,
            m.MTHNL_YIELD_QTY,
            m.ACETIC_ACID_YIELD_QTY,
            m.UREA_YIELD_QTY,
            m.LOW_PLYTHN_YIELD_QTY,
            m.HIGH_PLYTHN_YIELD_QTY,
            m.LINE_PLYTHN_YIELD_QTY,
            m.PLYPRPYLN_YIELD_QTY,
            m.PLYSTR_YIELD_QTY,
            m.NTRLN_YIELD_QTY,
            m.TRYLN_YIELD_QTY,
            m.NTRGN_YIELD_QTY,
            m.PIPE_TURN_OVER_QTY,
            m.LNG_IMPORT_QTY,
            m.LNG_EXPORT_QTY,
            m.LNG_TANK_INVNTRY_QTY,
            m.PIPE_GAS_SALE_QTY,
            m.CNG_SALE_QTY,
            m.LNG_SALE_QTY,
            m.LPG_SALE_QTY,
            m.COAL_GAS_SALE_QTY,
            m.POWER_YIELD_QTY,
            m.POWER_SPLY_QTY,
            m.CMPNY_OUT_POWER_SPLY_QTY,
            m.HEAT_STN_HEAT_YIELD_QTY,
            m.HEAT_STN_HEAT_GNRTN_QTY,
            m.HEAT_SPLY_QTY,
            m.CMPNY_OUT_HEAT_SPLY_QTY,
            m.HEAT_SPLY_AREA_QTY,
            m.WATER_SPLY_QTY,
            '' AS ROW_STS_CD,
            SYSDATE AS INSRT_TM,
            SYSDATE AS UPD_TM
       FROM INT.T_SEMI_FACT_STAGE m
            LEFT JOIN INT.D_PRFSNL_TYPE dim1
               ON m.D_PRFSNL_TYPE = dim1.prfsnl_type_cd
            LEFT JOIN INT.D_GAS_YIELD_TYPE dim2
               ON m.D_GAS_YIELD_TYPE = dim2.gas_yield_type_desc
            LEFT JOIN INT.D_WELL_DRILL_TYPE dim3
               ON m.D_WELL_DRILL_TYPE = dim3.well_drill_type_desc
            LEFT JOIN INT.D_DRILL_ENRGY_TYPE dim4
               ON m.D_DRILL_ENRGY_TYPE = dim4.drill_enrgy_type_desc
            LEFT JOIN INT.D_DOWN_HOLE_OPRTN_TYPE dim5
               ON m.D_DOWN_HOLE_OPRTN_TYPE = dim5.down_hole_oprtn_type_desc
            LEFT JOIN INT.D_RFNRY_ENRGY_LOST_TYPE dim6
               ON m.D_RFNRY_ENRGY_LOST_TYPE = dim6.rfnry_enrgy_lost_type_desc
            LEFT JOIN INT.D_LONG_LINE dim7
               ON m.D_LONG_LINE = dim7.long_line_id
            LEFT JOIN INT.D_LNG_EXPORT_TYPE dim8
               ON m.D_LNG_EXPORT_TYPE = dim8.lng_export_type_desc
            LEFT JOIN INT.D_ORGNL_ENRGY_TYPE dim9
               ON m.D_ORGNL_ENRGY_TYPE = dim9.orgnl_enrgy_type_desc
            LEFT JOIN INT.D_LONG_LINE_TYPE_HZ dim10
               ON m.D_LONG_LINE_TYPE = dim10.long_line_type_desc
            LEFT JOIN INT.D_INDSTRY_TYPE dim11
               ON m.D_INDSTRY_TYPE = dim11.indstry_type_desc
            LEFT JOIN INT.D_ORG do
               ON do.src_org_id = m.org_id
   ORDER BY src_rpt_cd
/

