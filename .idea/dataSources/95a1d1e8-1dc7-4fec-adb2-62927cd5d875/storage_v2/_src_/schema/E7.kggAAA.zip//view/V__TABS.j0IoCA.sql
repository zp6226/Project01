CREATE VIEW V$_TABS AS
  select t.org_id from e7_aim_action a join e7_aim_target t on a.target_id=t.target_id where t.org_id<10
/

