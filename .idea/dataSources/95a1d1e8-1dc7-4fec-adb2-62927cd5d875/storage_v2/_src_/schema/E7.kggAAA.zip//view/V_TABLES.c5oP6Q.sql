CREATE VIEW V$TABLES AS
  select a.action_id,t.org_id from e7_aim_action a left join e7_aim_target t on t.target_id=a.target_id
/

