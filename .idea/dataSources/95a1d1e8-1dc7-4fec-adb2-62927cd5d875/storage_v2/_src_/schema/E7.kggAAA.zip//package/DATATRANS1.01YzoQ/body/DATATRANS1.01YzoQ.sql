CREATE PACKAGE BODY DataTrans1 IS
  PROCEDURE DataTrans1(P_RPTYEAR  IN VARCHAR2,
                       P_RPTMONTH IN VARCHAR2,
                       P_RPTCODE  IN VARCHAR2) AS

    CURSOR C_REPINST IS
      SELECT repinst_id,
             org_id,
             report_code,
             report_year,
             report_quarter,
             report_month,
             report_frequent_code,
             status,
             writer,
             write_date,
             checker,
             check_date,
             condition,
             verify_note,
             create_user_id,
             create_user_name,
             create_time,
             update_user_id,
             update_user_name,
             update_time

        FROM E7.E7_STA_REPINST@TOSCREAL
       WHERE REPORT_YEAR = P_RPTYEAR
         AND REPORT_MONTH = P_RPTMONTH
         AND REPORT_CODE = P_RPTCODE
         AND ORG_ID IN (SELECT ORG_ID FROM E7_SYS_ORG);

    CURSOR C_RPTINDEXINST IS
      SELECT

       repinst_id, sta_index_inst_id, create_time, update_time
        FROM E7.E7_STA_RPT_INDEX_INST@TOSCREAL
       WHERE REPINST_ID IN
             (SELECT REPINST_ID
                FROM E7.E7_STA_REPINST@TOSCREAL
               WHERE REPORT_YEAR = P_RPTYEAR
                 AND REPORT_MONTH = P_RPTMONTH
                 AND REPORT_CODE = P_RPTCODE
                 AND ORG_ID IN (SELECT ORG_ID FROM E7_SYS_ORG));

    CURSOR C_INDEXINST IS
      SELECT sta_index_inst_id,
             index_code,
             org_id,
             report_year,
             report_quarter,
             report_month,
             report_frequent_code,
             index_value,
             unit_code,
             remark,
             index_inst_orderno,
             composited_index_code,
             create_time,
             update_time
        FROM E7.E7_STA_INDEX_INST@TOSCREAL
       WHERE STA_INDEX_INST_ID IN
             (SELECT STA_INDEX_INST_ID
                FROM E7.E7_STA_RPT_INDEX_INST@TOSCREAL
               WHERE REPINST_ID IN
                     (SELECT REPINST_ID
                        FROM E7.E7_STA_REPINST@TOSCREAL
                       WHERE REPORT_YEAR = P_RPTYEAR
                         AND REPORT_MONTH = P_RPTMONTH
                         AND REPORT_CODE = P_RPTCODE
                         AND ORG_ID IN (SELECT ORG_ID FROM E7_SYS_ORG)));

    CURSOR C_INDEXINSTDIMEN IS
      SELECT repinst_dtl_dimen,
             sta_index_inst_id,
             dim_code,
             dim_detail_code,
             dim_source,
             dim_deteail_id,
             dim_deteail_id2,
             unit_code,
             composite_dim_code,
             create_time,
             update_time
        FROM E7.E7_STA_INDEX_INST_DIMEN@TOSCREAL
       WHERE STA_INDEX_INST_ID IN
             (SELECT STA_INDEX_INST_ID
                FROM E7.E7_STA_RPT_INDEX_INST@TOSCREAL
               WHERE REPINST_ID IN
                     (SELECT REPINST_ID
                        FROM E7.E7_STA_REPINST@TOSCREAL
                       WHERE REPORT_YEAR = P_RPTYEAR
                         AND REPORT_MONTH = P_RPTMONTH
                         AND REPORT_CODE = P_RPTCODE
                         AND ORG_ID IN (SELECT ORG_ID FROM E7_SYS_ORG)));

    V_RESULT         NUMBER;
    V_REPINST        E7_STA_REPINST%ROWTYPE;
    V_RPTINDEXINST   E7_STA_RPT_INDEX_INST%ROWTYPE;
    V_INDEXINST      E7_STA_INDEX_INST%ROWTYPE;
    V_INDEXINSTDIMEN E7_STA_INDEX_INST_DIMEN%ROWTYPE;
  BEGIN
    FOR DATA_REPINST IN C_REPINST LOOP
      V_REPINST.repinst_id           := DATA_REPINST.repinst_id;
      V_REPINST.org_id               := DATA_REPINST.org_id;
      V_REPINST.report_code          := DATA_REPINST.report_code;
      V_REPINST.report_year          := DATA_REPINST.report_year;
      V_REPINST.report_quarter       := DATA_REPINST.report_quarter;
      V_REPINST.report_month         := DATA_REPINST.report_month;
      V_REPINST.report_frequent_code := DATA_REPINST.report_frequent_code;
      V_REPINST.status               := DATA_REPINST.status;
      V_REPINST.writer               := DATA_REPINST.writer;
      V_REPINST.write_date           := DATA_REPINST.write_date;
      V_REPINST.checker              := DATA_REPINST.checker;
      V_REPINST.check_date           := DATA_REPINST.check_date;
      V_REPINST.condition            := DATA_REPINST.condition;
      V_REPINST.verify_note          := DATA_REPINST.verify_note;
      V_REPINST.create_user_id       := DATA_REPINST.create_user_id;
      V_REPINST.create_user_name     := DATA_REPINST.create_user_name;
      V_REPINST.create_time          := DATA_REPINST.create_time;
      V_REPINST.update_user_id       := DATA_REPINST.update_user_id;
      V_REPINST.update_user_name     := DATA_REPINST.update_user_name;
      V_REPINST.update_time          := DATA_REPINST.update_time;
      BEGIN
        INSERT INTO E7_STA_REPINST VALUES V_REPINST;
        INSERT INTO DATA_RUNLOG
        VALUES
          ('【E7_STA_REPINST】' || P_RPTCODE || P_RPTYEAR || P_RPTMONTH ||
           V_REPINST.org_id,
           SYSDATE);
      EXCEPTION
        WHEN OTHERS THEN
          dbms_output.put_line(sqlerrm);
          NULL;
      END;
      COMMIT;
      V_RESULT := V_RESULT + 1;
    END LOOP;

    FOR DATA_RPTINDEXINST IN C_RPTINDEXINST LOOP
      V_RPTINDEXINST.repinst_id        := DATA_RPTINDEXINST.repinst_id;
      V_RPTINDEXINST.sta_index_inst_id := DATA_RPTINDEXINST.sta_index_inst_id;
      V_RPTINDEXINST.create_time       := DATA_RPTINDEXINST.create_time;
      V_RPTINDEXINST.update_time       := DATA_RPTINDEXINST.update_time;
      BEGIN
        INSERT INTO E7_STA_RPT_INDEX_INST VALUES V_RPTINDEXINST;

        INSERT INTO DATA_RUNLOG
        VALUES
          ('【E7_STA_RPT_INDEX_INST】' || P_RPTCODE || P_RPTYEAR ||
           P_RPTMONTH || V_RPTINDEXINST.repinst_id,
           SYSDATE);
      EXCEPTION
        WHEN OTHERS THEN
          dbms_output.put_line(sqlerrm);
          NULL;
      END;
      COMMIT;
      V_RESULT := V_RESULT + 1;
    END LOOP;

    FOR DATA_INDEXINST IN C_INDEXINST LOOP
      V_INDEXINST.sta_index_inst_id     := DATA_INDEXINST.sta_index_inst_id;
      V_INDEXINST.index_code            := DATA_INDEXINST.index_code;
      V_INDEXINST.org_id                := DATA_INDEXINST.org_id;
      V_INDEXINST.report_year           := DATA_INDEXINST.report_year;
      V_INDEXINST.report_quarter        := DATA_INDEXINST.report_quarter;
      V_INDEXINST.report_month          := DATA_INDEXINST.report_month;
      V_INDEXINST.report_frequent_code  := DATA_INDEXINST.report_frequent_code;
      V_INDEXINST.index_value           := DATA_INDEXINST.index_value;
      V_INDEXINST.unit_code             := DATA_INDEXINST.unit_code;
      V_INDEXINST.remark                := DATA_INDEXINST.remark;
      V_INDEXINST.index_inst_orderno    := DATA_INDEXINST.index_inst_orderno;
      V_INDEXINST.composited_index_code := DATA_INDEXINST.composited_index_code;
      V_INDEXINST.create_time           := DATA_INDEXINST.create_time;
      V_INDEXINST.update_time           := DATA_INDEXINST.update_time;
      BEGIN
        INSERT INTO E7_STA_INDEX_INST VALUES V_INDEXINST;
        INSERT INTO DATA_RUNLOG
        VALUES
          ('【E7_STA_INDEX_INST】' || P_RPTCODE || P_RPTYEAR || P_RPTMONTH ||
           V_INDEXINST.org_id,
           SYSDATE);
      EXCEPTION
        WHEN OTHERS THEN
          dbms_output.put_line(sqlerrm);
          NULL;
      END;
      COMMIT;
      V_RESULT := V_RESULT + 1;
    END LOOP;

    FOR DATA_INDEXINSTDIMEN IN C_INDEXINSTDIMEN LOOP
      V_INDEXINSTDIMEN.repinst_dtl_dimen  := DATA_INDEXINSTDIMEN.repinst_dtl_dimen;
      V_INDEXINSTDIMEN.sta_index_inst_id  := DATA_INDEXINSTDIMEN.sta_index_inst_id;
      V_INDEXINSTDIMEN.dim_code           := DATA_INDEXINSTDIMEN.dim_code;
      V_INDEXINSTDIMEN.dim_detail_code    := DATA_INDEXINSTDIMEN.dim_detail_code;
      V_INDEXINSTDIMEN.dim_source         := DATA_INDEXINSTDIMEN.dim_source;
      V_INDEXINSTDIMEN.dim_deteail_id     := DATA_INDEXINSTDIMEN.dim_deteail_id;
      V_INDEXINSTDIMEN.dim_deteail_id2    := DATA_INDEXINSTDIMEN.dim_deteail_id2;
      V_INDEXINSTDIMEN.unit_code          := DATA_INDEXINSTDIMEN.unit_code;
      V_INDEXINSTDIMEN.composite_dim_code := DATA_INDEXINSTDIMEN.composite_dim_code;
      V_INDEXINSTDIMEN.create_time        := DATA_INDEXINSTDIMEN.create_time;
      V_INDEXINSTDIMEN.update_time        := DATA_INDEXINSTDIMEN.update_time;
      BEGIN
        INSERT INTO E7_STA_INDEX_INST_DIMEN VALUES V_INDEXINSTDIMEN;

        INSERT INTO DATA_RUNLOG
        VALUES
          ('【E7_STA_INDEX_INST_DIMEN】' || P_RPTCODE || P_RPTYEAR ||
           P_RPTMONTH || V_INDEXINSTDIMEN.repinst_dtl_dimen,
           SYSDATE);

      EXCEPTION
        WHEN OTHERS THEN
          dbms_output.put_line(sqlerrm);
          NULL;
      END;

      COMMIT;
      V_RESULT := V_RESULT + 1;
    END LOOP;
  END;

END DataTrans1;
/

