CREATE PACKAGE TEST2 AS
PROCEDURE getSBZBSum (REPORTCODE IN VARCHAR2,

                    P_RPTYEAR  IN VARCHAR2,
                    P_RPTMONTH IN VARCHAR2,
                    P_RPTORGID IN VARCHAR2,
                    jsonStr OUT CLOB);
                    
 PROCEDURE dataQy (REPORTCODE IN VARCHAR2,

                    P_RPTYEAR  IN VARCHAR2,
                    P_RPTMONTH IN VARCHAR2);
                    
END TEST2;
/

