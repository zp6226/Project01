CREATE TRIGGER RPT_AUTH_TO_INT
  AFTER INSERT OR UPDATE OR DELETE
  ON E7_STA_RPT_AUTH
  FOR EACH ROW
  begin
  if inserting then
    insert into int.E7_STA_RPT_AUTH@Int_Dblk(RPT_AUTH_ID,REPORT_CODE,ORG_ID,V_ORG_ID,AUTH_TYPE,ENTRY_PERSON,VERIFY_PERSON,ORDER_NO,IS_NOTIFIED)
     values (:new_value.RPT_AUTH_ID,
     :new_value.REPORT_CODE,
     :new_value.ORG_ID,
     :new_value.V_ORG_ID,
     :new_value.AUTH_TYPE,
     :new_value.ENTRY_PERSON,
     :new_value.VERIFY_PERSON,
     :new_value.ORDER_NO,
     :new_value.IS_NOTIFIED);
   elsif updating then
     update int.E7_STA_RPT_AUTH@int_dblk
            set
    RPT_AUTH_ID = :new_value.RPT_AUTH_ID,
    REPORT_CODE = :new_value.REPORT_CODE,
    ORG_ID =:new_value.ORG_ID,
    V_ORG_ID =:new_value.V_ORG_ID,
    AUTH_TYPE =:new_value.AUTH_TYPE,
    ENTRY_PERSON =:new_value.ENTRY_PERSON,
    VERIFY_PERSON =:new_value.VERIFY_PERSON,
    ORDER_NO =:new_value.ORDER_NO,
    IS_NOTIFIED = :new_value.IS_NOTIFIED
     where RPT_AUTH_ID = :old_value.RPT_AUTH_ID;
   elsif deleting then
     delete from int.E7_STA_RPT_AUTH@int_dblk
     where RPT_AUTH_ID = :old_value.RPT_AUTH_ID;
   end if;
end;
/

